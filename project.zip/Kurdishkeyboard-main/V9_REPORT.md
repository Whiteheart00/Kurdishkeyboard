# KurdiKeyboard V9 — Smart Typing (preview)
Base: `calculator_prefs_v8/project.zip` and its matching workflow. No new third-party Android dependency was added. Existing signing, Firebase REST, Play Integrity, Redis, offline emoji generation, strict APK/DEX audit, security rules, and Vercel production deployment flow retained. No server/account configuration changes intended.

## Implemented in source
- Opt-in conservative space-triggered correction: 8 Kurdish and 8 English mappings, skips personal/learned words, protected editors and email/URI fields. It verifies the actual suffix and selection before replacement. Immediate correction-specific undo/redo is supported while the editor context matches; general undo/redo still depends on the host editor. No persistent undo text.
- Contextual offline phrase completions: six Kurdish and four English contexts; existing next-word tables retained. Supplemental Sorani word list, mixed enabled-language suggestion dictionaries and script filtering. This is not a language model or comprehensive spelling dictionary; mixed-script suggestions do not automatically switch physical key layout.
- Bounded multi-step cursor/delete gestures and code-point-safe word deletion. One-handed keyboard aligns to the selected side, with side-switch and expand controls retained.
- Clipboard category filters (all, pinned, links, text) and newest-first sorting within pinned/unpinned groups. Existing encrypted text history and editing retained. Full text search and image clipboard not implemented. Android can restrict clipboard reads; no changes to hidden-capture permissions/consent.
- Device-local Incognito setting in More Settings, off by default: suppresses new clipboard capture, learning, suggestions and sensitive writing/voice panels; pauses starting automatic cloud jobs. Existing data isn't deleted. Host app/system behavior and already running jobs are outside this guarantee.
- Kurdish voice: optional Android on-device recognizer (`ckb-IQ`, Android 12+); existing Manga service remains default. Kurdish recognition depends on installed compatible models. No automatic cloud fallback. No model bundled or acoustic accuracy verified.
- Security Dashboard in More Settings: last local App Check token acquisition, Firebase HTTP, clipboard vault, and writing API HTTP observations. No tokens, clipboard contents, user IDs or URLs in dashboard. It does not verify Redis directly, enforcement, or end-to-end security.
- Performance: precompiled regex in new helper, cancel/purge obsolete prediction tasks, bounded gesture steps. No measured RAM/CPU/battery or touch-latency improvement on device.

## Verified locally
- 26 V9 Java helper checks, 20,000 iterations host JVM sample (24 ms on final run; not a mobile benchmark).
- 71 Java source files parsed, zero syntax errors (not Android type checking).
- 81-file native source audit passed; safe Auto Backup allowlist, HTTPS and non-debuggable source checks passed; 3058 Noto emoji assets validated. Facebook catalog generated during CI from authorized font; zero prebuilt Facebook files in this ZIP as in baseline.
- 7 keyboard stability Node tests; 1 rate limiting mock test; 4 calculator/prefs source regression checks.
- Java tests: 16 numeric, 14 privacy, 11 clipboard capture, 5 clipboard crypto, 10 cloud crypto, 10 emoji code cases, plus editor gate, large text and clipboard preview tests passed.
- Activity report JVM test not run: org.json dependency absent. No Android SDK, Gradle build, resolved-dependency OSV scan, DEX audit of new APK, real-device speech, Firebase/Redis calls or Vercel deployment verified here. Workflow gates remain enabled.

## Test on phone before release
Run preview build with previous secrets. Upgrade without uninstalling; test existing encrypted clipboard and Firebase restore using disposable data. Enable the correction and multilingual toggles in Predictions. Test space-triggered correction in ordinary text and no correction in password/email/number fields; undo and redo, cursor selection and swipes. Test both one-handed sides and numeric keyboard. Test clipboard filters and rapid copy, verify no newly saved clip or learned word in Incognito. Test both voice providers (if installed), check dashboard after real actions, check strict DEX/OSV gates. Compare memory/CPU/battery/latency on same device and workload versus V8 before claiming an improvement. Do not change existing secrets or Firebase rules. Use production workflow only after preview tests pass.
