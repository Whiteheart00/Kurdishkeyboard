# Native Firebase REST V6 — Security hardening

Base: Firebase Only V5. Package ID, persistent signing certificate, Firebase REST schema, existing Firestore rules, native UI, emoji generation and encrypted backup format are unchanged. No Google Drive feature has been restored.

## Changes
- Explicitly disable APK debugging while retaining the existing build variant, filename and signing configuration. CI verifies the certificate SHA-256 against the supplied prior APK and rejects debuggable APKs before upload.
- Deny cleartext network traffic and use system trust anchors; reject HTTP and credentials/query/fragment in custom AI endpoint bases. Existing HTTP-only endpoints must be changed to HTTPS. No custom TLS bypass.
- Respect password and no-personalized-learning editor flags and locked credential storage. Do not automatically import clipboard data flagged sensitive; read literal clipboard text without resolving content URIs. Filter likely secrets (OTP, labeled credentials, token-shaped strings, checksum-valid card-like numbers) from new clipboard history and backup selection. The filter is heuristic; ordinary numeric codes can be rejected. Existing local history is not erased. Saved-text and AI panels are restricted in private fields; ordinary system paste is not intentionally removed.
- Stop caching user text and AI responses in the Vercel translation/rewrite handlers; return generic provider errors, limit request body size, and set no-store headers. AI translation/rewrite still sends explicitly requested text to its configured provider. Server-side rate limiting and authentication are not implemented.
- Keep Firebase config and signing files injected by secrets; delete staged files after build. Default GitHub token read-only; separate release publishing job has write access, depends on verified build and downloads its artifact. Old standalone workflow retired inside the ZIP; disable any old copies in the real repository. The external workflow checks the exact ZIP hash. Third-party action tags remain as in V5; pinning reviewed commit SHAs remains recommended.
- Strict native source and APK DEX audit retained. The redundant inline DEX diagnostic was removed because its own forbidden marker was detected by the source audit; the existing diagnostic script and strict DEX check remain.

## Verified locally
- 14 privacy heuristic checks; 10 encrypted backup checks; 7 keyboard JS tests.
- Source audit: 74 files; 3058 Noto images; backup allowlist and network policy. Facebook artwork is generated in CI using the authorized font (not included in this ZIP).
- Previous APK certificate SHA-1/SHA-256 confirmed; Firestore rules identical to V5.
- Workflow YAML and Bash parsing; two changed TypeScript files syntax parsed; credential-looking file/literal scan did not flag matches. These are not comprehensive security tests.

## Remaining verification
No Android SDK/Gradle build or live Firebase/Vercel access in this environment. Test installation over V5, Google login, encrypted upload/restore, background backup, private field behavior and HTTPS AI endpoints using dummy data. The local clipboard/settings state still uses credential-protected private SharedPreferences, not additional application-level encryption. No App Check, remote revocation, independent penetration test, dependency vulnerability audit or verified server-side retention policy implemented. Keep clipboard backup opt-in; do not store secrets in history. The existing Firestore rules must already be published. Restrict API keys and protect the public repository's main branch; never upload private keys. Build-time Firebase identifiers remain extractable from APKs; security rules and authentication, not API key secrecy, protect data.
