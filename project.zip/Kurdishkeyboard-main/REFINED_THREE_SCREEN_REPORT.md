# Native settings parity refinement
Base: three_fix/project.zip. Reference: original project.zip (LanguagesScreen.tsx, KeyboardPrefsScreen.tsx, SettingsUI.tsx, KeyboardView.tsx, EmojiGlyph.tsx). Those original source files are byte-identical to the new project. Android remains native; no embedded browser dependency was added.

## Changes
- Shared 56 dp settings header, arrow vector, title truncation, padding and divider for all three requested screens.
- Languages: original-type icons, flexible equal-height feature cards, active-language blue marker, actual plus/trash/check/chevron controls, translation radio selection, restore scroll position when the page is rebuilt. Disabled remove action for the last language.
- Emoji: active category count, real category eye and arrow icons, disabled opacity, expand/collapse indicator, atomic category reset, column count and separate size readouts, history-cleared inline status, Facebook selection color, and non-touch slider persistence. Preview no longer refreshes for unrelated history/category changes.
- Keyboard settings: original-style metric and switch icons, reduced fixed card sizing, RTL slider direction and compact readouts. The previously unused dynamicBackgroundGlow switch now drives native elevation and accent shadow color on API 28+; it is an approximation of the CSS shadow, can be clipped at the IME boundary, and is not guaranteed visually identical. Popup/flying-letter stacking is preserved above the raised surface.
- Avoid full settings hydration for simple setting changes; settings merge/persistence remains the existing mechanism. No clipboard store or keyboard data changed.

## Verification
- javac parse-only: 54 files, passed (not Android API type checking).
- Source audit: 61 files, passed.
- Vector parser: 483 path strings and geometry/invalid-input cases passed.
- JavaScript stability: 7 tests passed with Node --experimental-strip-types.
- Pure-JVM: 3 programs passed (large text, clipboard text, operation gate).
- No Android SDK/Gradle present. APK compilation, DEX audit, actual visual parity and input/scroll performance on a phone have not been verified. The tests above do not prove that every settings screen or every control is visually or functionally identical. Existing non-Facebook emoji styles still use Android system glyphs and filters; Facebook requires network when uncached.
- Workflow, package ID, Gradle settings, signing, clipboard changes, original web UI and data preserved. No new dependencies.
