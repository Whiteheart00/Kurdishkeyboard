# Native parity: Languages, Emoji, Keyboard preferences

Base: further_fix/project.zip. Reference: original project.zip, specifically LanguagesScreen.tsx, KeyboardPrefsScreen.tsx, SettingsUI.tsx, EmojiGlyph.tsx, richContent.ts and layouts.ts. All six reference files are byte-identical in the new archive. Android remains native; the web source remains separate.

## Languages
- Restored the original full heading, readable font and app-language labels, compact add-language button, divided language cards and native styled toggles.
- Replaced generic alert lists with bottom-aligned native dialogs, original four layout groups, two-column layout choices, selected marks, original three app-language choices and full add-language list (already enabled entries disabled).
- Layout choice now saves the layout ID, subtitle, direction and active language together. Adding a language activates it; removing the active language chooses the first remaining language. Settings patch is atomic at the existing state-store boundary.

## Emoji / zikr / kaomoji settings
- Reuse the existing native glyph renderer for all five style samples, live six-emoji preview, skin and hair cards, and category icons. Facebook uses the original CDN asynchronously with system-glyph fallback; other modes use existing native color/shadow approximations. Style, skin, and hair changes update previews. Size changes resize existing glyphs instead of recreating them.
- Restored full-width Facebook card, four two-column style cards and descriptions, original sample text, two-column history and suggestion limit controls, category rows and matching toggles.
- No new external service was introduced; the existing native Facebook renderer is shared with the settings page. Internet access is necessary to fetch uncached Facebook images. They fall back to system glyphs if not available.

## Keyboard preferences
- Replaced unnecessary IME engine creation for icon loading with existing settings icon loading; restored metric icon shapes, monospace readouts, spacing card, clock icon, and blue gradient PRO pill (as in the original page, not the home-screen gold badge).
- Slider readouts and metric summaries update during drag; settings are saved when released, with non-touch changes still saved immediately. Kept the native bottom-row editor link from the previous version rather than deleting that feature.

## Verification
- 53 Java source files parsed with javac syntax parser (not Android API type checking).
- 60 source/build files pass scripts/audit-native.py. No APK was produced locally, so DEX audit remains pending.
- 472 vector paths and parser geometry/invalid-input cases passed.
- 7 JavaScript stability tests and 3 JVM unit-test programs passed.
- Android SDK/Gradle and npm dependencies are not installed in the local environment. Full Android compile, visual parity, touch/gesture testing, runtime performance and the esbuild-dependent engine tests were not verified. Non-Facebook style rendering uses native approximations and is not guaranteed pixel-identical.
- Build workflow, Gradle files, package ID, signing settings, clipboard optimizations, original web code and data are unchanged.
