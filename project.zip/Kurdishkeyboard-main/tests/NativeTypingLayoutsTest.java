package io.kurdikebord.app;
import java.util.*;
public final class NativeTypingLayoutsTest {
    public static void main(String[] args) {
        for(String language:new String[]{"ckb","en","ar"}) {
            if(!NativeTypingLayouts.supports(language))throw new AssertionError(language);
            Set<String> keys=new HashSet<>();
            for(String[] row:NativeTypingLayouts.rows(language)) for(String key:row) if(key.isEmpty()||!keys.add(key))throw new AssertionError(language+" invalid key");
            if(keys.size()<26)throw new AssertionError(language+" incomplete");
        }
        if(!NativeTypingLayouts.supportsLayout("ckb","kurdi_qvfgh")||NativeTypingLayouts.supportsLayout("ckb","qwerty_kurdi")||NativeTypingLayouts.supports("ko"))throw new AssertionError("Layout routing");
        Set<String> kurdi=new HashSet<>();for(String[] row:NativeTypingLayouts.rows("ckb")) Collections.addAll(kurdi,row);
        for(String key:new String[]{"ھ","ە","ڕ","ڵ","ێ","وو","ۆ","ـ","ژ","چ","ڤ","گ","ک","ی"})if(!kurdi.contains(key))throw new AssertionError("Missing Kurdish key: "+key);
        if(!Arrays.asList(NativeTypingLayouts.alternatives("ا")).contains("أ"))throw new AssertionError("Arabic variants");
        for(int i=0;i<10000;i++){String[][] r=NativeTypingLayouts.rows(i%2==0?"ckb":"en");r[0][0]="changed";if("changed".equals(NativeTypingLayouts.rows(i%2==0?"ckb":"en")[0][0]))throw new AssertionError("Shared mutable rows");}
        System.out.println("PASS: Native layout keys, language routing, variants and 10,000 independent layout loads");
    }
}
