package io.kurdikebord.app;
public final class ImeSmartTextTest {
    static int count;
    static void check(boolean b){if(!b)throw new AssertionError("Check "+(count+1));count++;}
    public static void main(String[] args){
        check(ImeSmartText.correction("سلاو","ckb").equals("سڵاو"));
        check(ImeSmartText.correction("كوردی","ckb").equals("کوردی"));
        check(ImeSmartText.correction("teh","en").equals("the"));
        check(ImeSmartText.correction("Teh","en").equals("The"));
        check(ImeSmartText.correction("TEH","en").isEmpty());
        check(ImeSmartText.correction("teh","ar").isEmpty());
        check(ImeSmartText.correction("name@teh","en").isEmpty());
        check(ImeSmartText.correction("1234","en").isEmpty());
        check(ImeSmartText.correction("سڵاو","ckb").isEmpty());
        check(ImeSmartText.phrases("زۆر سوپاس ",false).contains("بۆ یارمەتیت"));
        check(ImeSmartText.phrases("Thank you ",true).contains("very much"));
        check(ImeSmartText.phrases("thank you",true).isEmpty());
        check(ImeSmartText.phrases("thank you. ",true).isEmpty());
        check(ImeSmartText.latinWord("hello")&&!ImeSmartText.latinWord("سڵاو"));
        check(ImeSmartText.steps(45,15)==3);
        check(ImeSmartText.steps(-1000,15)==4);
        check(ImeSmartText.steps(5,15)==0);
        check(ImeSmartText.spaceHoldChoice("",false).equals(ImeSmartText.SPACE_TRACKPAD));
        check(ImeSmartText.spaceHoldChoice("space_bar_custom_menu",false).equals(ImeSmartText.SPACE_TRACKPAD));
        check(ImeSmartText.spaceHoldChoice("space_bar_custom_menu",true).equals("space_bar_custom_menu"));
        check(ImeSmartText.spaceHoldChoice("show_subtype_picker",false).equals("show_subtype_picker"));
        check(ImeSmartText.spaceHoldChoice("no_action",false).equals("no_action"));
        ImeSmartText.CursorDrag drag=new ImeSmartText.CursorDrag(100);
        check(drag.move(100,12)==0);
        check(drag.move(107,12)==0);
        check(drag.move(124,12)==2);
        check(drag.move(124,12)==0);
        check(drag.move(112,12)==-1);
        check(drag.move(88,12)==-2);
        check(drag.move(1000,12)==4);
        check(drag.move(988,12)==-1);
        check(drag.move(988,12)==0);
        check(ImeSmartText.deleteWordUnits("hello کوردی ")==6);
        check(ImeSmartText.deleteWordUnits("a 😀 ")==3);
        check(ImeSmartText.clipMatches("https://example.com",false,2));
        check(!ImeSmartText.clipMatches("hello",false,2));
        check(ImeSmartText.clipMatches("hello",true,1));
        check(!ImeSmartText.clipMatches("hello",false,1));
        check(ImeSmartText.clipMatches("hello",false,3));
        check(ImeSmartText.EXTRA_KU.length>=60);
        long start=System.nanoTime();int sum=0;
        for(int i=0;i<20000;i++){sum+=ImeSmartText.correction("teh","en").length();sum+=ImeSmartText.deleteWordUnits("سڵاو کوردستان ");}
        check(sum>0);System.out.println("V9: "+count+" checks passed; 20,000 helper iterations in "+((System.nanoTime()-start)/1000000)+" ms (host JVM, not Android latency)");
    }
}
