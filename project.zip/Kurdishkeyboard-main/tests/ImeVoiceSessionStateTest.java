package io.kurdikebord.app;

public class ImeVoiceSessionStateTest {
    private static int count;
    private static void check(boolean ok) { count++; if(!ok) throw new AssertionError("check " + count); }
    public static void main(String[] args) {
        for (String state : new String[]{"connecting","starting","recording","transcribing"}) check(!ImeVoiceSessionState.terminal(state));
        for (String state : new String[]{"idle","result","error","cancelled","permission","model_missing","app_missing",null}) check(ImeVoiceSessionState.terminal(state));
        for (int utterance=0; utterance<3; utterance++) {
            check(ImeVoiceSessionState.action(false,false,false)==ImeVoiceSessionState.Action.START);
            check(ImeVoiceSessionState.action(true,false,true)==ImeVoiceSessionState.Action.STOP);
            check(ImeVoiceSessionState.action(true,false,false)==ImeVoiceSessionState.Action.CANCEL);
            check(ImeVoiceSessionState.terminal("result"));
        }
        check(ImeVoiceSessionState.action(false,true,true)==ImeVoiceSessionState.Action.STOP);
        check(ImeVoiceSessionState.action(false,true,false)==ImeVoiceSessionState.Action.CANCEL);
        check(ImeVoiceSessionState.action(false,false,true)==ImeVoiceSessionState.Action.START);
        System.out.println("Voice session state: "+count+" checks passed");
    }
}
