import importlib.util, io, tempfile, unittest, zipfile
from pathlib import Path
from PIL import Image
spec = importlib.util.spec_from_file_location('importer',Path(__file__).resolve().parents[1]/'scripts/import-facebook-emoji.py')
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
def png(color=(100,50,200,255), size=(64,64)):
    buf=io.BytesIO(); Image.new('RGBA',size,color).save(buf,format='PNG');return buf.getvalue()
class OfflineImportTest(unittest.TestCase):
    expected={'1f600':'😀','2764-fe0f':'❤️','1f44b-1f3fd':'👋🏽'}
    def test_zip_exact_alias_missing(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'pack.zip'
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('img/facebook/64/1f600.png',png());z.writestr('2764.png',png());z.writestr('1f999.png',png());z.writestr('../unrelated.txt','ignore')
            self.assertEqual(set(mod.load_pack(p,self.expected)),{'1f600','2764-fe0f'})
    def test_folder_skin_tone(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'1f44b-1f3fd.png').write_bytes(png());self.assertEqual(set(mod.load_pack(p,self.expected)),{'1f44b-1f3fd'})
    def test_invalid(self):
        with self.assertRaises(ValueError): mod.read_image(png(size=(32,32)))
        with self.assertRaises(ValueError): mod.read_image(png(color=(0,0,0,0)))
    def test_duplicate(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'pack.zip'
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('a/1f600.png',png());z.writestr('b/1f600.png',png((0,0,0,255)))
            with self.assertRaises(ValueError): mod.load_pack(p,self.expected)
if __name__=='__main__': unittest.main()
