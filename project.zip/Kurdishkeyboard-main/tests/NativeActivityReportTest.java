package io.kurdikebord.app;
import java.util.*;
import org.json.JSONObject;
public final class NativeActivityReportTest {
    private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args)throws Exception{
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        JSONObject old=new JSONObject().put("id","old").put("epochMs",1000).put("timestamp","1970-01-01T00:00:01.000Z").put("category","NETWORK").put("severity","SUCCESS").put("title","Health check").put("component","NetworkLayer").put("operation","http_request").put("status","COMPLETED").put("httpStatus",200).put("durationMs",35).put("appVersion","2.0.1").put("platform","Android").put("osVersion","14").put("metadata",new JSONObject().put("method","GET"));
        JSONObject next=new JSONObject().put("id","new").put("epochMs",2000).put("timestamp","1970-01-01T00:00:02.000Z").put("category","ERRORS").put("severity","ERROR").put("title","Failure").put("errorMessage","Example error").put("stackTrace","Example trace");
        String out=NativeActivityReport.format(Arrays.asList(next,old),"Category=ALL, Severity=ALL",false,"2.0.2","Android","15",new Date(3000));
        check(out.contains("Total Events: 2\nFilter: Category=ALL, Severity=ALL"),"scope");
        check(out.indexOf("EVENT 001\nEvent ID: old")<out.indexOf("EVENT 002\nEvent ID: new")&&out.contains("EVENT 001\nEvent ID: old")&&out.contains("EVENT 002\nEvent ID: new"),"chronology");
        check(out.contains("Time: 1970-01-01 00:00:01 (1970-01-01T00:00:01.000Z)"),"timestamps");
        check(out.contains("HTTP Status: 200\nDuration: 35ms"),"metrics");
        check(out.contains("Metadata:\n  - method: GET"),"metadata");
        check(out.contains("Stack Trace:\nExample trace"),"stack");
        check(out.contains("Application: تەختەکلیلی کوردی — KurdiKeyboard"),"application label");
        String one=NativeActivityReport.format(Collections.singletonList(old),null,true,"current","Android","15",new Date(3000));
        check(one.contains("Version: 2.0.1\nPlatform: Android / 14")&&!one.contains("Filter:"),"single event environment");
        System.out.println("8 report formatting checks passed");
    }
}
