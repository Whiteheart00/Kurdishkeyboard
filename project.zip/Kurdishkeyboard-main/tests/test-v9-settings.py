"""Source regressions; device interactions require Android instrumentation."""
from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[1]/'android-ime'
def src(n):return (P/n).read_text()
class SettingsTests(unittest.TestCase):
 def test_capture_toggle_moved(self):
  self.assertNotIn('{"captureHiddenClipboard",',src('NativeClipboardSettingsView.java'))
  s=src('NativeImeClipboardPanel.java');self.assertIn('ImeStateStore.setCaptureHiddenClipboard(context, true)',s);self.assertIn('ImeStateStore.setCaptureHiddenClipboard(context, false)',s);self.assertIn('!ImeStateStore.incognito(context) && ImeStateStore.clipboardCaptureEnabled(context)',s)
 def test_export_and_restore_use_portable_config(self):
  s=src('MainActivity.java');self.assertIn('Intent.ACTION_CREATE_DOCUMENT',s);self.assertIn('local-settings-export',s);self.assertIn('NativeSettingsSections.portableSettings(raw,core)',s);self.assertIn('ImeStateStore.updateSettings(this,clean,false)',s);self.assertIn('change.accept("exportBackup", true)',src('NativeMoreSettingsView.java'))
 def test_excluded_data(self):
  s=src('NativeSettingsSections.java');ex=s.split('private static final String[] DATA = {',1)[1].split('};',1)[0];
  for k in ('personalDictionary','textShortcuts','quickSnippets','emojiPinned','zikrHistories','aiServerUrl','proUnlocked'): self.assertIn('"'+k+'"',ex)
  self.assertNotIn('captureHiddenClipboard',s)
 def test_all_configurable_pages_have_reset(self):
  s=src('NativeSettingsSections.java');
  for page in ('keyboard_prefs','gestures','clipboard_settings','predictions','sound_vibration','themes','custom_theme','languages','layout_editor','font_style','media','ai_settings','more_settings','bottom_row','theme_store'): self.assertIn('case "'+page+'"',s)
  self.assertIn('if(portable(k,defaults))result.remove(k)',s);self.assertIn('resetSettingsSection(this,core,scope)',src('MainActivity.java'))
 def test_layout_uses_original_rows_and_no_bottom_write(self):
  s=src('NativeLayoutEditorView.java');self.assertIn('cached=lang.optJSONArray("rows")',s);self.assertIn('language.optJSONArray("defaults")',s);self.assertIn('send("saveLayout", rows)',s);self.assertNotIn('change.accept("saveBottomRow"',s.split('private void save() {')[1].split('private void send(')[0]);self.assertIn('ACTION_DROP',s);self.assertIn('setLayoutDirection(View.LAYOUT_DIRECTION_LTR)',s)
 def test_layout_preserves_multiple_codepoints(self):
  s=src('NativeImeLayout.java');self.assertIn('key.remove("codePoints")',s);self.assertIn('label.codePointCount(0,label.length())>1',s)
 def test_theme_border_and_radius(self):
  self.assertIn('custom.put("keyBorderWidth",Boolean.TRUE.equals(value)?1:0)',src('MainActivity.java'));self.assertIn('Math.max(4, Math.min(18, theme.optInt("borderRadius", 8)))',src('NativeThemeSettingsView.java'))
if __name__=='__main__': unittest.main()
