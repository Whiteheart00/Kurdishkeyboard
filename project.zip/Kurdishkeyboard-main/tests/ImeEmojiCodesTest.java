package io.kurdikebord.app;
public final class ImeEmojiCodesTest {
    private static void eq(String actual,String expected) { if (!expected.equals(actual)) throw new AssertionError(actual+" != "+expected); }
    public static void main(String[] args) {
        eq(ImeEmojiCodes.hex("😍"), "1f60d");
        eq(ImeEmojiCodes.hex("❤️"), "2764-fe0f");
        eq(ImeEmojiCodes.hex("#️⃣"), "0023-fe0f-20e3");
        eq(ImeEmojiCodes.hex("🧑🏽‍🦰"), "1f9d1-1f3fd-200d-1f9b0");
        eq(ImeEmojiCodes.hex("🇮🇶"), "1f1ee-1f1f6");
        eq(ImeEmojiCodes.alternative("2764-fe0f"), "2764");
        eq(ImeEmojiCodes.alternative("2764"), "2764-fe0f");
        eq(ImeEmojiCodes.alternative("1f60d"), "");
        eq(ImeEmojiCodes.alternative("1f441-fe0f-200d-1f5e8-fe0f"), "1f441-200d-1f5e8");
        eq(ImeEmojiCodes.alternative(""), "");
        System.out.println("10 emoji code cases passed");
    }
}
