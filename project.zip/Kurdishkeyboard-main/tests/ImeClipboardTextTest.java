package io.kurdikebord.app;
public class ImeClipboardTextTest {
    private static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] args) {
        String longText = "کوردی" + "a".repeat(506) + "😀" + "ب".repeat(300000);
        String preview = ImeClipboardText.preview(longText);
        check(preview.length() <= 513 && preview.endsWith("…"));
        check(!Character.isHighSurrogate(preview.charAt(preview.length()-2)));
        check(ImeClipboardText.preview("سڵاو😀").equals("سڵاو😀"));
        check(ImeClipboardText.appendTail("abc", "def", 5).equals("bcdef"));
        check(ImeClipboardText.appendTail("a😀", "b", 2).equals("b"));
        check(ImeClipboardText.appendTail("old", "😀x", 2).equals("x"));
        check(ImeClipboardText.appendTail("old", "😀x", 3).equals("😀x"));
        check(ImeClipboardText.appendTail("old", longText, 240).equals(longText.substring(longText.length()-240)));
        check(ImeClipboardText.appendTail("old", "", 0).isEmpty());
        System.out.println("PASS: bounded clipboard preview and editor tail; Unicode preserved");
    }
}
