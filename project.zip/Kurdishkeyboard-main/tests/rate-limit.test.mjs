import test from 'node:test';
import assert from 'node:assert/strict';
import { allowAiRequest } from '../api/_rateLimit.ts';
const req={headers:{'x-forwarded-for':'192.0.2.1'},socket:{remoteAddress:'127.0.0.1'}};
function response(){return {headers:{},setHeader(k,v){this.headers[k]=v},end(b){this.body=b}}}
test('rate limiter configuration, allow, deny, privacy and failures',async()=>{
 const old={...process.env},oldFetch=globalThis.fetch;
 try{
  process.env.VERCEL='1';delete process.env.UPSTASH_REDIS_REST_URL;delete process.env.UPSTASH_REDIS_REST_TOKEN;delete process.env.RATE_LIMIT_HMAC_KEY;
  let r=response();assert.equal(await allowAiRequest(req,r),false);assert.equal(r.statusCode,503);
  process.env.UPSTASH_REDIS_REST_URL='https://example.upstash.io';process.env.UPSTASH_REDIS_REST_TOKEN='test';process.env.RATE_LIMIT_HMAC_KEY='x'.repeat(32);
  globalThis.fetch=async(_url,opts)=>{const cmd=JSON.parse(opts.body);assert.equal(cmd[0],'EVAL');assert.equal(cmd[2],2);assert.equal(cmd[5],20);assert.equal(cmd[6],240);assert.ok(!opts.body.includes('192.0.2.1'));return {ok:true,json:async()=>({result:1})}};
  assert.equal(await allowAiRequest(req,response()),true);
  globalThis.fetch=async()=>({ok:true,json:async()=>({result:0})});r=response();assert.equal(await allowAiRequest(req,r),false);assert.equal(r.statusCode,429);
  globalThis.fetch=async()=>{throw Error('offline')};r=response();assert.equal(await allowAiRequest(req,r),false);assert.equal(r.statusCode,503);
  r=response();assert.equal(await allowAiRequest({...req,headers:{'x-forwarded-for':'spoofed, 192.0.2.1'}},r),false);assert.equal(r.statusCode,503);
 }finally{globalThis.fetch=oldFetch;for(const k of ['VERCEL','UPSTASH_REDIS_REST_URL','UPSTASH_REDIS_REST_TOKEN','RATE_LIMIT_HMAC_KEY']){if(old[k]===undefined)delete process.env[k];else process.env[k]=old[k]}}
});
