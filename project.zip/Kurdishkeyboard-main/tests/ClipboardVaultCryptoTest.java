package io.kurdikebord.app;
import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
public class ClipboardVaultCryptoTest {
 public static void main(String[] args)throws Exception{
  byte[] keyBytes=new byte[32];new java.security.SecureRandom().nextBytes(keyBytes);
  SecretKeySpec key=new SecretKeySpec(keyBytes,"AES");
  String text="[{\"text\":\"سڵاو 😀\",\"pinned\":true}]";
  byte[] a=ClipboardVaultCrypto.seal(key,text), b=ClipboardVaultCrypto.seal(key,text);
  if(!text.equals(ClipboardVaultCrypto.open(key,a)))throw new AssertionError("Unicode round trip");
  if(Arrays.equals(a,b))throw new AssertionError("nonce reuse");
  a[a.length-1]^=1;try{ClipboardVaultCrypto.open(key,a);throw new AssertionError("tampering accepted");}catch(java.security.GeneralSecurityException expected){}
  keyBytes[0]^=1;try{ClipboardVaultCrypto.open(new SecretKeySpec(keyBytes,"AES"),b);throw new AssertionError("wrong key accepted");}catch(java.security.GeneralSecurityException expected){}
  try{ClipboardVaultCrypto.open(key,new byte[10]);throw new AssertionError("truncated accepted");}catch(java.security.GeneralSecurityException expected){}
  System.out.println("5 clipboard cryptography checks passed (JVM, not Android Keystore)");
 }
}
