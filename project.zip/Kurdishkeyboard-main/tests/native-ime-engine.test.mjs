import assert from 'node:assert/strict';
import { before, test } from 'node:test';
import { runInNewContext } from 'node:vm';
import { build } from 'esbuild';

let call;
before(async () => {
  const bundle = await build({ entryPoints: ['src/native-ime/engine.ts'], bundle: true, write: false, format: 'iife', platform: 'neutral', target: 'es2020' });
  const globals = {};
  runInNewContext(bundle.outputFiles[0].text, globals);
  call = (operation, input = null) => JSON.parse(globals.kurdiNativeCall(operation, JSON.stringify(input)));
});

const deckInput = (settings, mode = 'characters', shift = 'off', kana = 'hira') => ({ settings, mode, shift, kana });

test('native deck uses the bundled defaults, preserves exact input strings and supports all keyboard modes', () => {
  const initial = call('deck', deckInput({}));
  assert.equal(initial.direction, 'rtl');
  assert.equal(initial.theme.id, 'amoled_cobalt');
  assert.deepEqual(initial.rows[0].keys.slice(0, 3).map(key => key.label), ['ق', 'ڤ', 'ف']);
  assert.ok(initial.rows.flatMap(row => row.keys).some(key => key.type === 'enter'));
  for (const mode of ['symbols', 'symbols2', 'numeric_advanced', 'phone', 'phone2']) {
    assert.ok(call('deck', deckInput({}, mode)).rows.length >= 3, mode);
  }
  const english = call('deck', deckInput({ activeLanguage: 'en' }, 'characters', 'caps'));
  assert.equal(english.direction, 'ltr');
  assert.equal(english.rows.find(row => row.keys.some(key => key.label === 'Q')).keys[0].label, 'Q');
});

test('secondary labels grow independently of primary labels and follow the visibility setting', () => {
  const key = call('deck', deckInput({})).rows[0].keys[0];
  const hidden = call('deck', deckInput({ showSecondaryHints: false })).rows[0].keys[0];
  assert.equal(key.hint, '1');
  assert.equal(key.hintSize, 10.5);
  assert.equal(hidden.hint, '');
  assert.equal(hidden.size, key.size);
  assert.equal(hidden.label, key.label);
});

test('native deck retains layout overrides, legacy gesture settings, and appearance options', () => {
  const initial = call('deck', deckInput({}));
  const id = initial.lang.characterLayoutId;
  const rowCount = initial.rows.length - 1;
  const settings = {
    customLayouts: { [id]: Array.from({ length: rowCount }, () => ['ژ']) },
    numberRowMode: 'always', keyboardHeightPx: 280, keyboardWidthPercent: 83,
    keyShapeStyle: 'pill_rounded', numberStyle: 'kurdish', spacebarLabelMode: 'custom', customSpacebarText: 'کوردستان',
    spacebarSwipeAction: 'move_cursor',
  };
  const model = call('deck', deckInput(settings));
  assert.equal(model.width, 83);
  assert.equal(model.height, 310);
  assert.equal(model.rows[0].weight, 0.76);
  assert.ok(model.rows[0].keys.some(key => key.label === '١'));
  assert.ok(model.rows[1].keys.some(key => key.label === 'ژ'));
  const space = model.rows.flatMap(row => row.keys).find(key => key.type === 'space');
  assert.equal(space.label, 'کوردستان');
  assert.equal(space.face.borderRadius, '9999px');
  assert.equal(call('hydrate', settings).spaceBarSwipeLeftAction, 'move_cursor_left');
});

test('translation search accepts native names, Kurdish and language codes with source-only auto detection', () => {
  assert.equal(call('filterLanguages', ['', true])[0].code, 'auto');
  assert.ok(!call('filterLanguages', ['', false]).some(language => language.code === 'auto'));
  assert.ok(call('filterLanguages', [' TÜRKÇE ', false]).some(language => language.code === 'tr'));
  assert.ok(call('filterLanguages', ['سۆرانی', false]).some(language => language.code === 'ckb'));
  assert.ok(call('filterLanguages', ['CKB', false]).some(language => language.code === 'ckb'));
  assert.deepEqual(call('filterLanguages', ['no matching language', false]), []);
});

test('predictions, emoji history, math and rewrite use the existing algorithms', () => {
  const predict = tail => call('predictions', { tail, settings: {}, kana: 'hira', learned: {} });
  assert.equal(predict('سڵاو ').items[0].value, 'هاوڕێ');
  assert.ok(predict('test@g').items[0].isEmail);
  assert.equal(predict('٣×٤=').math.formatted, '12');
  assert.equal(call('math', '(7+1)×8'), '64');
  assert.equal(call('math', '8÷0'), '');
  assert.equal(call('recordHistory', [{ pinned: [], recent: ['😊'] }, '❤️', 'auto_prepend', 2]).recent[0], '❤️');
  assert.ok(call('offlineRewrite', ['سڵاو هاوڕێ', 'formal']));
  assert.equal(call('offlineRewrite', ['i have good news', 'fix']), 'I have good news.');
  assert.equal(call('rewriteQuality', ['an original sentence with detail', 'a much longer answer with added details', 'shorten']), false);
});


test('prepared predictions reuse the same algorithm across consecutive edits', () => {
  const context = {
    settings: { activeLanguage: 'ckb' },
    kana: 'hira',
    learned: { 'سڵاوتان': 4 },
  };
  call('preparePredictions', context);
  for (const tail of ['', 'س', 'سڵاو ', '٣×٤=', 'name@g']) {
    assert.deepEqual(call('predictTail', tail), call('predictions', { ...context, tail }));
  }
  const updated = { ...context, learned: { 'سڵاوێکی': 8 } };
  call('preparePredictions', updated);
  assert.deepEqual(call('predictTail', 'سڵاو'), call('predictions', { ...updated, tail: 'سڵاو' }));
});

test('Android settings payloads are generated as JSON without a renderer', async () => {
  const bundle = await build({ entryPoints: ['src/native-ime/data.ts'], bundle: true, write: false, format: 'cjs', platform: 'node' });
  const module = { exports: {} };
  const { createRequire } = await import('node:module');
  new Function('module','exports','require',bundle.outputFiles[0].text)(module,module.exports,createRequire(import.meta.url));
  const data = JSON.parse(JSON.stringify(module.exports.nativeData));
  assert.ok(data.core.editableRows.kurdi_qvfgh.length);
  assert.ok(data.core.subtypes.some(lang => lang.code === 'ckb'));
  assert.ok(data.settingsPages.storeThemes.length);
  for (const lang of ['ckb','kmr','en','ar','fa']) {
    const page = data.settingsPages.pages[lang];
    assert.ok(page.keyboard_prefs.ranges.length > 0);
    assert.ok(page.gestures.sections.length > 0);
    assert.equal(page.faq.items.length, 5);
  }
});
