import test from 'node:test';
import assert from 'node:assert/strict';
import { PointerSessions, suffixEdit } from '../src/utils/inputEngine.ts';
import { readVersioned, writeVersioned, serializeSettingsBackup, parseSettingsBackup } from '../src/utils/persistentStorage.ts';
test('20,000 rapid pointer sessions preserve individual identities',()=>{
  const p=new PointerSessions();
  for(let i=0;i<10000;i++) {
    assert.equal(p.begin(1,'a',0,0),true);
    assert.equal(p.begin(2,'b',5,5),false);
    assert.equal(p.end(2).key,'b'); assert.equal(p.isOwner(1),true);
    assert.equal(p.end(1).key,'a'); assert.equal(p.end(1),undefined);
  }
});
test('cancellation and language changes invalidate old pointer events',()=>{
  const p=new PointerSessions(); p.begin(1,'a',0,0); p.begin(2,'b',0,0); p.clear();
  assert.equal(p.end(1),undefined); assert.equal(p.end(2),undefined); assert.equal(p.begin(3,'ژ',0,0),true);
});
test('Unicode suffix changes never split surrogate pair',()=>{
  assert.deepEqual(suffixEdit('سڵاو😀','سڵاو😁'),{expected:'😀',replacement:'😁'});
  assert.deepEqual(suffixEdit('کوردی','کوردستان'),{expected:'ی',replacement:'ستان'});
  for(let i=0;i<10000;i++) {const a='کوردی'+String.fromCodePoint(0x1f600+i%70),b='کوردی'+String.fromCodePoint(0x1f600+(i+1)%70);const e=suffixEdit(a,b);assert.equal(a.slice(0,a.length-e.expected.length)+e.replacement,b);}
});
test('versioned recovery retains previous valid value, rejects corrupt and wrong shape',()=>{
  const data=new Map();globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};
  writeVersioned('s','{"lang":"ckb"}','object');writeVersioned('s','{"lang":"en"}','object');assert.equal(readVersioned('s','object'),'{"lang":"en"}');
  data.set('s','broken');assert.equal(readVersioned('s','object'),'{"lang":"ckb"}');assert.throws(()=>writeVersioned('s','[]','object'));
  writeVersioned('c','[]','array');assert.equal(readVersioned('c','array'),'[]');
});

test('versioned settings export and legacy import',()=>{const data={activeLanguage:'ckb'};assert.deepEqual(parseSettingsBackup(serializeSettingsBackup(data)),data);assert.deepEqual(parseSettingsBackup(JSON.stringify(data)),data);assert.throws(()=>parseSettingsBackup('{"format":"kurdikeyboard-settings","version":2,"settings":{}}'));});

import { rewriteQuality } from '../api/_rewriteQuality.ts';
test('rewrite rejects empty, markdown and incorrect length',()=>{
  assert.equal(rewriteQuality('This is a long sentence with words.','Short sentence.','shorten'),true);
  assert.equal(rewriteQuality('This is a long sentence with words.','This is a long sentence with more words.','shorten'),false);
  assert.equal(rewriteQuality('This is a sentence.','This is a sentence.','expand'),false);
  assert.equal(rewriteQuality('This is a sentence.','This is a longer sentence with detail.','expand'),true);
  assert.equal(rewriteQuality('abc','  ','fix'),false);
  assert.equal(rewriteQuality('abc','```abc```','fix'),false);
});
test('settings mirror recovers without copying clipboard',()=>{
  const data=new Map();let native='';globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};
  globalThis.window={AndroidIME:{readNativeSettings:()=>native,writeNativeSettings:s=>{native=s;return true;}}};
  try {writeVersioned('kurdikebord_settings_v2','{"lang":"ckb"}','object');
  assert.equal(native,'{"lang":"ckb"}');writeVersioned('clipboard','["secret"]','array');assert.equal(native,'{"lang":"ckb"}');
  data.clear();assert.equal(readVersioned('kurdikebord_settings_v2','object'),native);}finally{delete globalThis.window;}
});
