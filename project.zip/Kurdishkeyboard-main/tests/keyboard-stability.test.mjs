import test from 'node:test';
import assert from 'node:assert/strict';
import { PointerSessions, suffixEdit } from '../src/utils/inputEngine.ts';
import { readVersioned, writeVersioned, serializeSettingsBackup, parseSettingsBackup } from '../src/utils/persistentStorage.ts';
test('20,000 rapid pointer sessions preserve individual identities',()=>{
  const p=new PointerSessions();
  for(let i=0;i<10000;i++) {
    assert.equal(p.begin(1,'a',0,0),true);
    assert.equal(p.begin(2,'b',5,5),false);
    assert.equal(p.end(2).key,'b'); assert.equal(p.isOwner(1),true);
    assert.equal(p.end(1).key,'a'); assert.equal(p.end(1),undefined);
  }
});
test('cancellation and language changes invalidate old pointer events',()=>{
  const p=new PointerSessions(); p.begin(1,'a',0,0); p.begin(2,'b',0,0); p.clear();
  assert.equal(p.end(1),undefined); assert.equal(p.end(2),undefined); assert.equal(p.begin(3,'ژ',0,0),true);
});
test('Unicode suffix changes never split surrogate pair',()=>{
  assert.deepEqual(suffixEdit('سڵاو😀','سڵاو😁'),{expected:'😀',replacement:'😁'});
  assert.deepEqual(suffixEdit('کوردی','کوردستان'),{expected:'ی',replacement:'ستان'});
  for(let i=0;i<10000;i++) {const a='کوردی'+String.fromCodePoint(0x1f600+i%70),b='کوردی'+String.fromCodePoint(0x1f600+(i+1)%70);const e=suffixEdit(a,b);assert.equal(a.slice(0,a.length-e.expected.length)+e.replacement,b);}
});
test('versioned recovery retains previous valid value, rejects corrupt and wrong shape',()=>{
  const data=new Map();globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};
  writeVersioned('s','{"lang":"ckb"}','object');writeVersioned('s','{"lang":"en"}','object');assert.equal(readVersioned('s','object'),'{"lang":"en"}');
  data.set('s','broken');assert.equal(readVersioned('s','object'),'{"lang":"ckb"}');assert.throws(()=>writeVersioned('s','[]','object'));
  writeVersioned('c','[]','array');assert.equal(readVersioned('c','array'),'[]');
});

test('versioned settings export and legacy import',()=>{const data={activeLanguage:'ckb'};assert.deepEqual(parseSettingsBackup(serializeSettingsBackup(data)),data);assert.deepEqual(parseSettingsBackup(JSON.stringify(data)),data);assert.throws(()=>parseSettingsBackup('{"format":"kurdikeyboard-settings","version":2,"settings":{}}'));});

import { rewriteQuality } from '../api/_rewriteQuality.ts';
test('rewrite rejects empty, markdown and incorrect length',()=>{
  assert.equal(rewriteQuality('This is a long sentence with words.','Short sentence.','shorten'),true);
  assert.equal(rewriteQuality('This is a long sentence with words.','This is a long sentence with more words.','shorten'),false);
  assert.equal(rewriteQuality('This is a sentence.','This is a sentence.','expand'),false);
  assert.equal(rewriteQuality('This is a sentence.','This is a longer sentence with detail.','expand'),true);
  assert.equal(rewriteQuality('abc','  ','fix'),false);
  assert.equal(rewriteQuality('abc','```abc```','fix'),false);
});
test('settings mirror recovers without copying clipboard',()=>{
  const data=new Map();let native='';globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};
  globalThis.window={AndroidIME:{readNativeSettings:()=>native,writeNativeSettings:s=>{native=s;return true;}}};
  try {writeVersioned('kurdikebord_settings_v2','{"lang":"ckb"}','object');
  assert.equal(native,'{"lang":"ckb"}');writeVersioned('clipboard','["secret"]','array');assert.equal(native,'{"lang":"ckb"}');
  data.clear();assert.equal(readVersioned('kurdikebord_settings_v2','object'),native);}finally{delete globalThis.window;}
});

import { serializeDataBackup, parseDataBackup } from '../src/utils/persistentStorage.ts';
const clipKey='kurdikebord_clipboard_v1';
const clip=[{id:'p',text:'سڵاو 😀',timestamp:123,pinned:true},{id:'n',text:'line\n2',timestamp:456}];
test('full backup preserves clipboard text, pinned flags, timestamps and order; old backups omit clipboard',()=>{
  const settings={activeLanguage:'ckb'};
  assert.deepEqual(parseDataBackup(serializeDataBackup(settings,clip)),{settings,clipboard:clip});
  assert.deepEqual(parseDataBackup(serializeDataBackup(settings,[])),{settings,clipboard:[]});
  assert.deepEqual(parseDataBackup(serializeSettingsBackup(settings)),{settings});
  assert.deepEqual(parseDataBackup(JSON.stringify(settings)),{settings});
  assert.throws(()=>parseDataBackup(JSON.stringify({format:'kurdikeyboard-settings',version:2,settings,clipboard:[{text:'bad'}]})));
  assert.throws(()=>serializeDataBackup(settings,[{...clip[0],pinned:'yes'}]));
});
test('native clipboard migration, recovery, deletion and stale mirror protection',()=>{
  const data=new Map([[clipKey,JSON.stringify(clip)]]);let native='';
  globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};
  const bridge={readNativeClipboard:()=>native,writeNativeClipboard:s=>{native=s;return true;}};
  globalThis.window={AndroidIME:bridge};
  try {
    assert.equal(readVersioned(clipKey,'array'),JSON.stringify(clip));
    writeVersioned(clipKey,JSON.stringify(clip),'array');
    data.clear();assert.equal(readVersioned(clipKey,'array'),native);
    data.set(clipKey+':recovery',JSON.stringify({version:1,payload:native}));
    writeVersioned(clipKey,'[]','array');
    assert.equal(data.has(clipKey+':recovery'),false);
    data.set(clipKey,JSON.stringify(clip));assert.equal(readVersioned(clipKey,'array'),'[]');
    assert.throws(()=>writeVersioned(clipKey,'[{}]','array'));assert.equal(native,'[]');
    bridge.writeNativeClipboard=()=>false;assert.throws(()=>writeVersioned(clipKey,JSON.stringify(clip),'array'));
    assert.equal(readVersioned(clipKey,'array'),'[]');
    native='';data.clear();data.set(clipKey+':recovery',JSON.stringify({version:1,payload:JSON.stringify(clip)}));assert.equal(readVersioned(clipKey,'array'),null);
  } finally {delete globalThis.window;}
});

test('native settings changes take precedence over an obsolete WebView mirror',()=>{
  const key='kurdikebord_settings_v2';const data=new Map([[key,'{"activeThemeId":"old"}']]);
  globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};
  globalThis.window={AndroidIME:{readNativeSettings:()=>'{"activeThemeId":"new"}'}};
  try{assert.equal(readVersioned(key,'object'),'{"activeThemeId":"new"}');}finally{delete globalThis.window;}
});

import {readFileSync,readdirSync} from 'node:fs';
test('native assets preserve original themes, character layouts, emojis and dictionaries',()=>{
  const root=new URL('../android-ime/native-data/',import.meta.url);
  const read=p=>JSON.parse(readFileSync(new URL(p,root),'utf8'));
  const themes=read('themes.json');assert.equal(themes.length,30);assert.equal(new Set(themes.map(t=>t.id)).size,30);
  const files=readdirSync(new URL('layouts/',root));assert.equal(files.length,41);
  for(const file of files){const layout=read('layouts/'+file);assert.ok(layout.off.length>0,file);for(const row of layout.off)for(const k of row)assert.ok(typeof k.value==='string'&&k.value.length>0,file);}
  assert.ok(read('layouts/kurdi_qvfgh.json').off.flat().some(k=>k.value==='وو'));
  assert.equal(read('rich.json').emojiCategories.length,9);
  assert.ok(read('dictionary.json').ckb.includes('سڵاو'));
  assert.ok(read('translation.json').some(l=>l.code==='ckb'));
});
