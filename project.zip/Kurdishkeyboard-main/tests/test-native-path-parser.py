#!/usr/bin/env python3
"""Exercise the vector parser on the JVM with a recording Android Path stand-in."""
import json
import re
import subprocess
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
icons = json.loads((root / 'src/data/generated/vectorIcons.json').read_text())
paths = [p['d'] for icon in icons.values() for p in icon.get('paths', []) if p.get('d')]
paths += re.findall(r'path = "([^"]+)";', (root / 'android-ime/NativeImeAppearance.java').read_text())
assert paths
with tempfile.TemporaryDirectory() as directory:
    tmp = Path(directory)
    stub = tmp / 'Path.java'
    stub.write_text('''package android.graphics;
import java.util.ArrayList;
import java.util.List;
public class Path {
    public List<String> kinds = new ArrayList<>();
    public List<float[]> coords = new ArrayList<>();
    private void add(String kind, float... v) {
        for (float n : v) if (Float.isNaN(n) || Float.isInfinite(n)) throw new AssertionError("Non-finite path coordinate");
        kinds.add(kind); coords.add(v);
    }
    public void moveTo(float x,float y) { add("M",x,y); }
    public void lineTo(float x,float y) { add("L",x,y); }
    public void cubicTo(float a,float b,float c,float d,float x,float y) { add("C",a,b,c,d,x,y); }
    public void quadTo(float a,float b,float x,float y) { add("Q",a,b,x,y); }
    public void close() { add("Z"); }
}''')
    test = tmp / 'NativePathParserTest.java'
    test.write_text('''package io.kurdikebord.app;
import android.graphics.Path;
import java.nio.file.Files;
import java.nio.file.Paths;
public class NativePathParserTest {
    static Path parse(String s) { return NativePathParser.createPathFromPathData(s); }
    static void expect(float[] actual, float... expected) {
        if (actual.length != expected.length) throw new AssertionError("Coordinate count");
        for (int i=0;i<actual.length;i++) if (Math.abs(actual[i]-expected[i])>0.001f) throw new AssertionError("Unexpected coordinate: "+actual[i]+" vs "+expected[i]);
    }
    public static void main(String[] args) throws Exception {
        Path p = parse("M1 2 3 4 h2 v-1 z m3 4 l1 2");
        if (!String.join("",p.kinds).equals("MLLVZML".replace("V","L"))) throw new AssertionError(p.kinds);
        expect(p.coords.get(1),3,4); expect(p.coords.get(2),5,4); expect(p.coords.get(3),5,3);
        expect(p.coords.get(5),4,6); expect(p.coords.get(6),5,8);
        p = parse("M0 0 C1 2 3 4 5 6 s2 3 4 5 Q10 12 13 14 t2 3");
        expect(p.coords.get(2),7,8,7,9,9,11); expect(p.coords.get(4),16,16,15,17);
        p = parse("M1 0 A1 1 0 0 1 0 1");
        if (!String.join("",p.kinds).equals("MC")) throw new AssertionError(p.kinds);
        expect(p.coords.get(1),1,0.552285f,0.552285f,1,0,1);
        p = parse("M0 0 a2 2 0 0110 0");
        float[] end=p.coords.get(p.coords.size()-1); expect(new float[]{end[end.length-2],end[end.length-1]},10,0);
        p = parse("M1e1-.5 L.2 3E1 A0 2 0 0 1 5 6");
        expect(p.coords.get(0),10,-.5f); expect(p.coords.get(1),.2f,30); expect(p.coords.get(2),5,6);
        for (String invalid : new String[]{"L1 2","M1","M0 0 A1 2 0 2 0 3 4","M0 0 Z 1 2"}) {
            try { parse(invalid); throw new AssertionError("Accepted invalid path: "+invalid); } catch (IllegalArgumentException expected) { }
        }
        int count=0;
        for (String s : Files.readAllLines(Paths.get(args[0]))) {
            Path vector=parse(s);
            if (vector.kinds.size()<1) throw new AssertionError("Empty vector");
            count++;
        }
        System.out.println("Native vector parser: all "+count+" bundled path strings and geometry/invalid-input cases passed.");
    }
}''')
    fixture = tmp / 'vectors.txt'
    fixture.write_text('\n'.join(' '.join(s.split()) for s in paths) + '\n')
    subprocess.run(['javac', '-d', str(tmp), str(stub), str(root / 'android-ime/NativePathParser.java'), str(test)], check=True)
    subprocess.run(['java', '-cp', str(tmp), 'io.kurdikebord.app.NativePathParserTest', str(fixture)], check=True)
