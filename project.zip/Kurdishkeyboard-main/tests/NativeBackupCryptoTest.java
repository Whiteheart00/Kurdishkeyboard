package io.kurdikebord.app;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
public class NativeBackupCryptoTest {
    static void check(boolean value,String label){if(!value)throw new AssertionError(label);}
    static byte[] encrypt(byte[] plain,char[] pass)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();NativeBackupCrypto.encrypt(plain,pass,out);return out.toByteArray();}
    static boolean rejects(byte[] bytes,char[] pass){try{NativeBackupCrypto.decrypt(new ByteArrayInputStream(bytes),pass);return false;}catch(Exception e){return true;}}
    public static void main(String[] args)throws Exception{
        char[] pass="A unique test passphrase only".toCharArray();byte[] text="سڵاو 😁 clipboard example".getBytes(StandardCharsets.UTF_8);
        byte[] a=encrypt(text,pass),b=encrypt(text,pass);
        check(Arrays.equals(text,NativeBackupCrypto.decrypt(new ByteArrayInputStream(a),pass)),"Unicode round trip");
        check(!Arrays.equals(a,b),"random salt/IV");
        check(rejects(a,"another test passphrase".toCharArray()),"wrong passphrase");
        byte[] bad=a.clone();bad[bad.length-1]^=1;check(rejects(bad,pass),"tampered ciphertext");
        bad=a.clone();bad[8]^=1;check(rejects(bad,pass),"tampered header");
        check(rejects(Arrays.copyOf(a,a.length-1),pass),"truncation");
        check(rejects("not a backup".getBytes(StandardCharsets.UTF_8),pass),"format rejection");
        boolean shortRejected=false;try{encrypt(text,"short".toCharArray());}catch(IOException e){shortRejected=true;}check(shortRejected,"minimum password");
        boolean hugeRejected=false;try{encrypt(new byte[NativeBackupCrypto.MAX+1],pass);}catch(IOException e){hugeRejected=true;}check(hugeRejected,"size limit");
        check(!new String(a,StandardCharsets.UTF_8).contains("clipboard example"),"not plaintext");
        System.out.println("10 backup encryption checks passed");
    }
}
