#!/usr/bin/env python3
"""Source-level regression checks; actual view measurement requires Android."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]

def source(name):
    return (ROOT / name).read_text()

class KeyboardPrefsCalculatorTest(unittest.TestCase):
    def test_native_calculator_first_on_initial_open_and_reset(self):
        s = source('android-ime/NativeImeCalculatorPanel.java')
        self.assertIn('private boolean calculator = true;', s)
        self.assertRegex(s, r'void reset\(\)\s*\{\s*calculator = true;')
        self.assertIn('if (calculator) addCalculator(panel); else addSnippets(panel);', s)
        self.assertIn('calculator = calc; keyboard.render();', s)
        self.assertRegex(s, r'reset\(\);\s*calculator = false;[^\n]*\n\s*keyboard.settingsPatch')
    def test_web_calculator_entry_points_match(self):
        s = source('src/components/keyboard/KeyboardView.tsx')
        self.assertEqual(s.count("setSnippetsCalcTab('calc');"), 2)
        self.assertNotIn("setSnippetsCalcTab('snippets');", s)
    def test_choice_rows_have_explicit_height_and_preserve_equal_width(self):
        s = source('android-ime/NativeKeyboardPrefsView.java')
        self.assertIn('new LayoutParams(0, dp(custom != null ? 40 : 36), 1)', s)
        self.assertIn('line.addView(button, cell);', s)
        self.assertLess(s.index('button.setSingleLine(true);'), s.index('button.setMinimumHeight('))
        self.assertIn('cell.setMarginStart(dp(index % columns == 0 ? 0 : 6));', s)
    def test_setting_ids_and_grid_columns_preserved(self):
        s = source('src/data/keyboardPreferences.ts')
        for key, columns in [('numberRowMode', 3), ('capitalizationBehavior', 2), ('bottomRowPreset', 2)]:
            self.assertRegex(s, rf"key: '{key}',[^\n]*columns: {columns}")

if __name__ == '__main__':
    unittest.main()
