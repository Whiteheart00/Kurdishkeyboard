package io.kurdikebord.app;
import java.util.Arrays;
import java.util.Collections;
public final class ImeClipboardCaptureTest {
    private static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] args) {
        ImeClipboardCapture capture = new ImeClipboardCapture();
        check(capture.isNew(100, Arrays.asList("یەک")));
        capture.accepted(100, Arrays.asList("یەک"));
        check(!capture.isNew(100, Arrays.asList("یەک")));
        check(capture.isNew(100, Arrays.asList("دوو")));
        capture.accepted(100, Arrays.asList("دوو"));
        check(capture.isNew(101, Arrays.asList("سێ")));
        capture.accepted(101, Arrays.asList("سێ"));
        check(capture.isNew(102, Arrays.asList("سێ")));
        check(!capture.isNew(102, Collections.emptyList()));
        check(ImeClipboardCapture.safeText("123456") == null);
        check(ImeClipboardCapture.safeText("password: demo") == null);
        check(ImeClipboardCapture.safeText("  سڵاو 😁 \n").equals("  سڵاو 😁 \n"));
        check(ImeClipboardCapture.safeText("  ") == null);
        capture.clear();
        check(capture.isNew(101, Arrays.asList("سێ")));
        System.out.println("Clipboard capture tests: 11 passed");
    }
}
