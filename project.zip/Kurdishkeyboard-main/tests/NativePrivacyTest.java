package io.kurdikebord.app;
public final class NativePrivacyTest {
    public static void main(String[] args) {
        String[] sensitive={"123456","۱۲۳۴۵۶","١٢٣٤","password: test","OTP: test","4111 1111 1111 1111","eyJabcdefgh.abcdefgh.abcdefghijkl","کۆدی دڵنیایی: ١٢٣٤"};
        String[] ordinary={"سڵاو چۆنیت", "😁", "12", "2026-11-27", "www.example.com", "4111 1111 1111 1112"};
        for(String v:sensitive) if(!NativePrivacy.looksSensitive(v)) throw new AssertionError("Missed sensitive sample");
        for(String v:ordinary) if(NativePrivacy.looksSensitive(v)) throw new AssertionError("False positive in ordinary sample");
        System.out.println("Privacy heuristic: "+(sensitive.length+ordinary.length)+" checks passed");
    }
}
