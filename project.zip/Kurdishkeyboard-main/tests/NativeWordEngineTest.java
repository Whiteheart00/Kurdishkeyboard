package io.kurdikebord.app;
import java.util.*;
public final class NativeWordEngineTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        check(NativeWordEngine.prefix("سڵاو، کورد").equals("کورد"));
        check(NativeWordEngine.prefix("hello 😀").isEmpty());
        check(NativeWordEngine.prefix("good day").equals("day"));
        check(NativeWordEngine.normalize("كوردی").equals(NativeWordEngine.normalize("کوردی")));
        check(NativeWordEngine.suggest(List.of("کوردستان","کوردی","کتێب"),"كورد",3).equals(List.of("کوردستان","کوردی")));
        check(NativeWordEngine.suggest(List.of("hello","hello","help"),"he",3).equals(List.of("hello","help")));
        check(NativeWordEngine.suggest(List.of("hello"),"",3).isEmpty());
        check(NativeWordEngine.suggest(List.of("hello"),"hek",3).contains("hello"));
        check(!NativeWordEngine.quality("This is a long sentence with words.","This is a long sentence with more words.","shorten"));
        check(NativeWordEngine.quality("This is a long sentence with words.","Short sentence.","shorten"));
        check(!NativeWordEngine.quality("abc","```abc```","fix"));
        for(int i=0;i<10000;i++) check(NativeWordEngine.suggest(List.of("سڵاو","سڵاوتان","سڵاو"),"سڵ",2).size()==2);
        System.out.println("PASS: Unicode prefix, normalized Kurdish, deduplication, AI quality, and 10,000 suggestion queries");
    }
}
