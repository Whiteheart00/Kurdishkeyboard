package io.kurdikebord.app;
public class ImeLargeTextTest {
    static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] args) {
        StringBuilder source = new StringBuilder("a");
        for (int i = 0; i < 300000; i++) source.append("\uD83D\uDE00");
        String text = source.toString();
        StringBuilder joined = new StringBuilder();
        for (String part : ImeLargeText.chunks(text, ImeLargeText.CHUNK)) {
            check(part.length() <= ImeLargeText.CHUNK);
            check(!Character.isHighSurrogate(part.charAt(part.length() - 1)));
            check(!Character.isLowSurrogate(part.charAt(0)));
            joined.append(part);
        }
        check(joined.toString().equals(text));
        check(ImeLargeText.chunks("", 10).isEmpty());
        check(ImeLargeText.preview("abc", 3).equals("abc"));
        check(ImeLargeText.preview(text, 300).length() <= 301);
        boolean[] keep = ImeLargeText.keep(new int[]{90, 50, 40, 5}, new boolean[]{false, false, true, false}, 140);
        check(keep[0] && !keep[1] && keep[2] && keep[3]);
        check(ImeLargeText.keep(new int[]{500}, new boolean[]{false}, 10)[0]);
        System.out.println("PASS: large text limits");
    }
}
