package io.kurdikebord.app;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class ImeOperationGateTest {
    static void check(boolean result) { if(!result) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        ImeOperationGate gate=new ImeOperationGate(256);
        for(int i=0;i<256;i++) check(gate.tryAcquire());
        check(!gate.tryAcquire()); for(int i=0;i<256;i++) gate.release();
        ExecutorService pool=Executors.newFixedThreadPool(8);
        AtomicInteger active=new AtomicInteger(), peak=new AtomicInteger();
        java.util.List<Future<?>> jobs=new java.util.ArrayList<>();
        for(int i=0;i<8;i++) jobs.add(pool.submit(()-> { for(int j=0;j<10000;j++) if(gate.tryAcquire()) { int n=active.incrementAndGet();peak.accumulateAndGet(n,Math::max); active.decrementAndGet();gate.release(); } }));
        for(Future<?> f:jobs) f.get();pool.shutdown();check(peak.get()<=256);check(active.get()==0);
        check(ImeOperationGate.isCurrent(1,1,2,2,true));check(!ImeOperationGate.isCurrent(1,2,2,2,true));check(!ImeOperationGate.isCurrent(1,1,2,3,true));check(!ImeOperationGate.isCurrent(1,1,2,2,false));
        checkTailRequests();
        System.out.println("PASS: bounded editor operations and coalesced context reads across edits and hide/reopen");
    }

    private static void checkTailRequests() {
        ImeTailRequests requests = new ImeTailRequests();
        check(requests.begin());
        long first = requests.revision();
        // Rapid edits supersede the in-flight result and leave one deferred refresh.
        for (int i = 0; i < 1000; i++) {
            requests.invalidate();
            check(!requests.begin());
        }
        check(!requests.finish(first));
        check(requests.hasWaitingRead());
        check(requests.begin());
        long refreshed = requests.revision();
        requests.invalidate(); // Keyboard hidden or focus changed.
        check(!requests.finish(refreshed));
        check(!requests.hasWaitingRead());
        check(requests.begin()); // The next visible editor can read with the same worker.
        check(requests.finish(requests.revision()));
    }
}
