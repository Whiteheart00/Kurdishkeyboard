package io.kurdikebord.app;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
public final class ImeNumericInputTest {
    static int count;
    static void check(boolean yes) { if (!yes) throw new AssertionError("case " + (count + 1)); count++; }
    static Set<String> values(int type, boolean kurdish) {
        Set<String> result = new HashSet<>();
        for (String[] row : ImeNumericInput.rows(type, kurdish)) result.addAll(Arrays.asList(row));
        return result;
    }
    public static void main(String[] args) {
        check(ImeNumericInput.type(1)==0);
        check(ImeNumericInput.type(0)==0);
        check(ImeNumericInput.type(0x21)==0);
        check(ImeNumericInput.type(2)==2);
        check(ImeNumericInput.type(0x12)==0x12); // PIN
        check(ImeNumericInput.type(3)==3);
        check(ImeNumericInput.type(4)==4);
        check(ImeNumericInput.type(0x3002)==0x3002);
        Set<String> latin = values(2,false), kurdish = values(2,true);
        check(latin.size()==13 && latin.containsAll(Arrays.asList("0","1","2","3","4","5","6","7","8","9","toggle","delete","enter")));
        check(kurdish.size()==13 && kurdish.containsAll(Arrays.asList("٠","١","٢","٣","٤","٥","٦","٧","٨","٩","toggle","delete","enter")));
        check(!latin.contains(".") && !latin.contains("-") && !latin.contains("+"));
        check(values(0x2002,false).contains(".") && !values(0x2002,false).contains("-"));
        check(values(0x1002,false).containsAll(Arrays.asList("+","-")) && !values(0x1002,false).contains("."));
        check(values(0x3002,true).containsAll(Arrays.asList("+","-",".","٠")));
        check(values(3,false).containsAll(Arrays.asList("+","*","#")));
        check(values(4,false).containsAll(Arrays.asList("/",":","-")));
        System.out.println("Numeric input tests: " + count + " passed");
    }
}
