# تەختەکلیلی کوردی — KurdiKeyboard

## Native Android preview

Android uses Java, Android Views and the system IME. The website and Vercel API remain a separate web application. Android packages generated JSON data, fonts and media rather than the web interface.

For the existing ZIP-based GitHub repository:
1. Back up settings in the old app and preserve the signing secrets.
2. Replace the repository root `project.zip` and `.github/workflows/build.yml` together. The workflow inside the ZIP is not activated automatically. Disable obsolete Android workflows that run on push.
3. In Actions, run **Build KurdiKeyboard and deploy Vercel from ZIP** with `native_ime_preview` checked (default). A push also builds a preview, without a public release.
4. Download `KurdiKeyboard-Native-Preview-APK` from Artifacts after all steps pass. Test installation, upgrade and keyboard behavior before publishing.

For a local build: install Node 22, JDK 17, Gradle 8.2.1 and Android SDK 34, install npm dependencies, run `node scripts/setup-android-ime.mjs` (existing signing keystore required), then `cd android && gradle assembleDebug`. Run the source and APK audits as in CI.

This is a migration preview, not a verified production release. See `NATIVE_MIGRATION_REPORT.md` for limitations and test status.
