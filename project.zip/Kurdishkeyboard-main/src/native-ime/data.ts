// Compiled to JSON by the Android build. The phone loads data, not JavaScript.
import { DEFAULT_SETTINGS, INITIAL_CLIPBOARD } from '../data/defaultSettings';
import { ALL_SUBTYPE_PRESETS, CHARACTER_LAYOUT_OPTIONS, EMAIL_DOMAIN_POPUP_OPTIONS, getEditableAlphaRows, EXTRA_EDITOR_KEYS } from '../data/layouts';
import { ALL_SWIPE_ACTIONS, ARABIC_HARAKAT_OPTIONS, SPACEBAR_CUSTOM_MENU_OPTIONS, GESTURE_GROUPS, getSwipeActionLabel, SWIPE_DISTANCE_THRESHOLDS, SWIPE_VELOCITY_THRESHOLDS } from '../data/gestures';
import { ALL_THEMES, STORE_THEMES } from '../data/themes';
import { ARABIC_COMMON_WORDS, ENGLISH_COMMON_WORDS, ENGLISH_NEXT_WORDS, KURDISH_NEXT_WORDS,
  KURDISH_SORANI_WORDS, PERSIAN_COMMON_WORDS, TURKISH_COMMON_WORDS } from '../data/dictionaries';
import { EMOJI_CATEGORIES, EMOJI_KEYWORD_MAP, EMOJI_NAME_LOOKUP, EMOJI_SKIN_TONES, EMOJI_HAIR_STYLES,
  KAOMOJI_LIST, TEXT_DECORATORS, ZIKR_CATEGORIES } from '../data/richContent';
import { AUTO_DETECT_LANG, TRANSLATION_LANGUAGES } from '../data/translationLanguages';
import { MISSING_FACEBOOK_BASE_CODES } from '../data/emojiVisuals';
import { SOUND_PACKS } from '../utils/sound';
import { OFFLINE_DIALECTS } from '../utils/kurdishSmartHelper';
import layouts from '../data/generated/layoutsBundle.json';
import icons from '../data/generated/vectorIcons.json';
import strings from '../data/generated/officialStrings.json';

import { keyboardPreferencesPayload } from '../data/keyboardPreferences';
import { getFaqItems, tOfficial, getAppDirection } from '../data/officialData';

const nativeSpaceHold = 'space_cursor_trackpad';
const nativeSpaceHoldLabels: Record<string, string> = {
  ckb: 'جوڵاندنی کێرسەر بە دەستڕاگرتن و ڕاکێشان',
  kmr: 'Bi ragirtin û kişandinê nîşankerê biguhezîne',
  en: 'Hold and drag to move cursor',
  ar: 'تحريك المؤشر بالضغط المطول والسحب',
  fa: 'حرکت مکان‌نما با نگه‌داشتن و کشیدن',
};
const nativeSettings = { ...DEFAULT_SETTINGS, spaceBarLongPressAction: nativeSpaceHold, spaceCursorChoiceV9: true };
const settingsPages = Object.fromEntries(['ckb','kmr','en','ar','fa'].map(lang => [lang, {
  keyboard_prefs: keyboardPreferencesPayload(DEFAULT_SETTINGS),
  gestures: {
    direction: getAppDirection(lang), title: tOfficial(lang, 'settings__gestures__title', 'ئاماژەکان'),
    sections: GESTURE_GROUPS.map(group => ({title: tOfficial(lang, group.titleKey, group.fallback), rows: group.rows.map(row => ({
      key: row.key, title: tOfficial(lang, row.label, row.fallback), value: nativeSettings[row.key], pro: row.pro,
      valueLabel: row.key === 'spaceBarLongPressAction' ? nativeSpaceHoldLabels[lang] : getSwipeActionLabel(DEFAULT_SETTINGS[row.key], lang),
      options: [...(row.key === 'spaceBarLongPressAction' ? [{id: nativeSpaceHold, label: nativeSpaceHoldLabels[lang]}] : []), ...row.options.map(id => ({id,label:getSwipeActionLabel(id,lang)}))]
    }))})),
    thresholds: [
      {key:'swipeDistanceThreshold', title:tOfficial(lang,'pref__gestures__swipe_distance_threshold__label','ماوەی ڕاکێشان'), unit:'dp',options:SWIPE_DISTANCE_THRESHOLDS},
      {key:'swipeVelocityThreshold', title:tOfficial(lang,'pref__gestures__swipe_velocity_threshold__label','ئاستی خێرایی ڕاکێشان'),unit:'dp/s',options:SWIPE_VELOCITY_THRESHOLDS}
    ]
  },
  faq: {direction:getAppDirection(lang), title:tOfficial(lang,'faq__screen_title','ڕێنمایی و پرسیارە باوەکان (FAQ)'),banner:tOfficial(lang,'faq__banner_title','زانیاری گشتی و بەکارهێنان'), appName:tOfficial(lang,'settings__home__display_name','تەختەکلیلی کوردی'),youtube:tOfficial(lang,'faq__button_watch_youtube','بینینی فێرکاری لە یوتوب'),facebook:tOfficial(lang,'faq__social_facebook','فەیسبووک'),items:getFaqItems(lang)},
}])) ;
const ascii = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'];
export const nativeData = {
  core: {
    defaults: { settings: nativeSettings, clipboard: INITIAL_CLIPBOARD, sounds: SOUND_PACKS,
      email: EMAIL_DOMAIN_POPUP_OPTIONS, harakat: ARABIC_HARAKAT_OPTIONS, spaceMenu: SPACEBAR_CUSTOM_MENU_OPTIONS, GESTURE_GROUPS, getSwipeActionLabel, SWIPE_DISTANCE_THRESHOLDS, SWIPE_VELOCITY_THRESHOLDS },
    themes: ALL_THEMES,
    subtypes: ALL_SUBTYPE_PRESETS,
    swipeActions: [...ALL_SWIPE_ACTIONS, nativeSpaceHold],
    languages: [AUTO_DETECT_LANG, ...TRANSLATION_LANGUAGES],
    characterLayouts: CHARACTER_LAYOUT_OPTIONS,
    editableRows: Object.fromEntries(CHARACTER_LAYOUT_OPTIONS.map(({ id }) => [id, getEditableAlphaRows(id)])),
  },
  settingsPages: { pages: settingsPages, storeThemes: STORE_THEMES, extraEditorKeys: EXTRA_EDITOR_KEYS },
  layouts,
  dialects: OFFLINE_DIALECTS,
  icons,
  strings,
  media: {
    categories: EMOJI_CATEGORIES, kaomoji: KAOMOJI_LIST, zikr: ZIKR_CATEGORIES,
    skinTones: EMOJI_SKIN_TONES, hairStyles: EMOJI_HAIR_STYLES, missingFacebook: MISSING_FACEBOOK_BASE_CODES,
    keywords: EMOJI_KEYWORD_MAP,
    names: EMOJI_NAME_LOOKUP,
    decorators: TEXT_DECORATORS.map(({ id, nameKu, preview }) => ({ id, label: nameKu, sample: preview })),
    decorationMaps: Object.fromEntries(TEXT_DECORATORS.filter(({ id }) => id.endsWith('_en')).map(({ id, transform }) =>
      [id, Object.fromEntries(ascii.map(char => [char, transform(char)]))])),
  },
  words: {
    ar: ARABIC_COMMON_WORDS, fa: PERSIAN_COMMON_WORDS, tr: TURKISH_COMMON_WORDS,
    en: ENGLISH_COMMON_WORDS, ckb: KURDISH_SORANI_WORDS,
    nextEnglish: ENGLISH_NEXT_WORDS, nextKurdish: KURDISH_NEXT_WORDS,
  },
};
