import { rewriteQuality } from '../../api/_rewriteQuality';
import { DEFAULT_SETTINGS, INITIAL_CLIPBOARD } from '../data/defaultSettings';
import { hydrateSettings } from '../data/hydrateSettings';
import { composeHangul, EMAIL_DOMAIN_POPUP_OPTIONS, resolveLayoutRows } from '../data/layouts';
import { ARABIC_HARAKAT_OPTIONS, SPACEBAR_CUSTOM_MENU_OPTIONS } from '../data/gestures';
import { findThemeById, ALL_THEMES } from '../data/themes';
import { getKeyShapeStyleProps } from '../data/officialData';
import { buildIndexedDictionary, getBaseDictionaryForLang } from '../data/dictionaries';
import { getKeyboardSuggestions, wordAtEnd } from '../data/keyboardPredictions';
import { EMOJI_CATEGORIES, KAOMOJI_LIST, ZIKR_CATEGORIES, TEXT_DECORATORS, searchEmojis, resolveEmojiWithModifiers } from '../data/richContent';
import { AUTO_DETECT_LANG, filterTranslationLanguages, TRANSLATION_LANGUAGES } from '../data/translationLanguages';
import { detectInlineMath, evaluateSafeMath, formatMathResult, getQuickDateTimeChips } from '../utils/mathAndTime';
import { runOfflineSmartRewrite } from '../utils/kurdishSmartHelper';
import { recordHistoryUsage, togglePinHistoryItem } from '../utils/emojiHistory';
import { SOUND_PACKS } from '../utils/sound';
import vectors from '../data/generated/vectorIcons.json';
import type { KeyboardSettings, KeyboardViewMode, KeySpec } from '../types/keyboard';

interface DeckRequest {
  settings: Partial<KeyboardSettings>;
  mode: KeyboardViewMode;
  shift: 'off' | 'once' | 'caps';
  kana: 'hira' | 'kata';
}

function deck({ settings: stored, mode, shift, kana }: DeckRequest) {
  const settings = hydrateSettings(stored);
  const lang = settings.enabledLanguages.find(item => item.code === settings.activeLanguage) ?? settings.enabledLanguages[0];
  const { rows, direction } = resolveLayoutRows(lang, mode, shift, kana, settings);
  const theme = findThemeById(settings.activeThemeId, settings.customTheme);
  const hGap = Math.max(2, Math.round((settings.keySpacingHorizontal ?? settings.keySpacingPercent) * 3.6 / 50) / 2);
  const vGap = Math.max(3, Math.round((settings.keySpacingVertical ?? settings.keySpacingPercent) * 6 / 100));
  const width = Math.max(72, Math.min(100, settings.keyboardWidthPercent));
  const height = Math.max(110, Math.min(720, settings.keyboardHeightPx));
  const contentScale = Math.max(0.82, Math.min(1.48, (1 + (height / 248 - 1) * 0.65) * Math.max(0.84, width / 100)));
  const fontSize = Math.round(16 * settings.fontSizePercent / 100 * contentScale);
  const iconSize = Math.round(17 * settings.iconSizePercent / 100 * contentScale);
  const hasNumberRow = mode === 'characters' && rows.length >= 6 && (
    settings.numberRowMode === 'always' || (settings.numberRowMode === 'per_language' && lang.numberRow)
  );
  const spaceLabel = settings.spacebarLabelMode === 'none' ? ''
    : settings.spacebarLabelMode === 'custom' ? settings.customSpacebarText
    : lang.characterLayoutId === 'kurdi_hybrid' ? (kana === 'kata' ? 'Kurdî (Latînî)' : 'کوردی')
    : lang.nativeName || 'کوردی';
  const borderWidth = theme.keyBorderWidth ?? (theme.hasKeyBorder ? 1 : 0);
  const border = borderWidth > 0 ? `${borderWidth}px solid ${theme.keyBorder}` : 'none';
  const numeric = mode === 'numeric_advanced';
  const numericPad = numeric || mode === 'phone' || mode === 'phone2';
  const modeKeys = new Set(['symbols', 'symbols2', 'characters', 'numeric_advanced', 'phone', 'phone2']);
  const icons: Record<string, [string, number]> = {
    shift: [shift === 'caps' ? 'ic_shift_lock' : 'ic_shift', 2],
    backspace: ['ic_delete', 3], enter: [numeric ? 'corner_down_left' : 'ic_enter', numeric ? 2 : 3],
    emoji: ['ic_smile', 2], globe: ['ic_global', 2], settings: ['ic_settings', 1],
    copy: ['ic_copy', 0], cut: ['ic_cuts', 0], paste: ['ic_pastes', 0], select_all: ['ic_select_all', 0],
    zwnj: ['ic_zwnj', 1],
  };
  function keyFace(key: KeySpec, isTopNumber: boolean, isLast: boolean) {
    const type = key.type || 'char';
    const tatweel = key.code === 1600;
    const punctuation = type === 'comma' || type === 'period';
    const digits = /^[0-9٠-٩۰-۹]$/.test(key.primary.trim());
    const label = type === 'space' ? spaceLabel : (shift !== 'off' && key.shiftPrimary) || key.primary;
    let bg = theme.keyBg;
    let color = theme.keyText;
    let keyBorder = border;
    if (type === 'enter') {
      bg = theme.enterBg;
      color = theme.enterText;
      keyBorder = theme.enterBorder ? `1px solid ${theme.enterBorder}` : 'none';
    } else if (type === 'space') {
      bg = numeric ? theme.specialKeyBg : theme.spaceBg;
      color = numeric ? theme.accent : theme.spaceText || theme.secondaryText;
    } else if (type === 'shift') {
      bg = shift !== 'off' ? theme.accent : theme.shiftBg || theme.specialKeyBg;
      color = shift !== 'off' ? theme.enterText : theme.shiftText || theme.specialKeyText;
    } else if (type === 'backspace' || tatweel) {
      bg = theme.backspaceBg || theme.specialKeyBg;
      color = theme.backspaceText || theme.specialKeyText;
    } else if (modeKeys.has(type)) {
      bg = theme.symbolsBg || theme.specialKeyBg;
      color = numeric && type === 'characters' ? theme.accent : theme.symbolsText || theme.specialKeyText;
    } else if (type === 'kana_toggle') {
      bg = theme.accent;
      color = theme.enterText;
    } else if (type !== 'char' && !punctuation) {
      bg = theme.specialKeyBg;
      color = theme.specialKeyText;
    } else if (numeric && !digits) {
      bg = theme.specialKeyBg;
    }
    const hasHint = settings.showSecondaryHints && !numericPad && !tatweel && !punctuation &&
      !['space','enter','backspace','shift','emoji','globe'].includes(type) && !['؟','،',':',',','.'].includes(label.trim());
    const hint = hasHint ? key.secondary?.trim() || '' : '';
    const hintLength = hint.replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '').length;
    const hintSize = hintLength <= 2 ? 10.5 : hintLength <= 4 ? 10.3 : hintLength <= 7 ? 9.4 : hintLength <= 10 ? 8.6 : hintLength <= 12 ? 8 : 7.2;
    const icon = tatweel ? ['ic_drezh', 6] as const : numeric && type === 'space' ? ['number_space', 0] as const : icons[type];
    const size = type === 'space' ? Math.round(13 * Math.min(1.28, contentScale))
      : numeric && type === 'characters' ? label.length > 6 ? 11 : 12.5
      : numeric && digits ? Math.round(fontSize * 1.18)
      : numeric && !isLast ? Math.round(fontSize * 1.14)
      : numeric && type === 'symbols' ? Math.max(13, fontSize - 3)
      : ['symbols','symbols2','characters','numeric_advanced','kana_toggle'].includes(type) ? Math.max(12, fontSize - 4)
      : type === 'period' ? Math.max(22, fontSize + 2)
      : isTopNumber ? Math.max(15, fontSize - 3)
      : label.length > 2 ? Math.max(12, fontSize - 4) : fontSize;
    const face = (pressed: boolean) => getKeyShapeStyleProps(settings.keyShapeStyle, theme, bg, keyBorder, theme.keyShadow, type === 'enter', pressed).style;
    return { ...key, type, label, color, hint, hintSize, size, icon: icon?.[0], iconSize: numeric && type === 'space' ? 22 : iconSize + (icon?.[1] || 0),
      labelOffset: hint ? Math.round((hintLength > 2 ? 8 : 6) * contentScale) : type === 'period' && !numeric ? -2 : 0,
      face: face(false), pressed: face(true) };
  }
  return { theme, direction, lang, width, height: height + (hasNumberRow ? 30 : 0),
    hGap: numeric ? Math.max(hGap, 6) : hGap, vGap: numeric ? Math.max(vGap, 7) : vGap,
    rows: rows.map((row, index) => ({
      weight: hasNumberRow && index === 0 ? 0.76 : 1,
      inset: mode === 'characters' && direction === 'ltr' && index < rows.length - 1 && row.length === 9 && row.every(key => !key.type || key.type === 'char') ? 14 : 0,
      keys: row.map(key => keyFace(key, hasNumberRow && index === 0, index === rows.length - 1)),
    })) };
}

let dictionaryKey = '';
let dictionary: ReturnType<typeof buildIndexedDictionary> = [];
type PredictionRequest = {
  settings: Partial<KeyboardSettings>;
  kana: DeckRequest['kana'];
  learned: Record<string, number>;
};

function predictionContext({ settings: partial, kana, learned }: PredictionRequest) {
  const settings = hydrateSettings(partial);
  const lang = settings.enabledLanguages.find(item => item.code === settings.activeLanguage) ?? settings.enabledLanguages[0];
  const latin = lang.dir === 'ltr' && lang.characterLayoutId !== 'qwerty_kurdi' && !(lang.characterLayoutId === 'kurdi_hybrid' && kana === 'hira');
  const personal = settings.personalDictionaryEnabled ? settings.personalDictionary : [];
  const learnedSorted = settings.personalDictionaryEnabled
    ? Object.entries(learned).sort((a, b) => b[1] - a[1]).map(([word]) => word) : [];
  const key = JSON.stringify([settings.activeLanguage, latin, personal, learnedSorted]);
  if (key !== dictionaryKey) {
    dictionaryKey = key;
    dictionary = buildIndexedDictionary([...personal, ...learnedSorted, ...getBaseDictionaryForLang(settings.activeLanguage, latin)]);
  }
  return { settings, dictionary, latin };
}

let preparedPredictions: ReturnType<typeof predictionContext> | undefined;

function predictTail(tail: string, context: ReturnType<typeof predictionContext>) {
  const { settings, dictionary, latin } = context;
  const limited = tail.slice(-80);
  const currentWord = wordAtEnd(limited);
  return { currentWord, items: getKeyboardSuggestions(limited, currentWord, currentWord ? '' : wordAtEnd(limited.trimEnd()), settings, dictionary, latin),
    math: detectInlineMath(limited) };
}

const operations = {
  defaults: () => ({ settings: DEFAULT_SETTINGS, clipboard: INITIAL_CLIPBOARD, sounds: SOUND_PACKS, email: EMAIL_DOMAIN_POPUP_OPTIONS,
    harakat: ARABIC_HARAKAT_OPTIONS, spaceMenu: SPACEBAR_CUSTOM_MENU_OPTIONS }),
  hydrate: hydrateSettings,
  deck,
  predictions: ({ tail, ...options }: PredictionRequest & { tail: string }) => predictTail(tail, predictionContext(options)),
  preparePredictions: (options: PredictionRequest) => { preparedPredictions = predictionContext(options); },
  predictTail: (tail: string) => preparedPredictions ? predictTail(tail, preparedPredictions) : null,
  compose: ({ tail, text }: { tail: string; text: string }) => composeHangul(tail, text),
  icon: (id: keyof typeof vectors) => vectors[id],
  media: () => ({ categories: EMOJI_CATEGORIES, kaomoji: KAOMOJI_LIST, zikr: ZIKR_CATEGORIES }),
  emojiSearch: (query: string) => searchEmojis(query),
  emojiModifier: ({ entry, skin, hair }: { entry: Parameters<typeof resolveEmojiWithModifiers>[0]; skin: string; hair: string }) => resolveEmojiWithModifiers(entry, skin, hair),
  recordHistory: (args: Parameters<typeof recordHistoryUsage>) => recordHistoryUsage(...args),
  togglePin: (args: Parameters<typeof togglePinHistoryItem>) => togglePinHistoryItem(...args),
  themes: () => ALL_THEMES,
  decorators: () => TEXT_DECORATORS.map(({ id, ...item }) => ({ id, label: item.nameKu, sample: item.preview })),
  decorate: ({ id, text }: { id: string; text: string }) => TEXT_DECORATORS.find(item => item.id === id)?.transform(text) ?? text,
  math: (text: string) => { const result = evaluateSafeMath(text); return result === null ? '' : formatMathResult(result); },
  dateTime: () => getQuickDateTimeChips(),
  languages: () => [AUTO_DETECT_LANG, ...TRANSLATION_LANGUAGES],
  filterLanguages: ([query, includeAuto]: [string, boolean]) => filterTranslationLanguages(query, includeAuto),
  offlineRewrite: (args: Parameters<typeof runOfflineSmartRewrite>) => runOfflineSmartRewrite(...args),
  rewriteQuality: (args: Parameters<typeof rewriteQuality>) => rewriteQuality(...args),
};

Object.assign(globalThis, {
  kurdiNativeCall(name: keyof typeof operations, json: string) {
    const operation = operations[name] as (arg: unknown) => unknown;
    return JSON.stringify(operation(JSON.parse(json)) ?? null);
  },
});
