// Dual-layer persistent storage (localStorage + IndexedDB + StorageManager.persist)
// Ensures keyboard state, editor text, settings, and clipboard history survive browser/phone restarts.

const DB_NAME = 'kurdikebord_persistent_db';
const STORE_NAME = 'kv_store';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase | null> | null = null;
type StorageErrorListener = (op: string, key: string, err: unknown) => void;
let storageErrorListener: StorageErrorListener | null = null;

export function setStorageErrorListener(listener: StorageErrorListener | null): void {
  storageErrorListener = listener;
}

function notifyStorageError(op: string, key: string, err: unknown): void {
  try {
    storageErrorListener?.(op, key, err);
  } catch {
    // Never let diagnostic hooks throw inside storage layer
  }
}

function openDB(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      let finished = false;
      const finish = (db: IDBDatabase | null) => { if (finished) { db?.close(); return; } finished = true; clearTimeout(timer); resolve(db); };
      const timer = setTimeout(() => finish(null), 3000);
      try {
        const req = window.indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME);
          }
        };
        req.onsuccess = () => { const db = req.result; db.onversionchange = () => { db.close(); dbPromise = null; }; db.onclose = () => { dbPromise = null; }; finish(db); };
        req.onblocked = () => finish(null);
        req.onerror = () => {
          notifyStorageError('openDB', DB_NAME, req.error);
          finish(null);
        };
      } catch (err) {
        notifyStorageError('openDB', DB_NAME, err);
        finish(null);
      }
    });
  }
  return dbPromise.then(db => { if (!db) dbPromise = null; return db; });
}

export async function requestPersistentStorage(): Promise<'granted' | 'denied' | 'unsupported'> {
  try {
    if (typeof navigator !== 'undefined' && navigator.storage?.persist) {
      const granted = await navigator.storage.persist();
      return granted ? 'granted' : 'denied';
    }
    return 'unsupported';
  } catch (err) {
    notifyStorageError('storage.persist', 'navigator.storage', err);
    return 'unsupported';
  }
}

export async function idbSet<T>(key: string, value: T): Promise<boolean> {
  const db = await openDB();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onabort = () => resolve(false);
      tx.onerror = () => {
        notifyStorageError('idbSet', key, tx.error);
        resolve(false);
      };
    } catch (err) {
      notifyStorageError('idbSet', key, err);
      resolve(false);
    }
  });
}

export async function idbGet<T>(key: string): Promise<T | undefined> {
  const db = await openDB();
  if (!db) return undefined;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      tx.onabort = () => resolve(undefined);
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = () => resolve(req.result as T | undefined);
      req.onerror = () => {
        notifyStorageError('idbGet', key, req.error);
        resolve(undefined);
      };
    } catch (err) {
      notifyStorageError('idbGet', key, err);
      resolve(undefined);
    }
  });
}

export async function idbDelete(key: string): Promise<boolean> {
  const db = await openDB();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onabort = () => resolve(false);
      tx.onerror = () => {
        notifyStorageError('idbDelete', key, tx.error);
        resolve(false);
      };
    } catch (err) {
      notifyStorageError('idbDelete', key, err);
      resolve(false);
    }
  });
}

// Preserve the existing primary keys for interoperability with earlier WebViews.
// A versioned last-known-good copy is consulted only if the primary is invalid.
type JsonKind = 'object' | 'array';
const NATIVE_SETTINGS_KEY = 'kurdikebord_settings_v2';
function nativeSettingsBridge(): {readNativeSettings?:()=>string;writeNativeSettings?:(raw:string)=>boolean}|undefined {
  if(typeof window==='undefined')return undefined;
  const host=window as any; return host.AndroidIME || host.AndroidAppSetup;
}
function mirrorSettings(key:string,raw:string):void {
  if(key!==NATIVE_SETTINGS_KEY)return;
  try { nativeSettingsBridge()?.writeNativeSettings?.(raw); } catch { /* legacy browser */ }
}
function validJson(raw: string | null, kind: JsonKind): raw is string {
  if (typeof raw !== 'string') return false;
  try { const value = JSON.parse(raw); return kind === 'array' ? Array.isArray(value) : value !== null && typeof value === 'object' && !Array.isArray(value); }
  catch { return false; }
}
export function readVersioned(key: string, kind: JsonKind): string | null {
  try {
    const current = localStorage.getItem(key);
    if (validJson(current,kind)) return current;
  } catch { /* IndexedDB remains a separate fallback. */ }
  if(key===NATIVE_SETTINGS_KEY) try {
    const raw=nativeSettingsBridge()?.readNativeSettings?.() || null;
    if(validJson(raw,kind)) return raw;
  } catch { /* IndexedDB fallback */ }
  try { const backup = JSON.parse(localStorage.getItem(key + ":recovery") || "null"); if (backup?.version === 1 && validJson(backup.payload,kind)) return backup.payload; } catch {}
  return null;
}
export function writeVersioned(key: string, raw: string, kind: JsonKind): void {
  if (!validJson(raw,kind)) throw new Error('invalid_storage_shape');
  let previous: string | null = null;
  try { previous = localStorage.getItem(key); } catch { /* Native mirror can still succeed. */ }
  if (previous === raw) { mirrorSettings(key,raw); return; }
  // Never overwrite a good recovery copy with malformed data. Backup failure must
  // not prevent the primary atomic write (e.g. localStorage quota pressure).
  if (validJson(previous,kind)) {
    try { localStorage.setItem(key + ':recovery', JSON.stringify({version:1,payload:previous})); }
    catch { /* primary write below may still succeed */ }
  }
  mirrorSettings(key,raw);
  localStorage.setItem(key,raw);
}

/** Versioned settings-only export; accepts unversioned legacy backups. */
export function serializeSettingsBackup(settings: object): string {
  return JSON.stringify({format:'kurdikeyboard-settings',version:1,settings},null,2);
}
export function parseSettingsBackup(raw: string): Record<string, unknown> {
  const parsed = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('invalid_backup');
  if (parsed.format === 'kurdikeyboard-settings') {
    if (parsed.version !== 1 || !parsed.settings || typeof parsed.settings !== 'object' || Array.isArray(parsed.settings)) throw new Error('unsupported_backup');
    return parsed.settings;
  }
  return parsed;
}
