/** One gesture owner; all other fingers retain independent tap sessions. */
export class PointerSessions {
  private sessions = new Map<number, {key:string; x:number; y:number; owner:boolean}>();
  private owner: number | null = null;
  begin(id:number,key:string,x:number,y:number):boolean {
    if (this.sessions.has(id)) return false;
    const owner = this.owner === null && this.sessions.size === 0;
    if (owner) this.owner=id;
    this.sessions.set(id,{key,x,y,owner});
    return owner;
  }
  isOwner(id:number):boolean { return this.owner===id && this.sessions.has(id); }
  end(id:number) { const session=this.sessions.get(id); this.sessions.delete(id); if(this.owner===id) this.owner=null; return session; }
  clear() { this.sessions.clear(); this.owner=null; }
}
/** Unicode-safe common prefix for verified suffix edits. */
export function suffixEdit(previous:string,next:string) {
  let common=0;
  while(common<previous.length && common<next.length && previous[common]===next[common]) common++;
  if(common>0 && /[\uD800-\uDBFF]/.test(previous[common-1])) common--;
  return {expected:previous.slice(common),replacement:next.slice(common)};
}
