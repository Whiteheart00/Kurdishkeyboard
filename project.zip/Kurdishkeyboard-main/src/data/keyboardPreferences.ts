import { BOTTOM_ROW_PRESETS, NUMBER_STYLE_OPTIONS } from './layouts';
import { KeyboardSettings } from '../types/keyboard';

export const PREF_SWITCHES = [
  { key: 'keyAnimation', title: 'کاریگەری جوڵان', subtitle: 'پیشاندانی ئەنیمەیشنی جوڵەی پیتەکان لەکاتی نووسیندا', pro: true, icon: 'ic_smart' },
  { key: 'dynamicBackgroundGlow', title: 'ڕەنگی داینامیکی پاشبنەما', subtitle: 'گۆڕینی ڕەنگی پشتەوە بە خۆکاری لەکاتی دەستلێدان', pro: true, icon: 'ic_themes' },
  { key: 'keyPopupPreview', title: 'بچووککراوەی پیت', subtitle: 'پیشاندانی بچووککراوەی پیت لەکاتی نووسین', pro: false, icon: 'ic_number' },
  { key: 'showSecondaryHints', title: 'پیتە لاوەکییەکانی خانەی دووەم', subtitle: 'نیشاندانی پیتە لاوەکییەکان وەک (ص، ض، ث، ذ) لەسەر پیتە سەرەکییەکان', pro: false, icon: 'ic_keyboards' },
  { key: 'showBottomKeys', title: 'دوگمەکانی خوارەوە', subtitle: 'پیشاندان/شاردنەوەی دوگمە بنەڕەتیەکانی بەشی خوارەوە', pro: false, icon: 'ic_keyboards' },
  { key: 'showGlobeKey', title: 'دوگمەی زمان', subtitle: 'نیشاندانی دوگمەی گۆڕینی زمان لە ڕیزی خوارەوە', pro: false, icon: 'ic_language' },
  { key: 'showLanguagePickerOnLongPress', title: 'پیشاندانی لیستی زمانەکان', subtitle: 'پیشاندانی لیستێکی خێرا بۆ زمانەکان لەکاتی دەستڕاگرتن لەسەر دوگمەی گۆڕینی زمان', pro: false, icon: 'layout_list' },
  { key: 'showEmojiKey', title: 'دوگمەی خەندە', subtitle: 'نیشاندانی دوگمەی ئیمۆجی و زیکر لە خوارەوە', pro: false, icon: 'ic_emoji' },
  { key: 'showCommaKey', title: 'دوگمەی فاریزە', subtitle: 'نیشاندانی دوگمەی فاریزە لە تەنیشت دوگمەی بۆشایی', pro: false, icon: 'ic_number' },
  { key: 'swapGlobeAndEmoji', title: 'پێچەوانەکردنی دوگمەکان', subtitle: 'شوێنی دوگمەی زمان و ئیمۆجی پێچەوانە دەکرێتەوە', pro: false, icon: 'ic_swipe' },
  { key: 'showTopToolbar', title: 'شریتی ئامرازەکانی سەرەوە', subtitle: 'پیشاندانی شریتی کۆپی، لکاندن و جووڵاندنی کێرسەر لە سەرەوەی کیبۆرد', pro: false, icon: 'ic_clipboards' },
  { key: 'spaceBarSwitchesToCharacters', title: 'گەڕانەوە بۆ پیتەکان بە دوگمەی بۆشایی', subtitle: 'دوای داگرتنی بۆشایی لە بەشی هێماکاندا خۆکارانە دەگەڕێتەوە سەر پیتەکان', pro: false, icon: 'ic_keyboards' },
  { key: 'autoCapitalization', title: 'پیتی گەورەی خۆکار (Auto-Cap)', subtitle: 'یەکەم پیتی هەر ڕستەیەک لە زمانە لاتینییەکاندا خۆکارانە گەورە دەکات', pro: false, icon: 'ic_number' },
  { key: 'autoSpacePunctuation', title: 'بۆشایی خۆکار دوای خاڵبەندی', subtitle: 'دانانی بۆشایی خۆکار دوای نووسینی (، . ؟ !)', pro: false, icon: 'ic_smart' },
  { key: 'flyingLettersEnabled', title: 'فڕینی پیتەکان لەکاتی نووسین', subtitle: 'کاریگەری بەرزبوونەوەی پیت بە شێوەیەکی جوان لەکاتی دەستلێدان', pro: false, icon: 'ic_smart' },
] as const;

export const PREF_OPTIONS = [
  { key: 'numberRowMode', title: 'ڕیزی ژمارەکانی سەرەوە', columns: 3, options: [
    { id: 'per_language', label: 'بەپێی زمان' }, { id: 'always', label: 'هەمیشە هەبێت' }, { id: 'never', label: 'شاراوە بێت' },
  ] },
  { key: 'capitalizationBehavior', title: 'شێوازی قفڵکردنی پیتی گەورە (Caps Lock)', columns: 2, options: [
    { id: 'capslock_by_double_tap', label: 'دوو جار داگرتن' }, { id: 'capslock_by_cycle', label: 'گۆڕینی یەکبەدوایەک' },
  ] },
  { key: 'bottomRowPreset', title: 'شێوازی ڕیزی خوارەوە', columns: 2,
    options: BOTTOM_ROW_PRESETS.map(({ id, labelKu }) => ({ id, label: labelKu })) },
  { key: 'spacebarLabelMode', title: 'ناوی سەر دوگمەی بۆشایی', columns: 3, options: [
    { id: 'language', label: 'ناوی زمان' }, { id: 'none', label: 'بێ ناو' }, { id: 'custom', label: 'ناوی تایبەت' },
  ] },
] as const;

export const PREF_RANGES = [
  { key: 'fontSizePercent', title: 'قیاسی فۆنت', min: 80, max: 160, step: 1, unit: '%', initial: 100 },
  { key: 'iconSizePercent', title: 'قەبارەی ئایکۆنەکان', min: 80, max: 160, step: 1, unit: '%', initial: 100 },
  { key: 'keySpacingHorizontal', title: 'مەودای ئاسۆیی نێوان دوگمەکان', min: 50, max: 160, step: 1, unit: '%', initial: 100 },
  { key: 'keySpacingVertical', title: 'مەودای ستوونی نێوان ڕیزەکان', min: 50, max: 160, step: 1, unit: '%', initial: 100 },
  { key: 'longPressDelayMs', title: 'ماوەی دەستڕاگرتن لەسەر پیتەکان', min: 150, max: 600, step: 10, unit: ' ms', initial: 300 },
  { key: 'flyingLettersSizeMultiplier', title: 'قەبارەی پیتە فڕیوەکان', min: 60, max: 140, step: 5, unit: '%', initial: 90 },
] as const;

export function keyboardPreferencesPayload(settings: KeyboardSettings) {
  const { proUnlocked, notificationsEnabled, customSpacebarText, numberStyle } = settings;
  return {
    proUnlocked, notificationsEnabled, customSpacebarText, numberStyle,
    numberStyles: NUMBER_STYLE_OPTIONS.map(({ id, labelKu }) => ({ id, label: labelKu })),
    switches: PREF_SWITCHES.map((row) => ({
      ...row,
      value: row.key === 'autoCapitalization' || row.key === 'spaceBarSwitchesToCharacters'
        ? settings[row.key] !== false : Boolean(settings[row.key]),
    })),
    options: PREF_OPTIONS.map((row) => ({ ...row, value: settings[row.key] ?? row.options[0]?.id })),
    ranges: PREF_RANGES.map((row) => ({
      ...row,
      value: settings[row.key] ?? (row.key === 'keySpacingHorizontal' || row.key === 'keySpacingVertical'
        ? settings.keySpacingPercent : row.initial),
    })),
  };
}

export function keyboardPreferencePatch(key: string, value: string | boolean | number): Partial<KeyboardSettings> | undefined {
  if (typeof value === 'boolean') {
    if (key === 'notificationsEnabled' || PREF_SWITCHES.some((row) => row.key === key)) return { [key]: value };
  }
  if (typeof value === 'number') {
    const range = PREF_RANGES.find((row) => row.key === key);
    if (range && value >= range.min && value <= range.max && (value - range.min) % range.step === 0) {
      return key === 'keySpacingHorizontal' ? { keySpacingHorizontal: value, keySpacingPercent: value } : { [key]: value };
    }
  }
  if (typeof value === 'string') {
    const option = PREF_OPTIONS.find((row) => row.key === key);
    if (option?.options.some(({ id }) => id === value)) return { [key]: value };
    if (key === 'numberStyle' && NUMBER_STYLE_OPTIONS.some(({ id }) => id === value)) return { numberStyle: value as KeyboardSettings['numberStyle'] };
    if (key === 'customSpacebarText') return { customSpacebarText: value };
  }
}
