import type { KeyboardSettings } from '../types/keyboard';
import { getNextWordPredictions, normalizeForPrediction, queryDictionarySuggestions } from './dictionaries';
import type { RankedWordEntry } from './dictionaries';
import { EMAIL_DOMAIN_POPUP_OPTIONS } from './layouts';
import { EMOJI_KEYWORD_MAP, EMOJI_NAME_LOOKUP, searchEmojis } from './richContent';

export function wordAtEnd(text: string): string {
  return text.match(/([^\s.,!?؟،:;()[\]{}"'«»]+)$/)?.[1] ?? '';
}

export function getKeyboardSuggestions(
  editorTail: string,
  currentWord: string,
  previousWord: string,
  settings: KeyboardSettings,
  indexedDictionaryPool: RankedWordEntry[],
  isLatinLike: boolean,
) {
  const shortcutsEnabled = settings.textShortcutsEnabled ?? true;
  if (!settings.wordSuggestions && !shortcutsEnabled && !settings.emojiSuggestions) return [];

  const results: {
    value: string;
    displayLabel?: string;
    isShortcut?: boolean;
    shortcutKey?: string;
    isEmail?: boolean;
    isEmoji?: boolean;
    replaceLength?: number;
  }[] = [];
  const seen = new Set<string>();

  // 0. Live Email Domain Suggestions when typing after "@" (e.g. "name@" or "name@g")
  const emailMatch = editorTail.match(/([^\s]*@)([a-zA-Z0-9.-]*)$/);
  if (emailMatch) {
    const partialDomain = (emailMatch[2] || '').toLowerCase();
    for (const opt of EMAIL_DOMAIN_POPUP_OPTIONS) {
      const domainWithoutAt = opt.value.slice(1);
      if (!partialDomain || domainWithoutAt.startsWith(partialDomain)) {
        if (!seen.has(opt.value)) {
          seen.add(opt.value);
          results.push({ value: opt.value, isEmail: true });
          if (results.length >= 8) break;
        }
      }
    }
    if (results.length > 0) return results;
  }

  // 0.5 Leading-Colon Emoji Suggestions (e.g. ":دڵ" or ":heart")
  if (settings.emojiSuggestions && settings.emojiSuggestionType === 'leading_colon') {
    const colonMatch = editorTail.match(/:([^\s:]{1,24})$/);
    const minLen = Math.max(1, settings.emojiSuggestionQueryMinLength || 2);
    if (colonMatch && colonMatch[1].length >= minLen) {
      const q = colonMatch[1];
      const maxEmoji = Math.max(1, Math.min(5, settings.emojiSuggestionMaxCount || 3));
      const directHits =
        EMOJI_KEYWORD_MAP[q.toLowerCase()] ||
        EMOJI_KEYWORD_MAP[q] ||
        EMOJI_KEYWORD_MAP[normalizeForPrediction(q)] ||
        [];
      const fallbackHits =
        directHits.length < maxEmoji ? searchEmojis(q, maxEmoji + 2).map((e) => e.c) : [];
      const combined = Array.from(new Set([...directHits, ...fallbackHits])).slice(0, maxEmoji);
      for (const em of combined) {
        if (!seen.has(em)) {
          seen.add(em);
          const name = settings.emojiSuggestionShowName ? EMOJI_NAME_LOOKUP[em] : undefined;
          results.push({
            value: em,
            displayLabel: name ? `${em} ${name}` : em,
            isEmoji: true,
            replaceLength: colonMatch[0].length,
          });
        }
      }
      if (results.length > 0) return results;
    }
  }

  // 1. Custom Text Shortcuts (Exact match first, then prefix match)
  if (shortcutsEnabled && currentWord && Array.isArray(settings.textShortcuts)) {
    const lower = currentWord.toLowerCase();
    const normCurrent = normalizeForPrediction(currentWord);
    const exactMatches = settings.textShortcuts.filter((sc) => {
      const k = sc.shortcut.trim().toLowerCase();
      return k === lower || normalizeForPrediction(k) === normCurrent;
    });
    const prefixMatches = settings.textShortcuts.filter((sc) => {
      const k = sc.shortcut.trim().toLowerCase();
      return (
        k !== lower &&
        normalizeForPrediction(k) !== normCurrent &&
        (k.startsWith(lower) || normalizeForPrediction(k).startsWith(normCurrent))
      );
    });

    for (const sc of [...exactMatches, ...prefixMatches]) {
      if (sc.expansion && !seen.has(sc.expansion)) {
        seen.add(sc.expansion);
        results.push({
          value: sc.expansion,
          isShortcut: true,
          shortcutKey: sc.shortcut,
        });
        if (results.length >= 3) break;
      }
    }
  }

  if (!settings.wordSuggestions) {
    return results;
  }

  // 2. Inline-Text Emoji suggestions for current word
  if (
    settings.emojiSuggestions &&
    (settings.emojiSuggestionType || 'inline_text') === 'inline_text' &&
    currentWord &&
    currentWord.length >= Math.max(1, settings.emojiSuggestionQueryMinLength || 2)
  ) {
    const maxEmoji = Math.max(1, Math.min(5, settings.emojiSuggestionMaxCount || 3));
    const emojiHits =
      EMOJI_KEYWORD_MAP[currentWord.toLowerCase()] ||
      EMOJI_KEYWORD_MAP[currentWord] ||
      EMOJI_KEYWORD_MAP[normalizeForPrediction(currentWord)];
    if (emojiHits) {
      for (const em of emojiHits.slice(0, maxEmoji)) {
        if (!seen.has(em)) {
          seen.add(em);
          const name = settings.emojiSuggestionShowName ? EMOJI_NAME_LOOKUP[em] : undefined;
          results.push({
            value: em,
            displayLabel: name ? `${em} ${name}` : em,
            isEmoji: true,
          });
        }
      }
    }
  }

  if (currentWord) {
    const matches = queryDictionarySuggestions(indexedDictionaryPool, currentWord, 6, seen);
    for (const w of matches) {
      seen.add(w);
      results.push({ value: w });
    }
    // If user typed a brand-new word not in dictionary yet, still offer quick-save/confirm chip so bar never looks dead
    if (results.length === 0 && currentWord.length >= 2) {
      results.push({ value: currentWord });
    }
  } else {
    // Next-word bi-gram prediction right after a space (e.g. "سڵاو " -> "هاوڕێ", "چۆنیت"...)
    const nextWords = getNextWordPredictions(previousWord, settings.activeLanguage, isLatinLike);
    for (const w of nextWords) {
      if (!seen.has(w)) {
        seen.add(w);
        results.push({ value: w });
      }
    }

    const defaults =
      settings.activeLanguage === 'ar'
        ? ['السلام', 'شكرا', 'مرحبا', 'إن شاء الله']
        : settings.activeLanguage === 'fa'
        ? ['سلام', 'ممنون', 'خوبی', 'لطفا']
        : settings.activeLanguage === 'tr'
        ? ['Merhaba', 'Teşekkürler', 'Nasılsın', 'Tamam']
        : isLatinLike
        ? ['Hello', 'Thanks', 'Please', 'Kurdistan', 'Awesome']
        : ['سڵاو', 'سوپاس', 'چۆنیت', 'دەستخۆش', 'کوردستان'];
    for (const w of defaults) {
      if (!seen.has(w) && results.length < 6) {
        seen.add(w);
        results.push({ value: w });
      }
    }
  }

  return results.slice(0, 6);
}
