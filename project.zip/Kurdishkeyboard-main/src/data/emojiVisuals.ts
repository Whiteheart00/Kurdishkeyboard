// Exact 51 emojis where emoji-datasource-facebook@16.0.0 has_img_facebook === false.
// Pre-skipping them avoids HTTP 404 / net::ERR_BLOCKED_BY_ORB in Android WebView and falls back instantaneously.
export const MISSING_FACEBOOK_BASE_CODES = [
  '0023-fe0f-20e3', '002a-fe0f-20e3', '0030-fe0f-20e3', '0031-fe0f-20e3',
  '0032-fe0f-20e3', '0033-fe0f-20e3', '0034-fe0f-20e3', '0035-fe0f-20e3',
  '0036-fe0f-20e3', '0037-fe0f-20e3', '0038-fe0f-20e3', '0039-fe0f-20e3',
  '00a9-fe0f', '00ae-fe0f', '1f1e8-1f1f6', '1f344-200d-1f7eb', '1f34b-200d-1f7e9',
  '1f3c3-200d-2640-fe0f-200d-27a1-fe0f', '1f3c3-200d-2642-fe0f-200d-27a1-fe0f',
  '1f3c3-200d-27a1-fe0f', '1f426-200d-1f525', '1f441-fe0f-200d-1f5e8-fe0f',
  '1f468-200d-1f9af-200d-27a1-fe0f', '1f468-200d-1f9bc-200d-27a1-fe0f',
  '1f468-200d-1f9bd-200d-27a1-fe0f', '1f469-200d-1f9af-200d-27a1-fe0f',
  '1f469-200d-1f9bc-200d-27a1-fe0f', '1f469-200d-1f9bd-200d-27a1-fe0f',
  '1f642-200d-2194-fe0f', '1f642-200d-2195-fe0f',
  '1f6b6-200d-2640-fe0f-200d-27a1-fe0f', '1f6b6-200d-2642-fe0f-200d-27a1-fe0f',
  '1f6b6-200d-27a1-fe0f', '1f9ce-200d-2640-fe0f-200d-27a1-fe0f',
  '1f9ce-200d-2642-fe0f-200d-27a1-fe0f', '1f9ce-200d-27a1-fe0f',
  '1f9d1-200d-1f9af-200d-27a1-fe0f', '1f9d1-200d-1f9bc-200d-27a1-fe0f',
  '1f9d1-200d-1f9bd-200d-27a1-fe0f', '1f9d1-200d-1f9d1-200d-1f9d2',
  '1f9d1-200d-1f9d1-200d-1f9d2-200d-1f9d2', '1f9d1-200d-1f9d2-200d-1f9d2',
  '1f9d1-200d-1f9d2', '1fa89', '1fa8f', '1fabe', '1fac6', '1fadc', '1fadf',
  '1fae9', '263b-fe0f', '26d3-fe0f-200d-1f4a5',
];
