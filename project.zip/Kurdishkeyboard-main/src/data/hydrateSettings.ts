import type { AppLanguageCode, KeyboardSettings, LanguageConfig } from '../types/keyboard';
import { DEFAULT_QUICK_SNIPPETS, DEFAULT_SETTINGS, DEFAULT_TOOLS_ORDER } from './defaultSettings';
import { normalizeSwipeAction } from './gestures';
import { findSubtypePreset } from './layouts';

export function hydrateSettings(partial: Partial<KeyboardSettings>): KeyboardSettings {
  const merged: KeyboardSettings = { ...DEFAULT_SETTINGS, ...partial };
  const values = merged as unknown as Record<string, unknown>;
  for (const [key, fallback] of Object.entries(DEFAULT_SETTINGS)) {
    const value = values[key];
    if (Array.isArray(fallback) ? !Array.isArray(value) : fallback !== null && fallback !== undefined && (typeof fallback !== typeof value || (typeof fallback === 'object' && value === null))) values[key] = fallback;
    if (typeof fallback === 'number' && !Number.isFinite(values[key])) values[key] = fallback;
  }
  const validLangs: AppLanguageCode[] = ['ckb', 'kmr', 'en', 'ar', 'fa'];
  if (!validLangs.includes(merged.appLanguage)) {
    merged.appLanguage = 'ckb';
  }
  if (!merged.keyShapeStyle) {
    merged.keyShapeStyle = 'default';
  }
  if (typeof window !== 'undefined' && merged.keyboardHeightPx === 292) {
    try {
      if (!window.localStorage.getItem('kurdikebord_compact_ui_v1')) {
        merged.keyboardHeightPx = DEFAULT_SETTINGS.keyboardHeightPx;
        window.localStorage.setItem('kurdikebord_compact_ui_v1', '1');
      }
    } catch {
      // ignore storage errors
    }
  }
  if (typeof merged.textShortcutsEnabled !== 'boolean') {
    merged.textShortcutsEnabled = DEFAULT_SETTINGS.textShortcutsEnabled;
  }
  if (!Array.isArray(merged.textShortcuts)) {
    merged.textShortcuts = DEFAULT_SETTINGS.textShortcuts;
  }
  if (typeof merged.aiServerUrl !== 'string') {
    merged.aiServerUrl = '';
  }
  if (!Array.isArray(merged.quickSnippets)) {
    merged.quickSnippets = DEFAULT_QUICK_SNIPPETS;
  }
  if (Array.isArray(merged.toolsOrder)) {
    const missingTools = DEFAULT_TOOLS_ORDER.filter((t) => !merged.toolsOrder.includes(t));
    if (missingTools.length > 0) {
      merged.toolsOrder = [...missingTools, ...merged.toolsOrder];
    }
  } else {
    merged.toolsOrder = DEFAULT_TOOLS_ORDER;
  }
  if (Array.isArray(merged.enabledLanguages) && merged.enabledLanguages.length > 0) {
    merged.enabledLanguages = merged.enabledLanguages.filter(lang => lang && typeof lang === 'object').map((lang: Partial<LanguageConfig>) => {
      const preset = findSubtypePreset(lang.code || 'ckb');
      return { ...preset, ...lang } as LanguageConfig;
    });
  } else {
    merged.enabledLanguages = DEFAULT_SETTINGS.enabledLanguages;
  }
  if (!merged.enabledLanguages.length) merged.enabledLanguages = DEFAULT_SETTINGS.enabledLanguages;
  if (!merged.enabledLanguages.some((l) => l.code === merged.activeLanguage)) {
    merged.activeLanguage = merged.enabledLanguages[0].code;
  }
  // Normalize & migrate all 12 official KurdiKebord gesture preferences
  merged.swipeUpAction = normalizeSwipeAction(partial.swipeUpAction, DEFAULT_SETTINGS.swipeUpAction);
  merged.swipeDownAction = normalizeSwipeAction(partial.swipeDownAction, DEFAULT_SETTINGS.swipeDownAction);
  merged.swipeLeftAction = normalizeSwipeAction(partial.swipeLeftAction, DEFAULT_SETTINGS.swipeLeftAction);
  merged.swipeRightAction = normalizeSwipeAction(partial.swipeRightAction, DEFAULT_SETTINGS.swipeRightAction);
  merged.spaceBarSwipeUpAction = normalizeSwipeAction(
    partial.spaceBarSwipeUpAction,
    DEFAULT_SETTINGS.spaceBarSwipeUpAction
  );
  const legacySpaceLeft =
    partial.spaceBarSwipeLeftAction ??
    (partial.spacebarSwipeAction === 'move_cursor'
      ? 'move_cursor_left'
      : partial.spacebarSwipeAction === 'none'
      ? 'no_action'
      : undefined);
  const legacySpaceRight =
    partial.spaceBarSwipeRightAction ??
    (partial.spacebarSwipeAction === 'move_cursor'
      ? 'move_cursor_right'
      : partial.spacebarSwipeAction === 'none'
      ? 'no_action'
      : undefined);
  merged.spaceBarSwipeLeftAction = normalizeSwipeAction(
    legacySpaceLeft,
    DEFAULT_SETTINGS.spaceBarSwipeLeftAction
  );
  merged.spaceBarSwipeRightAction = normalizeSwipeAction(
    legacySpaceRight,
    DEFAULT_SETTINGS.spaceBarSwipeRightAction
  );
  merged.spaceBarLongPressAction = normalizeSwipeAction(
    partial.spaceBarLongPressAction,
    DEFAULT_SETTINGS.spaceBarLongPressAction
  );
  const legacyDelSwipe =
    partial.deleteKeySwipeLeftAction ??
    (partial.backspaceSwipeDeleteWord === false ? 'no_action' : undefined);
  merged.deleteKeySwipeLeftAction = normalizeSwipeAction(
    legacyDelSwipe,
    DEFAULT_SETTINGS.deleteKeySwipeLeftAction
  );
  merged.deleteKeyLongPressAction = normalizeSwipeAction(
    partial.deleteKeyLongPressAction,
    DEFAULT_SETTINGS.deleteKeyLongPressAction
  );
  if (typeof merged.swipeDistanceThreshold !== 'number' || merged.swipeDistanceThreshold < 16) {
    merged.swipeDistanceThreshold = DEFAULT_SETTINGS.swipeDistanceThreshold;
  }
  if (typeof merged.swipeVelocityThreshold !== 'number' || merged.swipeVelocityThreshold < 50) {
    merged.swipeVelocityThreshold = DEFAULT_SETTINGS.swipeVelocityThreshold;
  }
  // Hydrate upgraded emoji system settings safely for existing users
  if (typeof merged.emojiHairStyle !== 'string') {
    merged.emojiHairStyle = DEFAULT_SETTINGS.emojiHairStyle;
  }
  if (typeof merged.emojiFontSizePx !== 'number' || merged.emojiFontSizePx < 16) {
    merged.emojiFontSizePx = DEFAULT_SETTINGS.emojiFontSizePx;
  }
  if (typeof merged.zikrFontSizePx !== 'number' || merged.zikrFontSizePx < 9) {
    merged.zikrFontSizePx = DEFAULT_SETTINGS.zikrFontSizePx;
  }
  if (!Array.isArray(merged.emojiCategoryOrder) || merged.emojiCategoryOrder.length === 0) {
    merged.emojiCategoryOrder = DEFAULT_SETTINGS.emojiCategoryOrder;
  }
  if (!Array.isArray(merged.emojiDisabledCategories)) {
    merged.emojiDisabledCategories = [];
  }
  if (!Array.isArray(merged.emojiPinned)) {
    merged.emojiPinned = DEFAULT_SETTINGS.emojiPinned;
  }
  if (!Array.isArray(merged.kaomojiPinned)) {
    merged.kaomojiPinned = DEFAULT_SETTINGS.kaomojiPinned;
  }
  if (!merged.zikrHistories || typeof merged.zikrHistories !== 'object') {
    merged.zikrHistories = DEFAULT_SETTINGS.zikrHistories;
  } else {
    merged.zikrHistories = {
      duaa: merged.zikrHistories.duaa || DEFAULT_SETTINGS.zikrHistories.duaa,
      quran: merged.zikrHistories.quran || DEFAULT_SETTINGS.zikrHistories.quran,
      salawat: merged.zikrHistories.salawat || DEFAULT_SETTINGS.zikrHistories.salawat,
    };
  }
  // Hydrate frame-resize geometry & KurdiKeyboard original preferences safely
  if (typeof merged.keySpacingHorizontal !== 'number') {
    merged.keySpacingHorizontal =
      typeof merged.keySpacingPercent === 'number'
        ? merged.keySpacingPercent
        : DEFAULT_SETTINGS.keySpacingHorizontal;
  }
  if (typeof merged.keySpacingVertical !== 'number') {
    merged.keySpacingVertical =
      typeof merged.keySpacingPercent === 'number'
        ? merged.keySpacingPercent
        : DEFAULT_SETTINGS.keySpacingVertical;
  }
  if (typeof merged.keyboardWidthPercent !== 'number' || merged.keyboardWidthPercent < 70 || merged.keyboardWidthPercent > 100) {
    merged.keyboardWidthPercent = DEFAULT_SETTINGS.keyboardWidthPercent;
  }
  if (typeof merged.keyboardBottomOffsetPx !== 'number' || merged.keyboardBottomOffsetPx < 0 || merged.keyboardBottomOffsetPx > 96) {
    merged.keyboardBottomOffsetPx = DEFAULT_SETTINGS.keyboardBottomOffsetPx;
  }
  if (typeof merged.keyboardHorizontalOffsetPx !== 'number' || merged.keyboardHorizontalOffsetPx < -80 || merged.keyboardHorizontalOffsetPx > 80) {
    merged.keyboardHorizontalOffsetPx = DEFAULT_SETTINGS.keyboardHorizontalOffsetPx;
  }
  if (!['always', 'per_language', 'never'].includes(merged.numberRowMode)) {
    merged.numberRowMode = DEFAULT_SETTINGS.numberRowMode;
  }
  if (typeof merged.longPressDelayMs !== 'number' || merged.longPressDelayMs < 150 || merged.longPressDelayMs > 600) {
    merged.longPressDelayMs = DEFAULT_SETTINGS.longPressDelayMs;
  }
  if (typeof merged.spaceBarSwitchesToCharacters !== 'boolean') {
    merged.spaceBarSwitchesToCharacters = DEFAULT_SETTINGS.spaceBarSwitchesToCharacters;
  }
  if (!['capslock_by_double_tap', 'capslock_by_cycle'].includes(merged.capitalizationBehavior)) {
    merged.capitalizationBehavior = DEFAULT_SETTINGS.capitalizationBehavior;
  }
  if (typeof merged.flyingLettersEnabled !== 'boolean') {
    merged.flyingLettersEnabled = DEFAULT_SETTINGS.flyingLettersEnabled;
  }
  if (typeof merged.flyingLettersSizeMultiplier !== 'number' || merged.flyingLettersSizeMultiplier < 60) {
    merged.flyingLettersSizeMultiplier = DEFAULT_SETTINGS.flyingLettersSizeMultiplier;
  }
  if (typeof merged.autoCapitalization !== 'boolean') {
    merged.autoCapitalization = DEFAULT_SETTINGS.autoCapitalization;
  }
  if (typeof merged.autoSpacePunctuation !== 'boolean') {
    merged.autoSpacePunctuation = DEFAULT_SETTINGS.autoSpacePunctuation;
  }
  if (typeof merged.rememberCapsLockState !== 'boolean') {
    merged.rememberCapsLockState = DEFAULT_SETTINGS.rememberCapsLockState;
  }
  if (typeof merged.clipboardHideOnPaste !== 'boolean') {
    merged.clipboardHideOnPaste = DEFAULT_SETTINGS.clipboardHideOnPaste;
  }
  if (merged.clipboardGridColumns !== 1 && merged.clipboardGridColumns !== 2) {
    merged.clipboardGridColumns = DEFAULT_SETTINGS.clipboardGridColumns;
  }
  if (typeof merged.vibrationDurationMs !== 'number' || merged.vibrationDurationMs < 6 || merged.vibrationDurationMs > 60) {
    merged.vibrationDurationMs = DEFAULT_SETTINGS.vibrationDurationMs;
  }
  return merged;
}

