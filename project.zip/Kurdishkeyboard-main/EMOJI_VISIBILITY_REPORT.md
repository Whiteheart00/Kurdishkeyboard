# Emoji visibility repair

Base: activity_report_fix/project.zip. Evidence: six supplied screenshots show category counts (176, 300, 122, 200), working category/selection UI, visible pin and variant markers, but missing emoji artwork in the IME and Settings live preview/style cards. This establishes a shared display failure, not that the catalog is empty. Exact device-level cause has not been reproduced.

## Changes
- `android-ime/NativeImeEmojiGlyphs.java`: replace the custom TextView Canvas drawing implementation with a standard Android FrameLayout containing a centered ImageView and a native text fallback. Load the bundled local 64×64 image before attachment or any network call. The shared 12 MiB bitmap cache remains; the existing ListView constructs visible rows rather than the entire catalog. This deliberately trades a small cold-cache decode cost for deterministic initial display. Remote Messenger artwork is optional, and invalid, oversized or completely transparent remote images cannot overwrite the local artwork. The existing style color filters, codepoint strings and optional remote URL remain. Native text is retained for values not present in the bundle, with alternate variation-selector lookup.
- `android-ime/NativeMediaSettingsView.java`: change preview handles to View so Settings uses the same renderer and can resize it. No changes to Activity Logs, signing, application ID, workflow, the clipboard, or other screens.
- Noto artwork is the offline fallback; not identical to Messenger artwork. No new WebView/Capacitor or external library.

## Verified locally
- All 3,058 catalog PNGs decode as 64×64 RGBA and have nonempty alpha content.
- Source audit: 63 files passed. Java syntax parse: 56 files passed (not Android API type checking).
- Emoji code unit tests: 10 cases passed.
- JavaScript stability tests: 7 passed.
- ZIP integrity and changed-file comparison performed after packaging.

## Still required on device
Build through existing workflow, install as an update without clearing app data, turn on airplane mode, open all categories, test Settings previews and all five styles, pin/unpin, select variants and insert into an ordinary text field. Repeat online for Messenger. The APK was not built or installed in this environment (Android SDK/Gradle unavailable), and visual success and runtime performance are not guaranteed. If the failure remains, supply the new build's APK and a Logcat excerpt for the app around opening the emoji panel; avoid including private typed text or clipboard contents.
