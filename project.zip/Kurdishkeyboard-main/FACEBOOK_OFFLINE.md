# Offline Facebook-style emoji support

Based on the latest space_popup_fix project. Native settings and the keyboard now resolve Facebook-style glyphs from `assets/native-ime/facebook-emoji/` first, with bundled Noto fallback. All runtime HTTP requests for emoji artwork have been removed from the shared Android renderer. The website is unchanged; API features elsewhere in the app are unaffected.

**No Facebook artwork is included in this archive.** None was found in the supplied projects. The upstream emoji-data documentation states that the licensing of Facebook's artwork is unclear: https://github.com/iamcal/emoji-data#image-sources. Use an artwork pack only if you have permission to package it. This archive includes 3,058 existing Noto images and an empty Facebook manifest. The Settings card reports the actual number of Facebook images and explicitly indicates Noto fallback.

To bundle a locally supplied authorized pack before building the Android APK:

```
python -m pip install Pillow
python scripts/import-facebook-emoji.py /path/to/authorized-pack.zip --authorized
python scripts/audit-native.py
```

The importer accepts a directory or ZIP of 64x64 PNGs named by Unicode code points, e.g. `1f600.png` or `2764-fe0f.png`. It validates each matching image, checks exact and variation-selector aliases, and stages the assets in the Android module. Rezip the project and run the existing workflow. No changes to the workflow or signing are required. Missing Facebook images use Noto offline, not a different network service. Android sends standard Unicode emoji, and other apps control the appearance of received text.

Tests: four synthetic importer cases, 10 Unicode code cases, native source and existing 3,058 asset audit passed. Full Android compilation and on-device visual/performance testing were not possible here. Actual Facebook artwork count in this archive: 0.
