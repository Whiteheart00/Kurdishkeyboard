# Offline Facebook 15.0 style from the user's release asset

The user supplied `https://github.com/Whiteheart00/Kurdishkeyboard/releases/download/latest-apk/Facebook15.0.ttf`.
The build workflow retrieves this exact release asset using `gh release download` and converts the supplied color font into 64x64 PNGs for the shared native Settings/IME renderer, before the Android project is generated. No new font file or Facebook artwork is included in this source archive. Existing Noto assets remain for unsupported sequences. Android commits standard Unicode; receiving apps choose their own rendering.

## Setup
1. Replace repository root `project.zip` and `.github/workflows/build.yml` with the supplied files. Disable older root build workflows unless updated separately.
2. Only if you have permission to package and redistribute the font artwork, create repository variable `FACEBOOK_FONT_AUTHORIZED` with value `true` in Settings > Secrets and variables > Actions > Variables.
3. Run the existing workflow with `native_ime_preview=true`. The runner requires read access to the supplied release asset (the workflow token can read its own repository).
4. Inspect the `Prepare offline Facebook emoji from release font` log for actual matched and missing counts and SHA-256. Missing asset, unsupported color font, missing required common emoji, or empty pack stops the build. Missing individual sequences use bundled Noto offline; the Settings card reports actual coverage.
5. The source and packaged asset audit require the pack and verify its manifest and every listed PNG is present in the APK. The existing no-embedded-web audit remains unchanged in scope. Test Settings and keyboard offline, including skin tones, ZWJ sequences, flags and category switching.

## Verification and limitations
- Direct download of the supplied binary was unavailable in this environment (DNS unavailable; web fetch restricted). Font contents, licensing, identity and actual coverage are not verified. Filename alone does not prove the artwork's identity or licensing.
- The conversion algorithm was exercised with a separate installed Noto color font: 3057 of 3058 catalog entries rendered; all output images were 64x64 RGBA and nonempty. These test images were not added to the source archive. This does not establish Facebook font compatibility.
- Normal source audit, strict missing-pack rejection, and strict positive source/packaged manifest audit with disposable synthetic fixture passed. The synthetic fixture is not an Android APK and does not prove real APK validity. Full Android build and device tests were not run.
- No runtime emoji network calls. No new Android dependencies, signing changes, or changes to Vercel. Build-time Python uses Pillow, fontTools and the system HarfBuzz library.
