# Keep application entry points and internal compatibility; shrink unused library code.
-keep,allowoptimization class io.kurdikebord.app.** { *; }
