# Native migration preview — verification report

## Implemented
- Replaced the hybrid launcher with a Java Android Activity and Android Views; removed embedded web renderer, legacy web migration, bridge annotations and Capacitor configuration from the Android path.
- Preserved native IME engine, layout editor, native settings storage and existing Java tools. Added native launcher, input-method setup/test, basic languages, AI/media settings and native JSON settings backup/import. Restored eleven original sound assets from the older supplied project.
- Separated Android Gradle staging from the website build. The Android data generator produces JSON; staging allows only native data, fonts and media. The web application remains in source for Vercel.
- Retained application ID io.kurdikebord.app and the existing signing configuration; a signing key is required rather than generated. Existing native preference files are retained. Automatic Android backup is disabled; explicit settings export/import is available.
- Added source and APK archive/DEX checks. CI also checks signing validity. Preview is default; publication and Vercel deployment require an explicit manual non-preview run.

## Locally checked
- Native source audit: 53 files passed.
- Java parser: 46 files parsed successfully (syntax only, not Android type checking).
- JavaScript stability suite: 7/7 passed.
- Pure Java tests: ImeOperationGateTest and ImeLargeTextTest passed.
- Native settings data generation inputs: five locales and restored sound paths checked using local TypeScript transpilation; selected text algorithm smoke checks passed.

## Not verified / remaining work
- No Android SDK/Gradle or installed npm dependency tree in the local environment: full Android compilation, dependency resolution, complete JS test suite, Vercel deployment, APK audit/signature check and device tests must run externally. No APK supplied here.
- The source audit checks specific forbidden references; it is not proof that an actual built APK is free of every possible web dependency. The CI APK audit is required.
- Native UI is not a pixel-identical port of the React screens. Advanced language, custom theme, media and AI configuration parity remains incomplete; bottom-row controls are stored but not fully applied by the engine. Existing native feature behavior needs device validation.
- Native preference storage is preserved. Old web-only local storage is not automatically migrated; export before updating, and retain the original app/data if backup is not available. Legacy JSON settings import is not a guarantee of migration of all data, clipboard, themes or custom layouts.
- The existing package ID and signing mechanism are kept, but actual in-place upgrade compatibility requires the same original signing certificate and a suitable version code. Verify on a test device. Never replace the original key to work around a signing error.
- This is a preview. Keep the previous production version available and do not publish until actual build, upgrade and feature tests pass.
