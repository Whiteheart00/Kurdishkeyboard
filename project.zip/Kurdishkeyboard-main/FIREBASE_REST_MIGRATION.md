# Firebase REST migration – strict native APK

The supplied build log establishes that seven android.webkit type descriptors remain in the APK. The exact owning classes were not supplied. Firebase Auth's runtime dependency on reCAPTCHA is the leading suspect, not a proven attribution of all seven types.

Changes:
- Remove Firebase Auth and Firestore Android runtime SDKs and their BOM. Keep the existing native Google Credential Manager / Google ID integration and Google Services build plugin.
- Exchange a Google ID token with Firebase Authentication's official REST endpoint, refresh Firebase ID tokens with the Secure Token API, and access Firestore with the user's Firebase ID token over HTTPS. No service account or administrator token is introduced. Encrypted refresh token is stored in a separate preference file using Android Keystore AES-GCM; the file is excluded by the existing Android backup allowlist. Existing Firebase SDK sessions are not migrated; sign in again.
- Keep the same `keyboardBackups/{uid}` document and four fields, encryption format, 750,000-byte limit, rules, per-user authorization, and opt-in pinned clipboard policy. Cloud writes use a document update-time/existence precondition plus the server timestamp transform to preserve conflict detection. Backups remain daily and subject to Android scheduling.
- Add a Gradle dependency guard for the removed SDKs and reCAPTCHA. Existing DEX audit remains byte-for-byte unchanged; diagnostic workflow still runs before the audit. Public repo configuration remains injected at build time from FIREBASE_GOOGLE_SERVICES_JSON; no config JSON or signing key is included.

Local verification: Java compiler parse (70 source/test files), 10 existing backup encryption checks, 7 keyboard stability tests, 3058 Noto PNG catalog and source audit (73 files). Facebook artwork is still generated in CI from the authorized release font; the log reported 3031/3058. Full Android compilation, final DEX inspection, Google authentication, live Firestore requests, and device backup/restore are not verified locally. Credential Manager still has dependencies that may introduce additional forbidden references; CI must fail if so. No audit bypass or unverified APK publication.

References: https://firebase.google.com/docs/reference/rest/auth ; https://firebase.google.com/docs/firestore/use-rest-api ; https://cloud.google.com/firestore/docs/reference/rest/v1/Write
