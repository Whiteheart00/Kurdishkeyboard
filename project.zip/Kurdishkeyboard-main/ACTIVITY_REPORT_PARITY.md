# Activity logs / reports — Native parity update

Base: `emoji_offline_fix/project.zip`. Reference: original `project.zip`, specifically `src/components/settings/ActivityLogsScreen.tsx`, `src/components/settings/SettingsUI.tsx` (SubPageHeader) and `src/utils/activityLogger.ts`.

## Changes
- Native header follows the original fixed RTL back/title/refresh alignment. Manual refresh reports the number of saved events.
- Category tabs show separate count badges; severity tabs use the original colored states, including the blue selected state. Toolbar actions now have vector icons, disabled states and the original two-column ordering. Clear-category/all actions have amber/rose styling.
- Selection mode has the original select-all/count/delete/done controls. The previous native-only copy-selected and export-selected actions are removed from that toolbar to match the reference (the normal copy, filtered copy, share, export, and individual copy actions remain).
- Inline feedback uses severity-specific colors, auto-dismisses after 3.8 seconds, and offers export/share actions for oversized clipboard reports. A large share falls back to the file picker. Single deletion confirmation identifies the event title.
- Event summaries use left-to-right technical text and monospace time/status. Expanded metadata is displayed one key per line rather than raw JSON.
- Native text formatter reproduces the original report heading, app name, chronological order, timestamp format, scope/filter line, optional HTTP/duration, metadata lines and stack trace. Individual reports use the event's saved version/platform. Export names include date and time.
- Native retention raised from 80 to the reference's 400 events, with the same 340,000-character trimming budget (minimum ten retained events), retaining newest events first. Existing preference names remain unchanged. No new collection of typed text, clipboard contents, or network payloads was added.
- Original React screen and logger remain byte-for-byte unchanged; no changes to keyboard, emoji assets, signing settings or workflows.

## Verification
- Actual Javac parser: 56 Java source files pass syntax parsing (not Android API type checking).
- Native source audit: 63 files passed; offline emoji catalog: 3,058 images passed.
- Vector parser JVM tests: 489 path strings and geometry/invalid-input checks passed.
- NativeActivityReportTest: eight formatting assertions passed on JVM with a minimal test-only JSONObject stand-in, not the Android framework runtime.
- ZIP integrity and changed-file list checked.

## Remaining limitations
Android SDK/device unavailable in this environment. APK compilation, installation, visual pixel parity, runtime latency and actual file sharing/export are not verified. Native export continues to use Android's document picker rather than writing directly to Downloads as the web implementation did. The old React diagnostic event sources and local-storage histories are not all migrated; this update focuses on the view, existing native event storage and report format. Existing native producers do not populate every optional field for every event. The formatter shows real recorded data only, not generated events. Some visual differences remain, including native wrapping and expanded-detail styling.
