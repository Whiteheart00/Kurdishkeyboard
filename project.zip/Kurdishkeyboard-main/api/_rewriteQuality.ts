/** Conservative structural checks, not a semantic or language-quality guarantee. */
export function rewriteQuality(input:string, output:string, mode:string): boolean {
  const a=Array.from(input.trim().normalize('NFC')).length;
  const b=Array.from(output.trim().normalize('NFC')).length;
  if (!b || /^\s*```/.test(output) || b>Math.max(20000,a*20)) return false;
  if (mode==='shorten' && a>=20 && b>=a) return false;
  if (mode==='expand' && a>=10 && b<=a) return false;
  return true;
}
