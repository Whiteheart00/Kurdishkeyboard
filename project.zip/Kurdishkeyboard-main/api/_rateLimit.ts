import type { IncomingMessage, ServerResponse } from 'node:http';
import { createHmac } from 'node:crypto';
import { isIP } from 'node:net';

// A single atomic operation shared by all serverless instances; no request text is sent.
const LUA = `local a=tonumber(redis.call('GET',KEYS[1]) or '0'); local b=tonumber(redis.call('GET',KEYS[2]) or '0'); if a>=tonumber(ARGV[1]) or b>=tonumber(ARGV[2]) then return 0 end; if redis.call('INCR',KEYS[1])==1 then redis.call('EXPIRE',KEYS[1],60) end; if redis.call('INCR',KEYS[2])==1 then redis.call('EXPIRE',KEYS[2],60) end; return 1`;
function reject(res: ServerResponse,status:number,message:string) {
  res.statusCode=status;res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json; charset=utf-8');
  if(status===429||status===503)res.setHeader('Retry-After','60');res.end(JSON.stringify({error:message}));return false;
}
export async function allowAiRequest(req:IncomingMessage,res:ServerResponse):Promise<boolean> {
  const production=process.env.VERCEL==='1'||process.env.NODE_ENV==='production';
  const base=process.env.UPSTASH_REDIS_REST_URL,token=process.env.UPSTASH_REDIS_REST_TOKEN,secret=process.env.RATE_LIMIT_HMAC_KEY;
  if(!base||!token||!secret||secret.length<32) {
    if(!production && !base && !token && !secret)return true; // local development only
    return reject(res,503,'AI service protection is not configured.');
  }
  try {
    const endpoint=new URL(base);
    if(endpoint.protocol!=='https:'||endpoint.username||endpoint.password||endpoint.search||endpoint.hash||endpoint.pathname!=='/'||!endpoint.hostname.endsWith('.upstash.io'))throw new Error('Invalid limiter endpoint');
    // Vercel replaces this header at its edge. Outside Vercel do not trust caller headers.
    const forwarded=process.env.VERCEL==='1'?req.headers['x-forwarded-for']:undefined;
    const ip=typeof forwarded==='string'?forwarded.trim():req.socket.remoteAddress||'';
    if(!isIP(ip))throw new Error('Client address unavailable');
    const digest=createHmac('sha256',secret).update(ip).digest('hex');
    const result=await fetch(endpoint,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
      body:JSON.stringify(['EVAL',LUA,2,`kk:ai:v1:ip:${digest}`,'kk:ai:v1:global',20,240]),signal:AbortSignal.timeout(3000),redirect:'error',cache:'no-store'});
    if(!result.ok)throw new Error('Limiter failed');
    const body=await result.json() as {result?:number};
    if(body.result===0)return reject(res,429,'Too many AI requests. Try again in a minute.');
    if(body.result!==1)throw new Error('Invalid limiter reply');
    return true;
  }catch{return reject(res,503,'AI service protection is temporarily unavailable.');}
}
