# Build repair — 26 November 2026

## Scope
Base: `project.zip` (Kurdishkeyboard-main), the newer source archive and the source named by the supplied GitHub Actions log. The older `projectکیبۆرد.zip` was compared for context. The decompiled archive identifies a different package (`com.goran.kurdikeyboard`, version 3.0.6); it was not merged into the app (`io.kurdikebord.app`). No app ID, signing configuration, version calculation, keyboard features, original assets or workflows were intentionally changed.

## Findings and repairs

- Android `:app:compileDebugJavaWithJavac` failed with 16 diagnostics in the supplied log.
  - `KurdiKeyboardImeService.java`: `getCurrentInputMethodSubtype()` is not a method on InputMethodService. Obtain the InputMethodManager from Context.INPUT_METHOD_SERVICE, null-check it, then call its getCurrentInputMethodSubtype(). Existing subtype callback and language mapping are preserved.
  - `NativeLayoutEditorView.java`: 15 view fields were declared blank final but assigned inside buildMainPage/buildBottomPage, which is not permitted by Java definite-assignment rules. Remove final from those 15 view references only. Move registration of the back-button listener until after bottomPage is initialized to avoid a separate definite-assignment problem. Other final fields and UI logic remain unchanged.
- Vercel logged TS2688 (`vite/client`) three times during serverless compilation. Vite web build and Vercel deployment nevertheless completed. Remove the explicit browser-only type library from the shared root tsconfig; the existing frontend accesses import.meta.env via its own type assertion. Delete the two empty, unreferenced tsconfig.app.json and tsconfig.node.json files. This targets the logged TypeScript error; the Vercel serverless build has not been rerun.
- Vite reported a future native config loader warning about __dirname. Replace it with import.meta.dirname (Node 22 as used by both workflows). The large-chunk warning and other nonfatal toolchain warnings are not addressed; they were not the cause of the APK failure.

## Verification performed locally
- Node 22.16.0: keyboard-stability.test.mjs: 7/7 passed.
- javac and java: ImeOperationGateTest and ImeLargeTextTest: both passed.
- TypeScript 5.8.3 transpileModule syntax checks: 47 source files, 0 error diagnostics. This is not a project typecheck or Vercel build.
- Static checks confirmed all 16 logged Java error patterns were addressed and bottomPage is initialized before listener registration.
- Full Gradle/APK build and device tests were not run: no Android SDK/Gradle in this environment. Dependency installation was blocked by unavailable npm cache/network; native-ime-engine.test.mjs could not run locally because esbuild is missing. The original CI log reported that suite passed 7/7, before these repairs. Vite and Vercel builds were not rerun locally.

## Use with the existing ZIP-based workflow
Replace the repository-root project.zip with this archive (do not nest it inside the old ZIP). Keep the existing .github/workflows/build.yml at repository root. Preserve the existing ANDROID_KEYSTORE_BASE64 and associated signing secrets; no keystore was included in the uploaded source archive, and the supplied CI log shows the secret was loaded successfully. Do not generate a replacement keystore if in-place APK updates are required. Keep existing Vercel secrets unchanged. Commit/push the ZIP or run the existing workflow manually. Inspect the new Android and Vercel logs before treating the build as fully verified.
