# Native design parity pass

## Reference and scope
The base is `design_fix/project.zip`. The visual reference is the original `project.zip` supplied in this conversation, not a newly invented design. Byte-for-byte comparisons confirmed that the seven web design files below in the base match the original archive: `src/App.tsx`, `src/components/keyboard/KeyboardView.tsx`, `src/data/officialData.ts`, `src/components/settings/HomeScreen.tsx`, `src/components/settings/ThemesScreen.tsx`, `src/components/settings/SettingsUI.tsx`, `src/components/icons/KurdiIcons.tsx`. No web UI is packaged into Android. This pass changes seven Java files; the web site, API, workflows, package ID and signing configuration remain unchanged.

## Findings and changes
- `MainActivity.java`: restored the persistent mobile top switcher (48dp, original logo, settings selection, quick native test action) and bottom-left floating native keyboard test button (52dp, 20dp offsets). Added bottom scroll space and theme-aware status/navigation bar colors. The test button invokes the existing native test dialog. Cached shell resources to avoid redecoding them on each settings navigation.
- `NativeSettingsHomeView.java`: corrected the theme-dependent background, premium icon and enabled-state copy, and restored the original red/sky/blue circular social icons. The prior extra direct settings shortcuts are preserved to avoid losing access to settings.
- `NativeImeAppearance.java`: ported the original premium badge paths and gradient stops; key faces use their full assigned bounds rather than shrinking to make room for a shadow. Inset highlights are drawn within the surface; CSS blur effects are approximated in Android drawing. Numeric-space icon uses the original aspect ratio.
- `NativeImeKeyFaces.java`: corrected the secondary-hint size formula (10px for short hints scaled as in the source, and the original phrase-size thresholds); numeric keys retain the original radius override; pill keys no longer receive an invented shadow when no theme shadow is defined. The dedicated number row condition follows the original source.
- `NativeImeKeyGrid.java`: removed the unconditional elevation/translationZ on all keys; draw tactile shadows outside the key rectangle, including a lightweight native glow approximation. Preserved the original 0.94 pressed scale and 2dp translation for the 3D style. Corrected numeric space icon dimensions and space-label chevron tint.
- `NativeImeView.java`: removed the two extra utility-strip buttons not present in the original three-button strip, freeing room for suggestions; clipboard is still reachable by holding Paste or via the existing tools panel, and text-edit tools remain in the tools panel. Restored the rail's circular controls and gap. Prior prediction-worker improvements remain.
- `NativeThemeSettingsView.java`: restored the original 3x3 key-shape preview selector instead of the selection dialog; restored the auto light/dark split preview, and the compact four-row theme previews without the invented number row, including selected badge and special key colors.

## Verification performed
- Java syntax parse via javac compiler API: 48/48 Java files.
- Native source/dependency audit: passed (55 files).
- Vector-path parser: all 469 bundled paths plus geometry/invalid-input tests passed.
- JavaScript stability tests: 7/7 passed.
- Standalone Java tests: 2/2 passed.
- Original visual reference files compared against the original uploaded ZIP: 7/7 byte-identical.

## Remaining limitations and acceptance checks
This is a source-based restoration, not a claim of pixel-perfect or complete feature parity. No Android SDK/Gradle installation or device/emulator is available locally; Android compilation, APK DEX audit, installation, screen rendering and speed have not been verified. CSS shadow/blur/glow and font rendering are approximated natively; theme cards and some settings/panels still differ from the React originals. The original screenshots are not available here, and the supplied decompiled archive is not used as a replacement for the original project source. Existing GitHub Actions must build the new APK and pass the unchanged DEX audit. For visual acceptance compare the same device, language, keyboard height/width, font, theme and shape settings in both versions. For runtime acceptance test typing, editing, shift, language, numeric/symbol modes, clipboard, theme changes, and long-press popups. No change to existing settings migration or version signing; preserve the old app's backup and signing secrets.
