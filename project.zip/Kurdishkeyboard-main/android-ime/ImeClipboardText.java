package io.kurdikebord.app;

/** Limits rendering work, never the stored or pasted clipboard contents. */
final class ImeClipboardText {
    private static final int PREVIEW_LIMIT = 512;
    private ImeClipboardText() {}

    static String preview(String text) {
        if (text.length() <= PREVIEW_LIMIT) return text;
        int end = PREVIEW_LIMIT;
        if (Character.isHighSurrogate(text.charAt(end - 1)) && Character.isLowSurrogate(text.charAt(end))) end--;
        return text.substring(0, end) + "…";
    }

    static String appendTail(String tail, String value, int limit) {
        if (limit <= 0) return "";
        if (value.length() >= limit) return suffix(value, limit);
        return suffix(tail, limit - value.length()) + value;
    }

    private static String suffix(String text, int limit) {
        int start = Math.max(0, text.length() - limit);
        if (start > 0 && start < text.length() && Character.isLowSurrogate(text.charAt(start)) && Character.isHighSurrogate(text.charAt(start - 1))) start++;
        return text.substring(start);
    }
}
