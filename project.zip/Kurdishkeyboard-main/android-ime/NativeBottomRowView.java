package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Native bottom-row arrangement editor matching original Kurdish keyboard UI. */
final class NativeBottomRowView extends LinearLayout {
    private static final int TEAL = 0xff2dd4bf;
    private static final int ACCENT = 0xffa4c9ff;
    private static final int MUTED = 0xff9ca3af;
    private static final int WARN = 0xffd4b89a;
    private static final int SAVE_BLUE = 0xff8eb8ff;
    private static final int SAVE_INK = 0xff0b1f3d;

    private static final String[] PRESETS = {
            "auto", "kurdish", "default", "bottom_row_compact", "bottom_row_simple",
            "bottom_row_full", "bottom_row_anysoft_classic", "bottom_row_right_handed", "bottom_row_left_handed"
    };
    private static final String[] PRESET_LABELS = {
            "خۆکار (بەپێی زمان)", "کوردی بنەڕەتی", "ستانداردی جیهانی", "کۆمپاکت", "سادە و پاک",
            "تەواو", "کلاسیکی AnySoft", "دەستی ڕاست", "دەستی چەپ"
    };
    private static final String[] DEFAULT_KEYS = {"گۆڕینی زمان", ".", "بۆشایی", "خەندە", "ناردن"};
    private static final String[] AVAILABLE = {
            "هێماکان 123?", "فاریزە ،", "نیشانەی سەرسوڕمان !", "گەڕانی دەنگی", "لەبەرگیراوەکان",
            "ڕێکخستنەکان", "دواتر", "پێشوو", "گۆڕینی زمان", "خەندە", "ناردن", "سڕینەوە", ".", "بۆشایی"
    };

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int surface;
    private final int border;
    private final int pageBg;

    private final LinearLayout previewRow;
    private final LinearLayout availableHost;
    private final LinearLayout presetHost;
    private final List<String> keys = new ArrayList<>();
    private String preset = "auto";
    private final Switch moveDown;

    NativeBottomRowView(Context context, String theme, String font, JSONObject data, Runnable back,
                        NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        pageBg = light ? 0xfff1f5f9 : 0xff0a0b0e;
        surface = light ? Color.WHITE : 0xff12141a;
        border = light ? 0xffe2e8f0 : 0x22ffffff;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(pageBg);

        if (data != null) {
            preset = data.optString("bottomRowPreset", "auto");
            JSONArray custom = data.optJSONArray("bottomRowKeys");
            if (custom != null && custom.length() > 0) {
                for (int i = 0; i < custom.length(); i++) keys.add(custom.optString(i));
            }
        }
        if (keys.isEmpty()) keys.addAll(Arrays.asList(DEFAULT_KEYS));

        LinearLayout header = row();
        header.setPadding(dp(12), dp(8), dp(12), dp(8));
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView backBtn = chip("←", 20, foreground, light ? 0xffe2e8f0 : 0xff1c1f27);
        backBtn.setOnClickListener(v -> back.run());
        header.addView(backBtn, new LayoutParams(dp(40), dp(40)));
        TextView title = label("شێوازی بەشی خوارەوە", 17, foreground);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LayoutParams(0, -2, 1));
        header.addView(new View(context), new LayoutParams(dp(40), dp(40)));
        addView(header, new LayoutParams(-1, dp(56)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(14), dp(8), dp(14), dp(24));
        scroll.addView(body);

        // Teal banner
        LinearLayout banner = row();
        banner.setPadding(dp(16), dp(16), dp(16), dp(16));
        banner.setBackground(appearance.background(TEAL, 20, 0, 0));
        banner.setGravity(Gravity.CENTER_VERTICAL);
        TextView bIcon = appearance.text("☝", 28, 0xff0f766e, font, 700);
        bIcon.setGravity(Gravity.CENTER);
        banner.addView(bIcon, new LayoutParams(dp(48), dp(48)));
        LinearLayout bCopy = column();
        TextView bTitle = label("تەختەکلیل هەڵنەبژێردراوە!", 15, 0xff042f2e);
        bTitle.setTypeface(Typeface.DEFAULT_BOLD);
        bCopy.addView(bTitle);
        bCopy.addView(label("پێویستە تەختەکلیل هەڵبژێریت بۆ نووسین", 12, 0xff134e4a));
        LayoutParams bcl = new LayoutParams(0, -2, 1);
        bcl.setMarginStart(dp(10));
        banner.addView(bCopy, bcl);
        append(body, banner, 0);

        TextView help = label("کەمێک دەست ڕاگرە و بیجوڵێنە بۆ لای ڕاست یان چەپ بۆ گۆڕینی شوێن، پەنجەی یەکدا بنێ بۆ گۆڕینی قەبارەکەی", 11, MUTED);
        help.setPadding(dp(14), dp(12), dp(14), dp(12));
        help.setBackground(appearance.background(surface, 16, 1, border));
        append(body, help, 12);

        // Preview
        LinearLayout previewCard = card();
        previewRow = row();
        previewRow.setGravity(Gravity.CENTER_VERTICAL);
        append(previewCard, previewRow, 0);
        append(body, previewCard, 12);
        renderPreview();

        // Presets
        LinearLayout presetCard = card();
        append(presetCard, label("شێوازە ئامادەکان", 13, ACCENT), 0);
        presetHost = column();
        append(presetCard, presetHost, 10);
        for (int i = 0; i < PRESETS.length; i++) {
            final String id = PRESETS[i];
            final String name = PRESET_LABELS[i];
            TextView chip = chip((id.equals(preset) ? "●  " : "○  ") + name, 12,
                    id.equals(preset) ? ACCENT : foreground,
                    id.equals(preset) ? (light ? 0xffe0f2fe : 0xff1d2838) : (light ? 0xfff1f5f9 : 0xff1c1f27));
            chip.setPadding(dp(12), 0, dp(12), 0);
            chip.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            chip.setOnClickListener(v -> {
                preset = id;
                if ("kurdish".equals(id) || "default".equals(id) || "auto".equals(id)) {
                    keys.clear();
                    keys.addAll(Arrays.asList(DEFAULT_KEYS));
                }
                change.accept("bottomRowPreset", id);
                renderPreview();
                renderPresets();
                renderAvailable();
            });
            LayoutParams lp = new LayoutParams(-1, dp(40));
            lp.topMargin = dp(i == 0 ? 0 : 6);
            presetHost.addView(chip, lp);
        }
        append(body, presetCard, 12);

        // Available
        LinearLayout availCard = card();
        LinearLayout availHead = row();
        availHead.addView(label("دوگمە بەردەستەکان", 13, ACCENT), new LayoutParams(0, -2, 1));
        availHead.addView(label("+", 18, ACCENT), new LayoutParams(dp(28), dp(28)));
        append(availCard, availHead, 0);
        availableHost = column();
        append(availCard, availableHost, 10);
        renderAvailable();
        append(body, availCard, 12);

        TextView reset = chip("↻  گێڕانەوە بۆ بنەڕەتی", 13, WARN, 0x22c4a484);
        reset.setOnClickListener(v -> {
            keys.clear();
            keys.addAll(Arrays.asList(DEFAULT_KEYS));
            preset = "default";
            change.accept("bottomRowPreset", "default");
            renderPreview();
            renderPresets();
            renderAvailable();
        });
        append(body, reset, 8);

        // Toggle
        LinearLayout toggle = row();
        toggle.setPadding(dp(14), dp(12), dp(14), dp(12));
        toggle.setBackground(appearance.background(surface, 16, 1, border));
        toggle.setGravity(Gravity.CENTER_VERTICAL);
        moveDown = new Switch(context);
        if (data != null) moveDown.setChecked(data.optBoolean("emojiLanguageBottom", false));
        moveDown.setOnCheckedChangeListener((b, on) -> change.accept("emojiLanguageBottom", String.valueOf(on)));
        toggle.addView(moveDown, new LayoutParams(-2, -2));
        LinearLayout tCopy = column();
        tCopy.addView(label("گواستنەوە بۆ خوارەوە", 13, foreground));
        tCopy.addView(label("دوگمەی ئیمۆجی و زمان بگۆڕە بۆ ژێر تەختەکلیل", 11, MUTED));
        LayoutParams tcl = new LayoutParams(0, -2, 1);
        tcl.setMarginStart(dp(10));
        toggle.addView(tCopy, tcl);
        toggle.addView(label("↓", 20, MUTED), new LayoutParams(dp(28), dp(28)));
        append(body, toggle, 12);

        TextView save = chip("💾  پاشەکەوتکردنی گۆڕانکارییەکان", 14, SAVE_INK, SAVE_BLUE);
        save.setOnClickListener(v -> {
            JSONArray arr = new JSONArray();
            for (String k : keys) arr.put(k);
            change.accept("saveBottomRow", arr.toString());
            change.accept("bottomRowPreset", preset);
            save.setText("✓  پاشەکەوت کرا");
            save.postDelayed(() -> save.setText("💾  پاشەکەوتکردنی گۆڕانکارییەکان"), 1800);
        });
        append(body, save, 16);
    }

    private void renderPresets() {
        for (int i = 0; i < presetHost.getChildCount() && i < PRESETS.length; i++) {
            TextView chip = (TextView) presetHost.getChildAt(i);
            boolean on = PRESETS[i].equals(preset);
            chip.setText((on ? "●  " : "○  ") + PRESET_LABELS[i]);
            chip.setTextColor(on ? ACCENT : foreground);
            chip.setBackground(appearance.background(on ? (light ? 0xffe0f2fe : 0xff1d2838) : (light ? 0xfff1f5f9 : 0xff1c1f27), 14, 0, 0));
        }
    }

    private void renderPreview() {
        previewRow.removeAllViews();
        for (int i = 0; i < keys.size(); i++) {
            final int idx = i;
            String name = keys.get(i);
            FrameLayout cell = new FrameLayout(getContext());
            TextView key = chip(shortLabel(name), 12, foreground, light ? 0xffe2e8f0 : 0xff1c1f27);
            cell.addView(key, new FrameLayout.LayoutParams(-1, -1));
            TextView x = chip("×", 11, Color.WHITE, 0xffef4444);
            FrameLayout.LayoutParams xlp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.START);
            xlp.topMargin = dp(2);
            xlp.setMarginStart(dp(2));
            x.setOnClickListener(v -> {
                keys.remove(idx);
                renderPreview();
                renderAvailable();
            });
            cell.addView(x, xlp);
            float w = name.contains("بۆشایی") ? 2.4f : 1f;
            LayoutParams lp = new LayoutParams(0, dp(52), w);
            lp.setMarginStart(dp(i == 0 ? 0 : 6));
            previewRow.addView(cell, lp);
        }
        if (keys.isEmpty()) {
            TextView empty = label("دوگمەیەک زیاد بکە…", 12, MUTED);
            empty.setGravity(Gravity.CENTER);
            previewRow.addView(empty, new LayoutParams(-1, dp(52)));
        }
    }

    private void renderAvailable() {
        availableHost.removeAllViews();
        LinearLayout line = null;
        int count = 0;
        for (String item : AVAILABLE) {
            if (keys.contains(item)) continue;
            if (line == null || count % 2 == 0) {
                line = row();
                LayoutParams lp = new LayoutParams(-1, -2);
                lp.topMargin = dp(count == 0 ? 0 : 8);
                availableHost.addView(line, lp);
            }
            final String add = item;
            TextView chip = chip("+  " + item, 11, foreground, light ? 0xfff1f5f9 : 0xff1c1f27);
            chip.setPadding(dp(10), 0, dp(10), 0);
            chip.setOnClickListener(v -> {
                keys.add(add);
                renderPreview();
                renderAvailable();
            });
            LayoutParams lp = new LayoutParams(0, dp(40), 1);
            lp.setMarginStart(dp(count % 2 == 0 ? 0 : 6));
            line.addView(chip, lp);
            count++;
        }
    }

    private String shortLabel(String label) {
        if (label.contains("بۆشایی")) return "Space";
        if (label.contains("زمان")) return "🌐";
        if (label.contains("خەندە")) return "☺";
        if (label.contains("ناردن")) return "↵";
        if (label.contains("هێما")) return "123";
        if (label.contains("فاریزە")) return "،";
        if (label.contains("سەرسوڕمان")) return "!";
        if (label.contains("دەنگ")) return "🎤";
        if (label.contains("لەبەرگیر")) return "📋";
        if (label.contains("ڕێکخستن")) return "⚙";
        if (label.contains("دواتر")) return "↷";
        if (label.contains("پێشوو")) return "↶";
        if (label.contains("سڕینەوە")) return "⌫";
        return label.length() > 10 ? label.substring(0, 9) + "…" : label;
    }

    private LinearLayout card() {
        LinearLayout view = column();
        view.setPadding(dp(14), dp(14), dp(14), dp(14));
        view.setBackground(appearance.background(surface, 18, 1, border));
        return view;
    }

    private TextView chip(String value, int size, int color, int bg) {
        TextView view = appearance.text(value, size, color, font, 700);
        view.setGravity(Gravity.CENTER);
        view.setBackground(appearance.background(bg, 14, 0, 0));
        view.setPadding(dp(8), 0, dp(8), 0);
        return view;
    }

    private TextView label(String value, int size, int color) {
        TextView view = appearance.text(value, size, color, font, 600);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
