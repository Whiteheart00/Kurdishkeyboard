package io.kurdikebord.app;

import static io.kurdikebord.app.NativeImeData.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NativeImeRewrite {
    private static final String LETTER = "\\u0621-\\u064A\\u066E-\\u06D5\\u06FA-\\u06FF\\u200C";
    private static final String ARABIC = "\\u0600-\\u06FF";
    private static final String SPACE = "[\\s\\p{Z}\\uFEFF]";
    private static final Pattern PREFIX = Pattern.compile("(?<![" + ARABIC + "])دە([\\u0621-\\u06FF]{3,})");
    private final NativeImeData data;

    NativeImeRewrite(NativeImeData data) { this.data = data; }

    String run(JSONArray args) { return rewrite(trim(args.optString(0)), args.optString(1), args.optJSONObject(2)); }

    private String rewrite(String input, String mode, JSONObject tone) {
        if (input.isEmpty()) return "";
        String lang = detect(input);
        String fixed = fix(input, lang);
        switch (mode) {
            case "fix": case "custom": return fixed;
            case "formal": return formal(fixed, lang);
            case "friendly":
                if ("ckb".equals(lang)) return (has(fixed, "^(سڵاو|چۆنیت|برا|هاوڕێ)") ? "" : "سڵاو هاوڕێ گیان، ") + fixed + " 😊";
                return ("ar".equals(lang) ? "أهلاً صديقي، " : "Hey there! ") + fixed + " 😊";
            case "shorten":
                String[] sentences = fixed.split("(?<=[.؟!])" + SPACE + "+");
                if (sentences.length > 1) return trim(sentences[0]);
                String[] words = fixed.split(SPACE + "+");
                int limit = (int) Math.ceil(words.length * .65);
                if (words.length <= 10) return fixed;
                StringBuilder shortText = new StringBuilder();
                for (int i = 0; i < limit; i++) {
                    if (i > 0) shortText.append(' ');
                    shortText.append(words[i]);
                }
                return shortText + "...";
            case "sorani": case "badini": return dialect(input, mode);
            case "poetic": return poetic(fixed, lang);
            case "expand": return expand(fixed, lang);
            case "rephrase":
                if (!"ckb".equals(lang)) return fixed;
                return replace(replace(fixed, ARABIC, "بەڵام", "لەگەڵ ئەوەشدا"), ARABIC, "زۆر", "بە ڕادەیەکی زۆر");
            case "explain":
                if ("ckb".equals(lang)) return "ڕوونکردنەوەی «" + fixed + "»: ئەم دەستەواژەیە بە مەبەستی دەربڕینی بیرۆکەکە بە شێوەیەکی سادە و ڕوون بەکاردێت. (بۆ شیکردنەوەی وردتر سێرڤەری AI چالاک بکە).";
                if ("ar".equals(lang)) return "توضيح «" + fixed + "»: عبارة تُستخدم للتعبير عن المعنى المقصود بوضوح.";
                return "Explanation of \"" + fixed + "\": expresses the intended idea clearly in context.";
            case "tone":
                if (tone == null) return fixed;
                String length = tone.optString("length"), style = tone.optString("style"), intent = tone.optString("intent");
                if ("very_short".equals(length) || "short".equals(length)) return rewrite(input, "shorten", null);
                if ("long".equals(length) || "detailed".equals(length)) return expand(fixed, lang);
                if ("professional".equals(style) || "academic".equals(style) || "email".equals(intent)) return formal(fixed, lang);
                if ("humor".equals(intent) || "casual".equals(style)) return rewrite(input, "friendly", null);
                return fixed;
            case "reply": return reply(input, lang);
            default: return "";
        }
    }

    private static String detect(String text) {
        if (has(text, "[ەێۆڕڵڤچپژگ]")) return "ckb";
        if (!has(text, "[" + ARABIC + "]")) return "en";
        return has(text, "(سڵاو|سلاڤ|چۆن|چەوا|باش|سوپاس|بەڵێ|نەخێر|دەست|تکایە|بۆ|لە|ئەم|ئەو|ئەز|من|تۆ|گەلەک|نوکە)") ? "ckb" : "ar";
    }

    private static String fix(String text, String lang) {
        String out = trim(text);
        if ("ckb".equals(lang)) {
            out = out.replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک')
                    .replaceAll("([\\u0621-\\u06FF])ه(?=" + SPACE + "|$|[،.؟!])", "$1ە")
                    .replace(',', '،').replace('?', '؟').replaceAll("[ \\t]{2,}", " ")
                    .replaceAll(SPACE + "+([،.؟!:;])", "$1")
                    .replaceAll("([،.؟!])([^\\s\\p{Z}0-9،.؟!])", "$1 $2")
                    .replaceAll("(?<![" + ARABIC + "])بۆچی" + SPACE + "+ە(?![" + ARABIC + "])", "بۆچییە");
            return trim(out);
        }
        out = out.replaceAll("[ \\t]{2,}", " ")
                .replaceAll(SPACE + "+([,.?!،؟])", "$1")
                .replaceAll("([,.?!،؟])([^\\s\\p{Z}0-9,.?!،؟])", "$1 $2");
        if ("en".equals(lang) && !out.isEmpty()) return end(out.substring(0, 1).toUpperCase(Locale.ROOT) + out.substring(1), "en");
        return out;
    }

    private String dialect(String text, String mode) {
        String out = fix(text, "ckb");
        JSONArray pairs = arr(data.load("dialects"), mode);
        for (int i = 0; i < pairs.length(); i++) {
            JSONArray pair = pairs.optJSONArray(i);
            out = replace(out, LETTER, pair.optString(0), pair.optString(1));
        }
        if ("badini".equals(mode)) {
            Matcher prefixes = PREFIX.matcher(out);
            StringBuffer rewritten = new StringBuffer();
            while (prefixes.find()) {
                String rest = prefixes.group(1);
                prefixes.appendReplacement(rewritten, Matcher.quoteReplacement(
                        has(rest, "^(ست|رگا|نگ|م|ق|رد|رس|ری|وڵ|ور|شت|فت|رمان|فە|رەج)") ? prefixes.group() : "د" + rest));
            }
            prefixes.appendTail(rewritten);
            out = rewritten.toString();
        }
        return trim(out);
    }

    private static String replace(String text, String letters, String from, String to) {
        return text.replaceAll("(?<![" + letters + "])" + Pattern.quote(from) + "(?![" + letters + "])", Matcher.quoteReplacement(to));
    }

    private static boolean has(String text, String pattern) { return Pattern.compile(pattern).matcher(text).find(); }

    private static String end(String text, String lang) {
        return has(text, "en".equals(lang) ? "[.!?]$" : "[.؟!]$") ? text : text + ".";
    }

    private static String formal(String fixed, String lang) {
        if ("ckb".equals(lang)) {
            String body = trim(fixed.replaceFirst("^(سڵاو|هەلاو|چۆنی|سڵاو هاوڕێ)[،,\\s\\p{Z}!؟]*", ""));
            return "سڵاو و ڕێز، " + end(body.isEmpty() ? fixed : body, lang) + " لەگەڵ ڕێز و سوپاسدا.";
        }
        if ("ar".equals(lang)) return "تحية طيبة وبعد، " + end(fixed, lang) + " مع خالص التقدير.";
        return "Hello, " + fixed + " Best regards.";
    }

    private static String poetic(String fixed, String lang) {
        String core = trim(fixed.replaceFirst("en".equals(lang) ? "[.!?]+$" : "[.!؟،]+$", ""));
        if ("ckb".equals(lang)) {
            if (has(core, "(سڵاو|بەیانی|ئێوارە|شەو)")) return core + "؛ وەک شنەبای بەیانی و تیشکی خۆر، دڵت پڕ بێت لە ئارامی و ڕووناکی.";
            if (has(core, "(خۆش|دڵ|عەشق|ئەوین|بیر|چاو|گیان)")) return core + " — وەک چرپەی باران لەسەر گەڵای پایز، هەمیشە لە قووڵایی دڵمدا دەدرەوشێتەوە.";
            if (has(core, "(سوپاس|دەستخۆش|ماندوو|ڕێز)")) return core + "؛ میهرەبانیت وەک گوڵێکی پڕ بۆنە کە جوانی بە هەموو ساتەکان دەبەخشێت.";
            return "وەک تیشکێکی هێمن لە ئاسمانی هەستدا:\n«" + core + "»\nدەنگی وشەکان بە نەرمی و جوانی دەگاتە دڵ.";
        }
        if ("ar".equals(lang)) return "كهمسِ نسيمٍ عذبٍ يلامس الروح:\n«" + core + "»\nكلماتٌ تنبض بالدفء والجمال.";
        return "Like quiet light woven through golden dusk:\n\"" + core + "\" — words carried on grace and warmth.";
    }

    private static String expand(String fixed, String lang) {
        String ended = end(fixed, lang) + " ";
        if ("ckb".equals(lang)) {
            if (has(fixed, "[؟?]$|(چۆن|کەی|چەند|لە کوێ|بۆچی|دەکرێت)")) return ended + "ئەگەر دەکرێت کەمێک وردەکاری زیاترمان پێ بدەیت تا بتوانین بە باشترین شێوە وەڵامت بدەینەوە و هاوکاریت بکەین.";
            if (has(fixed, "(سڵاو|بەیانی|ئێوارە)")) return ended + "هیوادارم تەندروستیت باش بێت و ڕۆژێکی پڕ لە ئارامی و سەرکەوتنت هەبێت؛ هەر شتێکت پێویست بوو لە خزمەتدام.";
            if (has(fixed, "(سوپاس|دەستخۆش)")) return ended + "بەڕاستی هەوڵ و هاوکارییەکەت جێی ڕێز و پێزانینی زۆرە، هیوای سەرکەوتن و تەندروستی باشت بۆ دەخوازم.";
            return ended + "مەبەستم ئەوەیە ئەم بابەتە بە ڕوونی و وردی باس بکەم بۆ ئەوەی هەموو لایەنەکانی دیار بێت و هیچ تێنەگەیشتنێک دروست نەبێت.";
        }
        if ("ar".equals(lang)) return ended + "أردت توضيح هذه النقطة بشكلٍ كامل ومفصل حتى تكون الصورة واضحة تماماً، ويسعدني مشاركة أي تفاصيل إضافية عند الحاجة.";
        return ended + "I wanted to share this clearly with full context so everything is easy to follow, and please let me know if you need any further details.";
    }

    private static String reply(String text, String lang) {
        if ("ckb".equals(lang)) {
            if (has(text, "(سڵاو|سلاڤ|الس|مەرحەبا|بەیانی|ئێوارە)")) return "وعلیکم السلام، سڵاو و ڕێز! سوپاس بۆ هەواڵپرسیت، باشم تۆ چۆنیت؟";
            if (has(text, "(چۆنیت|چۆنی|چەوانی|باشی|هەواڵت)")) return "سوپاس بۆ خوا باشم، هیوادارم تۆش باش و سەلامەت بیت.";
            if (has(text, "(سوپاس|دەستخۆش|مەمنون|خودا پاداشتت)")) return "شایەنی نییە، هەرکاتێک پێویستت بە هاوکاری بوو لە خزمەتدام.";
            if (has(text, "(ببوورە|داوای لێبوردن)")) return "هیچ کێشە نییە، ئاساییە هاوڕێ گیان.";
            if (has(text, "[؟?]|(کەی|چەند|لە کوێ|بۆچی|دەکرێت)")) return "بەڵێ بە دڵنیاییەوە، ئێستا پشکنینی بۆ دەکەم و زانیاری تەواوت بۆ دەنێرم.";
            return "زۆر باشە، نامەکەت گەیشت و سوپاس بۆ ئاگادارکردنەوەکەت.";
        }
        if ("ar".equals(lang)) {
            if (has(text, "(سلام|أهلا|مرحبا|صباح|مساء)")) return "وعليكم السلام ورحمة الله، أهلاً بك! كيف يمكنني مساعدتك؟";
            if (has(text, "(شكرا|مشكور|يعطيك)")) return "العفو، يسعدني دائماً مساعدتك.";
            return "تم استلام رسالتك بنجاح، شكراً لتواصلك.";
        }
        String lower = lower(text);
        if (has(lower, "(hello|hi|hey|good morning|good evening)")) return "Hello! Hope you are doing well. How can I help you?";
        if (has(lower, "(thank|thx|appreciate)")) return "You're very welcome! Happy to help anytime.";
        if (lower.contains("?")) return "Sure, let me check and get back to you shortly.";
        return "Got it, thank you for letting me know!";
    }

    static boolean quality(JSONArray args) {
        String input = Normalizer.normalize(trim(args.optString(0)), Normalizer.Form.NFC);
        String output = Normalizer.normalize(trim(args.optString(1)), Normalizer.Form.NFC);
        int a = input.codePointCount(0, input.length()), b = output.codePointCount(0, output.length());
        String mode = args.optString(2);
        return b > 0 && !output.startsWith("```") && b <= Math.max(20000L, a * 20L)
                && !("shorten".equals(mode) && a >= 20 && b >= a)
                && !("expand".equals(mode) && a >= 10 && b <= a);
    }
}
