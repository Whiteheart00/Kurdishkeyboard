package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.NativeImeData.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NativeImePrediction {
    private static final Pattern WORD = Pattern.compile("([^\\s\\p{Z}.,!?؟،:;()\\[\\]{}\"'«»]+)$");
    private static final Pattern EMAIL = Pattern.compile("([^\\s\\p{Z}]*@)([a-zA-Z0-9.-]*)$");
    private static final Pattern COLON = Pattern.compile(":([^\\s\\p{Z}:]{1,24})$");

    private final NativeImeData data;
    private final NativeImeMedia media;
    private JSONObject settings;
    private String language;
    private boolean latin;
    private boolean multilingual;
    private final Set<String> known = new HashSet<>();
    private final List<Word> dictionary = new ArrayList<>();

    NativeImePrediction(NativeImeData data, NativeImeMedia media) {
        this.data = data;
        this.media = media;
    }

    void prepare(JSONObject settings, String kana, JSONObject learned) {
        this.settings = settings;
        language = settings.optString("activeLanguage");
        JSONArray enabled = arr(settings, "enabledLanguages");
        JSONObject subtype = find(enabled, "code", language);
        if (subtype == null) subtype = enabled.optJSONObject(0);
        String layout = subtype.optString("characterLayoutId");
        latin = "ltr".equals(subtype.optString("dir")) && !"qwerty_kurdi".equals(layout)
                && !("kurdi_hybrid".equals(layout) && "hira".equals(kana));
        multilingual = settings.optBoolean("multilingualSuggestions");
        Set<String> words = new LinkedHashSet<>();
        if (settings.optBoolean("personalDictionaryEnabled")) {
            append(words, arr(settings, "personalDictionary"));
            List<String> recent = new ArrayList<>();
            Iterator<String> keys = learned.keys();
            while (keys.hasNext()) recent.add(keys.next());
            Collections.sort(recent, (a, b) -> Integer.compare(learned.optInt(b), learned.optInt(a)));
            words.addAll(recent);
        }
        String base = "ar".equals(language) || "fa".equals(language) || "tr".equals(language) ? language : latin ? "en" : "ckb";
        append(words, arr(data.load("words"), base));
        if ("ckb".equals(base)) Collections.addAll(words, ImeSmartText.EXTRA_KU);
        if (multilingual) {
            for (int i=0;i<enabled.length();i++) {
                JSONObject sub=enabled.optJSONObject(i); if(sub==null)continue;
                String code=sub.optString("code");
                if ("ku".equals(code)) code="ckb";
                if (java.util.Arrays.asList("ckb","en","ar","fa","tr").contains(code)) {
                    append(words, arr(data.load("words"),code));
                    if("ckb".equals(code))Collections.addAll(words,ImeSmartText.EXTRA_KU);
                }
            }
        }
        known.clear();
        dictionary.clear();
        Set<String> clean = new HashSet<>();
        for (String word : words) {
            String value = trim(word);
            if (!value.isEmpty() && clean.add(value)) { dictionary.add(new Word(value)); known.add(lower(value)); }
        }
    }

    JSONObject predict(String text) {
        String tail = text.substring(Math.max(0, text.length() - 80));
        String word = word(tail);
        JSONObject math = NativeImeMath.inline(tail);
        return json("currentWord", word, "items", items(tail, word), "math", math == null ? JSONObject.NULL : math);
    }

    private JSONArray items(String tail, String word) {
        JSONArray result = new JSONArray();
        if (settings == null) return result;
        boolean suggestions = settings.optBoolean("wordSuggestions");
        boolean shortcuts = settings.optBoolean("textShortcutsEnabled", true);
        boolean emoji = settings.optBoolean("emojiSuggestions");
        if (!suggestions && !shortcuts && !emoji) return result;
        Set<String> seen = new HashSet<>();
        Matcher email = EMAIL.matcher(tail);
        if (email.find()) {
            JSONArray domains = arr(obj(data.load("core"), "defaults"), "email");
            for (int i = 0; i < domains.length() && result.length() < 8; i++) {
                String value = domains.optJSONObject(i).optString("value");
                if (value.substring(1).startsWith(lower(email.group(2))) && seen.add(value)) {
                    result.put(json("value", value, "isEmail", true));
                }
            }
            if (result.length() > 0) return result;
        }
        int min = Math.max(1, settings.optInt("emojiSuggestionQueryMinLength", 2));
        int max = Math.max(1, Math.min(5, settings.optInt("emojiSuggestionMaxCount", 3)));
        String emojiType = settings.optString("emojiSuggestionType");
        JSONObject emojiData = null;
        if (emoji && "leading_colon".equals(emojiType)) {
            Matcher colon = COLON.matcher(tail);
            if (colon.find() && colon.group(1).length() >= min) {
                emojiData = data.load("media");
                String query = colon.group(1);
                JSONArray hits = hits(emojiData, query);
                for (int i = 0; i < hits.length() && result.length() < max; i++) {
                    addEmoji(result, seen, emojiData, hits.optString(i), colon.group().length());
                }
                if (hits.length() < max) {
                    JSONArray search = media.search(query, max + 2);
                    for (int i = 0; i < search.length() && result.length() < max; i++) {
                        addEmoji(result, seen, emojiData, search.optJSONObject(i).optString("c"), colon.group().length());
                    }
                }
                if (result.length() > 0) return result;
            }
        }
        if (shortcuts && !word.isEmpty()) fillShortcuts(result, seen, word);
        if (!suggestions) return result;
        if (emoji && (emojiType.isEmpty() || "inline_text".equals(emojiType)) && word.length() >= min) {
            if (emojiData == null) emojiData = data.load("media");
            JSONArray hits = hits(emojiData, word);
            for (int i = 0; i < Math.min(max, hits.length()); i++) addEmoji(result, seen, emojiData, hits.optString(i), 0);
        }
        if (!word.isEmpty()) {
            String corrected=ImeSmartText.correction(word, multilingual && ImeSmartText.latinWord(word) ? "en" : latin ? "en" : language);
            if(!corrected.isEmpty() && !known.contains(lower(word))) addWord(result,seen,corrected);
            String low = lower(word), normal = normalize(word);
            int ceiling = Math.min(6, result.length() + 6);
            for (int pass = 0; pass < 3 && result.length() < ceiling; pass++) {
                if (pass == 2 && normal.length() < 2) break;
                for (Word entry : dictionary) {
                    if (result.length() >= ceiling) break;
                    if (word.equals(entry.value) || seen.contains(entry.value)) continue;
                    if (multilingual && ImeSmartText.latinWord(word) != ImeSmartText.latinWord(entry.value)) continue;
                    boolean match = pass == 0 ? entry.low.startsWith(low)
                            : pass == 1 ? entry.normal.startsWith(normal)
                            : normal.length() >= 3 && oneEdit(normal, entry.normal.substring(0, Math.min(entry.normal.length(), normal.length())))
                            || entry.normal.length() > normal.length() && entry.normal.contains(normal);
                    if (match) addWord(result, seen, entry.value);
                }
            }
            if (result.length() == 0 && word.length() >= 2) result.put(json("value", word));
        } else {
            String previous=word(trim(tail));
            boolean useLatin=multilingual && !previous.isEmpty()?ImeSmartText.latinWord(previous):latin;
            for(String phrase:ImeSmartText.phrases(tail,useLatin)) if(result.length()<6) addWord(result,seen,phrase);
            JSONArray next = nextWords(previous,useLatin);
            for (int i = 0; i < next.length() && result.length() < 6; i++) addWord(result, seen, next.optString(i));
            for (String value : defaultWords(useLatin)) if (result.length() < 6) addWord(result, seen, value);
        }
        JSONArray limited = new JSONArray();
        for (int i = 0; i < Math.min(6, result.length()); i++) limited.put(result.opt(i));
        return limited;
    }

    private void fillShortcuts(JSONArray result, Set<String> seen, String word) {
        JSONArray entries = arr(settings, "textShortcuts");
        String low = lower(word), normal = normalize(word);
        for (int pass = 0; pass < 2 && result.length() < 3; pass++) {
            for (int i = 0; i < entries.length() && result.length() < 3; i++) {
                JSONObject entry = entries.optJSONObject(i);
                if (entry == null) continue;
                String key = lower(trim(entry.optString("shortcut"))), normalized = normalize(key);
                boolean exact = key.equals(low) || normalized.equals(normal);
                if (pass == 0 ? !exact : exact || !key.startsWith(low) && !normalized.startsWith(normal)) continue;
                String expansion = entry.optString("expansion");
                if (!expansion.isEmpty() && seen.add(expansion)) result.put(json("value", expansion,
                        "isShortcut", true, "shortcutKey", entry.opt("shortcut")));
            }
        }
    }

    private JSONArray nextWords(String word,boolean useLatin) {
        if (word.isEmpty()) return new JSONArray();
        JSONObject words = data.load("words");
        if (useLatin) return arr(obj(words, "nextEnglish"), lower(word));
        if ("ar".equals(language) || "fa".equals(language) || "tr".equals(language)) return new JSONArray();
        JSONObject values = obj(words, "nextKurdish");
        JSONArray exact = values.optJSONArray(word);
        if (exact != null) return exact;
        String normal = normalize(word);
        Iterator<String> keys = values.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (normalize(key).equals(normal)) return arr(values, key);
        }
        return new JSONArray();
    }

    private String[] defaultWords(boolean useLatin) {
        if(multilingual && useLatin)return new String[]{"Hello","Thanks","Please","Kurdistan","Awesome"};
        switch (language) {
            case "ar": return new String[]{"السلام", "شكرا", "مرحبا", "إن شاء الله"};
            case "fa": return new String[]{"سلام", "ممنون", "خوبی", "لطفا"};
            case "tr": return new String[]{"Merhaba", "Teşekkürler", "Nasılsın", "Tamam"};
            default: return useLatin ? new String[]{"Hello", "Thanks", "Please", "Kurdistan", "Awesome"}
                    : new String[]{"سڵاو", "سوپاس", "چۆنیت", "دەستخۆش", "کوردستان"};
        }
    }

    private JSONArray hits(JSONObject emojiData, String query) {
        JSONObject keywords = obj(emojiData, "keywords");
        JSONArray hits = keywords.optJSONArray(lower(query));
        if (hits == null) hits = keywords.optJSONArray(query);
        return hits == null ? arr(keywords, normalize(query)) : hits;
    }

    private void addEmoji(JSONArray result, Set<String> seen, JSONObject emoji, String value, int replace) {
        if (!seen.add(value)) return;
        String name = settings.optBoolean("emojiSuggestionShowName") ? obj(emoji, "names").optString(value) : "";
        result.put(json("value", value, "displayLabel", name.isEmpty() ? value : value + " " + name, "isEmoji", true,
                "replaceLength", replace > 0 ? replace : null));
    }

    private static String word(String text) {
        Matcher match = WORD.matcher(text);
        return match.find() ? match.group(1) : "";
    }

    private static String normalize(String word) {
        String input = lower(word);
        StringBuilder result = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= '\u064b' && c <= '\u065f' || c == '\u0670' || c == '\u0640') continue;
            switch (c) {
                case 'ھ': case 'ة': case 'ە': case 'ہ': c = 'ه'; break;
                case 'ي': case 'ى': case 'ێ': c = 'ی'; break;
                case 'ك': c = 'ک'; break;
                case 'ڕ': c = 'ر'; break;
                case 'ڵ': c = 'ل'; break;
                case 'ۆ': case 'ؤ': c = 'و'; break;
                case 'آ': case 'أ': case 'إ': c = 'ا'; break;
                default: break;
            }
            result.append(c);
        }
        return result.toString();
    }

    private static boolean oneEdit(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < a.length() && j < b.length()) {
            if (a.charAt(i) == b.charAt(j)) { i++; j++; continue; }
            if (++edits > 1) return false;
            if (a.length() >= b.length()) i++;
            if (a.length() <= b.length()) j++;
        }
        return edits + (i < a.length() || j < b.length() ? 1 : 0) <= 1;
    }

    private static void append(Set<String> destination, JSONArray source) {
        for (int i = 0; i < source.length(); i++) if (source.opt(i) instanceof String) destination.add(source.optString(i));
    }

    private static void addWord(JSONArray result, Set<String> seen, String value) {
        if (seen.add(value)) result.put(json("value", value));
    }

    private static final class Word {
        final String value, low, normal;
        Word(String value) {
            this.value = value;
            low = lower(value);
            normal = normalize(value);
        }
    }
}
