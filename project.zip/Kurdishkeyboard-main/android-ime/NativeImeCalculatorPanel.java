package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.NativeImePanelStyle.*;

import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

final class NativeImeCalculatorPanel {
    private static final String[][] KEYS = {
            {"C", "(", ")", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "-"}, {"1", "2", "3", "+"}, {"0", ".", "%", "⌫"}
    };

    private final NativeImeView keyboard;
    private final NativeImePanelStyle ui;
    private final NativeImePanels panels;
    private boolean calculator;
    private String expression = "";
    private boolean adding;
    private String snippetTitle = "";
    private String snippetBody = "";

    NativeImeCalculatorPanel(NativeImeView keyboard, NativeImePanelStyle ui, NativeImePanels panels) {
        this.keyboard = keyboard;
        this.ui = ui;
        this.panels = panels;
    }

    void reset() {
        calculator = false;
        expression = "";
        adding = false;
        snippetTitle = "";
        snippetBody = "";
    }

    View render() {
        int height = Math.max(keyboard.settings.optInt("keyboardHeightPx", 248) + 44, 325);
        LinearLayout panel = ui.panel(height, 12, 10);
        LinearLayout header = ui.row();
        LinearLayout tabs = ui.row();
        ui.padding(tabs, 4, 4);
        tabs.setBackground(ui.face(ui.color(0xcce2e8f0, 0xff171920), 12, 0));
        ui.add(tabs, tab("کلێشەکان", "message_square_text", false), WRAP, 32, 0);
        ui.add(tabs, tab("بژمێری خێرا", "calculator", true), WRAP, 32, 4);
        ui.add(header, tabs, WRAP, WRAP, 0);
        ui.flex(header, new View(keyboard.getContext()), 1, 0);
        if (!calculator) {
            TextView add = ui.button("نوێ", 12, adding ? Color.WHITE : ui.color(0xff075985, 0xff7dd3fc), 700,
                    adding ? 0xff059669 : ui.color(0xffe0f2fe, 0x330ea5e9), 12, 0, 10, () -> { adding = !adding; keyboard.render(); });
            ui.titleIcon(add, "plus", 14, 4);
            ui.add(header, add, WRAP, 32, 0);
        }
        ui.add(header, ui.close(() -> keyboard.openPanel("keys"), 16), 32, 32, 6);
        ui.add(panel, header, MATCH, WRAP, 0);
        if (calculator) addCalculator(panel); else addSnippets(panel);
        return panel;
    }

    private TextView tab(String label, String icon, boolean calc) {
        boolean selected = calc == calculator;
        TextView tab = ui.button(label, 12, selected ? Color.WHITE : ui.mutedText(), 700,
                selected ? BLUE : 0, 8, 0, 12, () -> { calculator = calc; keyboard.render(); });
        ui.titleIcon(tab, icon, 14, 6);
        tab.setSelected(selected);
        return tab;
    }

    private void addCalculator(LinearLayout panel) {
        LinearLayout display = ui.row();
        display.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ui.padding(display, 12, 8);
        display.setBackground(ui.face(ui.color(Color.WHITE, 0xff12141a), 16, ui.border()));
        LinearLayout numbers = ui.column();
        numbers.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView entered = mono("", 14, ui.mutedText(), 400);
        TextView preview = mono("", 18, SKY, 800);
        entered.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        preview.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        ui.add(numbers, entered, MATCH, 20, 0);
        ui.add(numbers, preview, MATCH, 28, 0);
        ui.flex(display, numbers, WRAP, 0);

        LinearLayout actions = ui.row();
        TextView equation = ui.button("هاوکێشە", 11, ui.mutedText(), 700, ui.color(0xffe2e8f0, 0x1affffff), 12, 0, 10,
                () -> insert(expression + " = " + value(), true));
        equation.setContentDescription("دانانی هاوکێشە و ئەنجام");
        TextView insert = ui.button("دانان", 12, Color.WHITE, 800, BLUE, 12, 0, 14, () -> insert(value(), true));
        ui.add(actions, equation, WRAP, 36, 0);
        ui.add(actions, insert, WRAP, 36, 6);
        ui.add(display, actions, WRAP, WRAP, 8);
        ui.add(panel, display, MATCH, WRAP, 8);

        Runnable update = () -> {
            String value = value();
            entered.setText(expression.isEmpty() ? "0" : expression);
            preview.setText(value.isEmpty() ? "" : "= " + value);
            ui.enabled(equation, !value.isEmpty());
            ui.enabled(insert, !value.isEmpty());
        };
        for (String[] keys : KEYS) {
            LinearLayout row = ui.row();
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            for (String key : keys) {
                boolean control = "C".equals(key) || "⌫".equals(key);
                boolean operator = "÷×-+%()".contains(key);
                int tint = control ? ui.color(0xffe11d48, 0xfffda4af) : operator ? ui.color(0xff0369a1, 0xff7dd3fc) : ui.foreground();
                int fill = control ? ui.color(0xfffff1f2, 0x26f43f5e) : operator ? ui.color(0xfff0f9ff, 0x260ea5e9) : ui.color(Color.WHITE, 0xff1a1c23);
                int outline = control ? ui.color(0xfffecdd3, 0x40f43f5e) : operator ? ui.color(0xffbae6fd, 0x4038bdf8) : ui.color(0xffe2e8f0, 0x12ffffff);
                TextView cell = mono(key, 16, tint, 700);
                cell.setBackground(ui.face(fill, 12, outline));
                ui.press(cell, () -> { calcKey(key); update.run(); });
                ui.flex(row, cell, MATCH, row.getChildCount() == 0 ? 0 : 6);
            }
            ui.flex(panel, row, MATCH, 6);
        }
        update.run();
    }

    private TextView mono(String label, double size, int color, int weight) {
        TextView text = ui.text(label, size, color, weight);
        text.setTypeface(Typeface.MONOSPACE, weight >= 600 ? Typeface.BOLD : Typeface.NORMAL);
        text.setTextDirection(View.TEXT_DIRECTION_LTR);
        ui.truncate(text);
        return text;
    }

    private void calcKey(String key) {
        switch (key) {
            case "C": expression = ""; break;
            case "⌫": if (!expression.isEmpty()) expression = expression.substring(0, expression.length() - 1); break;
            default: if (expression.length() < 160) expression += key;
        }
    }

    private String value() { return expression.isEmpty() ? "" : keyboard.engine.text("math", expression); }

    private void insert(String text, boolean close) {
        keyboard.insert(text);
        if (close) keyboard.openPanel("keys");
    }

    private void addSnippets(LinearLayout panel) {
        LinearLayout dates = ui.row();
        ui.add(dates, ui.icon("calendar_clock", SKY, 16), 16, 16, 0);
        JSONArray chips = keyboard.engine.array("dateTime", null);
        for (int i = 0; i < chips.length(); i++) {
            JSONObject chip = chips.optJSONObject(i);
            if (chip == null) continue;
            String value = chip.optString("value");
            String label = chip.optString("label") + ": ";
            TextView button = ui.button(label + value, 11, ui.color(0xff1e293b, 0xffe4e4e7), 600,
                    ui.color(Color.WHITE, 0xff171920), 12, ui.border(), 10, () -> insert(value + " ", false));
            android.text.SpannableString title = new android.text.SpannableString(label + value);
            title.setSpan(new android.text.style.ForegroundColorSpan(SKY), 0, label.length(), 0);
            button.setText(title);
            ui.add(dates, button, WRAP, 32, 6);
        }
        ui.add(panel, ui.horizontal(dates), MATCH, 34, 8);
        if (adding) addSnippetFields(panel);
        LinearLayout cards = ui.column();
        JSONArray saved = keyboard.settings.optJSONArray("quickSnippets");
        LinearLayout row = null;
        for (int i = 0; saved != null && i < saved.length(); i++) {
            JSONObject snippet = saved.optJSONObject(i);
            if (snippet == null) continue;
            if (row == null || row.getChildCount() == 2) {
                row = ui.row();
                row.setGravity(Gravity.TOP);
                ui.add(cards, row, MATCH, WRAP, cards.getChildCount() == 0 ? 0 : 8);
            }
            ui.flex(row, snippetCard(snippet), WRAP, row.getChildCount() == 0 ? 0 : 8);
        }
        if (row != null && row.getChildCount() == 1) ui.flex(row, new View(keyboard.getContext()), 1, 8);
        ui.flex(panel, ui.scroll(cards), MATCH, 8);
    }

    private View snippetCard(JSONObject snippet) {
        LinearLayout card = ui.row();
        card.setGravity(Gravity.TOP);
        ui.padding(card, 10, 10);
        card.setBackground(ui.face(ui.color(Color.WHITE, 0xff16181e), 16, ui.color(0xffe2e8f0, 0x14ffffff)));
        LinearLayout words = ui.column();
        TextView title = ui.text(snippet.optString("label"), 11, SKY, 800);
        title.setGravity(Gravity.RIGHT);
        ui.truncate(title);
        ui.add(words, title, MATCH, WRAP, 0);
        String body = snippet.optString("text");
        TextView text = ui.text(body, 12, ui.color(0xff334155, 0xffe4e4e7), 400);
        text.setGravity(Gravity.RIGHT);
        text.setMaxLines(2);
        text.setEllipsize(android.text.TextUtils.TruncateAt.END);
        ui.add(words, text, MATCH, WRAP, 2);
        ui.press(words, () -> insert(body + " ", true));
        ui.flex(card, words, WRAP, 0);
        ui.add(card, ui.iconButton("trash_2", "سڕینەوە", MUTED, 14, 0, 8,
                () -> deleteSnippet(snippet.optString("id"))), 24, 24, 4);
        return card;
    }

    private void addSnippetFields(LinearLayout panel) {
        LinearLayout form = ui.column();
        ui.padding(form, 10, 10);
        form.setBackground(ui.face(ui.color(Color.WHITE, 0xff16181f), 16, ui.border()));
        LinearLayout row = ui.row();
        String heading = "ناونیشانی کورت (وەک: ناونیشانم)";
        String body = "دەقی تەواوی کلێشەکە لێرە بنووسە...";
        ui.flex(row, panels.input(heading, snippetTitle, () -> panels.beginTyping(heading, snippetTitle, "snippets_calc", value -> {
            snippetTitle = value;
            keyboard.render();
        })), 36, 0);
        TextView save = ui.button("پاشەکەوت", 12, Color.WHITE, 700, 0xff0284c7, 12, 0, 12, this::saveSnippet);
        ui.titleIcon(save, "check", 14, 4);
        ui.add(row, save, WRAP, 36, 8);
        ui.add(form, row, MATCH, WRAP, 0);
        ui.add(form, panels.input(body, snippetBody, () -> panels.beginTyping(body, snippetBody, "snippets_calc", value -> {
            snippetBody = value;
            keyboard.render();
        })), MATCH, 36, 8);
        ui.add(panel, form, MATCH, WRAP, 8);
    }

    private void saveSnippet() {
        String text = snippetBody.trim();
        if (text.isEmpty()) return;
        String label = snippetTitle.trim();
        if (label.isEmpty()) label = text.substring(0, text.offsetByCodePoints(0, Math.min(18, text.codePointCount(0, text.length()))));
        JSONArray updated = new JSONArray().put(json("id", "snp_" + System.currentTimeMillis(), "label", label, "text", text));
        JSONArray saved = keyboard.settings.optJSONArray("quickSnippets");
        for (int i = 0; saved != null && i < saved.length(); i++) updated.put(saved.opt(i));
        reset();
        keyboard.settingsPatch(json("quickSnippets", updated));
    }

    private void deleteSnippet(String id) {
        JSONArray saved = keyboard.settings.optJSONArray("quickSnippets");
        JSONArray updated = new JSONArray();
        for (int i = 0; saved != null && i < saved.length(); i++) {
            JSONObject item = saved.optJSONObject(i);
            if (item != null && !id.equals(item.optString("id"))) updated.put(item);
        }
        keyboard.settingsPatch(json("quickSnippets", updated));
    }
}
