package io.kurdikebord.app;

/** Android InputType bit fields; kept framework-independent for JVM tests. */
final class ImeNumericInput {
    static final int NUMBER = 2, PHONE = 3, DATETIME = 4;
    static final int SIGNED = 0x1000, DECIMAL = 0x2000;
    private ImeNumericInput() {}
    static int type(int inputType) {
        int cls = inputType & 0xf;
        return cls == NUMBER || cls == PHONE || cls == DATETIME ? inputType : 0;
    }
    static String digit(int n, boolean kurdish) {
        return String.valueOf((char)((kurdish ? '\u0660' : '0') + n));
    }
    // Control tokens are never committed as text.
    static String[][] rows(int inputType, boolean kurdish) {
        int cls = inputType & 0xf;
        String[] extras = cls == PHONE ? new String[]{"+", "*", "#"}
                : cls == DATETIME ? new String[]{"/", ":", "-"}
                : new String[]{(inputType & SIGNED) != 0 ? "-" : "", (inputType & SIGNED) != 0 ? "+" : "", (inputType & DECIMAL) != 0 ? "." : ""};
        String[][] rows = new String[4][];
        for (int r = 0; r < 3; r++) {
            String a = digit(r * 3 + 1, kurdish), b = digit(r * 3 + 2, kurdish), c = digit(r * 3 + 3, kurdish);
            rows[r] = extras[r].isEmpty() ? new String[]{a,b,c} : new String[]{a,b,c,extras[r]};
        }
        rows[3] = new String[]{"toggle", digit(0,kurdish), "delete", "enter"};
        return rows;
    }
}
