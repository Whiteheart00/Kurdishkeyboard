package io.kurdikebord.app;

final class ImeEmojiCodes {
    private ImeEmojiCodes() {}
    static String hex(String text) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < text.length();) {
            int cp = text.codePointAt(index);
            if (builder.length() != 0) builder.append('-');
            String part = Integer.toHexString(cp);
            for (int pad = part.length(); pad < 4; pad++) builder.append('0');
            builder.append(part);
            index += Character.charCount(cp);
        }
        return builder.toString();
    }

    static String alternative(String code) {
        if (code.contains("-fe0f")) return code.replace("-fe0f", "");
        return !code.isEmpty() && !code.contains("-") && code.length() <= 4 ? code + "-fe0f" : "";
    }
}
