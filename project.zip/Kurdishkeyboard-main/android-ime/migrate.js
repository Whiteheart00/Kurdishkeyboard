(async () => {
  const result = {};
  const read = key => localStorage.getItem(key);
  const shape = (raw, array) => {
    try {
      const value = JSON.parse(raw);
      return value && typeof value === 'object' && Array.isArray(value) === array ? value : undefined;
    } catch { return undefined; }
  };
  const recovery = (key, array) => {
    const entry = shape(read(`${key}:recovery`), false);
    return entry?.version === 1 ? shape(entry.payload, array) : undefined;
  };
  const settings = 'kurdikebord_settings_v2';
  const clipboard = 'kurdikebord_clipboard_v1';
  result.settings = shape(read(settings), false)
    ?? shape(KurdiMigration.recoverySettings(), false) ?? recovery(settings, false);
  result.clipboard = shape(read(clipboard), true) ?? recovery(clipboard, true);
  result.learned = shape(read('kurdikebord_learned_words_v1'), false);
  result.sourceLanguage = read('kurdi_tr_src') ?? undefined;
  result.targetLanguage = read('kurdi_tr_tgt') ?? undefined;

  if (result.settings === undefined || result.clipboard === undefined) {
    const fallback = await new Promise((resolve, reject) => {
      const request = indexedDB.open('kurdikebord_persistent_db', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('kv_store');
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(Error('IndexedDB is blocked'));
      request.onsuccess = () => {
        const db = request.result;
        try {
          const transaction = db.transaction('kv_store', 'readonly');
          const store = transaction.objectStore('kv_store');
          const oldSettings = store.get(settings);
          const oldClipboard = store.get(clipboard);
          transaction.oncomplete = () => {
            db.close();
            resolve({ settings: oldSettings.result, clipboard: oldClipboard.result });
          };
          transaction.onabort = () => { db.close(); reject(transaction.error); };
        } catch (error) { db.close(); reject(error); }
      };
    });
    result.settings ??= shape(JSON.stringify(fallback.settings), false);
    result.clipboard ??= shape(JSON.stringify(fallback.clipboard), true);
  }
  if (result.settings?.keyboardHeightPx === 292 && !read('kurdikebord_compact_ui_v1')) {
    delete result.settings.keyboardHeightPx;
  }
  KurdiMigration.complete(JSON.stringify(result));
})().catch(() => KurdiMigration.failed());
