package io.kurdikebord.app;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

final class NativeGestureSettingsView extends LinearLayout {
    private static final int ACCENT = 0xff9ac5ff;
    private static final int SELECTED = 0xffa4c9ff;
    private static final String LEFT = "spaceBarSwipeLeftAction";
    private static final String RIGHT = "spaceBarSwipeRightAction";

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final boolean rtl;
    private final int foreground;
    private final int border;
    private final Map<String, GestureRow> directionalSpaceRows = new HashMap<>();
    private final TextView languagePreset;
    private final TextView cursorPreset;
    private Dialog picker;

    NativeGestureSettingsView(Context context, String theme, String font, JSONObject data, Runnable back,
                              NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        light = "light".equals(theme);
        rtl = !"ltr".equals(data.optString("direction"));
        foreground = light ? 0xff0f172a : Color.WHITE;
        border = light ? 0xffe2e8f0 : 0x14ffffff;
        appearance = new NativeImeAppearance(context, null);
        setOrientation(VERTICAL);
        setLayoutDirection(rtl ? LAYOUT_DIRECTION_RTL : LAYOUT_DIRECTION_LTR);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = horizontal();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = appearance.text(rtl ? "→" : "←", 20, foreground, "system", 500);
        arrow.setContentDescription(rtl ? "گەڕانەوە" : "Back");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = text(data.optString("title"), 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        divider(this);

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(20));
        scroll.addView(body);

        boolean notifications = data.optBoolean("notificationsEnabled");
        if (!notifications) append(body, NativeSettingsNotification.create(context, appearance, font, change), 0);
        LinearLayout presets = horizontal();
        languagePreset = button("بۆشایی ← گۆڕینی زمان", 12, () -> applyPreset(false));
        cursorPreset = button("بۆشایی ← جووڵاندنی کێرسەر", 12, () -> applyPreset(true));
        addEqual(presets, languagePreset, 40, 0);
        addEqual(presets, cursorPreset, 40, 8);
        append(body, presets, notifications ? 0 : 20);

        JSONArray sections = data.optJSONArray("sections");
        for (int index = 0; sections != null && index < sections.length(); index++) {
            JSONObject section = sections.optJSONObject(index);
            if (section == null) continue;
            LinearLayout group = column();
            append(group, text(section.optString("title"), 12, ACCENT, 700), 0);
            JSONArray rows = section.optJSONArray("rows");
            for (int i = 0; rows != null && i < rows.length(); i++) {
                JSONObject entry = rows.optJSONObject(i);
                if (entry == null) continue;
                GestureRow row = new GestureRow(entry, data.optBoolean("proUnlocked"));
                if (LEFT.equals(row.key) || RIGHT.equals(row.key)) directionalSpaceRows.put(row.key, row);
                append(group, row, 6);
                divider(group);
            }
            append(body, group, 20);
        }
        paintPresets();

        JSONArray thresholds = data.optJSONArray("thresholds");
        for (int index = 0; thresholds != null && index < thresholds.length(); index++) {
            JSONObject threshold = thresholds.optJSONObject(index);
            if (threshold != null) append(body, thresholdCard(threshold), 10);
        }
    }

    private void applyPreset(boolean cursor) {
        GestureRow left = directionalSpaceRows.get(LEFT);
        GestureRow right = directionalSpaceRows.get(RIGHT);
        if (left == null || right == null) return;
        left.select(cursor ? "move_cursor_left" : "switch_to_next_subtype");
        right.select(cursor ? "move_cursor_right" : "switch_to_prev_subtype");
        paintPresets();
        change.accept("spacebarPreset", cursor);
    }

    private void paintPresets() {
        GestureRow left = directionalSpaceRows.get(LEFT);
        GestureRow right = directionalSpaceRows.get(RIGHT);
        boolean cursor = left != null && right != null
                && "move_cursor_left".equals(left.value) && "move_cursor_right".equals(right.value);
        paintChoice(languagePreset, !cursor, true);
        paintChoice(cursorPreset, cursor, true);
    }

    private final class GestureRow extends LinearLayout {
        final String key;
        final String title;
        final JSONArray options;
        final TextView action;
        String value;

        GestureRow(JSONObject entry, boolean unlocked) {
            super(NativeGestureSettingsView.this.getContext());
            key = entry.optString("key");
            title = entry.optString("title");
            options = entry.optJSONArray("options");
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(0, dp(10), 0, dp(10));
            setFocusable(true);
            LinearLayout copy = column();
            LinearLayout heading = horizontal();
            TextView name = text(title, 14, foreground, 700);
            heading.addView(name);
            if (entry.optBoolean("pro") && !unlocked) {
                TextView badge = appearance.text("PRO", 10, Color.WHITE, "system", 800);
                badge.setPadding(dp(6), dp(2), dp(6), dp(2));
                badge.setBackground(appearance.background(0xff465bcb, 6, 0, 0));
                LayoutParams position = new LayoutParams(-2, -2);
                position.setMarginStart(dp(6));
                heading.addView(badge, position);
            }
            append(copy, heading, 0);
            action = text("", 12, ACCENT, 400);
            append(copy, action, 2);
            addView(copy, new LayoutParams(0, -2, 1));
            TextView arrow = appearance.text("⌄", 16, 0xffa1a1aa, "system", 500);
            addView(arrow, new LayoutParams(dp(20), -2));
            select(entry.optString("value"));
            action.setText(entry.optString("valueLabel", action.getText().toString()));
            setOnClickListener(v -> openPicker(this));
        }

        void select(String id) {
            value = id;
            for (int i = 0; options != null && i < options.length(); i++) {
                JSONObject entry = options.optJSONObject(i);
                if (entry != null && id.equals(entry.optString("id"))) {
                    action.setText(entry.optString("label"));
                    return;
                }
            }
            action.setText(id);
        }
    }

    private void openPicker(GestureRow row) {
        if (row.options == null) return;
        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = column();
        panel.setLayoutDirection(getLayoutDirection());
        panel.setBackground(appearance.background(light ? Color.WHITE : 0xff12151d, 24, 1, border));
        panel.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout header = horizontal();
        header.setPadding(dp(8), 0, dp(8), 0);
        header.addView(text(row.title, 14, foreground, 800), new LayoutParams(0, -2, 1));
        TextView close = button("×", 20, dialog::dismiss);
        close.setContentDescription(rtl ? "داخستن" : "Close");
        close.setBackground(appearance.background(light ? 0xfff1f5f9 : 0x1affffff, 16, 0, 0));
        header.addView(close, new LayoutParams(dp(32), dp(32)));
        append(panel, header, 0);
        ScrollView scroller = new ScrollView(getContext());
        LinearLayout list = column();
        scroller.addView(list);
        int maxListHeight = Math.round(getResources().getDisplayMetrics().heightPixels * .75f) - dp(60);
        int idealHeight = dp(row.options.length() * 42);
        LayoutParams listPosition = new LayoutParams(-1, Math.max(dp(42), Math.min(maxListHeight, idealHeight)));
        listPosition.topMargin = dp(10);
        panel.addView(scroller, listPosition);
        for (int index = 0; index < row.options.length(); index++) {
            JSONObject entry = row.options.optJSONObject(index);
            if (entry == null) continue;
            String id = entry.optString("id");
            boolean selected = id.equals(row.value);
            TextView item = text(entry.optString("label") + (selected ? "  ✓" : ""), 12,
                    selected ? Color.WHITE : foreground, 700);
            item.setMinHeight(dp(38));
            item.setPaddingRelative(dp(14), dp(4), dp(14), dp(4));
            if (selected) item.setBackground(appearance.background(0xff0b5fa8, 16, 0, 0));
            append(list, item, 4);
            item.setOnClickListener(v -> {
                row.select(id);
                paintPresets();
                change.accept(row.key, id);
                dialog.dismiss();
            });
        }
        dialog.setContentView(panel);
        dialog.setOnDismissListener(d -> picker = null);
        dialog.show();
        picker = dialog;
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = getResources().getDisplayMetrics().widthPixels;
            window.setLayout(Math.min(dp(448), width - dp(24)), WindowManager.LayoutParams.WRAP_CONTENT);
            window.setGravity(width >= dp(640) ? Gravity.CENTER : Gravity.BOTTOM);
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.y = width >= dp(640) ? 0 : dp(12);
            window.setAttributes(attrs);
            window.setDimAmount(.7f);
        }
    }

    @Override protected void onDetachedFromWindow() {
        if (picker != null) picker.dismiss();
        super.onDetachedFromWindow();
    }

    private View thresholdCard(JSONObject entry) {
        LinearLayout card = column();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(appearance.background(light ? Color.WHITE : 0xff12151c, 16, 1, border));
        LinearLayout top = horizontal();
        top.addView(text(entry.optString("title"), 12, foreground, 700), new LayoutParams(0, -2, 1));
        TextView value = appearance.text("", 12, ACCENT, "system", 700);
        value.setTextDirection(TEXT_DIRECTION_LTR);
        top.addView(value);
        append(card, top, 0);
        LinearLayout choices = horizontal();
        JSONArray options = entry.optJSONArray("options");
        String key = entry.optString("key");
        String unit = entry.optString("unit");
        Consumer<Integer> select = number -> {
            value.setText(number + " " + unit);
            for (int i = 0; i < choices.getChildCount(); i++) {
                TextView choice = (TextView) choices.getChildAt(i);
                paintChoice(choice, choice.getTag().equals(number), false);
            }
        };
        for (int index = 0; options != null && index < options.length(); index++) {
            int number = options.optInt(index);
            TextView choice = button(String.valueOf(number), 12, () -> {
                select.accept(number);
                change.accept(key, number);
            });
            choice.setTag(number);
            addEqual(choices, choice, 32, index == 0 ? 0 : 6);
        }
        select.accept(entry.optInt("value"));
        append(card, choices, 10);
        return card;
    }

    private void paintChoice(TextView view, boolean active, boolean preset) {
        int background = preset ? light ? Color.WHITE : 0xff14171d : light ? 0xfff1f5f9 : 0x0fffffff;
        view.setSelected(active);
        view.setTextColor(active ? 0xff051b3a : light ? 0xff334155 : 0xffd4d4d8);
        view.setBackground(appearance.background(active ? SELECTED : background, preset ? 16 : 12,
                preset ? 1 : 0, active ? SELECTED : border));
    }

    private TextView button(String name, int size, Runnable click) {
        TextView view = appearance.text(name, size, foreground, font, 700);
        view.setOnClickListener(v -> click.run());
        return view;
    }

    private TextView text(String name, int size, int color, int weight) {
        TextView view = appearance.text(name, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setOrientation(VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private void divider(LinearLayout layout) {
        View line = new View(getContext());
        line.setBackgroundColor(border);
        layout.addView(line, new LayoutParams(-1, dp(1)));
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private void addEqual(LinearLayout parent, View child, int height, int gap) {
        LayoutParams params = new LayoutParams(0, dp(height), 1);
        params.setMarginStart(dp(gap));
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
