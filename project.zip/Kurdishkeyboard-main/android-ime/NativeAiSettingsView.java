package io.kurdikebord.app;

import android.content.Context;
import android.app.AlertDialog;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;

/** Settings controls restored from the original AISettingsScreen. No embedded browser. */
final class NativeAiSettingsView extends LinearLayout {
    private final NativeImeAppearance a;
    private final NativeClipboardSettingsView.Change change;
    private final JSONObject data;
    private final String font;
    private final boolean light;
    private final int ink,muted,accent,border;
    private final TextView source,server,result,test;
    NativeAiSettingsView(Context context,String theme,String font,JSONObject data,Runnable back,NativeClipboardSettingsView.Change change){
        super(context);this.data=data;this.change=change;this.font=font;a=new NativeImeAppearance(context,null);light="light".equals(theme);ink=light?0xff0f172a:Color.WHITE;muted=light?0xff64748b:0xffa1a1aa;accent=light?0xff0369a1:0xff9ac5ff;border=light?0xffe2e8f0:0x26ffffff;
        setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_RTL);setBackgroundColor(light?0xfff8fafc:"dark".equals(theme)?0xff0c0e12:Color.BLACK);
        LinearLayout header=row();header.setPadding(dp(16),0,dp(16),0);TextView arrow=text("→",20,ink,700);arrow.setOnClickListener(v->back.run());header.addView(arrow,new LayoutParams(dp(40),dp(55)));header.addView(text("ژیری دەسکرد (AI)",16,ink,700),new LayoutParams(0,dp(55),1));addView(header);
        ScrollView scroll=new ScrollView(context);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));LinearLayout body=column();body.setPadding(dp(16),dp(12),dp(16),dp(24));scroll.addView(body);
        if(!data.optBoolean("notificationsEnabled"))append(body,NativeSettingsNotification.create(context,a,font,change),0);
        LinearLayout line=row();line.addView(description("وەڵامدەرەوەی زیرەک","بەکارهێنانی ژیری دەسکرد بۆ ڕاستکردنەوە و داڕشتنەوەی دەقەکان"),new LayoutParams(0,-2,1));Switch enabled=new Switch(context);enabled.setChecked(data.optBoolean("smartReplyEnabled"));enabled.setOnCheckedChangeListener((v,on)->save("smartReplyEnabled",on));line.addView(enabled);append(body,line,20);
        append(body,text("ڕێکخستنی ژیری دەسکرد",12,accent,700),20);append(body,description("مۆدێلی ژیری دەسکرد","ژیری دەسکردی Gemini (پڕۆکسی سێرڤەری پارێزراو)"),12);divider(body);
        LinearLayout sourceRow=column();append(sourceRow,text("سەرچاوەی دەق",14,ink,700),0);source=text("",12,muted,400);append(sourceRow,source,4);sourceRow.setOnClickListener(v->{save("aiTextSource","selected_or_all".equals(data.optString("aiTextSource"))?"all":"selected_or_all");refresh();});append(body,sourceRow,12);divider(body);
        append(body,text("پەیوەندی سێرڤەر (Vercel AI)",12,accent,700),20);LinearLayout urlRow=column();append(urlRow,text("بەستەری سێرڤەری AI (Vercel)",14,ink,700),0);server=text("",12,muted,400);append(urlRow,server,4);urlRow.setOnClickListener(v->edit());append(body,urlRow,12);divider(body);
        LinearLayout actions=row();test=button("پشکنینی پەیوەندی سێرڤەر",true);test.setOnClickListener(v->testConnection());actions.addView(test,new LayoutParams(0,dp(44),1));TextView edit=button("دەستکاری",false);edit.setOnClickListener(v->edit());LayoutParams lp=new LayoutParams(dp(90),dp(44));lp.setMarginStart(dp(8));actions.addView(edit,lp);append(body,actions,12);
        result=text("",12,muted,500);result.setPadding(dp(12),dp(12),dp(12),dp(12));result.setVisibility(GONE);append(body,result,12);
        guide(body,"چۆنیەتی دروستکردنی لینکی خۆڕایی Vercel (بێ کارتی بانک)","١. پڕۆژەکەت لە GitHub دابنێ.\n٢. لە Vercel پڕۆژەی نوێ زیاد بکە.\n٣. ڕیپۆزیتۆری تەختەکلیلی کوردی هەڵبژێرە.\n٤. GEMINI_API_KEY لە Environment Variables دابنێ و Deploy بکە.\n٥. بەستەرەکە لە سێرڤەری AI دابنێ، یان VITE_API_BASE_URL لە GitHub Secrets.");
        guide(body,"چۆنیەتی بەکارهێنانی ژیری دەسکرد","لە کاتی نووسین لە شریتی ئامرازەکانی کیبۆرد، ئایکۆنی AI هەڵبژێرە. دەقی دیاریکراو یان هەموو دەقەکە بە پێی ڕێکخستنەکەت بەکار دەهێنرێت.");refresh();
    }
    private void save(String key,Object value){ImeStateStore.put(data,key,value);change.accept(key,value);}
    private String base(){return NativeImeNetwork.apiBase(data.optString("aiServerUrl"),getResources().getString(R.string.native_ime_api_base));}
    private void refresh(){source.setText("selected_or_all".equals(data.optString("aiTextSource"))?"دەقی دیاریکراو یان هەمووی":"تەنها هەموو دەقەکە");String url=base();server.setText(url.isEmpty()?"هێشتا بەستەر دیاری نەکراوە":url);}
    private void edit(){EditText input=new EditText(getContext());input.setSingleLine();input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setTextDirection(TEXT_DIRECTION_LTR);input.setText(data.optString("aiServerUrl"));input.setHint("https://example.vercel.app");AlertDialog d=new AlertDialog.Builder(getContext()).setTitle("بەستەری سێرڤەری AI (Vercel)").setView(input).setNegativeButton("داخستن",null).setNeutralButton("بنەڕەتی",(v,w)->{save("aiServerUrl","");refresh();}).setPositiveButton("پاشەکەوت",null).create();d.setOnShowListener(v->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{String raw=input.getText().toString().trim(),normalized=NativeImeNetwork.apiBase(raw,"");if(!raw.isEmpty()&&normalized.isEmpty()){input.setError("بەستەرەکە دروست نییە");return;}save("aiServerUrl",normalized);refresh();d.dismiss();}));d.show();}
    private void testConnection(){final String url=base();if(url.isEmpty()){showResult("هێشتا بەستەری سێرڤەر دیاری نەکراوە",false);return;}test.setEnabled(false);test.setText("خەریکی پشکنینە...");new Thread(()->{String message;boolean ready=false;HttpURLConnection connection=null;try{connection=(HttpURLConnection)new URL(url+"/api/health").openConnection();connection.setConnectTimeout(8000);connection.setReadTimeout(8000);connection.setRequestMethod("GET");connection.setInstanceFollowRedirects(false);if(connection.getResponseCode()!=200)throw new java.io.IOException("HTTP "+connection.getResponseCode());try(java.io.InputStream in=connection.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buf=new byte[2048];int n;while((n=in.read(buf))!=-1){if(out.size()+n>32768)throw new java.io.IOException("Response too large");out.write(buf,0,n);}JSONObject json=new JSONObject(out.toString("UTF-8"));ready=json.optBoolean("ok")&&json.optBoolean("aiConfigured");message=ready?"پەیوەندی سێرڤەر سەرکەوتوو بوو":json.optBoolean("ok")?"سێرڤەر بەردەستە، بەڵام کلیلی AI ڕێک نەخراوە":"وەڵامی سێرڤەر دروست نییە";}}catch(Exception e){message="پەیوەندی سێرڤەر سەرکەوتوو نەبوو";}finally{if(connection!=null)connection.disconnect();}final String msg=message;final boolean ok=ready;post(()->{test.setEnabled(true);test.setText("پشکنینی پەیوەندی سێرڤەر");showResult(msg,ok);});},"native-ai-health").start();}
    private void showResult(String msg,boolean ok){result.setText(msg);result.setTextColor(ok?light?0xff065f46:0xffa7f3d0:light?0xff9f1239:0xfffda4af);result.setBackground(a.background(ok?0x2610b981:0x26f43f5e,16,1,ok?0x5910b981:0x59f43f5e));result.setVisibility(VISIBLE);}
    private void guide(LinearLayout p,String title,String content){TextView b=button(title,false);append(p,b,16);TextView desc=text(content,12,muted,400);desc.setPadding(dp(16),dp(16),dp(16),dp(16));desc.setBackground(a.background(light?Color.WHITE:0xff17181b,16,1,border));desc.setVisibility(GONE);append(p,desc,8);b.setOnClickListener(v->desc.setVisibility(desc.getVisibility()==VISIBLE?GONE:VISIBLE));}
    private LinearLayout description(String title,String subtitle){LinearLayout c=column();append(c,text(title,14,ink,700),0);append(c,text(subtitle,12,muted,400),4);return c;}private int dp(int n){return a.dp(n);}private LinearLayout row(){LinearLayout v=new LinearLayout(getContext());v.setGravity(Gravity.CENTER_VERTICAL);return v;}private LinearLayout column(){LinearLayout v=new LinearLayout(getContext());v.setOrientation(VERTICAL);return v;}private TextView text(String s,int size,int color,int weight){TextView v=a.text(s,size,color,font,weight);v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return v;}private TextView button(String s,boolean primary){TextView v=text(s,12,primary?accent:ink,700);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(8),dp(8),dp(8));v.setMinHeight(dp(44));v.setBackground(a.background(primary?(light?0xfff0f9ff:0x1a38bdf8):0x0affffff,16,1,primary?0x5938bdf8:border));return v;}private void append(LinearLayout p,View v,int gap){LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(gap);p.addView(v,lp);}private void divider(LinearLayout p){View d=new View(getContext());d.setBackgroundColor(border);LayoutParams lp=new LayoutParams(-1,dp(1));lp.topMargin=dp(12);p.addView(d,lp);}
}
