package io.kurdikebord.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

final class NativePredictionSettingsView extends LinearLayout {
    private static final int BLUE = 0xffa4c9ff;
    private static final int MUTED = 0xffa1a1aa;
    private static final String[][] SWITCHES = {
        {"wordSuggestions", "پێشنیارکردنی ووشە", "پیشاندانی ووشە پێشنیارکراوەکان لەکاتی نووسیندا"},
        {"textShortcutsEnabled", "کورتکراوەکانی نووسین", "کاتێک کورتکراوەیەک دەنووسیت (نموونە: س)، ڕستە تەواوەکەی لە شریتی پێشنیارەکان پیشان دەدات"},
        {"autoComplete", "تەواوکەری خۆکاری سیستەم", "پیشاندانی پێشنیاری تەواوکەری خۆکاری سیستەم"},
        {"doubleSpacePeriod", "خاڵبەندی بە دوگمەی بۆشایی", "بە دووجار دەستدان لە دوگمەی بۆشایی خاڵ یان هێمای کۆتایی ڕستە زیادەبێت"},
        {"personalDictionaryEnabled", "فەرهەنگی ناوخۆیی بەرنامەکە", "پێشنیارکردنی ئەو ووشانەی لە فەرهەنگی ناوخۆیی بەرنامەکەدا پاشەکەوتکراون"},
    };

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int border;
    private final List<JSONObject> shortcuts = new ArrayList<>();
    private final List<String> words = new ArrayList<>();
    private final EditText trigger;
    private final EditText expansion;
    private final EditText newWord;
    private final TextView error;
    private final TextView save;
    private final TextView cancel;
    private final TextView shortcutHeading;
    private final TextView dictionaryDetail;
    private final LinearLayout shortcutList;
    private final LinearLayout dictionaryList;
    private String editingId;

    NativePredictionSettingsView(Context context, String theme, String font, JSONObject data, Runnable back,
                                 NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        border = light ? 0xffe2e8f0 : 0x1affffff;
        JSONArray existingShortcuts = data.optJSONArray("textShortcuts");
        for (int i = 0; existingShortcuts != null && i < existingShortcuts.length(); i++) {
            JSONObject shortcut = existingShortcuts.optJSONObject(i);
            if (shortcut != null) shortcuts.add(shortcut);
        }
        JSONArray existingWords = data.optJSONArray("personalDictionary");
        for (int i = 0; existingWords != null && i < existingWords.length(); i++) words.add(existingWords.optString(i));

        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setOrientation(VERTICAL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);
        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("پێشنیارکردن", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        View divider = new View(context);
        divider.setBackgroundColor(border);
        addView(divider, new LayoutParams(-1, dp(1)));

        ScrollView scroller = new ScrollView(context);
        addView(scroller, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setFocusableInTouchMode(true);
        body.setPadding(dp(16), dp(12), dp(16), dp(24));
        scroller.addView(body);
        body.requestFocus();
        boolean notifications = data.optBoolean("notificationsEnabled");
        if (!notifications) append(body, NativeSettingsNotification.create(context, appearance, font, change), 0);
        JSONObject prefs = data.optJSONObject("switches");
        for (int i = 0; i < SWITCHES.length; i++) {
            append(body, switchRow(SWITCHES[i], prefs != null && prefs.optBoolean(SWITCHES[i][0])),
                    i == 0 && notifications ? 0 : 20);
        }

        shortcutHeading = label("", 14, foreground, 700);
        LinearLayout shortcutPanel = panel();
        append(body, disclosure(shortcutHeading,
                label("دانان، دەستکاریکردن و سڕینەوەی کورتکراوەی تایبەتی خۆت (نموونە: س : السَّلَاْمُ عَلَیْکُم براکەم)", 12, MUTED, 400),
                shortcutPanel), 20);
        append(body, shortcutPanel, 10);

        LinearLayout fields = row();
        trigger = input("کورتکراوە (نموونە: س)", this::saveShortcut);
        expansion = input("دەقی تەواو (نموونە: السَّلَاْمُ عَلَیْکُم براکەم)", this::saveShortcut);
        weighted(fields, trigger, 1, 0);
        weighted(fields, expansion, 2, 8);
        append(shortcutPanel, fields, 0);
        error = label("", 11, 0xfffb7185, 700);
        error.setVisibility(GONE);
        append(shortcutPanel, error, 6);
        TextWatcher clearError = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { error.setVisibility(GONE); }
            @Override public void afterTextChanged(Editable editable) {}
        };
        trigger.addTextChangedListener(clearError);
        expansion.addTextChangedListener(clearError);
        LinearLayout actions = row();
        save = button("", true, this::saveShortcut);
        weighted(actions, save, 1, 0);
        cancel = button("پاشگەزبوونەوە", false, () -> { resetShortcut(); renderShortcuts(); });
        LayoutParams cancelPosition = new LayoutParams(-2, dp(40));
        cancelPosition.setMarginStart(dp(8));
        actions.addView(cancel, cancelPosition);
        append(shortcutPanel, actions, 8);
        shortcutList = column();
        ScrollView shortcutScroll = new ScrollView(context) {
            @Override protected void onMeasure(int width, int height) {
                int limit = Math.min(dp(256), MeasureSpec.getMode(height) == MeasureSpec.UNSPECIFIED
                        ? dp(256) : MeasureSpec.getSize(height));
                super.onMeasure(width, MeasureSpec.makeMeasureSpec(limit, MeasureSpec.AT_MOST));
            }
        };
        shortcutScroll.setNestedScrollingEnabled(true);
        shortcutScroll.addView(shortcutList);
        append(shortcutPanel, shortcutScroll, 12);
        resetShortcut();
        renderShortcuts();

        LinearLayout dictionaryPanel = panel();
        dictionaryPanel.setVisibility(GONE);
        dictionaryDetail = label("", 12, MUTED, 400);
        append(body, disclosure(label("ڕێکخستنی فەرهەنگی ناوخۆیی", 14, foreground, 700), dictionaryDetail, dictionaryPanel), 20);
        append(body, dictionaryPanel, 10);
        LinearLayout dictionaryForm = row();
        newWord = input("ووشەیەکی نوێ بنووسە...", this::addWord);
        weighted(dictionaryForm, newWord, 1, 0);
        TextView add = button("＋ زیادکردن", true, this::addWord);
        LayoutParams addPosition = new LayoutParams(-2, dp(40));
        addPosition.setMarginStart(dp(8));
        dictionaryForm.addView(add, addPosition);
        append(dictionaryPanel, dictionaryForm, 0);
        dictionaryList = column();
        append(dictionaryPanel, dictionaryList, 12);
        renderDictionary();
    }

    private void saveShortcut() {
        String shortText = trim(trigger.getText().toString());
        String fullText = trim(expansion.getText().toString());
        int colon = shortText.indexOf(':');
        if (fullText.isEmpty() && colon >= 0) {
            String left = trim(shortText.substring(0, colon));
            String right = trim(shortText.substring(colon + 1));
            if (!left.isEmpty() && !right.isEmpty()) {
                shortText = left;
                fullText = right;
            }
        }
        if (shortText.isEmpty()) {
            showError("تکایە کورتکراوەکە بنووسە (نموونە: س)");
            return;
        }
        if (shortText.chars().anyMatch(NativePredictionSettingsView::isWhitespace)) {
            showError("کورتکراوە نابێت بۆشایی تێدابێت");
            return;
        }
        if (fullText.isEmpty()) {
            showError("تکایە دەقە تەواوەکە بنووسە (نموونە: السَّلَاْمُ عَلَیْکُم براکەم)");
            return;
        }

        JSONObject target = null;
        for (JSONObject item : shortcuts) {
            boolean match = editingId == null ? shortText.toLowerCase(Locale.ROOT).equals(trim(item.optString("shortcut")).toLowerCase(Locale.ROOT))
                    : editingId.equals(item.optString("id"));
            if (match) {
                target = item;
                break;
            }
        }
        try {
            if (target == null) {
                target = new JSONObject().put("id", "sc_" + UUID.randomUUID())
                        .put("shortcut", shortText).put("expansion", fullText);
                shortcuts.add(0, target);
            } else {
                target.put("shortcut", shortText).put("expansion", fullText);
            }
        } catch (JSONException impossible) { return; }
        change.accept("textShortcuts", new JSONArray(shortcuts).toString());
        resetShortcut();
        renderShortcuts();
    }

    private static boolean isWhitespace(int character) {
        return character == 0xfeff || Character.isSpaceChar(character)
                || character >= '\t' && character <= '\r';
    }

    private static String trim(String value) {
        int start = 0;
        int end = value.length();
        while (start < end && isWhitespace(value.charAt(start))) start++;
        while (end > start && isWhitespace(value.charAt(end - 1))) end--;
        return value.substring(start, end);
    }

    private void resetShortcut() {
        editingId = null;
        trigger.setText("");
        expansion.setText("");
        error.setVisibility(GONE);
        save.setText("＋ زیادکردنی کورتکراوە");
        cancel.setVisibility(GONE);
    }

    private void showError(String message) {
        error.setText(message);
        error.setVisibility(VISIBLE);
    }

    private void renderShortcuts() {
        shortcutHeading.setText("کورتکراوە تایبەتەکان (" + shortcuts.size() + ")");
        shortcutList.removeAllViews();
        if (shortcuts.isEmpty()) {
            TextView empty = appearance.text("هیچ کورتکراوەیەک نییە، لە سەرەوە کورتکراوەی تایبەتی خۆت زیاد بکە", 12, MUTED, font, 400);
            empty.setMinHeight(dp(48));
            append(shortcutList, empty, 0);
        }
        for (JSONObject shortcut : shortcuts) {
            String id = shortcut.optString("id");
            LinearLayout line = row();
            line.setPadding(dp(12), dp(8), dp(8), dp(8));
            boolean editing = id.equals(editingId);
            line.setBackground(appearance.background(editing ? 0x2628a1e8 : light ? Color.WHITE : 0x0affffff,
                    12, 1, editing ? BLUE : border));
            TextView tag = appearance.text(shortcut.optString("shortcut"), 12, light ? 0xff075985 : BLUE, font, 800);
            tag.setMaxEms(8);
            tag.setSingleLine();
            tag.setEllipsize(TextUtils.TruncateAt.END);
            tag.setPadding(dp(9), dp(4), dp(9), dp(4));
            tag.setBackground(appearance.background(0x400a5fa8, 8, 0, 0));
            line.addView(tag);
            TextView full = label(shortcut.optString("expansion"), 12, foreground, 500);
            full.setSingleLine();
            full.setEllipsize(TextUtils.TruncateAt.END);
            weighted(line, full, 1, 8);
            compactAction(line, "✎", "دەستکاریکردن", () -> {
                editingId = id;
                trigger.setText(shortcut.optString("shortcut"));
                expansion.setText(shortcut.optString("expansion"));
                save.setText("✓ پاشەکەوتکردنی گۆڕانکاری");
                cancel.setVisibility(VISIBLE);
                renderShortcuts();
            });
            compactAction(line, "×", "سڕینەوە", () -> {
                shortcuts.removeIf(item -> id.equals(item.optString("id")));
                if (id.equals(editingId)) resetShortcut();
                change.accept("textShortcuts", new JSONArray(shortcuts).toString());
                renderShortcuts();
            });
            append(shortcutList, line, shortcutList.getChildCount() == 0 ? 0 : 8);
        }
    }

    private void addWord() {
        String clean = trim(newWord.getText().toString());
        if (clean.isEmpty() || words.contains(clean)) return;
        words.add(0, clean);
        newWord.setText("");
        updateWords();
    }

    private void updateWords() {
        change.accept("personalDictionary", new JSONArray(words).toString());
        renderDictionary();
    }

    private void renderDictionary() {
        dictionaryDetail.setText("زیادکردن، بینین، یان سڕینەوەی ووشەکانی ناو فەرهەنگی ناوخۆیی (" + words.size() + ")");
        dictionaryList.removeAllViews();
        for (String word : words) {
            LinearLayout item = row();
            item.setPadding(dp(12), 0, dp(4), 0);
            item.setBackground(appearance.background(light ? Color.WHITE : 0x0dffffff, 12, 1, border));
            weighted(item, label(word, 12, foreground, 500), 1, 0);
            compactAction(item, "×", "سڕینەوە", () -> {
                words.removeIf(word::equals);
                updateWords();
            });
            append(dictionaryList, item, dictionaryList.getChildCount() == 0 ? 0 : 6);
        }
    }

    private View switchRow(String[] entry, boolean initial) {
        LinearLayout line = row();
        LinearLayout copy = column();
        append(copy, label(entry[1], 14, foreground, 700), 0);
        append(copy, label(entry[2], 12, MUTED, 400), 2);
        weighted(line, copy, 1, 0);
        Switch toggle = new Switch(getContext());
        toggle.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        toggle.setContentDescription(entry[1]);
        toggle.setChecked(initial);
        int[][] states = { {android.R.attr.state_checked}, {} };
        toggle.setThumbTintList(new ColorStateList(states, new int[]{0xff0b3263, 0xff8e939e}));
        toggle.setTrackTintList(new ColorStateList(states, new int[]{BLUE, 0xff6c707a}));
        toggle.setOnCheckedChangeListener((view, checked) -> change.accept(entry[0], checked));
        LayoutParams params = new LayoutParams(dp(52), -2);
        params.setMarginStart(dp(12));
        line.addView(toggle, params);
        return line;
    }

    private View disclosure(TextView title, TextView subtitle, View content) {
        LinearLayout button = row();
        button.setPadding(dp(16), dp(16), dp(16), dp(16));
        button.setBackground(appearance.background(light ? Color.WHITE : 0xff14171d, 16, 1, border));
        LinearLayout text = column();
        append(text, title, 0);
        append(text, subtitle, 2);
        weighted(button, text, 1, 0);
        TextView chevron = appearance.text(content.getVisibility() == VISIBLE ? "⌃" : "⌄", 16, MUTED, "system", 700);
        button.addView(chevron, new LayoutParams(dp(20), -2));
        button.setOnClickListener(v -> {
            boolean open = content.getVisibility() != VISIBLE;
            content.setVisibility(open ? VISIBLE : GONE);
            chevron.setText(open ? "⌃" : "⌄");
        });
        return button;
    }

    private EditText input(String hint, Runnable submit) {
        EditText input = new EditText(getContext());
        input.setSingleLine();
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setTextSize(12);
        input.setTypeface(appearance.text("", 12, foreground, font, 400).getTypeface());
        input.setTextColor(foreground);
        input.setHintTextColor(MUTED);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setBackground(appearance.background(light ? Color.WHITE : 0x80000000, 12, 1, border));
        input.setMinHeight(dp(40));
        input.setHint(hint);
        input.setOnEditorActionListener((v, action, event) -> {
            if (action != EditorInfo.IME_ACTION_DONE && (event == null
                    || event.getKeyCode() != android.view.KeyEvent.KEYCODE_ENTER
                    || event.getAction() != android.view.KeyEvent.ACTION_UP)) return false;
            submit.run();
            return true;
        });
        return input;
    }

    private void compactAction(LinearLayout line, String icon, String description, Runnable action) {
        TextView button = appearance.text(icon, 18, MUTED, "system", 700);
        button.setContentDescription(description);
        button.setOnClickListener(v -> action.run());
        line.addView(button, new LayoutParams(dp(32), dp(36)));
    }

    private TextView button(String text, boolean primary, Runnable action) {
        TextView button = appearance.text(text, 12, primary ? 0xff051b3a : MUTED, font, 800);
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setMinHeight(dp(40));
        button.setBackground(appearance.background(primary ? BLUE : 0x0dffffff, 12, 0, 0));
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private TextView label(String text, int size, int color, int weight) {
        TextView label = appearance.text(text, size, color, font, weight);
        label.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return label;
    }

    private LinearLayout panel() {
        LinearLayout panel = column();
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackground(appearance.background(light ? 0xfff8fafc : 0xff101216, 16, 1, border));
        return panel;
    }

    private LinearLayout row() {
        LinearLayout line = new LinearLayout(getContext());
        line.setGravity(Gravity.CENTER_VERTICAL);
        return line;
    }

    private LinearLayout column() {
        LinearLayout column = new LinearLayout(getContext());
        column.setOrientation(VERTICAL);
        return column;
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private void weighted(LinearLayout parent, View child, int weight, int gap) {
        LayoutParams params = new LayoutParams(0, -2, weight);
        params.setMarginStart(dp(gap));
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
