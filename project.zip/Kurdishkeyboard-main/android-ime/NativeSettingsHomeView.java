package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

/** Native port of the original HomeScreen layout, using its original vector assets. */
final class NativeSettingsHomeView extends LinearLayout {
    private final NativeImeAppearance a;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int ink, muted, surface, border;
    private final JSONObject data;
    private final LinearLayout body;

    NativeSettingsHomeView(Context context, String theme, String font, JSONObject data, Runnable back,
                           NativeClipboardSettingsView.Change change) {
        super(context);
        this.font=font; this.change=change; this.data=data;
        a=new NativeImeAppearance(context,null);
        light="light".equals(theme); ink=light?0xff0f172a:Color.WHITE;
        muted=light?0xff64748b:0xffa1a1aa; surface=light?Color.WHITE:0xff121316;
        border=light?0xffe2e8f0:0x0fffffff;
        setOrientation(VERTICAL); setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light?0xfff1f5f9:0xff07080b);
        ScrollView scroll=new ScrollView(context); scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(false);
        addView(scroll,new LayoutParams(-1,-1)); body=column(); body.setPadding(dp(16),dp(8),dp(16),dp(32)); scroll.addView(body);
        LinearLayout top=row(); top.setPadding(0,dp(8),0,dp(8));
        ImageView logo=new ImageView(context); try(java.io.InputStream in=context.getAssets().open("public/app-icon.png")){logo.setImageBitmap(BitmapFactory.decodeStream(in));}catch(Exception ignored){}
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER); top.addView(logo,new LayoutParams(dp(36),dp(36)));
        TextView title=text("تەختەکلیلی کوردی",20,ink,800); LayoutParams titleLp=new LayoutParams(0,-2,1); titleLp.setMarginStart(dp(10));top.addView(title,titleLp);
        TextView status=text(data.optBoolean("proUnlocked")?"پێشکەوتوو":"ئاسایی",12,ink,700); status.setGravity(Gravity.CENTER); status.setPadding(dp(14),0,dp(14),0); status.setBackground(a.background(light?0xfff1f5f9:0xff17191e,30,1,border));top.addView(status,new LayoutParams(-2,dp(36))); status.setOnClickListener(v->pro()); append(body,top,0);
        if(!data.optBoolean("notificationsEnabled")) append(body,NativeSettingsNotification.create(context,a,font,change),12);
        LinearLayout premium=row(); premium.setPadding(dp(16),dp(16),dp(16),dp(16)); premium.setBackground(gradient(light?0xfff1f5f9:0xff1a2029,light?Color.WHITE:0xff111318,24,border));
        premium.addView(icon("ic_premium",0xfff5b82e,44),new LayoutParams(dp(44),dp(44))); LinearLayout copy=column();copy.addView(text(data.optBoolean("proUnlocked")?"وەشانی پێشکەوتوو چالاکە":"وەشانی پێشکەوتووی بەرنامەکە",14,ink,700));copy.addView(text("بە چەندین تایبەتمەندی هەمەجۆر بەردەستە..",12,muted,400));LayoutParams cp=new LayoutParams(0,-2,1);cp.setMarginStart(dp(14));premium.addView(copy,cp);premium.addView(chevron());premium.setOnClickListener(v->pro());append(body,premium,16);
        activation();
        if(!data.optBoolean("ratingDismissed")) rating();
        tileRow("languages","زمان","ic_language","themes","ڕووکار","ic_themes");
        tileRow("keyboard_prefs","تەختەکلیل","ic_keyboards","media","خەندەکان","ic_xanda");
        TextView site=text("www.kurdikebord.io",20,0xffa5caff,800);site.setGravity(Gravity.CENTER);site.setTextDirection(TEXT_DIRECTION_LTR);append(body,site,24);
        LinearLayout socials=row();socials.setGravity(Gravity.CENTER);for(String[] s:new String[][]{{"یوتوب","ic_youtube"},{"تێلیگرام","ic_telegram"},{"فەیسبووک","ic_facebook"}}){LinearLayout item=column();item.setGravity(Gravity.CENTER);item.addView(icon(s[1],0xff38bdf8,24),new LayoutParams(dp(48),dp(48)));TextView t=text(s[0],12,muted,500);t.setGravity(Gravity.CENTER);item.addView(t);item.setOnClickListener(v->open("faq"));socials.addView(item,new LayoutParams(0,-2,1));}append(body,socials,12);
        group(new String[][]{{"layout_editor","ڕیزبەندی تایبەت","ic_keyboard_keys"},{"clipboard_settings","لەبەرگیراوەکان","ic_clipboards"},{"sound_vibration","دەنگ و لەرزین","ic_sound"}});
        group(new String[][]{{"gestures","ئاماژەکان","ic_swipe"},{"predictions","پێشنیارکردن","ic_spellcheck"},{"more_settings","ڕێکخستنی زیاتر","ic_ui_settings"}});
        group(new String[][]{{"bottom_row","شێوازی بەشی خوارەوە","ic_keyboard_bottom_row"},{"custom_theme","ڕووکاری تایبەت","ic_colors"},{"font_style","فۆنت","ic_font"},{"ai_settings","زیرەکی دەستکرد","ic_smart"},{"activity_logs","تۆمارەکان","ic_history1"}});
        group(new String[][]{{"faq","ڕێنمایی و پرسیارە باوەکان (FAQ)","ic_forum"},{"about","دەربارە","ic_library"}});
    }
    private void activation(){
        boolean enabled=data.optBoolean("imeEnabled"),selected=data.optBoolean("imeSelected"),ready=enabled&&selected;
        LinearLayout card=column();card.setPadding(dp(16),dp(16),dp(16),dp(16));card.setBackground(gradient(light?(ready?0xffecfdf5:0xfff0f9ff):(ready?0xff063526:0xff0b2340),light?Color.WHITE:0xff091320,24,ready?0x5534d399:0x5938bdf8));
        LinearLayout header=row();header.addView(icon(ready?"ic_check":"ic_keyboards",ready?0xff34d399:0xff9ac5ff,24),new LayoutParams(dp(40),dp(40)));LinearLayout labels=column();labels.addView(text(ready?"تەختەکلیلی کوردی چالاکە لە هەموو مۆبایلدا":"چالاککردنی وەک کیبۆردی سەرەکی مۆبایل",14,ink,800));labels.addView(text(ready?"ئێستا لە هەموو بەرنامەکاندا کار دەکات":"بۆ بەکارهێنان لە هەموو بەرنامەکانی مۆبایلدا ئەم دوو هەنگاوە تەواو بکە:",11,muted,400));LayoutParams lp=new LayoutParams(0,-2,1);lp.setMarginStart(dp(12));header.addView(labels,lp);card.addView(header);
        action(card,"١. چالاککردنی تەختەکلیلی کوردی لە ڕێکخستنی مۆبایل",enabled?0xff164e3c:0xff0b5fa8,()->change.accept("enableIme",true));
        action(card,"٢. هەڵبژاردنی تەختەکلیلی کوردی",selected?0xff164e3c:0xff0b5fa8,()->change.accept("selectIme",true));
        action(card,"٣. تاقیکردنەوەی خێرای تەختەکلیل (بێ لاگ)",0xff059669,()->change.accept("testIme",true));append(body,card,16);
    }
    private void rating(){LinearLayout card=column();card.setPadding(dp(20),dp(20),dp(20),dp(20));card.setBackground(gradient(light?0xfff0f9ff:0xff071d33,light?Color.WHITE:0xff051424,24,0x3338bdf8));LinearLayout header=row();TextView t=text("هەڵسەنگاندنی بەرنامەکە",16,light?0xff0c4a6e:0xff8ec2ff,800);t.setGravity(Gravity.CENTER);header.addView(t,new LayoutParams(0,-2,1));TextView close=text("×",22,muted,600);header.addView(close,new LayoutParams(dp(32),dp(32)));close.setOnClickListener(v->{change.accept("ratingDismissed",true);card.setVisibility(GONE);});card.addView(header);LinearLayout stars=row();stars.setLayoutDirection(LAYOUT_DIRECTION_LTR);stars.setGravity(Gravity.CENTER);int initial=data.optInt("userRating");for(int i=1;i<=5;i++){final int value=i;TextView star=text("★",28,i<=initial?0xfffbbf24:0x558ec2ff,700);star.setGravity(Gravity.CENTER);stars.addView(star,new LayoutParams(dp(36),dp(42)));star.setOnClickListener(v->{change.accept("userRating",value);for(int j=0;j<5;j++)((TextView)stars.getChildAt(j)).setTextColor(j<value?0xfffbbf24:0x558ec2ff);});}append(card,stars,8);TextView detail=text("ئەگەر سوودت لە تەختەکلیلی کوردی وەرگرتووە، تکایە بە ٥ ئەستێرە پشتگیریمان بکە",12,muted,400);detail.setGravity(Gravity.CENTER);append(card,detail,8);action(card,"هەڵسەنگاندن لە گۆگڵ پلەی",light?0xff0b5fa8:0xff123553,()->{change.accept("userRating",5);change.accept("ratingDismissed",true);card.setVisibility(GONE);});append(body,card,16);}
    private void pro(){new android.app.AlertDialog.Builder(getContext()).setTitle("وەشانی پێشکەوتوو").setMessage("ڕووکار و تایبەتمەندییە پێشکەوتووەکان").setNegativeButton("داخستن",null).setPositiveButton(data.optBoolean("proUnlocked")?"ناچالاککردن":"چالاککردن",(d,w)->change.accept("proUnlocked",!data.optBoolean("proUnlocked"))).show();}
    private void tileRow(String id1,String t1,String i1,String id2,String t2,String i2){LinearLayout line=row();line.addView(tile(id1,t1,i1),new LayoutParams(0,dp(128),1));LayoutParams p=new LayoutParams(0,dp(128),1);p.setMarginStart(dp(14));line.addView(tile(id2,t2,i2),p);append(body,line,14);}
    private View tile(String id,String title,String icon){LinearLayout tile=column();tile.setGravity(Gravity.CENTER);tile.setBackground(gradient(0xff084d88,0xff063a69,24,0x2638bdf8));ImageView image=icon(icon,Color.WHITE,24);image.setBackground(a.background(0x26ffffff,28,0,0));tile.addView(image,new LayoutParams(dp(52),dp(52)));TextView t=text(title,14,Color.WHITE,700);t.setGravity(Gravity.CENTER);append(tile,t,12);tile.setOnClickListener(v->open(id));return tile;}
    private void group(String[][] rows){LinearLayout group=column();group.setBackground(a.background(surface,24,1,border));for(int i=0;i<rows.length;i++){String[] s=rows[i];if(i>0){View d=new View(getContext());d.setBackgroundColor(border);group.addView(d,new LayoutParams(-1,dp(1)));}LinearLayout line=row();line.setPadding(dp(16),dp(14),dp(16),dp(14));ImageView img=icon(s[2],light?0xff0369a1:0xff8ec2ff,20);img.setBackground(a.background(light?0xfff1f5f9:0xff1d2129,24,0,0));line.addView(img,new LayoutParams(dp(40),dp(40)));LayoutParams p=new LayoutParams(0,-2,1);p.setMarginStart(dp(14));line.addView(text(s[1],14,ink,700),p);line.addView(chevron());line.setOnClickListener(v->open(s[0]));group.addView(line);}append(body,group,16);}
    private void action(LinearLayout card,String label,int color,Runnable fn){TextView b=text(label,12,Color.WHITE,800);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);b.setPadding(dp(14),dp(8),dp(14),dp(8));b.setMinHeight(dp(44));b.setBackground(a.background(color,16,0,0));b.setOnClickListener(v->fn.run());append(card,b,8);}
    private void open(String id){change.accept("openPage",id);}
    private ImageView icon(String name,int tint,int size){ImageView view=new ImageView(getContext());Drawable d=a.icon(name,tint,size);view.setImageDrawable(d);view.setScaleType(ImageView.ScaleType.CENTER);return view;}
    private TextView chevron(){TextView t=text("‹",23,muted,500);t.setGravity(Gravity.CENTER);t.setLayoutParams(new LayoutParams(dp(24),dp(28)));return t;}
    private TextView text(String value,int size,int color,int weight){TextView t=a.text(value,size,color,font,weight);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return t;}
    private GradientDrawable gradient(int top,int bottom,int radius,int stroke){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(getContext());v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout column(){LinearLayout v=new LinearLayout(getContext());v.setOrientation(VERTICAL);return v;}
    private void append(LinearLayout parent,View child,int gap){LayoutParams p=new LayoutParams(-1,-2);p.topMargin=dp(gap);parent.addView(child,p);}
    private int dp(int n){return a.dp(n);}
}
