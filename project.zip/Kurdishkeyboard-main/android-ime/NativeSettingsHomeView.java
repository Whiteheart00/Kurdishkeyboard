package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/**
 * Native settings home — structure aligned with original Kurdish keyboard / Floris-style sections.
 * Opens existing native pages via change("openPage", pageId).
 */
final class NativeSettingsHomeView extends LinearLayout {
    private static final int ACCENT = 0xffa4c9ff;
    private static final int MUTED = 0xff9ca3af;

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int surface;
    private final int border;
    private final int pageBg;

    private static final String[][] SECTIONS = {
            // id, titleKu, descKu, emoji
            {"keyboard_prefs", "تەختەکلیل", "قەبارە، ڕیز، یەکدەستی، پیشاندانی تووڵبار", "⌨"},
            {"languages", "زمانەکان", "هەڵبژاردنی زمانەکانی کیبۆرد", "🌐"},
            {"ai_settings", "زیرەکی دەستکرد", "ڕێکخستنی API", "✦"},
            {"custom_theme", "ڕووکاری تایبەت", "ڕەنگەکان", "🎨"},
            {"typing", "نووسین", "گەورەکردن، بۆشایی خۆکار، درێژکردنەوە", "✎"},
            {"gestures", "جووڵە و ئاماژە", "swipe، long-press، space / delete", "✋"},
            {"sound_vibration", "دەنگ و لەرینەوە", "کلیک، هەستەکی، کەناڵی دەنگ", "🔔"},
            {"layout_editor", "دەستکاریکردنی ڕیزبەندی", "پیت، هێما، ڕاکێشان، پاشەکەوت", "▦"},
            {"bottom_row", "شێوازی بەشی خوارەوە", "دوگمەکانی خوارەوە و قەبارە", "▭"},
            {"clipboard_settings", "کلیپبۆرد", "مێژوو، پێشنیار، پاراستن", "📋"},
            {"predictions", "پێشبینی و فەرهەنگ", "پێشنیار، فێربوون، dictionary", "✦"},
            {"theme_store", "ڕووکار و تێم", "ڕەنگ، سێبەر، ئۆنلاین تێم", "🎨"},
            {"font_style", "فۆنت", "کوردیفۆنت، قەبارە، ستایل", "Aa"},
            {"media", "میدیا و ئیمۆجی", "ئیمۆجی، ستیکەر، مێژوو", "☺"},
            {"more_settings", "زیاتر", "باکئەپ، زمان، پێشکەوتوو", "⚙"},
            {"faq", "پرسیار و وەڵام", "یارمەتی و ڕێنمایی", "❓"},
            {"about", "دەربارە", "وەشان، مۆڵەت، پەرەپێدەر", "ⓘ"},
    };

    NativeSettingsHomeView(Context context, String theme, String font, JSONObject data, Runnable back,
                           NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        pageBg = light ? 0xfff1f5f9 : 0xff0a0b0e;
        surface = light ? Color.WHITE : 0xff12141a;
        border = light ? 0xffe2e8f0 : 0x22ffffff;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(pageBg);

        LinearLayout header = row();
        header.setPadding(dp(12), dp(8), dp(12), dp(8));
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView backBtn = chip("←", 20, foreground, light ? 0xffe2e8f0 : 0xff1c1f27);
        backBtn.setOnClickListener(v -> back.run());
        header.addView(backBtn, new LayoutParams(dp(40), dp(40)));
        TextView title = label("ڕێکخستنەکان", 18, foreground);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LayoutParams(0, -2, 1));
        header.addView(new View(context), new LayoutParams(dp(40), dp(40)));
        addView(header, new LayoutParams(-1, dp(56)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(14), dp(8), dp(14), dp(28));
        scroll.addView(body);

        // Hero card
        LinearLayout hero = column();
        hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.setBackground(appearance.background(light ? 0xffe0f2fe : 0xff0c1929, 20, 1, light ? 0xffbae6fd : 0x33a4c9ff));
        TextView heroTitle = label("تەختەکلیلی کوردی", 16, ACCENT);
        heroTitle.setTypeface(Typeface.DEFAULT_BOLD);
        TextView heroDesc = label("هەموو ڕێکخستنەکان لێرەن — دیزاین و ڕەفتار وەک سیستەمی ڕەسەن، لەگەڵ تایبەتمەندییەکانی خۆت.", 12, MUTED);
        hero.addView(heroTitle);
        hero.addView(heroDesc);
        append(body, hero, 0);

        String group = "";
        for (String[] section : SECTIONS) {
            String id = section[0];
            // soft grouping headers
            String nextGroup = groupOf(id);
            if (!nextGroup.equals(group)) {
                group = nextGroup;
                TextView gh = label(group, 12, ACCENT);
                gh.setPadding(dp(4), dp(16), dp(4), dp(6));
                append(body, gh, 0);
            }
            append(body, sectionRow(id, section[1], section[2], section[3]), group.isEmpty() ? 10 : 8);
        }
    }

    private String groupOf(String id) {
        switch (id) {
            case "keyboard_prefs":
            case "typing":
            case "gestures":
            case "sound_vibration":
            case "layout_editor":
            case "bottom_row":
                return "تەختەکلیل و نووسین";
            case "clipboard_settings":
            case "predictions":
            case "media":
                return "ناوەڕۆک و یارمەتیدەر";
            case "theme_store":
            case "font_style":
                return "ڕووکار";
            default:
                return "گشتی";
        }
    }

    private LinearLayout sectionRow(String id, String title, String desc, String emoji) {
        LinearLayout row = row();
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setBackground(appearance.background(surface, 18, 1, border));
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = chip(emoji, 16, foreground, light ? 0xffe2e8f0 : 0xff1c1f27);
        row.addView(icon, new LayoutParams(dp(42), dp(42)));
        LinearLayout copy = column();
        TextView t = label(title, 14, foreground);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        TextView d = label(desc, 11, MUTED);
        copy.addView(t);
        copy.addView(d);
        LayoutParams cl = new LayoutParams(0, -2, 1);
        cl.setMarginStart(dp(12));
        row.addView(copy, cl);
        TextView chev = label("‹", 18, MUTED);
        row.addView(chev, new LayoutParams(dp(24), dp(24)));
        row.setOnClickListener(v -> change.accept("openPage", id));
        return row;
    }

    private TextView chip(String value, int size, int color, int bg) {
        TextView view = appearance.text(value, size, color, font, 700);
        view.setGravity(Gravity.CENTER);
        view.setBackground(appearance.background(bg, 14, 0, 0));
        return view;
    }

    private TextView label(String value, int size, int color) {
        TextView view = appearance.text(value, size, color, font, 600);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
