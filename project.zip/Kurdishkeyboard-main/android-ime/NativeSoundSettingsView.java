package io.kurdikebord.app;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

final class NativeSoundSettingsView extends LinearLayout {
    private static final int ACCENT = 0xff9ac5ff;
    private static final int SELECTED = 0xffa4c9ff;
    private static final int INK = 0xff051b3a;
    private static final int MUTED = 0xffa1a1aa;

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int surface;
    private final int border;
    private final JSONArray packs;
    private final boolean hasIcons;
    private boolean soundEnabled;
    private boolean vibrationEnabled;
    private String pack;
    private int volume;
    private int duration;
    private MediaPlayer player;

    NativeSoundSettingsView(Context context, String theme, String font, JSONObject data, Runnable back,
                            NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        packs = data.optJSONArray("packs");
        soundEnabled = data.optBoolean("soundEnabled");
        vibrationEnabled = data.optBoolean("vibrationEnabled");
        pack = data.optString("soundPack", "modern");
        volume = Math.max(10, Math.min(100, (int) Math.round(data.optDouble("soundVolume", .75) * 100)));
        duration = Math.max(8, Math.min(60, data.optInt("vibrationDurationMs", 16)));
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : 0xffffffff;
        surface = light ? 0xffffffff : 0xff12151c;
        border = light ? 0xffe2e8f0 : 0x14ffffff;
        NativeImeEngine icons = null;
        try { icons = new NativeImeEngine(context); } catch (IOException ignored) { }
        hasIcons = icons != null;
        appearance = new NativeImeAppearance(context, icons);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setOrientation(VERTICAL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : 0xff000000);

        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : 0xff000000);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("دەنگ و لەرزین", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        View divider = new View(context);
        divider.setBackgroundColor(light ? 0xffe2e8f0 : 0x0dffffff);
        addView(divider, new LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(20));
        scroll.addView(body);
        boolean notifications = data.optBoolean("notificationsEnabled");
        if (!notifications) append(body, NativeSettingsNotification.create(context, appearance, font, change), 0);
        append(body, label("کاریگەری دەنگ / دەستلێدان", 12, ACCENT, 700), notifications ? 0 : 24);

        Toggle sound = new Toggle("چالاککردنی کاریگەری دەنگی", soundEnabled);
        append(body, toggleRow(sound), 16);
        sound.setOnClickListener(v -> {
            soundEnabled = !soundEnabled;
            sound.paint(soundEnabled);
            change.accept("soundEnabled", soundEnabled);
            if (soundEnabled) preview("char", true, false);
        });

        TextView packLabel = label("", 12, MUTED, 400);
        append(body, ends(label("جۆری دەنگی کلیلەکان", 12, light ? foreground : 0xffd4d4d8, 700), packLabel), 20);
        LinearLayout cards = column();
        append(body, cards, 10);
        for (int i = 0; packs != null && i < packs.length(); i++) {
            JSONObject entry = packs.optJSONObject(i);
            if (entry == null) continue;
            PackCard card = new PackCard(entry);
            if (pack.equals(card.id)) packLabel.setText(card.name);
            append(cards, card, i == 0 ? 0 : 8);
            card.setOnClickListener(v -> {
                pack = card.id;
                soundEnabled = true;
                sound.paint(true);
                packLabel.setText(card.name);
                for (int j = 0; j < cards.getChildCount(); j++) ((PackCard) cards.getChildAt(j)).paint();
                change.accept("soundPack", pack);
                preview("char", true, false);
            });
        }
        if (icons != null) icons.close();
        append(body, slider(true), 12);

        append(body, label("کاریگەری لەرزین / دەستلێدان", 12, ACCENT, 700), 24);
        Toggle vibration = new Toggle("چالاککردنی کاریگەری لەرزین", vibrationEnabled);
        append(body, toggleRow(vibration), 16);
        View durationCard = slider(false);
        durationCard.setVisibility(vibrationEnabled ? VISIBLE : GONE);
        append(body, durationCard, 16);
        vibration.setOnClickListener(v -> {
            vibrationEnabled = !vibrationEnabled;
            vibration.paint(vibrationEnabled);
            durationCard.setVisibility(vibrationEnabled ? VISIBLE : GONE);
            change.accept("vibrationEnabled", vibrationEnabled);
            if (vibrationEnabled) preview("char", false, true);
        });

        append(body, label("تاقیکردنەوەی دەنگ و لەرزین", 12, MUTED, 700), 24);
        LinearLayout tester = row();
        String[] keys = {"char", "space", "backspace"};
        String[] names = {"پیت", "بۆشایی", "سڕینەوە"};
        for (int i = 0; i < keys.length; i++) {
            String key = keys[i];
            TextView button = appearance.text(names[i], 12, ACCENT, font, 700);
            button.setBackground(appearance.background(0xff151820, 16, 1, 0x1affffff));
            button.setOnClickListener(v -> preview(key, soundEnabled, vibrationEnabled));
            LayoutParams position = new LayoutParams(0, dp(44), 1);
            if (i > 0) position.setMarginStart(dp(8));
            tester.addView(button, position);
        }
        append(body, tester, 8);
    }

    private View slider(boolean forVolume) {
        LinearLayout card = column();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(appearance.background(surface, 16, 1, border));
        String title = forVolume ? "ئاستی دەنگ" : "ماوەی لەرزین (هێز)";
        TextView value = appearance.text(forVolume ? volume + "%" : duration + " ms", 12, ACCENT, "system", 700);
        value.setTextDirection(TEXT_DIRECTION_LTR);
        append(card, ends(label(title, 12, foreground, 700), value), 0);
        SeekBar seek = new SeekBar(getContext());
        int first = forVolume ? 10 : 8;
        int step = forVolume ? 5 : 2;
        seek.setMax((forVolume ? 100 - first : 60 - first) / step);
        seek.setProgress(Math.round(((forVolume ? volume : duration) - first) / (float) step));
        seek.setContentDescription(title);
        seek.setProgressTintList(ColorStateList.valueOf(SELECTED));
        seek.setThumbTintList(ColorStateList.valueOf(SELECTED));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!fromUser) return;
                int next = first + progress * step;
                if (forVolume) {
                    volume = next;
                    value.setText(volume + "%");
                    change.accept("soundVolume", volume / 100.0);
                } else {
                    duration = next;
                    value.setText(duration + " ms");
                    change.accept("vibrationDurationMs", duration);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { preview("char", forVolume, !forVolume); }
        });
        append(card, seek, 8);
        return card;
    }

    private void preview(String type, boolean sound, boolean vibration) {
        if (vibration) {
            Vibrator vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                int ms = "backspace".equals(type) ? Math.min(65, Math.round(duration * 1.35f)) : duration;
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else vibrator.vibrate(ms);
            }
        }
        if (!sound) return;
        String category = "space".equals(type) ? "space" : "backspace".equals(type) ? "delete" : "standard";
        String file = "native-ime/" + type + ".wav";
        for (int i = 0; packs != null && i < packs.length(); i++) {
            JSONObject entry = packs.optJSONObject(i);
            if (entry == null || !pack.equals(entry.optString("id"))) continue;
            JSONObject files = entry.optJSONObject("files");
            if (files != null) {
                String path = files.optString(category);
                if (path.matches("/assets/aistudio/fx_[a-z0-9_]+\\.(wav|mp3|ogg)")) file = "public" + path;
            }
            break;
        }

        releasePlayer();
        MediaPlayer sample = new MediaPlayer();
        player = sample;
        try (AssetFileDescriptor descriptor = getContext().getAssets().openFd(file)) {
            sample.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build());
            sample.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
            float level = volume / 100f;
            sample.setOnPreparedListener(ready -> {
                if (player != ready) return;
                ready.setVolume(level, level);
                ready.start();
            });
            sample.setOnCompletionListener(done -> { if (player == done) releasePlayer(); });
            sample.setOnErrorListener((failed, what, extra) -> {
                if (player == failed) releasePlayer();
                return true;
            });
            sample.prepareAsync();
        } catch (IOException | IllegalArgumentException | IllegalStateException ignored) {
            releasePlayer();
        }
    }

    @Override protected void onDetachedFromWindow() {
        releasePlayer();
        super.onDetachedFromWindow();
    }

    private void releasePlayer() {
        if (player == null) return;
        MediaPlayer old = player;
        player = null;
        old.release();
    }

    private final class PackCard extends LinearLayout {
        final String id;
        final String name;
        final TextView title;
        final TextView mark;
        final ImageView icon;

        PackCard(JSONObject entry) {
            super(NativeSoundSettingsView.this.getContext());
            id = entry.optString("id");
            name = entry.optString("labelKu");
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(14), dp(12), dp(14), dp(12));
            setFocusable(true);
            icon = new ImageView(getContext());
            icon.setScaleType(ImageView.ScaleType.CENTER);
            addView(icon, new LayoutParams(dp(36), dp(36)));
            LinearLayout copy = column();
            title = label(name, 14, foreground, 700);
            copy.addView(title);
            append(copy, label(entry.optString("subtitle"), 11, MUTED, 400), 2);
            LayoutParams textPosition = new LayoutParams(0, -2, 1);
            textPosition.setMarginStart(dp(12));
            textPosition.setMarginEnd(dp(8));
            addView(copy, textPosition);
            mark = appearance.text("✓", 14, INK, "system", 800);
            mark.setBackground(appearance.background(SELECTED, 12, 0, 0));
            addView(mark, new LayoutParams(dp(24), dp(24)));
            paint();
        }

        void paint() {
            boolean active = id.equals(pack);
            setSelected(active);
            setBackground(appearance.background(active ? 0xff132238 : surface, 16, 1, active ? 0xff7fb5ff : border));
            icon.setBackground(appearance.background(active ? SELECTED : 0x0fffffff, 12, 0, 0));
            if (hasIcons) icon.setImageDrawable(appearance.icon("ic_sound", active ? INK : MUTED, 16));
            title.setTextColor(active ? 0xffffffff : foreground);
            mark.setVisibility(active ? VISIBLE : INVISIBLE);
        }
    }

    private final class Toggle extends FrameLayout {
        final String title;
        private final View knob;

        Toggle(String title, boolean checked) {
            super(NativeSoundSettingsView.this.getContext());
            this.title = title;
            setLayoutDirection(LAYOUT_DIRECTION_LTR);
            setContentDescription(title);
            setFocusable(true);
            knob = new View(getContext());
            addView(knob);
            paint(checked);
        }

        void paint(boolean checked) {
            setSelected(checked);
            setBackground(appearance.background(checked ? ACCENT : 0xff1d1f24, 15, checked ? 0 : 2, 0xff6c707a));
            int size = dp(checked ? 22 : 16);
            FrameLayout.LayoutParams position = new FrameLayout.LayoutParams(
                    size, size, Gravity.CENTER_VERTICAL | (checked ? Gravity.RIGHT : Gravity.LEFT));
            position.setMargins(dp(5), 0, dp(5), 0);
            knob.setLayoutParams(position);
            knob.setBackground(appearance.background(checked ? 0xff0b3263 : 0xff8e939e, 12, 0, 0));
        }
    }

    private LinearLayout toggleRow(Toggle toggle) {
        LinearLayout result = row();
        result.addView(label(toggle.title, 14, foreground, 700), new LayoutParams(0, -2, 1));
        result.addView(toggle, new LayoutParams(dp(52), dp(30)));
        return result;
    }

    private LinearLayout ends(View start, View end) {
        LinearLayout result = row();
        result.addView(start, new LayoutParams(0, -2, 1));
        result.addView(end, new LayoutParams(-2, -2));
        return result;
    }

    private TextView label(String text, int size, int color, int weight) {
        TextView view = appearance.text(text, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private int dp(int size) { return appearance.dp(size); }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }
}
