package io.kurdikebord.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;

/** Local-only status, never records content, tokens, URLs, user IDs or exception messages. */
final class NativeSecurityStatus {
    private static final String PREF="kk_security_status_v9";
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static void note(Context c,String key,int code){
        if(c==null || !ImeStateStore.unlocked(c) || ImeStateStore.incognito(c))return;
        if(!"appcheck".equals(key)&&!"firebase".equals(key)&&!"vault".equals(key)&&!"api".equals(key))return;
        if(code<0||code>599)return;
        SharedPreferences p=prefs(c);long now=System.currentTimeMillis();
        if(p.getInt(key,-1)==code && now-p.getLong(key+"_time",0)<30000)return;
        p.edit().putInt(key,code).putLong(key+"_time",now).apply();
    }
    private static String status(SharedPreferences p,String key,boolean http){
        long t=p.getLong(key+"_time",0);if(t==0)return "هێشتا تاقی نەکراوەتەوە";
        int code=p.getInt(key,0);
        String result=http?(code==0?"Connection failed":"HTTP "+code):(code==1?"OK":"Unavailable");
        return result+" · "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(t));
    }
    static void show(Context c){
        SharedPreferences p=prefs(c);
        String text="App Check token: "+status(p,"appcheck",false)+"\n\nFirebase REST: "+status(p,"firebase",true)+"\n\nClipboard vault: "+status(p,"vault",false)+"\n\nAI / Translation HTTP: "+status(p,"api",true)+"\n\nIncognito: "+(ImeStateStore.incognito(c)?"ON":"OFF")+"\n\n"+
            "ئەمە دوا دۆخی تۆمارکراوە، نەک پشکنینی ڕاستەوخۆی سێرڤەر. Redis و App Check Enforcement تەنها لە Console و تاقیکردنەوەی سێرڤەر پشتڕاست دەکرێنەوە. HTTP 429 واتە سنووردارکردن؛ هۆکاری وردی لەم ڕاپۆرتەدا دیار نییە.";
        TextView v=new TextView(c);v.setText(text);v.setTextSize(15);v.setPadding(28,20,28,20);v.setTextIsSelectable(true);
        ScrollView scroll=new ScrollView(c);scroll.addView(v);new AlertDialog.Builder(c).setTitle("Security Dashboard").setView(scroll).setPositiveButton("داخستن",null).show();
    }
}
