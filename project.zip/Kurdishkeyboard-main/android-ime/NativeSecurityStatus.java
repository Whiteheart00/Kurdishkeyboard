package io.kurdikebord.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;

/** Local-only status, never records content, tokens, URLs, user IDs or exception messages. */
final class NativeSecurityStatus {
    private static final String PREF="kk_security_status_v9";
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static void note(Context c,String key,int code){
        if(c==null || !ImeStateStore.unlocked(c) || ImeStateStore.incognito(c))return;
        if(!"appcheck".equals(key)&&!"firebase".equals(key)&&!"vault".equals(key)&&!"api".equals(key))return;
        if(code<0||code>599)return;
        SharedPreferences p=prefs(c);long now=System.currentTimeMillis();
        if(p.getInt(key,-1)==code && now-p.getLong(key+"_time",0)<30000)return;
        p.edit().putInt(key,code).putLong(key+"_time",now).apply();
    }
    /** Read-only snapshot; refresh rereads local status, never starts a network request. */
    static View create(Context c,String theme,String font,Runnable back){
        return new Dashboard(c,theme,font,back);
    }
    private static final class Dashboard extends LinearLayout {
        private final NativeImeAppearance appearance;
        private final String font;
        private final boolean light;
        private final int ink,muted,surface,border,blue,green,amber,red;
        private final LinearLayout body;
        Dashboard(Context c,String theme,String font,Runnable back){
            super(c); this.font=font; light="light".equals(theme);
            appearance=new NativeImeAppearance(c,null);
            ink=light?0xff0f172a:Color.WHITE; muted=light?0xff475569:0xffa1a1aa;
            surface=light?Color.WHITE:0xff18191c; border=light?0xffe2e8f0:0x1affffff;
            blue=light?0xff075985:0xff8ec2ff;green=light?0xff166534:0xff86efac;
            amber=light?0xff92400e:0xfffcd34d;red=light?0xffb91c1c:0xfffda4af;
            setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_RTL);
            setBackgroundColor(light?0xfff8fafc:"dark".equals(theme)?0xff0c0e12:Color.BLACK);
            LinearLayout header=new LinearLayout(c);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(16),0,dp(16),0);
            TextView arrow=appearance.text("→",22,ink,"system",500);arrow.setContentDescription("گەڕانەوە");arrow.setOnClickListener(v->back.run());
            header.addView(arrow,new LayoutParams(dp(48),dp(55)));
            TextView title=label("داشبۆردی ئاسایش",16,ink,700);header.addView(title,new LayoutParams(0,dp(55),1));
            addView(header,new LayoutParams(-1,dp(55))); View line=new View(c);line.setBackgroundColor(border);addView(line,new LayoutParams(-1,dp(1)));
            ScrollView scroll=new ScrollView(c);scroll.setFillViewport(true);addView(scroll,new LayoutParams(-1,0,1));
            body=column();body.setPadding(dp(16),dp(16),dp(16),dp(24));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
            render();
        }
        private int dp(int n){return appearance.dp(n);}
        private LinearLayout column(){LinearLayout l=new LinearLayout(getContext());l.setOrientation(VERTICAL);return l;}
        private TextView label(String value,int size,int tint,int weight){TextView t=appearance.text(value,size,tint,font,weight);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,size);t.setIncludeFontPadding(true);return t;}
        private void append(LinearLayout parent,View child,int top){LayoutParams p=new LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(child,p);}
        private LinearLayout card(){LinearLayout l=column();l.setPadding(dp(16),dp(12),dp(16),dp(12));l.setBackground(appearance.background(surface,22,1,border));return l;}
        private void render(){
            body.removeAllViews();
            LinearLayout summary=card();
            append(summary,label("پاراستنی داتا و پەیوەندی",17,blue,700),0);
            append(summary,label("دوا دۆخی تۆمارکراوی ئامرازەکان لەسەر ئەم مۆبایلە. ئەمە پشکنینی ڕاستەوخۆی سێرڤەر نییە.",12,muted,400),6);
            TextView refresh=label("↻   نوێکردنەوەی دۆخ",13,blue,700);refresh.setGravity(Gravity.CENTER);refresh.setMinHeight(dp(48));refresh.setBackground(appearance.background(light?0xffeff6ff:0xff193646,14,1,blue));refresh.setOnClickListener(v->render());append(summary,refresh,12);
            append(body,summary,0);
            SharedPreferences p=prefs(getContext());
            statusCard(p,"appcheck","App Check","دوا هەوڵی وەرگرتنی تۆکنی Play Integrity",false);
            statusCard(p,"firebase","Firebase REST","دوا وەڵامی پەیوەندیی پاشەکەوت",true);
            statusCard(p,"vault","پاراستنی Clipboard","دوا دۆخی کارکردنی خەزنەی شفرەکراو",false);
            statusCard(p,"api","AI و وەرگێڕان","دوا وەڵامی HTTP ـی ئامرازەکانی نووسین",true);
            boolean incognito=ImeStateStore.incognito(getContext());
            LinearLayout privacy=card();append(privacy,label("نووسینی تایبەت (Incognito)",15,ink,700),0);
            append(privacy,label(incognito?"چالاکە":"ناچالاکە",13,incognito?green:muted,700),4);
            append(privacy,label("لە ڕێکخستنی زیاتر دەتوانیت دۆخی نووسینی تایبەت بگۆڕیت.",12,muted,400),4);append(body,privacy,12);
            LinearLayout info=card();append(info,label("پشکنینی سێرڤەر",15,blue,700),0);
            append(info,label("Redis و App Check Enforcement تەنها لە Console و تاقیکردنەوەی سێرڤەر پشتڕاست دەکرێنەوە. HTTP 429 نیشانەی سنووردارکردنە؛ هۆکاری ورد لێرە دیار نییە. کلیل، تۆکن و دەقی تایبەت پیشان نادرێن.",12,muted,400),6);append(body,info,12);
        }
        private void statusCard(SharedPreferences p,String key,String title,String description,boolean http){
            long time=p.getLong(key+"_time",0);int code=p.getInt(key,0);
            int tint;String status;
            if(time==0){tint=muted;status="هێشتا تاقی نەکراوەتەوە";}
            else if(http){tint=code>=200&&code<300?green:code==429?amber:red;status=code==0?"پەیوەندی سەرکەوتوو نەبوو":"HTTP "+code;}
            else {tint=code==1?green:amber;status=code==1?"سەرکەوتوو (OK)":"بەردەست نییە";}
            LinearLayout item=card();append(item,label(title,15,ink,700),0);append(item,label(description,12,muted,400),4);
            TextView state=label(status,13,tint,700);state.setPadding(dp(12),dp(8),dp(12),dp(8));state.setBackground(appearance.background(light?0xfff1f5f9:0xff222429,12,0,0));append(item,state,10);
            if(time>0){TextView stamp=label(DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(time)),11,muted,400);stamp.setTextDirection(TEXT_DIRECTION_LTR);append(item,stamp,5);}
            append(body,item,12);
        }
    }
}
