package io.kurdikebord.app;
import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;
import com.google.android.gms.tasks.Tasks;
import java.util.concurrent.TimeUnit;
/** Monitor-first attestation for Firebase REST. Console enforcement controls rejection. */
final class NativeAppCheck {
    private static FirebaseAppCheck instance;
    private static synchronized FirebaseAppCheck get(Context context) {
        if(instance==null){
            FirebaseApp app=FirebaseApp.getInstance();
            FirebaseAppCheck check=FirebaseAppCheck.getInstance(app);
            check.installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance(),false);
            instance=check;
        }
        return instance;
    }
    static String token(Context c){
        try {
            if(android.os.Looper.myLooper()==android.os.Looper.getMainLooper())return null;
            return Tasks.await(get(c).getAppCheckToken(false),15,TimeUnit.SECONDS).getToken();
        } catch(Exception unavailable) {
            // Monitoring stage: let the server decide. Never log tokens or use debug attestation.
            android.util.Log.w("NativeAppCheck","App Check token unavailable");return null;
        }
    }
}
