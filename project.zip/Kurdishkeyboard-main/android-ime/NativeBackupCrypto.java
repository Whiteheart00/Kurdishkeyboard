package io.kurdikebord.app;

import java.io.*;
import java.security.SecureRandom;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Versioned encrypted container. Header is authenticated; no plaintext written to disk. */
final class NativeBackupCrypto {
    static final int MAX = 16 * 1024 * 1024;
    private static final byte[] MAGIC = {'K','K','B','A','C','K',1,0};
    private static final int ROUNDS = 600000, HEADER = 8 + 16 + 12;
    private static final SecureRandom RNG = new SecureRandom();
    private static Cipher cipher(int mode, char[] password, byte[] header) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(password, Arrays.copyOfRange(header,8,24),ROUNDS,256);
        byte[] key = null;
        try {
            key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(mode,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,header,24,12));
            cipher.updateAAD(header);
            return cipher;
        } finally { spec.clearPassword(); if(key!=null) Arrays.fill(key,(byte)0); }
    }
    static void encrypt(byte[] plain, char[] password, OutputStream out) throws Exception {
        if(plain.length>MAX || password.length<12) throw new IOException("Invalid backup size or passphrase");
        byte[] header = new byte[HEADER]; RNG.nextBytes(header); System.arraycopy(MAGIC,0,header,0,MAGIC.length);
        byte[] encrypted = cipher(Cipher.ENCRYPT_MODE,password,header).doFinal(plain);
        out.write(header); out.write(encrypted); out.flush();
    }
    static byte[] decrypt(InputStream in, char[] password) throws Exception {
        DataInputStream input = new DataInputStream(in); byte[] header = new byte[HEADER]; input.readFully(header);
        if(!Arrays.equals(MAGIC,Arrays.copyOf(header,8))) throw new IOException("Unsupported backup format");
        ByteArrayOutputStream body = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int n;
        while((n=input.read(buffer))!=-1) { if(body.size()+n>MAX+16) throw new IOException("Backup too large"); body.write(buffer,0,n); }
        return cipher(Cipher.DECRYPT_MODE,password,header).doFinal(body.toByteArray());
    }
}
