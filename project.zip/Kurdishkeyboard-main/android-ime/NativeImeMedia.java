package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.NativeImeData.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashSet;
import java.util.Set;

final class NativeImeMedia {
    private static final String KASHIDA_JOINABLE = "بپتثجچحخسشصضطظعغفڤقکكگلڵمنهیيێ";
    private final NativeImeData data;

    NativeImeMedia(NativeImeData data) { this.data = data; }

    JSONArray search(String input, int limit) {
        String query = lower(trim(input));
        JSONArray result = new JSONArray();
        if (query.isEmpty()) return result;
        JSONArray categories = arr(data.load("media"), "categories");
        for (int i = 0; i < categories.length(); i++) {
            JSONArray items = arr(categories.optJSONObject(i), "items");
            for (int j = 0; j < items.length(); j++) {
                JSONObject entry = items.optJSONObject(j);
                if (entry.optString("c").equals(query) || lower(entry.optString("k")).contains(query)
                        || lower(entry.optString("e")).contains(query)) {
                    result.put(entry);
                    if (result.length() >= limit) return result;
                }
            }
        }
        return result;
    }

    String emojiModifier(JSONObject entry, String tone, String hair) {
        String base = entry.optString("c");
        if (!hair.isEmpty() && ("👨".equals(base) || "👩".equals(base) || "🧑".equals(base))) {
            return base + tone + "\u200d" + hair;
        }
        if (tone.isEmpty()) return base;
        JSONArray variants = arr(entry, "v");
        JSONObject selected = find(arr(data.load("media"), "skinTones"), "mod", tone);
        String exact = selected == null ? "" : variants.optString(selected.optInt("index", -1));
        if (!exact.isEmpty()) return exact;
        for (int i = 0; i < variants.length(); i++) if (variants.optString(i).contains(tone)) return variants.optString(i);
        return base;
    }

    JSONArray emojiVariants(JSONObject entry, String tone) {
        String base = entry.optString("c");
        Set<String> variants = new LinkedHashSet<>();
        variants.add(base);
        JSONArray tones = arr(entry, "v");
        for (int i = 0; i < tones.length(); i++) variants.add(tones.optString(i));
        if ("👨".equals(base) || "👩".equals(base) || "🧑".equals(base)) {
            JSONArray styles = arr(data.load("media"), "hairStyles");
            for (int i = 0; i < styles.length(); i++) {
                String hair = styles.optJSONObject(i).optString("mod");
                if (!hair.isEmpty()) variants.add(emojiModifier(entry, tone, hair));
            }
        }
        return new JSONArray(variants);
    }

    String decorate(String id, String text) {
        switch (id) {
            case "kashida": return kashida(text);
            case "royal_frame": return frame(text, "꧁༒ ", " ༒꧂");
            case "hearts_frame": return frame(text, "♡︎ ", " ♡︎");
            case "stars_frame": return frame(text, "★彡 ", " 彡★");
            case "kurdish_ornate": return frame(kashida(trim(text)), "✦ ༺ ", " ༻ ✦");
            case "none": return text;
            default:
                JSONObject mapping = obj(obj(data.load("media"), "decorationMaps"), id);
                if (mapping.length() == 0) return text;
                StringBuilder converted = new StringBuilder();
                for (int i = 0; i < text.length(); ) {
                    int point = text.codePointAt(i);
                    String value = new String(Character.toChars(point));
                    converted.append(mapping.optString(value, value));
                    i += Character.charCount(point);
                }
                return converted.toString();
        }
    }

    private static String frame(String text, String prefix, String suffix) {
        String clean = trim(text);
        return clean.isEmpty() ? "" : prefix + clean + suffix;
    }

    private static String kashida(String text) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); ) {
            int code = text.codePointAt(i);
            result.appendCodePoint(code);
            i += Character.charCount(code);
            if (i < text.length() && KASHIDA_JOINABLE.indexOf(code) >= 0 && text.charAt(i) != ' ' && text.charAt(i) != '\n') result.append('ـ');
        }
        return result.toString();
    }

    static JSONObject recordHistory(JSONArray args) {
        JSONObject history = args.optJSONObject(0);
        String value = trim(args.optString(1));
        JSONArray pinned = arr(history, "pinned"), recent = arr(history, "recent");
        String strategy = args.optString(2);
        boolean manual = "manual_prepend".equals(strategy) || "manual_append".equals(strategy);
        if (value.isEmpty() || contains(pinned, value) || manual && contains(recent, value)) return history;
        int limit = Math.max(5, Math.min(120, defaultLimit(args.optInt(3), 40)));
        boolean append = strategy.endsWith("_append");
        JSONArray revised = withValue(recent, value, append);
        JSONArray limited = new JSONArray();
        int start = append ? Math.max(0, revised.length() - limit) : 0;
        for (int i = start; i < Math.min(revised.length(), start + limit); i++) limited.put(revised.opt(i));
        return json("pinned", pinned, "recent", limited);
    }

    static JSONObject togglePin(JSONArray args) {
        JSONObject history = args.optJSONObject(0);
        String value = trim(args.optString(1));
        if (value.isEmpty()) return history;
        JSONArray pinned = arr(history, "pinned"), recent = arr(history, "recent");
        if (contains(pinned, value)) {
            return json("pinned", remove(pinned, value),
                    "recent", limit(withValue(recent, value, false), Math.max(5, defaultLimit(args.optInt(3), 40))));
        }
        return json("pinned", limit(withValue(pinned, value, false), Math.max(4, Math.min(80, defaultLimit(args.optInt(2), 24)))),
                "recent", remove(recent, value));
    }

    private static int defaultLimit(int value, int fallback) { return value == 0 ? fallback : value; }

    private static JSONArray limit(JSONArray source, int size) {
        JSONArray result = new JSONArray();
        for (int i = 0; i < Math.min(source.length(), size); i++) result.put(source.opt(i));
        return result;
    }

    private static JSONArray remove(JSONArray source, String value) {
        JSONArray result = new JSONArray();
        for (int i = 0; i < source.length(); i++) if (!value.equals(source.optString(i))) result.put(source.opt(i));
        return result;
    }

    private static JSONArray withValue(JSONArray source, String value, boolean append) {
        if (append) return remove(source, value).put(value);
        JSONArray result = new JSONArray().put(value);
        for (int i = 0; i < source.length(); i++) if (!value.equals(source.optString(i))) result.put(source.opt(i));
        return result;
    }
}
