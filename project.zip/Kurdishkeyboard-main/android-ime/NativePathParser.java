package io.kurdikebord.app;

import android.graphics.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** SVG path data to Android graphics primitives, with no external runtime libraries. */
final class NativePathParser {
    private static final Pattern NUMBER = Pattern.compile("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?");
    private final String data;
    private final Matcher number;
    private final Path path = new Path();
    private int pos;
    private double x, y, startX, startY, controlX, controlY;
    private char previous;

    private NativePathParser(String data) {
        this.data = data;
        number = NUMBER.matcher(data);
    }

    static Path createPathFromPathData(String data) {
        return data == null ? null : new NativePathParser(data).parse();
    }

    private void skip() {
        while (pos < data.length() && (Character.isWhitespace(data.charAt(pos)) || data.charAt(pos) == ',')) pos++;
    }
    private IllegalArgumentException invalid() {
        return new IllegalArgumentException("Invalid vector path at offset " + pos);
    }
    private double read() {
        skip();
        number.region(pos, data.length());
        if (!number.lookingAt()) throw invalid();
        pos = number.end();
        double value = Double.parseDouble(number.group());
        if ((Double.isNaN(value) || Double.isInfinite(value)) || Math.abs(value) > Float.MAX_VALUE) throw invalid();
        return value;
    }
    private boolean flag() {
        skip();
        if (pos >= data.length()) throw invalid();
        char c = data.charAt(pos++);
        if (c != '0' && c != '1') throw invalid();
        return c == '1';
    }
    private double px(boolean relative) { return read() + (relative ? x : 0); }
    private double py(boolean relative) { return read() + (relative ? y : 0); }
    private void line(double nx, double ny) { path.lineTo((float) nx, (float) ny); x = nx; y = ny; }
    private void cubic(double ax, double ay, double bx, double by, double nx, double ny) {
        path.cubicTo((float) ax, (float) ay, (float) bx, (float) by, (float) nx, (float) ny);
        controlX = bx; controlY = by; x = nx; y = ny;
    }
    private void quad(double ax, double ay, double nx, double ny) {
        path.quadTo((float) ax, (float) ay, (float) nx, (float) ny);
        controlX = ax; controlY = ay; x = nx; y = ny;
    }
    private Path parse() {
        char cmd = 0;
        boolean first = true;
        while (true) {
            skip();
            if (pos == data.length()) return path;
            char c = data.charAt(pos);
            if (Character.isLetter(c)) { cmd = c; pos++; }
            if (cmd == 0) throw invalid();
            boolean rel = Character.isLowerCase(cmd);
            char op = Character.toUpperCase(cmd);
            if (first && op != 'M') throw invalid();
            first = false;
            switch (op) {
                case 'M':
                    startX = px(rel); startY = py(rel); x = startX; y = startY;
                    path.moveTo((float) x, (float) y);
                    cmd = rel ? 'l' : 'L';
                    break;
                case 'L': line(px(rel), py(rel)); break;
                case 'H': line(px(rel), y); break;
                case 'V': line(x, py(rel)); break;
                case 'C': cubic(px(rel), py(rel), px(rel), py(rel), px(rel), py(rel)); break;
                case 'S': {
                    boolean reflect = previous == 'C' || previous == 'S';
                    cubic(reflect ? 2*x-controlX : x, reflect ? 2*y-controlY : y,
                            px(rel), py(rel), px(rel), py(rel));
                    break;
                }
                case 'Q': quad(px(rel), py(rel), px(rel), py(rel)); break;
                case 'T': {
                    boolean reflect = previous == 'Q' || previous == 'T';
                    quad(reflect ? 2*x-controlX : x, reflect ? 2*y-controlY : y, px(rel), py(rel));
                    break;
                }
                case 'A': {
                    double rx = read(), ry = read(), rotation = read();
                    boolean large = flag(), sweep = flag();
                    arc(rx, ry, rotation, large, sweep, px(rel), py(rel));
                    break;
                }
                case 'Z':
                    path.close(); x = startX; y = startY; cmd = 0;
                    break;
                default: throw invalid();
            }
            previous = op;
        }
    }

    /** Convert endpoint-form ellipses to at most quarter-circle cubic segments. */
    private void arc(double rx, double ry, double degrees, boolean large, boolean sweep, double nx, double ny) {
        if (x == nx && y == ny) return;
        rx = Math.abs(rx); ry = Math.abs(ry);
        if (rx == 0 || ry == 0) { line(nx, ny); return; }
        double phi = Math.toRadians(degrees % 360), cos = Math.cos(phi), sin = Math.sin(phi);
        double dx = (x-nx)/2, dy = (y-ny)/2;
        double u = (cos*dx + sin*dy)/rx, v = (-sin*dx + cos*dy)/ry;
        double scale = Math.hypot(u, v);
        if (scale > 1) { rx *= scale; ry *= scale; u /= scale; v /= scale; }
        double norm = u*u + v*v;
        if (norm == 0 || (Double.isNaN(norm) || Double.isInfinite(norm))) { line(nx, ny); return; }
        double k = (large == sweep ? -1 : 1) * Math.sqrt(Math.max(0, (1-norm)/norm));
        double cu = k*v, cv = -k*u;
        double cx = (x+nx)/2 + cos*rx*cu - sin*ry*cv;
        double cy = (y+ny)/2 + sin*rx*cu + cos*ry*cv;
        double a = Math.atan2(v-cv, u-cu);
        double b = Math.atan2(-v-cv, -u-cu);
        double delta = b-a;
        if (sweep && delta < 0) delta += 2*Math.PI;
        if (!sweep && delta > 0) delta -= 2*Math.PI;
        int count = Math.max(1, (int) Math.ceil(Math.abs(delta)/(Math.PI/2)));
        double step = delta/count;
        for (int i=0; i<count; i++) {
            double end = a+step, t = 4.0/3 * Math.tan(step/4);
            double sx = -cos*rx*Math.sin(a)-sin*ry*Math.cos(a);
            double sy = -sin*rx*Math.sin(a)+cos*ry*Math.cos(a);
            double ex = -cos*rx*Math.sin(end)-sin*ry*Math.cos(end);
            double ey = -sin*rx*Math.sin(end)+cos*ry*Math.cos(end);
            double fx = i==count-1 ? nx : cx+cos*rx*Math.cos(end)-sin*ry*Math.sin(end);
            double fy = i==count-1 ? ny : cy+sin*rx*Math.cos(end)+cos*ry*Math.sin(end);
            cubic(x+t*sx, y+t*sy, fx-t*ex, fy-t*ey, fx, fy);
            a = end;
        }
    }
}
