package io.kurdikebord.app;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;


import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Native Android settings activity. */
public class MainActivity extends android.app.Activity {
    static final String EXTRA_EMOJI_SETTINGS = "io.kurdikebord.app.OPEN_EMOJI_SETTINGS";
    static final String EXTRA_NATIVE_SETTINGS = "io.kurdikebord.app.OPEN_NATIVE_SETTINGS";
    public static final String DIAG_PREFS_NAME = "kurdikebord_diag_prefs";
    public static final String DIAG_LOGS_KEY = "native_events_json";
    private static final int MAX_NATIVE_LOGS = 400;
    private static final int MAX_NATIVE_LOG_CHARS = 340_000;
    private static volatile boolean crashHandlerInstalled = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private View nativeSettingsPage;
    private static final int OPEN_SETTINGS_BACKUP = 21704;
    private NativeMoreSettingsView backupPickerOwner;
    private static final int EXPORT_ACTIVITY_REPORT = 21706;
    private static final int CLOUD_BACKUP = 21707;
    private String pendingActivityReport;
    private Dialog activeTestDialog = null;
    private String currentPage = "settings_home";
    private NativeImeData pageData;
    private NativeImeAppearance chromeAppearance;
    private android.graphics.Bitmap chromeLogo;
    private NativeImeData pageData() { if (pageData == null) pageData = new NativeImeData(this); return pageData; }
    private boolean homeImeEnabled, homeImeSelected;
    private final java.util.ArrayDeque<String> settingsHistory = new java.util.ArrayDeque<>();
    private void navigateSettings(String page) { if (!page.equals(currentPage)) settingsHistory.push(currentPage); openNativePage(page,"{}"); }
    private void backSettings() { if (!settingsHistory.isEmpty()) openNativePage(settingsHistory.pop(),"{}"); else if (!"settings_home".equals(currentPage)) openNativePage("settings_home","{}"); else finish(); }

    public static synchronized void recordNativeEvent(
            Context ctx,
            String category,
            String severity,
            String title,
            String description,
            String component,
            String operation,
            String status,
            Throwable error
    ) {
        if (ctx == null) return;
        try {
            SharedPreferences prefs = ctx.getApplicationContext().getSharedPreferences(DIAG_PREFS_NAME, MODE_PRIVATE);
            String existingRaw = prefs.getString(DIAG_LOGS_KEY, "[]");
            JSONArray arr;
            try {
                arr = new JSONArray(existingRaw);
            } catch (Exception e) {
                arr = new JSONArray();
            }

            long nowMs = System.currentTimeMillis();
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            iso.setTimeZone(TimeZone.getTimeZone("UTC"));

            JSONObject obj = new JSONObject();
            obj.put("id", "nat_" + Long.toString(nowMs, 36) + "_" + (int) (Math.random() * 9999));
            obj.put("timestamp", iso.format(new Date(nowMs)));
            obj.put("epochMs", nowMs);
            obj.put("category", category);
            obj.put("severity", severity);
            obj.put("title", title);
            obj.put("description", description);
            obj.put("component", component);
            obj.put("operation", operation);
            obj.put("status", status);
            obj.put("platform", "Android");
            obj.put("osVersion", android.os.Build.VERSION.RELEASE);
            try { obj.put("appVersion", ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName); } catch (Exception ignored) {}
            if (error != null) {
                String msg = error.getMessage();
                obj.put("errorMessage", error.getClass().getSimpleName() + (msg != null ? ": " + msg : ""));
                String trace = Log.getStackTraceString(error);
                if (trace != null && trace.length() > 2400) {
                    trace = trace.substring(0, 2400) + "... [truncated]";
                }
                obj.put("stackTrace", trace);
            }

            JSONArray next = new JSONArray();
            next.put(obj);
            int limit = Math.min(arr.length(), MAX_NATIVE_LOGS - 1);
            for (int i = 0; i < limit; i++) {
                next.put(arr.get(i));
            }
            String serialized = next.toString();
            while (serialized.length() > MAX_NATIVE_LOG_CHARS && next.length() > 10) {
                int keep = Math.max(10, (int)(next.length() * 0.8));
                while (next.length() > keep) next.remove(next.length()-1);
                serialized = next.toString();
            }
            prefs.edit().putString(DIAG_LOGS_KEY, serialized).apply();
        } catch (Exception ignored) {
        }
    }

    private void installSilentCrashHandler() {
        if (crashHandlerInstalled) return;
        crashHandlerInstalled = true;
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        final Context appCtx = getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                recordNativeEvent(
                        appCtx,
                        "CRASHES",
                        "CRITICAL",
                        "Uncaught Android Exception",
                        "Fatal uncaught exception on thread " + (thread != null ? thread.getName() : "unknown"),
                        "AndroidRuntime",
                        "uncaught_exception",
                        "FAILED",
                        throwable
                );
            } catch (Exception ignored) {
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installSilentCrashHandler();
        showNativeSettingsShell();
        if (getIntent() != null && getIntent().getBooleanExtra(EXTRA_EMOJI_SETTINGS, false)) openNativePage("media", "{}");
    }

    /** Full-screen native settings (native only). Used when opened from the IME. */
    private void showNativeSettingsShell() {
        try {
            if (getWindow() != null) {
                getWindow().setStatusBarColor(0xff0a0b0e);
                getWindow().setNavigationBarColor(0xff0a0b0e);
            }
        } catch (Exception ignored) {}
        openNativePage("settings_home", "{}");
    }

    private void openNativePage(String page, String dataJson) {
        runOnUiThread(() -> {
            try {
                android.widget.ScrollView previousScroll = page.equals(currentPage) ? findSettingsScroll(nativeSettingsPage) : null;
                int previousY = previousScroll == null ? 0 : previousScroll.getScrollY();
                currentPage = page;
                JSONObject payload = settingsPayload(page);
                String theme = payload.optString("appTheme", "dark");
                String font = payload.optString("fontStyle", "kurdifont1");
                Runnable back = this::backSettings;
                NativeClipboardSettingsView.Change change = (key, value) -> {
                    if ("openPage".equals(key)) { navigateSettings(String.valueOf(value)); return; }
                    if ("enableIme".equals(key)) { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); return; }
                    if ("selectIme".equals(key)) { ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker(); return; }
                    if ("testIme".equals(key)) { showNativeTestDialog("", "light".equals(theme)); return; }
                    applyNativeChange(page, key, value);
                };

                if ("settings_home".equals(page)) {
                    nativeSettingsPage = new NativeSettingsHomeView(this, theme, font, payload, back, change);
                } else if ("bottom_row".equals(page)) {
                    nativeSettingsPage = new NativeBottomRowView(this, theme, font, payload, back, change);
                } else if ("layout_editor".equals(page)) {
                    nativeSettingsPage = new NativeLayoutEditorView(this, theme, font, payload, back, change);
                } else if ("about".equals(page)) {
                    nativeSettingsPage = new NativeAboutView(this, theme, font, back);
                } else if ("faq".equals(page)) {
                    nativeSettingsPage = new NativeFaqView(this, theme, font, payload, back);
                } else if ("font_style".equals(page)) {
                    nativeSettingsPage = new NativeFontSettingsView(this, theme, font, back, change);
                } else if (("keyboard_prefs".equals(page) || "typing".equals(page))) {
                    nativeSettingsPage = new NativeKeyboardPrefsView(this, theme, font, payload, back, change);
                } else if ("gestures".equals(page)) {
                    nativeSettingsPage = new NativeGestureSettingsView(this, theme, font, payload, back, change);
                } else if ("sound_vibration".equals(page)) {
                    nativeSettingsPage = new NativeSoundSettingsView(this, theme, font, payload, back, change);
                } else if ("predictions".equals(page)) {
                    nativeSettingsPage = new NativePredictionSettingsView(this, theme, font, payload, back, change);
                } else if ("clipboard_settings".equals(page)) {
                    nativeSettingsPage = new NativeClipboardSettingsView(this, theme, font, payload, back, change);
                } else if ("themes".equals(page)) {
                    nativeSettingsPage = new NativeThemeSettingsView(this, theme, font, payload, back, change);
                } else if ("languages".equals(page)) {
                    nativeSettingsPage = new NativeLanguageSettingsView(this, theme, font, payload, back, change);
                } else if ("theme_store".equals(page) || "custom_theme".equals(page)) {
                    nativeSettingsPage = new NativeThemeSettingsView(this, theme, font, payload, "theme_store".equals(page), back, change);
                } else if ("more_settings".equals(page)) {
                    nativeSettingsPage = new NativeMoreSettingsView(this, theme, font, payload, back, change, this::openSettingsBackup);
                } else if ("media".equals(page)) {
                    nativeSettingsPage = new NativeMediaSettingsView(this, theme, font, payload, pageData().load("media"), back, change);
                } else if ("ai_settings".equals(page)) {
                    nativeSettingsPage = new NativeAiSettingsView(this, theme, font, payload, back, change);
                } else if ("activity_logs".equals(page)) {
                    nativeSettingsPage = new NativeActivityLogsView(this, theme, font, payload, back);
                } else {
                    currentPage = "settings_home";
                    nativeSettingsPage = new NativeSettingsHomeView(this, theme, font, payload, back, change);
                }

                setContentView(settingsChrome(nativeSettingsPage, theme, font));
                android.widget.ScrollView nextScroll=findSettingsScroll(nativeSettingsPage);
                if(previousY>0 && nextScroll!=null) nextScroll.post(()->nextScroll.scrollTo(0,previousY));
            } catch (Exception e) {
                recordNativeEvent(this,"ERRORS","ERROR","Native settings page failed",page,"MainActivity","open_settings_page","FAILED",e);
                Toast.makeText(this, "نەتوانرا ڕێکخستن بکرێتەوە", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    /** Original mobile switcher and floating test control, rendered as native views. */
    private View settingsChrome(View content, String theme, String font) {
        boolean light="light".equals(theme);
        if(chromeAppearance==null)chromeAppearance=new NativeImeAppearance(this,null);
        NativeImeAppearance a=chromeAppearance;
        int ink=light?0xff0f172a:Color.WHITE, canvas=light?0xfff8fafc:"dark".equals(theme)?0xff0c0e12:Color.BLACK;
        android.widget.FrameLayout shell=new android.widget.FrameLayout(this);shell.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);shell.setBackgroundColor(canvas);
        LinearLayout stack=new LinearLayout(this);stack.setOrientation(LinearLayout.VERTICAL);shell.addView(stack,new android.widget.FrameLayout.LayoutParams(-1,-1));
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(16),0,dp(16),0);bar.setBackgroundColor(light?Color.WHITE:Color.BLACK);
        android.widget.ImageView logo=new android.widget.ImageView(this);if(chromeLogo==null)try(java.io.InputStream stream=getAssets().open("public/app-icon.png")){chromeLogo=android.graphics.BitmapFactory.decodeStream(stream);}catch(Exception ignored){}logo.setImageBitmap(chromeLogo);
        bar.addView(logo,new LinearLayout.LayoutParams(dp(24),dp(24)));
        TextView title=a.text("تەختەکلیلی کوردی",14,ink,font,800);title.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(0,-1,1);titleLp.setMarginStart(dp(8));titleLp.setMarginEnd(dp(8));bar.addView(title,titleLp);
        LinearLayout switcher=new LinearLayout(this);switcher.setOrientation(LinearLayout.HORIZONTAL);switcher.setGravity(Gravity.CENTER_VERTICAL);switcher.setPadding(dp(4),dp(4),dp(4),dp(4));switcher.setBackground(a.background(light?0xfff1f5f9:0x0fffffff,12,1,light?0xffe2e8f0:0x1affffff));
        TextView test=chromeButton(a,"تەختەکلیل","ic_keyboards",font,light?0xff64748b:0xffa1a1aa);test.setOnClickListener(v->showNativeTestDialog("",light));switcher.addView(test,new LinearLayout.LayoutParams(-2,dp(28)));
        TextView settings=chromeButton(a,"ڕێکخستنەکان","ic_settings",font,Color.WHITE);settings.setBackground(a.background(0xff0b5fa8,8,0,0));LinearLayout.LayoutParams activeLp=new LinearLayout.LayoutParams(-2,dp(28));activeLp.setMarginStart(dp(4));switcher.addView(settings,activeLp);
        settings.setSelected(true);
        bar.addView(switcher,new LinearLayout.LayoutParams(-2,-2));stack.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));
        View line=new View(this);line.setBackgroundColor(light?0xffe2e8f0:0x1affffff);stack.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        stack.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        // Reserve scroll space under the overlaid button so no setting becomes inaccessible.
        addSettingsBottomInset(content,dp(84));
        android.widget.ImageView fab=new android.widget.ImageView(this);fab.setImageDrawable(a.icon("ic_keyboards",0xff051b3a,24));fab.setScaleType(android.widget.ImageView.ScaleType.CENTER);fab.setBackground(a.background(0xffa4c9ff,16,0,0));fab.setElevation(dp(4));fab.setContentDescription("تاقیکردنەوەی تەختەکلیل");fab.setOnClickListener(v->showNativeTestDialog("",light));
        android.widget.FrameLayout.LayoutParams fabLp=new android.widget.FrameLayout.LayoutParams(dp(52),dp(52),Gravity.BOTTOM|Gravity.LEFT);fabLp.leftMargin=dp(20);fabLp.bottomMargin=dp(20);shell.addView(fab,fabLp);
        if(getWindow()!=null){getWindow().setStatusBarColor(light?Color.WHITE:Color.BLACK);getWindow().setNavigationBarColor(canvas);int flags=light?View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR:0;if(light && android.os.Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;getWindow().getDecorView().setSystemUiVisibility(flags);}
        return shell;
    }
    private TextView chromeButton(NativeImeAppearance a,String text,String icon,String font,int ink){
        TextView button=a.text(text,12,ink,font,700);button.setSingleLine(true);button.setPadding(dp(12),0,dp(12),0);button.setCompoundDrawablesRelativeWithIntrinsicBounds(a.icon(icon,ink,14),null,null,null);button.setCompoundDrawablePadding(dp(6));return button;
    }
    private android.widget.ScrollView findSettingsScroll(View view){
        if(view instanceof android.widget.ScrollView)return (android.widget.ScrollView)view;
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){android.widget.ScrollView found=findSettingsScroll(group.getChildAt(i));if(found!=null)return found;}}
        return null;
    }
    private void addSettingsBottomInset(View v,int inset){
        if(v instanceof android.widget.ScrollView){v.setPadding(v.getPaddingLeft(),v.getPaddingTop(),v.getPaddingRight(),v.getPaddingBottom()+inset);((android.widget.ScrollView) v).setClipToPadding(false);return;}
        if(v instanceof ViewGroup){ViewGroup group=(ViewGroup)v;for(int i=0;i<group.getChildCount();i++)addSettingsBottomInset(group.getChildAt(i),inset);}
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); settingsHistory.clear();
        openNativePage(intent != null && intent.getBooleanExtra(EXTRA_EMOJI_SETTINGS, false) ? "media" : "settings_home", "{}");
    }
    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused && "settings_home".equals(currentPage) && (homeImeEnabled != checkImeEnabled() || homeImeSelected != checkImeSelected())) openNativePage("settings_home", "{}");
    }
    @Override public void onBackPressed() {
        backSettings();
    }

    @Override
    public void onPause() {
        super.onPause();
        recordNativeEvent(
                this,
                "APPLICATION",
                "DEBUG",
                "Android MainActivity Paused",
                "MainActivity entered background/paused state.",
                "MainActivity",
                "onPause",
                "INFO",
                null
        );
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        String orient = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE ? "landscape" : "portrait";
        recordNativeEvent(
                this,
                "APPLICATION",
                "DEBUG",
                "Android Configuration Changed",
                "Configuration updated (orientation=" + orient + ").",
                "MainActivity",
                "onConfigurationChanged",
                "INFO",
                null
        );
    }

    @Override
    public void onDestroy() {
        if (activeTestDialog != null && activeTestDialog.isShowing()) {
            try {
                activeTestDialog.dismiss();
            } catch (Exception ignored) {
            }
        }
        activeTestDialog = null;
        super.onDestroy();
    }

    private boolean checkImeEnabled() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) return false;
            List<InputMethodInfo> list = imm.getEnabledInputMethodList();
            String pkg = getPackageName();
            for (InputMethodInfo info : list) {
                if (pkg.equals(info.getPackageName())) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean checkImeSelected() {
        try {
            String current = Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.DEFAULT_INPUT_METHOD
            );
            return current != null && current.startsWith(getPackageName() + "/");
        } catch (Exception ignored) {
            return false;
        }
    }

    private int dp(int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                getResources().getDisplayMetrics()
        ));
    }

    private GradientDrawable roundedBg(int fillColor, int strokeColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fillColor);
        gd.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) {
            gd.setStroke(dp(1), strokeColor);
        }
        return gd;
    }

    private Button makeActionButton(String label, int bgColor, int textColor, int strokeColor) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(textColor);
        btn.setBackground(roundedBg(bgColor, strokeColor, 12));
        btn.setPadding(dp(14), dp(8), dp(14), dp(8));
        btn.setMinHeight(dp(40));
        btn.setMinimumHeight(dp(40));
        return btn;
    }

    private void showNativeTestDialog(final String initialText, final boolean isLightTheme) {
        try {
            if (activeTestDialog != null && activeTestDialog.isShowing()) {
                return;
            }


            final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
            activeTestDialog = dialog;

            Window win = dialog.getWindow();
            if (win != null) {
                win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                win.setSoftInputMode(
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                );
                win.setStatusBarColor(isLightTheme ? Color.parseColor("#FFFFFF") : Color.parseColor("#000000"));
            }

            int bgCanvas = isLightTheme ? Color.parseColor("#F1F5F9") : Color.parseColor("#07080B");
            int headerBg = isLightTheme ? Color.parseColor("#FFFFFF") : Color.parseColor("#0D1016");
            int cardBg = isLightTheme ? Color.parseColor("#FFFFFF") : Color.parseColor("#12161E");
            int borderColor = isLightTheme ? Color.parseColor("#CBD5E1") : Color.parseColor("#262D3B");
            int textPrimary = isLightTheme ? Color.parseColor("#0F172A") : Color.parseColor("#F8FAFC");
            int textMuted = isLightTheme ? Color.parseColor("#64748B") : Color.parseColor("#94A3B8");
            int accentBlue = Color.parseColor("#0B5FA8");
            int subtleBtnBg = isLightTheme ? Color.parseColor("#E2E8F0") : Color.parseColor("#1A202C");
            int dangerText = isLightTheme ? Color.parseColor("#DC2626") : Color.parseColor("#FB7185");

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundColor(bgCanvas);
            root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            root.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));

            // 1. Compact Native Header
            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.setBackgroundColor(headerBg);
            header.setPadding(dp(14), dp(12), dp(14), dp(12));

            TextView titleView = new TextView(this);
            titleView.setText("تاقیکردنەوەی خێرای تەختەکلیل");
            titleView.setTextColor(textPrimary);
            titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f);
            titleView.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            );
            titleView.setLayoutParams(titleLp);
            header.addView(titleView);

            Button switchImeBtn = makeActionButton("گۆڕینی کیبۆرد", accentBlue, Color.WHITE, 0);
            LinearLayout.LayoutParams switchLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            );
            switchLp.setMarginEnd(dp(8));
            switchImeBtn.setLayoutParams(switchLp);
            switchImeBtn.setOnClickListener(v -> {
                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showInputMethodPicker();
                } catch (Exception ignored) {
                }
            });
            header.addView(switchImeBtn);

            Button closeBtn = makeActionButton("داخستن", subtleBtnBg, textPrimary, borderColor);
            closeBtn.setOnClickListener(v -> dialog.dismiss());
            header.addView(closeBtn);

            root.addView(header);

            // 2. Main Native EditText Card
            LinearLayout contentWrap = new LinearLayout(this);
            contentWrap.setOrientation(LinearLayout.VERTICAL);
            contentWrap.setPadding(dp(14), dp(14), dp(14), dp(12));
            LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            );
            contentWrap.setLayoutParams(contentLp);

            LinearLayout editorCard = new LinearLayout(this);
            editorCard.setOrientation(LinearLayout.VERTICAL);
            editorCard.setBackground(roundedBg(cardBg, borderColor, 18));
            editorCard.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            );
            editorCard.setLayoutParams(cardLp);

            final EditText editText = new EditText(this);
            editText.setBackground(null);
            editText.setTextColor(textPrimary);
            editText.setHintTextColor(textMuted);
            editText.setHint("لێرە بە خێرایی تەواو بنووسە بۆ تاقیکردنەوەی تەختەکلیلی کوردی...");
            editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.5f);
            editText.setGravity(Gravity.TOP | Gravity.START);
            editText.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            editText.setInputType(
                    InputType.TYPE_CLASS_TEXT
                            | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                            | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            );
            editText.setHorizontallyScrolling(false);
            if (initialText != null && !initialText.isEmpty()) {
                editText.setText(initialText);
                editText.setSelection(initialText.length());
            }
            LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            );
            editText.setLayoutParams(editLp);
            editorCard.addView(editText);

            // Footer row inside editor card: live stats + Copy + Clear
            LinearLayout footer = new LinearLayout(this);
            footer.setOrientation(LinearLayout.HORIZONTAL);
            footer.setGravity(Gravity.CENTER_VERTICAL);
            footer.setPadding(0, dp(10), 0, 0);

            final TextView statsView = new TextView(this);
            statsView.setTextColor(textMuted);
            statsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            LinearLayout.LayoutParams statsLp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            );
            statsView.setLayoutParams(statsLp);
            footer.addView(statsView);

            Runnable updateStats = () -> {
                String txt = editText.getText() != null ? editText.getText().toString() : "";
                String trimmed = txt.trim();
                int words = trimmed.isEmpty() ? 0 : trimmed.split("\\s+").length;
                statsView.setText(txt.length() + " پیت · " + words + " ووشە");
            };
            updateStats.run();

            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    updateStats.run();
                }
            });

            Button copyBtn = makeActionButton("کۆپی", subtleBtnBg, textPrimary, borderColor);
            LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            );
            copyLp.setMarginEnd(dp(8));
            copyBtn.setLayoutParams(copyLp);
            copyBtn.setOnClickListener(v -> {
                try {
                    String txt = editText.getText() != null ? editText.getText().toString() : "";
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && !txt.isEmpty()) {
                        cm.setPrimaryClip(ClipData.newPlainText("KurdiKeyboard", txt));
                        Toast.makeText(MainActivity.this, "دەقەکە کۆپی کرا", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ignored) {
                }
            });
            footer.addView(copyBtn);

            Button clearBtn = makeActionButton("پاککردنەوە", subtleBtnBg, dangerText, borderColor);
            clearBtn.setOnClickListener(v -> editText.setText(""));
            footer.addView(clearBtn);

            editorCard.addView(footer);
            contentWrap.addView(editorCard);
            root.addView(contentWrap);

            dialog.setContentView(root);
            dialog.setOnDismissListener(d -> {
                activeTestDialog = null;
                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
                    }
                } catch (Exception ignored) {
                }
            });

            dialog.show();

            mainHandler.postDelayed(() -> {
                try {
                    editText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
                    }
                } catch (Exception ignored) {
                }
            }, 120);
        } catch (Exception ignored) {
        }
    }

    private void openSettingsBackup() {
        if (!(nativeSettingsPage instanceof NativeMoreSettingsView) || backupPickerOwner != null) return;
        backupPickerOwner = (NativeMoreSettingsView) nativeSettingsPage;
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain"});
        try {
            startActivityForResult(picker, OPEN_SETTINGS_BACKUP);
        } catch (android.content.ActivityNotFoundException unavailable) {
            backupPickerOwner.showStatus("هەڵبژێری فایل بەردەست نییە.", "", true);
            backupPickerOwner = null;
        }
    }

    void exportActivityReport(String report) {
        if (pendingActivityReport != null) return;
        pendingActivityReport = report;
        try {
            startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("text/plain").putExtra(Intent.EXTRA_TITLE, "kurdikeyboard-activity-report-" + new SimpleDateFormat("yyyy-MM-dd'T'HH-mm-ss",Locale.US).format(new Date()) + ".txt"), EXPORT_ACTIVITY_REPORT);
        } catch (Exception unavailable) {
            pendingActivityReport = null;
            Toast.makeText(this,"هەناردەکردن بەردەست نییە",Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        if (request == CLOUD_BACKUP) {
            if (result == RESULT_OK) openNativePage(currentPage,"{}");
            return;
        }
        if (request == EXPORT_ACTIVITY_REPORT) {
            String report = pendingActivityReport;
            pendingActivityReport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && report != null) {
                Uri uri = data.getData();
                new Thread(() -> {
                    boolean success = false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new java.io.IOException("Cannot open document");
                        out.write(report.getBytes(StandardCharsets.UTF_8));
                        success = true;
                    } catch (Exception ignored) {}
                    final boolean saved = success;
                    runOnUiThread(() -> Toast.makeText(this,saved?"ڕاپۆرت پاشەکەوت کرا":"پاشەکەوت سەرکەوتوو نەبوو",Toast.LENGTH_SHORT).show());
                }, "activity-report-export").start();
            }
            return;
        }
        if (request == OPEN_SETTINGS_BACKUP + 1) {
            if (result == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    JSONObject core=pageData().load("core"); JSONObject settings=new NativeImeSettings(core).hydrate(ImeStateStore.effectiveSettings(this,ImeStateStore.read(this)));
                    if(out==null)throw new java.io.IOException("Cannot open document");out.write(ImeStateStore.json("format","kurdikeyboard-settings","version",1,"settings",settings).toString(2).getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"پاشەکەوت کرا",Toast.LENGTH_SHORT).show();
                } catch(Exception error){Toast.makeText(this,"پاشەکەوت سەرکەوتوو نەبوو",Toast.LENGTH_SHORT).show();}
            } return;
        }
        if (request != OPEN_SETTINGS_BACKUP) {
            super.onActivityResult(request, result, data);
            return;
        }
        NativeMoreSettingsView owner = backupPickerOwner;
        backupPickerOwner = null;
        Uri uri = data == null ? null : data.getData();
        if (result != RESULT_OK || owner == null || uri == null) return;
        new Thread(() -> readSettingsBackup(owner, uri), "settings-backup-reader").start();
    }

    private void readSettingsBackup(NativeMoreSettingsView owner, Uri uri) {
        String filename = "";
        String error = "";
        String content = "";
        try {
            try (android.database.Cursor cursor = getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) filename = cursor.getString(0);
            }
            try (java.io.InputStream input = getContentResolver().openInputStream(uri);
                 java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream()) {
                if (input == null) throw new java.io.IOException("No document stream");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (output.size() + count > 16 * 1024 * 1024) {
                        error = "فایلی پاشەکەوت زۆر گەورەیە.";
                        break;
                    }
                    output.write(buffer, 0, count);
                }
                if (error.isEmpty()) content = new JSONObject().put("name", filename == null ? "" : filename)
                        .put("text", output.toString("UTF-8")).toString();
            }
        } catch (Exception failure) {
            error = "خوێندنەوەی فایلەکە سەرکەوتوو نەبوو.";
        }
        final String message = error;
        final String payload = content;
        runOnUiThread(() -> {
            if (nativeSettingsPage != owner || isFinishing() || isDestroyed()) return;
            if (message.isEmpty()) owner.importBackup(payload);
            else owner.showStatus(message, "", true);
        });
    }

    private JSONObject settingsPayload(String page) throws Exception {
        NativeImeData data = pageData();
        JSONObject core = data.load("core");
        JSONObject state = ImeStateStore.read(this);
        JSONObject settings = new JSONObject(new NativeImeSettings(core).hydrate(ImeStateStore.effectiveSettings(this, state)).toString());
        JSONObject config = data.load("settingsPages");
        JSONObject localized = NativeImeData.obj(NativeImeData.obj(config, "pages"), settings.optString("appLanguage", "ckb"));
        JSONObject payload = new JSONObject(NativeImeData.obj(localized, "typing".equals(page) ? "keyboard_prefs" : page).toString());
        for (String name : new String[]{"switches", "options", "ranges", "thresholds"}) {
            JSONArray rows = payload.optJSONArray(name);
            if (rows == null) continue;
            for (int i=0;i<rows.length();i++) {
                JSONObject row = rows.optJSONObject(i); if(row == null) continue;
                String key = row.optString("key"); if(settings.has(key)) row.put("value", settings.opt(key));
            }
        }
        JSONArray sections = payload.optJSONArray("sections");
        for(int i=0;sections!=null && i<sections.length();i++) {
            JSONArray rows = NativeImeData.arr(sections.optJSONObject(i),"rows");
            for(int j=0;j<rows.length();j++) {
                JSONObject row=rows.optJSONObject(j); if(row==null)continue;
                String value=settings.optString(row.optString("key")); row.put("value",value);
                JSONObject option=NativeImeData.find(NativeImeData.arr(row,"options"),"id",value);
                row.put("valueLabel",option==null?value:option.optString("label"));
            }
        }
        NativeImeData.merge(payload, settings);
        payload.put("incognitoLocal",ImeStateStore.incognito(this));
        if ("clipboard_settings".equals(page)) payload.put("captureHiddenClipboard", ImeStateStore.captureHiddenClipboard(this));
        if ("settings_home".equals(page)) {
            homeImeEnabled = checkImeEnabled(); homeImeSelected = checkImeSelected();
            payload.put("imeEnabled",homeImeEnabled); payload.put("imeSelected",homeImeSelected);
        }
        if ("predictions".equals(page)) {
            JSONObject switches=new JSONObject();
            for(String key:new String[]{"wordSuggestions","textShortcutsEnabled","autoComplete","doubleSpacePeriod","personalDictionaryEnabled","smartAutoCorrection","multilingualSuggestions"}) switches.put(key,settings.optBoolean(key));
            payload.put("switches",switches);
        }
        payload.put("packs",NativeImeData.obj(core,"defaults").optJSONArray("sounds"));
        payload.put("themes",config.optJSONArray("storeThemes"));
        if ("themes".equals(page)) {
            JSONArray builtins = new JSONArray(), all = NativeImeData.arr(core,"themes"), store=NativeImeData.arr(config,"storeThemes");
            for (int i=0;i<all.length();i++) { JSONObject item=all.optJSONObject(i); if(item!=null && NativeImeData.find(store,"id",item.optString("id"))==null) builtins.put(item); }
            payload.put("builtins",builtins);
        }
        if ("languages".equals(page)) { payload.put("presets",core.optJSONArray("subtypes")); payload.put("layoutOptions",core.optJSONArray("characterLayouts")); }
        payload.put("custom",settings.optJSONObject("customTheme"));
        payload.put("active",settings.optString("activeThemeId"));
        payload.put("downloaded",settings.optJSONArray("downloadedThemeIds"));
        payload.put("extra",config.optJSONArray("extraEditorKeys"));
        JSONArray enabled=NativeImeData.arr(settings,"enabledLanguages"), langs=new JSONArray();
        for(int i=0;i<enabled.length();i++) {
            JSONObject item=NativeImeData.copy(enabled.optJSONObject(i));
            String layout=item.optString("characterLayoutId","kurdi_qvfgh");
            JSONArray defaults=NativeImeData.obj(core,"editableRows").optJSONArray(layout);
            JSONArray custom=NativeImeData.obj(settings,"customLayouts").optJSONArray(layout);
            item.put("layout",layout); item.put("layoutName",item.optString("subtitle",layout));
            item.put("label",item.optString("subtitle",layout)); item.put("defaults",defaults); item.put("rows",custom==null?defaults:custom);
            item.put("active",item.optString("code").equals(settings.optString("activeLanguage"))); langs.put(item);
        }
        payload.put("languages",langs);
        return payload;
    }

    private void applyNativeChange(String page, String key, Object value) {
        try {
            // Most single-key updates do not need to hydrate the complete settings model.
            JSONObject patch = new JSONObject();
            boolean needsExisting = "clearMediaRecent".equals(key) || "applyTheme".equals(key)
                    || "saveLayout".equals(key) || "resetLayout".equals(key) || "custom_theme".equals(page);
            JSONObject settings = needsExisting ? new NativeImeSettings(pageData().load("core"))
                    .hydrate(ImeStateStore.effectiveSettings(this,ImeStateStore.read(this))) : new JSONObject();
            if ("captureHiddenClipboard".equals(key)) {
                if (!ImeStateStore.setCaptureHiddenClipboard(this, Boolean.TRUE.equals(value))) throw new JSONException("Storage unavailable");
                return;
            }
            if ("incognitoLocal".equals(key)) { ImeStateStore.setIncognito(this,Boolean.TRUE.equals(value)); return; }
            if ("securityDashboard".equals(key)) { NativeSecurityStatus.show(this); return; }
            if ("activityLogs".equals(key)) { navigateSettings("activity_logs"); return; }
            if ("cloudBackup".equals(key)) { startActivityForResult(new Intent(this, NativeFirebaseBackupActivity.class), CLOUD_BACKUP); return; }
            if ("exportBackup".equals(key)) { startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"kurdikeyboard-backup.json"), OPEN_SETTINGS_BACKUP + 1); return; }
            if ("importBackup".equals(key)) {
                JSONObject raw = new JSONObject(new JSONObject(String.valueOf(value)).getString("text"));
                if ("kurdikeyboard-settings".equals(raw.optString("format"))) { if(raw.optInt("version")!=1)throw new JSONException("Unsupported backup"); raw=raw.getJSONObject("settings"); }
                JSONObject core = pageData().load("core");
                JSONObject clean = new NativeImeSettings(core).hydrate(raw);
                if(ImeStateStore.updateSettings(this,clean,true)==null)throw new JSONException("Storage unavailable");
                NativeSettingsBackup.write(this,clean.toString());
                openNativePage(page,"{}"); Toast.makeText(this,"پاشەکەوت گەڕێندرایەوە",Toast.LENGTH_SHORT).show(); return;
            }
            if ("resetAll".equals(key)) {
                new android.app.AlertDialog.Builder(this).setMessage("هەموو ڕێکخستنەکان بگەڕێنرێنەوە؟").setNegativeButton("نەخێر",null).setPositiveButton("بەڵێ",(d,w)->{
                    ImeStateStore.setCaptureHiddenClipboard(this,false); ImeStateStore.updateSettings(this,new JSONObject(),true); NativeSettingsBackup.write(this,"{}"); openNativePage(page,"{}");
                }).show(); return;
            }
            if ("resetEmojiCategories".equals(key) && value instanceof JSONArray) {
                patch.put("emojiCategoryOrder",value);patch.put("emojiDisabledCategories",new JSONArray());
            } else if ("languageSelection".equals(key) && value instanceof JSONObject) {
                JSONObject selection=(JSONObject)value; patch.put("enabledLanguages",selection.getJSONArray("enabledLanguages"));patch.put("activeLanguage",selection.getString("activeLanguage"));
            } else if ("clearMediaRecent".equals(key)) {
                patch.put("recentEmojis",new JSONArray()); patch.put("recentKaomoji",new JSONArray());
                JSONObject histories=NativeImeData.obj(settings,"zikrHistories"); JSONArray recent=new JSONArray();
                for(String kind:new String[]{"duaa","quran","salawat"}) { JSONObject item=NativeImeData.obj(histories,kind); JSONArray pinned=NativeImeData.arr(item,"pinned"); for(int i=0;i<pinned.length();i++)recent.put(pinned.opt(i)); item.put("recent",new JSONArray()); histories.put(kind,item); }
                patch.put("recentZikr",recent);patch.put("zikrHistories",histories);
            } else if ("applyTheme".equals(key)) {
                patch.put("activeThemeId",value); JSONArray ids=NativeImeData.arr(settings,"downloadedThemeIds"); if(!NativeImeData.contains(ids,String.valueOf(value)))ids.put(value); patch.put("downloadedThemeIds",ids);
            } else if ("themeMode".equals(key)) {
                String mode = String.valueOf(value); patch.put("keyboardThemeMode",mode);
                if ("dark".equals(mode)) patch.put("activeThemeId","amoled_cobalt");
                if ("light".equals(mode)) { JSONArray themes=NativeImeData.arr(pageData().load("core"),"themes"); for(int i=0;i<themes.length();i++){JSONObject t=themes.optJSONObject(i); if(t!=null && t.optBoolean("isLight")){patch.put("activeThemeId",t.optString("id"));break;}} }
            } else if ("applyCustom".equals(key)) patch.put("activeThemeId","custom_user_theme");
            else if ("custom_theme".equals(page) && java.util.Arrays.asList("bg","keyBg","keyText","keyBorder","enterBg","borderRadius","hasKeyBorder").contains(key)) {
                JSONObject custom=NativeImeData.obj(settings,"customTheme"); custom.put(key,value);
                if("bg".equals(key))custom.put("toolbarBg",value); if("keyBg".equals(key))custom.put("spaceBg",value); if("enterBg".equals(key))custom.put("accent",value);
                patch.put("customTheme",custom);patch.put("activeThemeId","custom_user_theme");
            } else if ("saveLayout".equals(key) || "resetLayout".equals(key)) {
                JSONObject update = new JSONObject(String.valueOf(value)); String layout=update.getString("layout"); JSONObject custom=NativeImeData.obj(settings,"customLayouts");
                if("resetLayout".equals(key))custom.remove(layout); else { custom.put(layout,update.getJSONArray("rows")); patch.put("activeLanguage",update.optString("code")); }
                patch.put("customLayouts",custom);
            } else if ("saveBottomRow".equals(key)) patch.put("bottomRowKeys",new JSONArray(String.valueOf(value)));
            else if ("emojiLanguageBottom".equals(key)) patch.put(key,Boolean.parseBoolean(String.valueOf(value)));
            else if ("textShortcuts".equals(key) || "personalDictionary".equals(key)) patch.put(key,value instanceof JSONArray?value:new JSONArray(String.valueOf(value)));
            else if ("spacebarPreset".equals(key)) {
                boolean cursor=Boolean.TRUE.equals(value);patch.put("spaceBarSwipeLeftAction",cursor?"move_cursor_left":"switch_to_next_subtype");patch.put("spaceBarSwipeRightAction",cursor?"move_cursor_right":"switch_to_prev_subtype");patch.put("spacebarSwipeAction",cursor?"move_cursor":"switch_lang");
            } else { patch.put(key,value); if("keySpacingHorizontal".equals(key))patch.put("keySpacingPercent",value); }
            ImeStateStore.mergeSettingsPatch(this,patch);
            if ("applyCustom".equals(key)) { backSettings(); return; }
            if ("appTheme".equals(key) || "appLanguage".equals(key) || "applyCustom".equals(key) || "proUnlocked".equals(key) || ("languages".equals(page) && ("languageSelection".equals(key) || "enabledLanguages".equals(key) || "activeLanguage".equals(key) || "translationEngine".equals(key))) || ("themes".equals(page) && ("activeThemeId".equals(key) || "themeMode".equals(key) || "keyShapeStyle".equals(key) || "appAccentColor".equals(key)))) openNativePage(page,"{}");
        } catch(Exception error) { recordNativeEvent(this,"ERRORS","ERROR","Settings update failed",key,"MainActivity","settings_update","FAILED",error); Toast.makeText(this,"پاشەکەوت سەرکەوتوو نەبوو",Toast.LENGTH_SHORT).show(); }
    }

}
