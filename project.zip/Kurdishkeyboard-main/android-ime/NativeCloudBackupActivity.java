package io.kurdikebord.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** Native document-picker backup: no broad storage permissions, account tokens or network client. */
public final class NativeCloudBackupActivity extends Activity {
    private static final int CREATE=4101, OPEN=4102;
    private static final int[] BITS={1,2,4,8,16,32,64};
    private static final String[] LABELS={"ڕێکخستنەکانی تەختەکلیل","زمان و ڕیزبەندییەکان","ڕووکار و دیزاینەکان","فەرهەنگ، وشە فێربووەکان و کورتکراوەکان","ئیمۆجییە دڵخوازەکان و مێژوو","Clipboard ـی پینکراو","هەموو مێژووی Clipboard"};
    private CheckBox[] choices=new CheckBox[7];
    private TextView status;
    private Button save,restore;
    private Switch auto;
    private boolean busy,light;
    private int fg,muted,card,background,blue;
    private JSONObject pending;
    private char[] pendingPassword;
    private NativeImeAppearance appearance;
    private String font;

    @Override public void onCreate(Bundle state){
        JSONObject settings=ImeStateStore.effectiveSettings(this,ImeStateStore.read(this));
        light="light".equals(settings.optString("appTheme"));font=settings.optString("fontStyle","system");
        if(light)setTheme(android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        fg=light?0xff172033:Color.WHITE;muted=light?0xff526173:0xffa1a1aa;card=light?Color.WHITE:0xff17181c;background=light?0xfff8fafc:0xff090a0c;blue=light?0xff0965b5:0xffa4c9ff;
        appearance=new NativeImeAppearance(this,null);
        getWindow().setStatusBarColor(background);getWindow().setNavigationBarColor(background);
        LinearLayout root=column();root.setBackgroundColor(background);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),0,dp(12),0);
        TextView back=text("→",24,fg,true);back.setContentDescription("گەڕانەوە");back.setOnClickListener(v->onBackPressed());header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(56)));
        header.addView(text("Google Drive · پاشەکەوت",18,fg,true),new LinearLayout.LayoutParams(0,dp(56),1));root.addView(header);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));LinearLayout content=column();content.setPadding(dp(16),dp(8),dp(16),dp(24));scroll.addView(content);
        LinearLayout intro=section(content);intro.addView(text("پاشەکەوت و گەڕاندنەوەی داتاکان",18,blue,true));intro.addView(text("فایلەکە بە وشەی نهێنی شفرە دەکرێت. لە هەڵبژێری فایلدا Google Drive یان بیرگەی مۆبایل هەڵبژێرە.",13,muted,false));
        LinearLayout selection=section(content);selection.addView(text("داتاکانی پاشەکەوت",16,fg,true));
        for(int i=0;i<choices.length;i++){CheckBox box=new CheckBox(this);box.setText(LABELS[i]);box.setTextColor(fg);box.setTextSize(14);box.setTypeface(appearance.font(font, 500));box.setButtonTintList(ColorStateList.valueOf(blue));box.setChecked(i<3||i==4);box.setMinHeight(dp(46));choices[i]=box;selection.addView(box);}
        choices[5].setOnCheckedChangeListener((b,on)->{if(on)choices[6].setChecked(false);});choices[6].setOnCheckedChangeListener((b,on)->{if(on)choices[5].setChecked(false);});
        selection.addView(text("Clipboard و فەرهەنگ دەتوانن زانیاری تایبەت تێدا بێت. وشەی نهێنی و زانیاری بانکی هەڵمەگرە. فلتەری کۆدی نهێنی تەواو نییە.",12,muted,false));
        save=button(content,"پاشەکەوتکردن لە Google Drive",true,()->beginExport());
        restore=button(content,"گەڕاندنەوە لە Google Drive",false,()->openDocument());
        status=text("",13,blue,true);content.addView(status);
        LinearLayout automatic=section(content);automatic.addView(text("Android Auto Backup",16,blue,true));
        auto=new Switch(this);auto.setText("پاشەکەوتی خۆکاری ڕێکخستنە ناهەستیارەکان");auto.setTextColor(fg);auto.setTextSize(14);auto.setChecked(NativeAutoBackup.enabled(this));automatic.addView(auto);
        auto.setOnCheckedChangeListener((b,on)->{busy(true);work(()->{boolean ok=false;try{ok=ImeStateStore.configureAutoBackup(this,on,core());}catch(Exception e){}final boolean success=ok;runOnUiThread(()->done(success?(on?"پاشەکەوتی خۆکار چالاکە. کات و گەڕاندنەوە لە دەستی Android ـدایە.":"پاشەکەوتی خۆکار ناچالاکە. کۆپییە کۆنەکان لە ڕێکخستنی Google بەڕێوەببە."):"گۆڕینی پاشەکەوتی خۆکار سەرکەوتوو نەبوو."));});});
        automatic.addView(text("تەنها هەندێک ڕێکخستنی ڕەنگ، قەبارە و کردار. Clipboard، دەقە فێربووەکان، API و ڕاپۆرت نانێردرێن. پێویستی بە Backup ـی چالاکی Android هەیە.",12,muted,false));
        button(automatic,"ڕێکخستنی Backup ـی Android",false,()->{try{startActivity(new Intent("android.settings.BACKUP_SETTINGS"));}catch(Exception ex){status("لە Settings ـی مۆبایل، Google → Backup بکەرەوە.");}});
        if(android.os.Build.VERSION.SDK_INT<26){save.setEnabled(false);restore.setEnabled(false);status("Backup ـی شفرەکراو پێویستی بە Android 8 یان نوێتر هەیە.");}
    }
    private int dp(float x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=appearance.text(s,size,color,font,bold?700:400);t.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);t.setPadding(0,dp(7),0,dp(7));return t;}
    private LinearLayout section(LinearLayout parent){LinearLayout l=column();l.setPadding(dp(14),dp(10),dp(14),dp(10));l.setBackground(bg(card,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);parent.addView(l,p);return l;}
    private Button button(LinearLayout parent,String label,boolean primary,Runnable task){Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(14);b.setTextColor(primary?(light?Color.WHITE:0xff062c55):fg);b.setBackground(bg(primary?blue:card,14));b.setOnClickListener(v->task.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.bottomMargin=dp(10);parent.addView(b,p);return b;}
    private void status(String s){if(!isFinishing()&&!isDestroyed()&&status!=null)status.setText(s);}
    private void busy(boolean on){busy=on;save.setEnabled(!on&&android.os.Build.VERSION.SDK_INT>=26);restore.setEnabled(!on&&android.os.Build.VERSION.SDK_INT>=26);auto.setEnabled(!on);}
    private void done(String s){if(isFinishing()||isDestroyed())return;busy(false);status(s);}
    private void work(Runnable r){new Thread(r,"native-cloud-backup").start();}
    private JSONObject core(){return new NativeImeData(this).load("core");}
    private int mask(){int m=0;for(int i=0;i<BITS.length;i++)if(choices[i].isChecked())m|=BITS[i];return m;}
    private void beginExport(){
        if(busy)return;int selected=mask();if(selected==0){status("لانیکەم یەک بەش هەڵبژێرە.");return;}
        busy(true);status("ئامادەکردنی داتاکان…");
        work(()->{try{JSONObject data=NativeCloudBackup.capture(this,core(),selected);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;reviewClips(data);});}catch(Exception e){runOnUiThread(()->done("ئامادەکردنی پاشەکەوت سەرکەوتوو نەبوو."));}});
    }
    private void reviewClips(JSONObject data){
        JSONArray clips=data.optJSONArray("clipboard");
        if(clips==null||clips.length()==0){exportPassword(data);return;}
        String[] names=new String[clips.length()];boolean[] keep=new boolean[clips.length()];Arrays.fill(keep,true);
        for(int i=0;i<names.length;i++){JSONObject item=clips.optJSONObject(i);String t=item.optString("text");names[i]=(item.optBoolean("pinned")?"★ ":"")+(t.length()>160?t.substring(0,160)+"…":t);}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Clipboard · "+clips.length()+" · فلتەرکراو: "+data.optInt("skipped")).setMultiChoiceItems(names,keep,(d,w,on)->keep[w]=on).setNegativeButton("پاشگەزبوونەوە",(d,w)->done("پاشەکەوت هەڵوەشایەوە.")).setPositiveButton("بەردەوامبوون",(d,w)->{JSONArray chosen=new JSONArray();for(int i=0;i<keep.length;i++)if(keep[i])chosen.put(clips.opt(i));ImeStateStore.put(data,"clipboard",chosen);exportPassword(data);}).create();
        dialog.setOnCancelListener(d->done("پاشەکەوت هەڵوەشایەوە."));dialog.show();
    }
    private interface PasswordAction {void accept(char[] password);}
    private void passwordDialog(boolean confirm,PasswordAction action){
        LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(8));
        form.addView(text(confirm?"وشەی نهێنی درێژ (لانیکەم ١٢ پیت). بۆ گەڕاندنەوە پێویستە، لە ئەپدا هەڵناگیرێت.":"وشەی نهێنی فایلی پاشەکەوت بنووسە.",13,fg,false));
        EditText first=passwordField("وشەی نهێنی");form.addView(first);EditText second=passwordField("دووبارە وشەی نهێنی");if(confirm)form.addView(second);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(confirm?"شفرەکردنی فایل":"کردنەوەی فایل").setView(form).setNegativeButton("پاشگەزبوونەوە",(x,w)->done("هەڵوەشایەوە.")).setPositiveButton("بەردەوامبوون",null).create();
        d.setOnCancelListener(x->done("هەڵوەشایەوە."));d.setOnDismissListener(x->{first.getText().clear();second.getText().clear();});d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{char[] pass=chars(first);char[] twice=chars(second);boolean ok=pass.length>=12&&(!confirm||Arrays.equals(pass,twice));Arrays.fill(twice,'\0');if(!ok){Arrays.fill(pass,'\0');first.setError("وشەی نهێنی کەمە یان یەکسان نییە");return;}d.dismiss();action.accept(pass);});
    }
    private EditText passwordField(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);e.setSaveEnabled(false);if(android.os.Build.VERSION.SDK_INT>=26){e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);e.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);}return e;}
    private char[] chars(EditText e){char[] a=new char[e.length()];e.getText().getChars(0,a.length,a,0);return a;}
    private void exportPassword(JSONObject data){passwordDialog(true,pass->{pending=data;pendingPassword=pass;try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,"kurdikeyboard-"+new SimpleDateFormat("yyyy-MM-dd-HHmmss",Locale.US).format(new Date())+".kkbackup"),CREATE);}catch(Exception e){clearPending();done("هەڵبژێری فایل بەردەست نییە.");}});}
    private void openDocument(){if(busy)return;busy(true);try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),OPEN);}catch(Exception e){done("هەڵبژێری فایل بەردەست نییە.");}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=CREATE&&request!=OPEN)return;
        if(result!=RESULT_OK||data==null||data.getData()==null){clearPending();done("هەڵوەشایەوە.");return;}Uri uri=data.getData();
        if(request==CREATE){JSONObject snapshot=pending;char[] pass=pendingPassword;pending=null;pendingPassword=null;if(snapshot==null||pass==null){done("پاشەکەوت دووبارە دەست پێبکە.");return;}status("شفرەکردن و نووسینی فایل…");work(()->{byte[] bytes=null;boolean ok=false;try{bytes=snapshot.toString().getBytes(StandardCharsets.UTF_8);try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();NativeBackupCrypto.encrypt(bytes,pass,out);}ok=true;}catch(Exception e){}finally{Arrays.fill(pass,'\0');if(bytes!=null)Arrays.fill(bytes,(byte)0);}final boolean saved=ok;runOnUiThread(()->done(saved?"فایلی شفرەکراو پاشەکەوت کرا. دڵنیا بە لە تەواوبوونی هاوکاتکردنی Drive.":"پاشەکەوت سەرکەوتوو نەبوو؛ فایلی ناتەواو بسڕەوە."));});}
        else{busy(true);passwordDialog(false,pass->readBackup(uri,pass));}
    }
    private void readBackup(Uri uri,char[] pass){status("خوێندنەوە و پشکنینی فایل…");work(()->{byte[] bytes=null;try{try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException();bytes=NativeBackupCrypto.decrypt(in,pass);}JSONObject payload=new JSONObject(new String(bytes,StandardCharsets.UTF_8));int available=NativeCloudBackup.validate(payload);runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())confirmRestore(payload,available);});}catch(Exception e){runOnUiThread(()->done("وشەی نهێنی هەڵەیە، فایل خراپە یان پشتیگیری ناکرێت."));}finally{Arrays.fill(pass,'\0');if(bytes!=null)Arrays.fill(bytes,(byte)0);}});}
    private void confirmRestore(JSONObject payload,int available){ArrayList<String> names=new ArrayList<>();ArrayList<Integer> bits=new ArrayList<>();for(int i=0;i<BITS.length;i++)if((available&BITS[i])!=0){names.add(LABELS[i]);bits.add(BITS[i]);}boolean[] selected=new boolean[bits.size()];Arrays.fill(selected,true);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("گەڕاندنەوە · "+NativeImeData.arr(payload,"clipboard").length()+" Clipboard").setMultiChoiceItems(names.toArray(new String[0]),selected,(x,w,on)->selected[w]=on).setNegativeButton("پاشگەزبوونەوە",(x,w)->done("هەڵوەشایەوە.")).setPositiveButton("گەڕاندنەوە",(x,w)->{int chosen=0;for(int i=0;i<selected.length;i++)if(selected[i])chosen|=bits.get(i);if(chosen==0){done("هیچ بەشێک هەڵنەبژێردرا.");return;}final int m=chosen;new AlertDialog.Builder(this).setMessage("ڕێکخستنە هەڵبژێردراوەکان دەگۆڕدرێن. Clipboard ـی ئێستا دەپارێزرێت و دەقی دووبارە زیاد ناکرێت.").setNegativeButton("پاشگەزبوونەوە",(a,b)->done("هەڵوەشایەوە.")).setPositiveButton("بەڵێ",(a,b)->applyRestore(payload,m)).setOnCancelListener(a->done("هەڵوەشایەوە.")).show();}).create();d.setOnCancelListener(x->done("هەڵوەشایەوە."));d.show();}
    private void applyRestore(JSONObject payload,int selected){status("گەڕاندنەوەی داتاکان…");work(()->{boolean ok=false;try{ok=ImeStateStore.restoreCloud(this,payload,core(),selected);}catch(Exception e){}final boolean result=ok;runOnUiThread(()->{if(result)setResult(RESULT_OK);done(result?"داتاکان گەڕێندرانەوە.":"گەڕاندنەوە سەرکەوتوو نەبوو (فایل یان قەبارەی داتا). ");});});}
    private void clearPending(){pending=null;if(pendingPassword!=null)Arrays.fill(pendingPassword,'\0');pendingPassword=null;}
    @Override public void onBackPressed(){if(busy){status("چاوەڕێی تەواوبوونی فرمانەکە بکە یان پەنجەرەکە دابخە.");return;}super.onBackPressed();}
    @Override protected void onDestroy(){clearPending();super.onDestroy();}
}
