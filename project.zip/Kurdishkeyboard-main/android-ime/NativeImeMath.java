package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NativeImeMath {
    private static final Pattern EXPRESSION = Pattern.compile("([0-9٠-٩۰-۹(][0-9٠-٩۰-۹+\\-*/×÷−().%\\s\\p{Z}]*[0-9٠-٩۰-۹)])\\s*(=)?$");
    private static final Pattern OPERATOR = Pattern.compile("[+\\-*/×÷−%]");
    private static final Pattern SAFE = Pattern.compile("[0-9+\\-*/().%]+");
    private static final Pattern DATE = Pattern.compile("[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}");
    private static final Pattern PHONE = Pattern.compile("0[0-9]{2,3}-[0-9]{3,4}-[0-9]{3,4}");
    private static final String[] MONTHS = {"کانوونی دووەم", "شوبات", "ئازار", "نیسان", "ئایار", "حوزەیران",
            "تەممووز", "ئاب", "ئەیلوول", "تشرینی یەکەم", "تشرینی دووەم", "کانوونی یەکەم"};
    private static final String[] DAYS = {"یەکشەممە", "دووشەممە", "سێشەممە", "چوارشەممە", "پێنجشەممە", "هەینی", "شەممە"};

    private NativeImeMath() {}

    static String digits(String input) {
        StringBuilder result = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= '٠' && c <= '٩') c = (char) ('0' + c - '٠');
            else if (c >= '۰' && c <= '۹') c = (char) ('0' + c - '۰');
            result.append(c);
        }
        return result.toString();
    }

    static JSONObject inline(String tail) {
        Matcher match = EXPRESSION.matcher(tail);
        if (!match.find()) return null;
        String expression = NativeImeData.trim(match.group(1));
        if (!OPERATOR.matcher(expression.substring(1)).find()) return null;
        String ascii = digits(expression);
        if (DATE.matcher(ascii).matches() || PHONE.matcher(ascii).matches()) return null;
        String formatted = format(expression);
        return formatted.isEmpty() ? null : json("rawMatch", match.group(), "hasTrailingEquals", match.group(2) != null, "formatted", formatted);
    }

    static String format(String expression) {
        String ascii = digits(expression).replace('×', '*').replace('÷', '/').replace('−', '-')
                .replace("،", "").replaceAll("[\\s\\p{Z}\\uFEFF]+", "");
        if (ascii.length() > 80 || !SAFE.matcher(ascii).matches()) return "";
        Parser parser = new Parser(ascii);
        double result = parser.expression();
        if (parser.position != ascii.length() || Double.isNaN(result) || Double.isInfinite(result)) return "";
        double scaled = result * 1_000_000;
        double floor = Math.floor(scaled);
        double rounded = (scaled - floor >= 0.5 ? floor + 1 : floor) / 1_000_000;
        if (Double.isInfinite(rounded)) return rounded < 0 ? "-Infinity" : "Infinity";
        if (rounded == 0) return "0";
        BigDecimal decimal = BigDecimal.valueOf(rounded).stripTrailingZeros();
        if (Math.abs(rounded) >= 1e15) {
            // Match the original shortest decimal representation for large calculator results.
            BigDecimal exact = new BigDecimal(rounded);
            for (int digits = 1; digits <= 17; digits++) {
                BigDecimal candidate = exact.round(new MathContext(digits, RoundingMode.HALF_EVEN));
                if (candidate.doubleValue() == rounded) {
                    decimal = candidate.stripTrailingZeros();
                    break;
                }
            }
        }
        if (Math.abs(rounded) < 1e21) return decimal.toPlainString();
        return decimal.toString().replace('E', 'e');
    }

    static JSONArray dateTime() {
        Calendar date = Calendar.getInstance();
        int year = date.get(Calendar.YEAR), month = date.get(Calendar.MONTH), day = date.get(Calendar.DAY_OF_MONTH);
        String time = String.format(Locale.ROOT, "%02d:%02d", date.get(Calendar.HOUR_OF_DAY), date.get(Calendar.MINUTE));
        return new JSONArray()
                .put(json("id", "time", "label", "کاتژمێر", "value", time))
                .put(json("id", "date_num", "label", "بەروار", "value", String.format(Locale.ROOT, "%d/%02d/%02d", year, month + 1, day)))
                .put(json("id", "date_ku", "label", "بەرواری کوردی", "value",
                        DAYS[date.get(Calendar.DAY_OF_WEEK) - 1] + "، " + day + "ی " + MONTHS[month] + "ی " + year));
    }

    private static final class Parser {
        final String input;
        int position;
        Parser(String input) { this.input = input; }

        char peek() { return position < input.length() ? input.charAt(position) : 0; }

        double expression() {
            double value = term();
            while (peek() == '+' || peek() == '-') {
                char operation = input.charAt(position++);
                double other = term();
                value = operation == '+' ? value + other : value - other;
            }
            return value;
        }

        double term() {
            double value = unary();
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                char operation = input.charAt(position++);
                double other = unary();
                if (operation != '*' && other == 0) return Double.NaN;
                if (operation == '*') value *= other;
                else if (operation == '/') value /= other;
                else value %= other;
            }
            return value;
        }

        double unary() {
            if (peek() == '+' || peek() == '-') {
                char sign = input.charAt(position++);
                double value = unary();
                return sign == '-' ? -value : value;
            }
            if (peek() == '(') {
                position++;
                double value = expression();
                if (peek() != ')') return Double.NaN;
                position++;
                return value;
            }
            int start = position;
            boolean dot = false;
            while (peek() >= '0' && peek() <= '9' || peek() == '.' && !dot) {
                if (peek() == '.') dot = true;
                position++;
            }
            try { return Double.parseDouble(input.substring(start, position)); }
            catch (NumberFormatException invalid) { return Double.NaN; }
        }
    }
}
