package io.kurdikebord.app;
import java.util.*;

/** Small, allocation-bounded prefix predictor. No editor data is persisted. */
final class NativeWordEngine {
    static String prefix(String before){int i=before.length();while(i>0){int cp=before.codePointBefore(i);int type=Character.getType(cp);if(!Character.isLetter(cp)&&type!=Character.NON_SPACING_MARK&&type!=Character.COMBINING_SPACING_MARK&&cp!=0x200c)break;i-=Character.charCount(cp);}return before.substring(i);}
    static String normalize(String s){StringBuilder b=new StringBuilder(s.length());String lower=s.toLowerCase(Locale.ROOT);for(int i=0;i<lower.length();i++){char c=lower.charAt(i);if(c>=0x064b&&c<=0x065f||c==0x0670||c==0x0640)continue;switch(c){case 'ھ':case 'ة':case 'ە':case 'ہ':c='ه';break;case 'ي':case 'ى':case 'ێ':c='ی';break;case 'ك':c='ک';break;case 'ڕ':c='ر';break;case 'ڵ':c='ل';break;case 'ۆ':case 'ؤ':c='و';break;case 'آ':case 'أ':case 'إ':c='ا';break;default:break;}b.append(c);}return b.toString();}
    private static boolean oneEdit(String a,String b){if(Math.abs(a.length()-b.length())>1)return false;int i=0,j=0,edits=0;while(i<a.length()&&j<b.length()){if(a.charAt(i)==b.charAt(j)){i++;j++;}else{if(++edits>1)return false;if(a.length()>=b.length())i++;if(b.length()>=a.length())j++;}}return edits+((i<a.length()||j<b.length())?1:0)<=1;}
    static List<String> suggest(List<String> words,String p,int limit){
        LinkedHashSet<String> out=new LinkedHashSet<>();if(p.isEmpty()||p.length()>64||limit<=0)return new ArrayList<>();String raw=p.toLowerCase(Locale.ROOT), norm=normalize(p);if(norm.isEmpty())return new ArrayList<>();
        for(int pass=0;pass<3;pass++)for(String w:words){if(w==null||w.isEmpty()||w.length()>120||w.equals(p)||out.contains(w))continue;String n=pass==0?"":normalize(w);boolean match=pass==0?w.toLowerCase(Locale.ROOT).startsWith(raw):pass==1?n.startsWith(norm):norm.length()>=3&&oneEdit(norm,n.substring(0,Math.min(n.length(),norm.length())));if(match){out.add(w);if(out.size()>=limit)return new ArrayList<>(out);}}
        return new ArrayList<>(out);
    }
    static boolean quality(String input,String output,String mode){int a=input.trim().codePointCount(0,input.trim().length()),b=output.trim().codePointCount(0,output.trim().length());return b>0&&!output.trim().startsWith("```")&&b<=Math.max(20000,a*20)&&(!"shorten".equals(mode)||a<20||b<a)&&(!"expand".equals(mode)||a<10||b>a);}
}
