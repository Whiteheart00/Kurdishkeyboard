package io.kurdikebord.app;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.UserManager;
import org.json.JSONObject;

/** Credential-protected, settings-only recovery mirror. Never stores editor or clipboard data. */
final class NativeSettingsBackup {
    private static final String PREF="kurdi_settings_recovery_v1";
    private static SharedPreferences prefs(Context c) {
        UserManager u=(UserManager)c.getSystemService(Context.USER_SERVICE);
        if(android.os.Build.VERSION.SDK_INT >= 24 && u!=null && !u.isUserUnlocked()) return null;
        return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
    }
    private static boolean valid(String s) { if(s==null||s.length()>524288) return false; try { new JSONObject(s); return true; } catch(Exception e) { return false; } }
    static synchronized String read(Context c) { try { SharedPreferences p=prefs(c); if(p==null)return ""; String s=p.getString("current", ""); if(valid(s)) return s; s=p.getString("previous", ""); return valid(s)?s:""; } catch(RuntimeException e) { return ""; } }
    static synchronized boolean write(Context c,String s) { if(!valid(s))return false; try { SharedPreferences p=prefs(c); if(p==null)return false; String old=p.getString("current", ""); if(s.equals(old))return true; SharedPreferences.Editor edit=p.edit(); if(valid(old))edit.putString("previous",old); edit.putString("current",s).putInt("version",1); edit.apply(); return true; } catch(RuntimeException e) { return false; } }
}
