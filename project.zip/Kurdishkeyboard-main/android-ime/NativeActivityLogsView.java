package io.kurdikebord.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Native version of ActivityLogsScreen: filters, report cards and explicit export actions. */
final class NativeActivityLogsView extends LinearLayout {
    private static final String[] CATEGORIES = {"ALL","APPLICATION","USER_OPERATIONS","NETWORK","STORAGE","BACKGROUND_TASKS","WARNINGS","ERRORS","CRASHES"};
    private static final String[] CATEGORY_EN = {"All Events","Application","User Operations","Network","Storage","Background Tasks","Warnings","Errors","Crashes"};
    private static final String[] CATEGORY_KU = {"هەموو ڕووداوەکان","بەرنامە","کردارەکان","تۆڕ و API","بیرگە و فایل","پاشبنەما","ئاگادارکردنەوە","هەڵەکان","پەککەوتن"};
    private static final String[] SEVERITIES = {"ALL","DEBUG","INFO","SUCCESS","WARNING","ERROR","CRITICAL"};
    private final MainActivity activity;
    private final NativeImeAppearance a;
    private final boolean light, english;
    private final String font;
    private final int ink, muted, border, surface, subtle;
    private final SharedPreferences prefs;
    private final ArrayList<JSONObject> logs = new ArrayList<>(), filtered = new ArrayList<>();
    private final Set<String> selected = new HashSet<>(), expanded = new HashSet<>();
    private final LinearLayout categoryChips, severityChips, cards, selectionActions, noticeArea, confirmArea, categoryActions;
    private final Runnable delayedFilter = this::filter;
    private final java.util.Map<String,String> searchIndex = new java.util.HashMap<>();
    private final TextView summary, selectButton;
    private final EditText search;
    private String category="ALL", severity="ALL", query="";
    private boolean selecting;
    private static final int PAGE_SIZE = 50;
    private int limit = PAGE_SIZE;
    private final Runnable delayedReload = this::reload;
    private final SharedPreferences.OnSharedPreferenceChangeListener logListener = (p, key) -> {
        if (MainActivity.DIAG_LOGS_KEY.equals(key)) {
            removeCallbacks(delayedReload);
            postDelayed(delayedReload, 180);
        }
    };
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        prefs.registerOnSharedPreferenceChangeListener(logListener);
        reload();
    }
    @Override protected void onDetachedFromWindow() {
        prefs.unregisterOnSharedPreferenceChangeListener(logListener);
        removeCallbacks(delayedReload);
        removeCallbacks(delayedFilter);
        super.onDetachedFromWindow();
    }

    NativeActivityLogsView(MainActivity activity, String theme, String font, JSONObject data, Runnable back) {
        super(activity); this.activity=activity; this.font=font; a=new NativeImeAppearance(activity,null);
        light="light".equals(theme); english="en".equals(data.optString("appLanguage"));
        ink=light?0xff0f172a:Color.WHITE; muted=light?0xff64748b:0xffa1a1aa; border=light?0xffe2e8f0:0x14ffffff;
        surface=light?Color.WHITE:0xff12141a; subtle=light?0xfff1f5f9:0xff181b23;
        prefs=activity.getSharedPreferences(MainActivity.DIAG_PREFS_NAME,Context.MODE_PRIVATE);
        setOrientation(VERTICAL);setLayoutDirection(english||"kmr".equals(data.optString("appLanguage"))?LAYOUT_DIRECTION_LTR:LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light?0xfff8fafc:0xff0c0e12);
        LinearLayout header=row(); header.setPadding(dp(12),0,dp(12),0);
        ImageView backButton=iconButton("arrow_right",tr("Back","گەڕانەوە"),back);if(getLayoutDirection()==LAYOUT_DIRECTION_LTR)backButton.setRotation(180);header.addView(backButton,new LayoutParams(dp(40),dp(40)));
        TextView title=text(tr("Activity Logs & Reports","تۆماری چالاکی و ڕاپۆرتەکان"),16,ink,800);header.addView(title,new LayoutParams(0,-1,1));
        title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);header.addView(iconButton("refresh_cw",tr("Refresh reports","نوێکردنەوە"),this::reload),new LayoutParams(dp(40),dp(40)));addView(header,new LayoutParams(-1,dp(55)));View divider=new View(activity);divider.setBackgroundColor(border);addView(divider,new LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));
        LinearLayout body=column();body.setPadding(dp(16),dp(12),dp(16),dp(16));scroll.addView(body);
        LinearLayout counts=row();counts.setBackground(a.background(surface,16,1,border));counts.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout summaryWords=column();summaryWords.addView(text("Activity Logs & Reports",12,ink,800));summary=text("",11,muted,400);summaryWords.addView(summary);counts.addView(summaryWords,new LayoutParams(0,-2,1));
        selectButton=button(tr("Select","هەڵبژاردن"),false,()->{selecting=!selecting;selected.clear();cancelConfirmation();refreshCards();});counts.addView(selectButton,new LayoutParams(-2,dp(36)));append(body,counts,0);
        noticeArea=column();append(body,noticeArea,0);confirmArea=column();append(body,confirmArea,0);
        search=new EditText(activity);search.setSingleLine(true);search.setTextColor(ink);search.setHintTextColor(muted);search.setTextSize(13);search.setTypeface(a.font(font,400));search.setHint(tr("Search events, errors, components, operations...","گەڕان لە ناونیشان، هەڵە، پێکهاتە، کردار..."));search.setPadding(dp(6),0,dp(6),0);search.setBackgroundColor(Color.TRANSPARENT);LinearLayout searchRow=row();searchRow.setBackground(a.background(surface,16,1,border));searchRow.addView(iconButton("search",tr("Search","گەڕان"),()->{search.requestFocus();((android.view.inputmethod.InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(search,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}),new LayoutParams(dp(36),dp(40)));searchRow.addView(search,new LayoutParams(0,dp(40),1));ImageView clearSearch=iconButton("logs_close",tr("Clear search","پاککردنەوەی گەڕان"),()->search.setText(""));clearSearch.setVisibility(GONE);searchRow.addView(clearSearch,new LayoutParams(dp(32),dp(40)));append(body,searchRow,12);
        categoryChips=chipStrip(body);severityChips=chipStrip(body);severityChips.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        LinearLayout actions=row();pair(actions,button(tr("Copy All","کۆپی هەمووی"),true,()->copy(logs)),button(tr("Copy Filtered","کۆپی فلتەرکراو"),false,()->copy(filtered)));append(body,actions,10);
        actions=row();pair(actions,button(tr("Share","هاوبەشکردن"),false,()->share(filtered)),button(tr("Export .txt","دابەزاندن .txt"),false,()->export(filtered)));append(body,actions,6);
        categoryActions=row();append(body,categoryActions,6);
        selectionActions=column();append(body,selectionActions,8);
        cards=column();append(body,cards,8);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString();clearSearch.setVisibility(query.isEmpty()?GONE:VISIBLE);limit=PAGE_SIZE;removeCallbacks(delayedFilter);postDelayed(delayedFilter,120);}public void afterTextChanged(Editable e){}});
        setFocusableInTouchMode(true);requestFocus();
        // First load happens on attachment.
    }
    private void cancelConfirmation(){confirmArea.removeAllViews();}
    private ImageView iconButton(String name,String description,Runnable action){ImageView v=new ImageView(activity);v.setImageDrawable(a.icon(name,muted,16));v.setScaleType(ImageView.ScaleType.CENTER);v.setContentDescription(description);v.setFocusable(true);v.setOnClickListener(w->action.run());return v;}
    private String tr(String en,String ku){return english?en:ku;}
    private int dp(int n){return a.dp(n);}
    private LinearLayout row(){LinearLayout r=new LinearLayout(activity);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private LinearLayout column(){LinearLayout c=new LinearLayout(activity);c.setOrientation(VERTICAL);return c;}
    private TextView text(String s,int size,int color,int weight){TextView v=a.text(s,size,color,font,weight);v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return v;}
    private TextView button(String label,boolean primary,Runnable action){TextView b=text(label,12,primary?Color.WHITE:ink,700);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(36));b.setPadding(dp(9),dp(6),dp(9),dp(6));b.setBackground(a.background(primary?0xff0b5fa8:subtle,12,1,primary?0xff0b5fa8:border));b.setOnClickListener(v->action.run());return b;}
    private void append(LinearLayout parent,View v,int gap){LayoutParams p=new LayoutParams(-1,-2);p.topMargin=dp(gap);parent.addView(v,p);}
    private void pair(LinearLayout r,View first,View second){r.addView(first,new LayoutParams(0,-2,1));LayoutParams p=new LayoutParams(0,-2,1);p.setMarginStart(dp(6));r.addView(second,p);}
    private LinearLayout chipStrip(LinearLayout parent){HorizontalScrollView s=new HorizontalScrollView(activity);s.setHorizontalScrollBarEnabled(false);LinearLayout r=row();s.addView(r);append(parent,s,8);return r;}
    private void chips(){categoryChips.removeAllViews();severityChips.removeAllViews();for(int i=0;i<CATEGORIES.length;i++){String cat=CATEGORIES[i];int count=0;for(JSONObject event:logs)if("ALL".equals(cat)||cat.equals(event.optString("category")))count++;addChip(categoryChips,(english?CATEGORY_EN[i]:CATEGORY_KU[i])+"  "+count,cat.equals(category),()->{category=cat;limit=PAGE_SIZE;filter();chips();});}for(String s:SEVERITIES)addChip(severityChips,s,s.equals(severity),()->{severity=s;limit=PAGE_SIZE;filter();chips();});}
    private void addChip(LinearLayout r,String label,boolean active,Runnable action){LayoutParams p=new LayoutParams(-2,dp(32));p.setMarginEnd(dp(6));r.addView(button(label,active,action),p);}
    private void reload(){logs.clear();searchIndex.clear();try{JSONArray values=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]"));for(int i=0;i<values.length();i++){JSONObject e=values.optJSONObject(i);if(e!=null){logs.add(e);searchIndex.put(id(e),searchText(e));}}}catch(Exception ignored){}selected.retainAll(ids(logs));expanded.retainAll(ids(logs));chips();filter();}
    private void filter(){removeCallbacks(delayedFilter);filtered.clear();String q=query.trim().toLowerCase(Locale.ROOT);for(JSONObject e:logs){if(!"ALL".equals(category)&&!category.equals(e.optString("category")))continue;if(!"ALL".equals(severity)&&!severity.equals(e.optString("severity")))continue;if(!q.isEmpty()&&!searchable(e).contains(q))continue;filtered.add(e);}refreshCards();}
    private String searchable(JSONObject e){String value=searchIndex.get(id(e));return value==null?searchText(e):value;}
    private String searchText(JSONObject e){StringBuilder out=new StringBuilder();for(String field:new String[]{"id","title","description","component","operation","status","category","severity","errorMessage","operationId","metadata"})out.append(e.optString(field)).append(' ');return out.toString().toLowerCase(Locale.ROOT);}
    private String id(JSONObject event){return event.optString("id");}
    private Set<String> ids(List<JSONObject> events){Set<String> ids=new HashSet<>();for(JSONObject e:events)ids.add(id(e));return ids;}
    private List<JSONObject> chosen(){List<JSONObject> result=new ArrayList<>();for(JSONObject event:logs)if(selected.contains(id(event)))result.add(event);return result;}
    private boolean hasActiveFilter(){return !"ALL".equals(category)||!"ALL".equals(severity)||!query.trim().isEmpty();}
    private void resetFilters(){category="ALL";severity="ALL";query="";search.setText("");limit=PAGE_SIZE;chips();filter();}
    private void refreshCards(){
        categoryActions.removeAllViews();categoryActions.setVisibility(logs.isEmpty()?GONE:VISIBLE);TextView clearAll=button(tr("Clear All Reports","سڕینەوەی هەموو"),false,()->confirmDelete(ids(logs)));clearAll.setTextColor(severityColor("ERROR"));if(!"ALL".equals(category)){Set<String> targets=new HashSet<>();for(JSONObject event:logs)if(category.equals(event.optString("category")))targets.add(id(event));if(!targets.isEmpty()){TextView clearCat=button(tr("Clear Category","سڕینەوەی پۆل"),false,()->confirmDelete(targets));clearCat.setTextColor(severityColor("WARNING"));pair(categoryActions,clearCat,clearAll);}else categoryActions.addView(clearAll,new LayoutParams(-1,-2));}else categoryActions.addView(clearAll,new LayoutParams(-1,-2));summary.setText(logs.size()+tr(" saved · "," تۆمار · ")+filtered.size()+tr(" matching"," پیشاندراو"));selectButton.setText(selecting?tr("Done","تەواو"):tr("Select","هەڵبژاردن"));selectButton.setBackground(a.background(selecting?0xff0b5fa8:subtle,12,1,border));selectButton.setTextColor(selecting?Color.WHITE:ink);
        selectionActions.removeAllViews();if(selecting){LinearLayout r=row();pair(r,button(!filtered.isEmpty()&&selected.equals(ids(filtered))?tr("Deselect All","لابردنی هەمووی"):tr("Select All (","هەڵبژاردنی هەمووی (")+filtered.size()+")",false,()->{Set<String> all=ids(filtered);boolean allSelected=selected.equals(all);selected.clear();if(!allSelected)selected.addAll(all);refreshCards();}),button(selected.size()+tr(" selected · Copy"," هەڵبژێردراو · کۆپی"),false,()->copy(chosen())));append(selectionActions,r,0);r=row();pair(r,button(tr("Export selected","هەناردەی هەڵبژێردراو"),false,()->export(chosen())),button(tr("Delete selected","سڕینەوەی هەڵبژێردراو"),false,()->confirmDelete(new HashSet<>(selected))));append(selectionActions,r,6);}
        cards.removeAllViews();if(filtered.isEmpty()){LinearLayout empty=column();empty.setPadding(dp(22),dp(28),dp(22),dp(28));empty.setBackground(a.background(surface,24,1,border));TextView heading=text(logs.isEmpty()?tr("No Activity Reports Recorded Yet","هێشتا هیچ ڕاپۆرتێک تۆمار نەکراوە"):tr("No Matching Reports Found","هیچ ڕاپۆرتێک بەپێی ئەم فلتەرە نەدۆزرایەوە"),14,ink,800);heading.setGravity(Gravity.CENTER);empty.addView(heading);TextView info=text(logs.isEmpty()?tr("Application warnings and errors appear here.","چالاکی و ئاگادارکردنەوە و هەڵەکانی بەرنامە لێرە تۆمار دەکرێن."):tr("Try clearing your search or switching filters.","گەڕانەکە پاک بکەرەوە یان فلتەرەکان بگۆڕە."),12,muted,400);info.setGravity(Gravity.CENTER);append(empty,info,8);if(hasActiveFilter())append(empty,button(tr("Reset Filters","پاککردنەوەی فلتەرەکان"),true,this::resetFilters),8);append(cards,empty,0);return;}for(int i=0;i<Math.min(limit,filtered.size());i++)addCard(filtered.get(i));if(limit<filtered.size())append(cards,button(tr("Load More (","پیشاندانی زیاتر (")+(filtered.size()-limit)+tr(" remaining)"," ماوە)"),false,()->{limit+=PAGE_SIZE;refreshCards();}),8);}
    private int severityColor(String s){switch(s){case "CRITICAL":case "ERROR":return light?0xffbe123c:0xfffda4af;case "WARNING":return light?0xff92400e:0xfffcd34d;case "SUCCESS":return light?0xff065f46:0xff6ee7b7;case "INFO":return light?0xff0369a1:0xff7dd3fc;default:return muted;}}
    private int severityFill(String s){switch(s){case "CRITICAL":return light?0xfffee2e2:0x33ef4444;case "ERROR":return light?0xffffe4e6:0x33f43f5e;case "WARNING":return light?0xfffef3c7:0x33f59e0b;case "SUCCESS":return light?0xffd1fae5:0x3310b981;case "INFO":return light?0xffe0f2fe:0x330ea5e9;default:return subtle;}}
    private TextView pill(String value,int color,int fill){TextView tag=text(value,10,color,800);tag.setGravity(Gravity.CENTER);tag.setPadding(dp(6),dp(3),dp(6),dp(3));tag.setBackground(a.background(fill,6,0,0));return tag;}
    private void addCard(JSONObject e){
        String key=id(e);boolean open=expanded.contains(key);boolean checked=selected.contains(key);
        LinearLayout card=column();card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackground(a.background(surface,16,checked?2:1,checked?0xff38bdf8:border));
        LinearLayout top=row();top.setGravity(Gravity.TOP);card.addView(top);
        if(selecting){ImageView check=iconButton(checked?"logs_checked":"logs_square",tr("Select event","هەڵبژاردنی ڕووداو"),()->{if(!selected.add(key))selected.remove(key);refreshCards();});check.setSelected(checked);top.addView(check,new LayoutParams(dp(24),dp(28)));}
        LinearLayout words=column();top.addView(words,new LayoutParams(0,-2,1));
        LinearLayout tags=row();tags.setLayoutDirection(LAYOUT_DIRECTION_LTR);String sev=e.optString("severity");int sevColor=severityColor(sev);
        tags.addView(pill(sev,sevColor,severityFill(sev)));LayoutParams catLp=new LayoutParams(-2,-2);catLp.setMarginStart(dp(6));tags.addView(pill(e.optString("category"),muted,subtle),catLp);words.addView(tags);
        if(e.has("httpStatus")||e.has("durationMs")){LinearLayout metrics=row();metrics.setLayoutDirection(LAYOUT_DIRECTION_LTR);if(e.has("httpStatus"))metrics.addView(pill("HTTP "+e.optString("httpStatus"),severityColor(e.optInt("httpStatus")>=400?"ERROR":"SUCCESS"),subtle));if(e.has("durationMs")){TextView duration=text(e.optString("durationMs")+"ms",10,muted,400);duration.setTypeface(android.graphics.Typeface.MONOSPACE);duration.setPadding(dp(6),0,0,0);metrics.addView(duration);}append(words,metrics,3);}
        TextView title=text(e.optString("title"),12,ink,800);title.setTextDirection(TEXT_DIRECTION_LTR);append(words,title,6);
        String description=e.optString("description");if(!description.isEmpty()){TextView desc=text(description,11,muted,400);desc.setTextDirection(TEXT_DIRECTION_LTR);desc.setMaxLines(2);desc.setEllipsize(TextUtils.TruncateAt.END);append(words,desc,4);}
        TextView meta=text(time(e)+" · "+e.optString("component")+" · "+e.optString("status"),11,muted,400);meta.setTextDirection(TEXT_DIRECTION_LTR);append(words,meta,4);
        Runnable toggle=()->{if(!expanded.add(key))expanded.remove(key);refreshCards();};words.setOnClickListener(v->toggle.run());ImageView chevron=iconButton("chevron_down",open?tr("Collapse details","داخستنی وردەکاری"):tr("Expand details","کردنەوەی وردەکاری"),toggle);chevron.setRotation(open?180:0);top.addView(chevron,new LayoutParams(dp(24),dp(28)));
        if(open){LinearLayout detail=column();detail.setLayoutDirection(LAYOUT_DIRECTION_LTR);detail.setPadding(dp(10),dp(10),dp(10),dp(10));detail.setBackground(a.background(subtle,12,1,border));
            for(String[] field:new String[][]{{"Event ID","id"},{"Time (ISO)","timestamp"},{"Component","component"},{"Operation","operation"},{"Status","status"},{"App Version","appVersion"},{"Platform","platform"},{"OS Version","osVersion"},{"Operation ID","operationId"},{"Related Event","relatedEventId"}}){String value=e.optString(field[1]);if(!value.isEmpty()){TextView line=text(field[0]+": "+value,11,ink,400);line.setTextIsSelectable(true);append(detail,line,4);}}
            for(String[] field:new String[][]{{"Error Message","errorMessage"},{"Sanitized Metadata","metadata"},{"Stack Trace","stackTrace"}}){String value=e.optString(field[1]);if(value.isEmpty())continue;TextView label=text(field[0],10,field[1].equals("errorMessage")?severityColor("ERROR"):field[1].equals("stackTrace")?severityColor("WARNING"):muted,800);append(detail,label,8);TextView block=text(value,11,ink,400);block.setTextIsSelectable(true);block.setTypeface(android.graphics.Typeface.MONOSPACE);append(detail,block,4);}
            append(card,detail,10);LinearLayout actions=row();TextView copy=button(tr("Copy Report","کۆپیکردنی ڕاپۆرت"),true,()->copy(java.util.Collections.singletonList(e)));TextView delete=button(tr("Delete","سڕینەوە"),false,()->confirmDelete(java.util.Collections.singleton(key)));delete.setTextColor(severityColor("ERROR"));pair(actions,copy,delete);append(card,actions,8);
        }append(cards,card,10);
    }
    private String time(JSONObject e){long epoch=e.optLong("epochMs",0);return epoch>0?new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(epoch)):e.optString("timestamp");}
    private String eventBlock(JSONObject e,int i){StringBuilder b=new StringBuilder(String.format(Locale.US,"EVENT %03d\n",i));String[][] fields={{"Event ID","id"},{"Category","category"},{"Severity","severity"},{"Event","title"},{"Time","timestamp"},{"Component","component"},{"Operation","operation"},{"Status","status"},{"Operation ID","operationId"},{"Related Event ID","relatedEventId"},{"HTTP Status","httpStatus"},{"Duration (ms)","durationMs"},{"Description","description"},{"Error","errorMessage"},{"Metadata","metadata"},{"Stack Trace","stackTrace"},{"App Version","appVersion"},{"Platform","platform"},{"OS Version","osVersion"}};for(String[] f:fields){String value=e.optString(f[1],"");if(!value.isEmpty())b.append(f[0]).append(": ").append(value).append('\n');}return b.append("----------------------------------------").toString();}
    private String report(List<JSONObject> events){List<JSONObject> sorted=new ArrayList<>(events);java.util.Collections.sort(sorted,(left,right)->Long.compare(left.optLong("epochMs"),right.optLong("epochMs")));String version="unknown";try{version=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName;}catch(Exception ignored){}StringBuilder b=new StringBuilder("========================================\nAPPLICATION ACTIVITY REPORT\n========================================\nApplication: KurdiKeyboard\nVersion: ").append(version).append("\nPlatform: Android / ").append(android.os.Build.VERSION.RELEASE).append("\nGenerated: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())).append("\nTotal Events: ").append(sorted.size()).append("\n----------------------------------------\n");for(int i=0;i<sorted.size();i++)b.append(eventBlock(sorted.get(i),i+1)).append('\n');return b.append("========================================\nEND OF REPORT\n========================================").toString();}
    private void notice(String message){noticeArea.removeAllViews();LinearLayout strip=row();strip.setPadding(dp(12),dp(8),dp(8),dp(8));strip.setBackground(a.background(subtle,16,1,border));strip.addView(text(message,12,ink,700),new LayoutParams(0,-2,1));strip.addView(iconButton("logs_close",tr("Dismiss message","داخستنی پەیام"),noticeArea::removeAllViews),new LayoutParams(dp(28),dp(28)));append(noticeArea,strip,12);}
    private boolean hasEvents(List<JSONObject> e){if(!e.isEmpty())return true;notice(tr("No reports selected","هیچ ڕاپۆرتێک هەڵنەبژێردراوە"));return false;}
    private void copy(List<JSONObject> e){if(!hasEvents(e))return;String report=report(e);if(report.length()>180000){notice(tr("Report too large to copy; use Export","ڕاپۆرتەکە گەورەیە؛ هەناردەی بکە"));return;}try{((ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Activity report",report));notice(tr("Copied","کۆپی کرا"));}catch(Exception ex){notice(tr("Copy failed","کۆپیکردن سەرکەوتوو نەبوو"));}}
    private void share(List<JSONObject> e){if(!hasEvents(e))return;String report=report(e);if(report.length()>180000){notice(tr("Report too large to share; use Export","ڕاپۆرتەکە گەورەیە؛ هەناردەی بکە"));return;}try{activity.startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,report),tr("Share report","هاوبەشکردنی ڕاپۆرت")));}catch(Exception ex){notice(tr("Share unavailable","هاوبەشکردن بەردەست نییە"));}}
    private void export(List<JSONObject> e){if(hasEvents(e))activity.exportActivityReport(report(e));}
    private void confirmDelete(Set<String> targets){
        if(targets.isEmpty()){notice(tr("No reports selected","هیچ ڕاپۆرتێک هەڵنەبژێردراوە"));return;}
        Set<String> snapshot=new HashSet<>(targets);confirmArea.removeAllViews();LinearLayout box=column();box.setPadding(dp(14),dp(12),dp(14),dp(12));box.setBackground(a.background(light?0xfffff1f2:0x33be123c,16,1,0xffbe123c));
        box.addView(text(tr("Permanently delete ","دڵنیایت لە سڕینەوەی ")+snapshot.size()+tr(" report(s)?"," ڕاپۆرت؟"),12,severityColor("ERROR"),800));LinearLayout actions=row();TextView yes=button(tr("Confirm Delete","بەڵێ، بیسڕەوە"),true,()->deleteConfirmed(snapshot));yes.setBackground(a.background(0xffbe123c,12,0,0));pair(actions,yes,button(tr("Cancel","پاشگەزبوونەوە"),false,this::cancelConfirmation));append(box,actions,10);append(confirmArea,box,12);
        confirmArea.post(()->confirmArea.requestRectangleOnScreen(new android.graphics.Rect(0,0,confirmArea.getWidth(),Math.max(confirmArea.getHeight(),dp(110))),false));
    }
    private void deleteConfirmed(Set<String> targets){try{synchronized(MainActivity.class){JSONArray existing=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]")),keep=new JSONArray();for(int i=0;i<existing.length();i++){JSONObject e=existing.optJSONObject(i);if(e==null||!targets.contains(id(e)))keep.put(existing.get(i));}prefs.edit().putString(MainActivity.DIAG_LOGS_KEY,keep.toString()).apply();}selected.removeAll(targets);expanded.removeAll(targets);cancelConfirmation();removeCallbacks(delayedReload);reload();notice(tr("Reports deleted","ڕاپۆرتەکان سڕانەوە"));}catch(Exception ex){notice(tr("Delete failed","سڕینەوە سەرکەوتوو نەبوو"));}}
}
