package io.kurdikebord.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Native version of ActivityLogsScreen: filters, report cards and explicit export actions. */
final class NativeActivityLogsView extends LinearLayout {
    private static final String[] CATEGORIES = {"ALL","APPLICATION","USER_OPERATIONS","NETWORK","STORAGE","BACKGROUND_TASKS","WARNINGS","ERRORS","CRASHES"};
    private static final String[] CATEGORY_EN = {"All Events","Application","User Operations","Network","Storage","Background Tasks","Warnings","Errors","Crashes"};
    private static final String[] CATEGORY_KU = {"هەموو ڕووداوەکان","بەرنامە","کردارەکان","تۆڕ و API","بیرگە و فایل","پاشبنەما","ئاگادارکردنەوە","هەڵەکان","پەککەوتن"};
    private static final String[] SEVERITIES = {"ALL","DEBUG","INFO","SUCCESS","WARNING","ERROR","CRITICAL"};
    private final MainActivity activity;
    private final NativeImeAppearance a;
    private final boolean light, english;
    private final String font;
    private final int ink, muted, border, surface, subtle;
    private final SharedPreferences prefs;
    private final ArrayList<JSONObject> logs = new ArrayList<>(), filtered = new ArrayList<>();
    private final Set<String> selected = new HashSet<>(), expanded = new HashSet<>();
    private final LinearLayout categoryChips, severityChips, cards, selectionActions;
    private final TextView summary, selectButton;
    private String category="ALL", severity="ALL", query="";
    private boolean selecting;
    private int limit = 20;
    private final Runnable delayedReload = this::reload;
    private final SharedPreferences.OnSharedPreferenceChangeListener logListener = (p, key) -> {
        if (MainActivity.DIAG_LOGS_KEY.equals(key)) {
            removeCallbacks(delayedReload);
            postDelayed(delayedReload, 180);
        }
    };
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        prefs.registerOnSharedPreferenceChangeListener(logListener);
        reload();
    }
    @Override protected void onDetachedFromWindow() {
        prefs.unregisterOnSharedPreferenceChangeListener(logListener);
        removeCallbacks(delayedReload);
        super.onDetachedFromWindow();
    }

    NativeActivityLogsView(MainActivity activity, String theme, String font, JSONObject data, Runnable back) {
        super(activity); this.activity=activity; this.font=font; a=new NativeImeAppearance(activity,null);
        light="light".equals(theme); english="en".equals(data.optString("appLanguage"));
        ink=light?0xff0f172a:Color.WHITE; muted=light?0xff64748b:0xffa1a1aa; border=light?0xffe2e8f0:0x14ffffff;
        surface=light?Color.WHITE:0xff12141a; subtle=light?0xfff1f5f9:0xff181b23;
        prefs=activity.getSharedPreferences(MainActivity.DIAG_PREFS_NAME,Context.MODE_PRIVATE);
        setOrientation(VERTICAL);setLayoutDirection(english||"kmr".equals(data.optString("appLanguage"))?LAYOUT_DIRECTION_LTR:LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light?0xfff8fafc:0xff0c0e12);
        LinearLayout header=row(); header.setPadding(dp(12),0,dp(12),0);
        TextView backButton=button(english?"←":"→",false,back);header.addView(backButton,new LayoutParams(dp(40),dp(40)));
        TextView title=text(tr("Activity Logs & Reports","تۆماری چالاکی و ڕاپۆرتەکان"),16,ink,800);header.addView(title,new LayoutParams(0,-1,1));
        header.addView(button("↻",false,this::reload),new LayoutParams(dp(40),dp(40)));addView(header,new LayoutParams(-1,dp(55)));
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));
        LinearLayout body=column();body.setPadding(dp(16),dp(12),dp(16),dp(16));scroll.addView(body);
        LinearLayout counts=row();counts.setBackground(a.background(surface,16,1,border));counts.setPadding(dp(12),dp(10),dp(12),dp(10));
        summary=text("",12,ink,700);counts.addView(summary,new LayoutParams(0,-2,1));
        selectButton=button(tr("Select","هەڵبژاردن"),false,()->{selecting=!selecting;selected.clear();refreshCards();});counts.addView(selectButton,new LayoutParams(-2,dp(36)));append(body,counts,0);
        EditText search=new EditText(activity);search.setSingleLine(true);search.setTextColor(ink);search.setHintTextColor(muted);search.setTextSize(13);search.setTypeface(a.font(font,400));search.setHint(tr("Search reports...","گەڕان لە ڕاپۆرتەکان..."));search.setPadding(dp(12),0,dp(12),0);search.setBackground(a.background(surface,16,1,border));
        LayoutParams searchLp=new LayoutParams(-1,dp(42));searchLp.topMargin=dp(12);body.addView(search,searchLp);
        categoryChips=chipStrip(body);severityChips=chipStrip(body);severityChips.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        LinearLayout actions=row();pair(actions,button(tr("Copy All","کۆپی هەمووی"),true,()->copy(logs)),button(tr("Copy Filtered","کۆپی فلتەرکراو"),false,()->copy(filtered)));append(body,actions,10);
        actions=row();pair(actions,button(tr("Share","هاوبەشکردن"),false,()->share(filtered)),button(tr("Export .txt","دابەزاندن .txt"),false,()->export(filtered)));append(body,actions,6);
        actions=row();pair(actions,button(tr("Clear Category","سڕینەوەی پۆل"),false,()->{if(!"ALL".equals(category)){Set<String> ids=new HashSet<>();for(JSONObject event:logs)if(category.equals(event.optString("category")))ids.add(id(event));confirmDelete(ids);}else notice(tr("Choose a category first","سەرەتا پۆلێک هەڵبژێرە"));}),button(tr("Clear All Reports","سڕینەوەی هەموو"),false,()->confirmDelete(ids(logs))));append(body,actions,6);
        selectionActions=column();append(body,selectionActions,8);
        cards=column();append(body,cards,8);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString();limit=20;filter();}public void afterTextChanged(Editable e){}});
        reload();
    }
    private String tr(String en,String ku){return english?en:ku;}
    private int dp(int n){return a.dp(n);}
    private LinearLayout row(){LinearLayout r=new LinearLayout(activity);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private LinearLayout column(){LinearLayout c=new LinearLayout(activity);c.setOrientation(VERTICAL);return c;}
    private TextView text(String s,int size,int color,int weight){TextView v=a.text(s,size,color,font,weight);v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return v;}
    private TextView button(String label,boolean primary,Runnable action){TextView b=text(label,12,primary?Color.WHITE:ink,700);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(36));b.setPadding(dp(9),dp(6),dp(9),dp(6));b.setBackground(a.background(primary?0xff0b5fa8:subtle,12,1,primary?0xff0b5fa8:border));b.setOnClickListener(v->action.run());return b;}
    private void append(LinearLayout parent,View v,int gap){LayoutParams p=new LayoutParams(-1,-2);p.topMargin=dp(gap);parent.addView(v,p);}
    private void pair(LinearLayout r,View first,View second){r.addView(first,new LayoutParams(0,-2,1));LayoutParams p=new LayoutParams(0,-2,1);p.setMarginStart(dp(6));r.addView(second,p);}
    private LinearLayout chipStrip(LinearLayout parent){HorizontalScrollView s=new HorizontalScrollView(activity);s.setHorizontalScrollBarEnabled(false);LinearLayout r=row();s.addView(r);append(parent,s,8);return r;}
    private void chips(){categoryChips.removeAllViews();severityChips.removeAllViews();for(int i=0;i<CATEGORIES.length;i++){String cat=CATEGORIES[i];int count=0;for(JSONObject event:logs)if("ALL".equals(cat)||cat.equals(event.optString("category")))count++;addChip(categoryChips,(english?CATEGORY_EN[i]:CATEGORY_KU[i])+"  "+count,cat.equals(category),()->{category=cat;limit=20;filter();chips();});}for(String s:SEVERITIES)addChip(severityChips,s,s.equals(severity),()->{severity=s;limit=20;filter();chips();});}
    private void addChip(LinearLayout r,String label,boolean active,Runnable action){LayoutParams p=new LayoutParams(-2,dp(32));p.setMarginEnd(dp(6));r.addView(button(label,active,action),p);}
    private void reload(){logs.clear();try{JSONArray values=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]"));for(int i=0;i<values.length();i++){JSONObject e=values.optJSONObject(i);if(e!=null)logs.add(e);}}catch(Exception ignored){}selected.retainAll(ids(logs));expanded.retainAll(ids(logs));chips();filter();}
    private void filter(){filtered.clear();String q=query.trim().toLowerCase(Locale.ROOT);for(JSONObject e:logs){if(!"ALL".equals(category)&&!category.equals(e.optString("category")))continue;if(!"ALL".equals(severity)&&!severity.equals(e.optString("severity")))continue;if(!q.isEmpty()&&!e.toString().toLowerCase(Locale.ROOT).contains(q))continue;filtered.add(e);}refreshCards();}
    private String id(JSONObject event){return event.optString("id");}
    private Set<String> ids(List<JSONObject> events){Set<String> ids=new HashSet<>();for(JSONObject e:events)ids.add(id(e));return ids;}
    private List<JSONObject> chosen(){List<JSONObject> result=new ArrayList<>();for(JSONObject event:logs)if(selected.contains(id(event)))result.add(event);return result;}
    private void refreshCards(){summary.setText("Activity Logs & Reports\n"+logs.size()+tr(" saved · "," تۆمار · ")+filtered.size()+tr(" matching"," پیشاندراو"));selectButton.setText(selecting?tr("Done","تەواو"):tr("Select","هەڵبژاردن"));selectButton.setBackground(a.background(selecting?0xff0b5fa8:subtle,12,1,border));selectButton.setTextColor(selecting?Color.WHITE:ink);
        selectionActions.removeAllViews();if(selecting){LinearLayout r=row();pair(r,button(tr("Select filtered","هەڵبژاردنی فلتەرکراو"),false,()->{Set<String> all=ids(filtered);if(selected.containsAll(all))selected.removeAll(all);else selected.addAll(all);refreshCards();}),button(selected.size()+tr(" selected · Copy"," هەڵبژێردراو · کۆپی"),false,()->copy(chosen())));append(selectionActions,r,0);r=row();pair(r,button(tr("Export selected","هەناردەی هەڵبژێردراو"),false,()->export(chosen())),button(tr("Delete selected","سڕینەوەی هەڵبژێردراو"),false,()->confirmDelete(new HashSet<>(selected))));append(selectionActions,r,6);}
        cards.removeAllViews();if(filtered.isEmpty()){TextView empty=text(tr("No matching reports","هیچ ڕاپۆرتێک نەدۆزرایەوە"),13,muted,500);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(24),0,dp(24));append(cards,empty,0);return;}for(int i=0;i<Math.min(limit,filtered.size());i++)addCard(filtered.get(i));if(limit<filtered.size())append(cards,button(tr("Load more","پیشاندانی زیاتر"),false,()->{limit+=20;refreshCards();}),8);}
    private int severityColor(String s){switch(s){case "CRITICAL":case "ERROR":return light?0xffbe123c:0xfffda4af;case "WARNING":return light?0xff92400e:0xfffcd34d;case "SUCCESS":return light?0xff065f46:0xff6ee7b7;case "INFO":return light?0xff0369a1:0xff7dd3fc;default:return muted;}}
    private void addCard(JSONObject e){String key=id(e);LinearLayout card=column();card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(a.background(surface,16,1,border));LinearLayout top=row();String s=e.optString("severity");TextView tag=text(s,10,severityColor(s),800);tag.setPadding(dp(8),dp(4),dp(8),dp(4));tag.setBackground(a.background(subtle,8,1,border));top.addView(tag);TextView category=text(e.optString("category"),10,muted,600);category.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);top.addView(category,new LayoutParams(0,-2,1));card.addView(top);
        TextView title=text((selecting?(selected.contains(key)?"☑  ":"☐  "):"")+e.optString("title"),14,ink,700);title.setPadding(0,dp(7),0,dp(3));card.addView(title);card.addView(text(time(e)+" · "+e.optString("component"),11,muted,400));TextView details=text(expanded.contains(key)?"⌃":"⌄",15,muted,700);details.setGravity(Gravity.CENTER);card.addView(details,new LayoutParams(-1,dp(24)));
        View.OnClickListener toggle=v->{if(selecting){if(!selected.add(key))selected.remove(key);}else if(!expanded.add(key))expanded.remove(key);refreshCards();};title.setOnClickListener(toggle);details.setOnClickListener(toggle);top.setOnClickListener(toggle);
        if(expanded.contains(key)){TextView detail=text(eventBlock(e,1),11,ink,400);detail.setTextIsSelectable(true);detail.setPadding(dp(8),dp(8),dp(8),dp(8));detail.setBackground(a.background(subtle,10,1,border));append(card,detail,4);LinearLayout actions=row();pair(actions,button(tr("Copy","کۆپی"),false,()->copy(java.util.Collections.singletonList(e))),button(tr("Delete","سڕینەوە"),false,()->confirmDelete(java.util.Collections.singleton(key))));append(card,actions,6);actions=row();pair(actions,button(tr("Share","هاوبەشکردن"),false,()->share(java.util.Collections.singletonList(e))),button(tr("Export .txt","دابەزاندن"),false,()->export(java.util.Collections.singletonList(e))));append(card,actions,6);}append(cards,card,8);}
    private String time(JSONObject e){long epoch=e.optLong("epochMs",0);return epoch>0?new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(epoch)):e.optString("timestamp");}
    private String eventBlock(JSONObject e,int i){StringBuilder b=new StringBuilder(String.format(Locale.US,"EVENT %03d\n",i));String[][] fields={{"Event ID","id"},{"Category","category"},{"Severity","severity"},{"Event","title"},{"Time","timestamp"},{"Component","component"},{"Operation","operation"},{"Status","status"},{"Operation ID","operationId"},{"Related Event ID","relatedEventId"},{"HTTP Status","httpStatus"},{"Duration (ms)","durationMs"},{"Description","description"},{"Error","errorMessage"},{"Metadata","metadata"},{"Stack Trace","stackTrace"}};for(String[] f:fields){String value=e.optString(f[1],"");if(!value.isEmpty())b.append(f[0]).append(": ").append(value).append('\n');}return b.append("----------------------------------------").toString();}
    private String report(List<JSONObject> events){List<JSONObject> sorted=new ArrayList<>(events);sorted.sort(Comparator.comparingLong(e->e.optLong("epochMs")));String version="unknown";try{version=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName;}catch(Exception ignored){}StringBuilder b=new StringBuilder("========================================\nAPPLICATION ACTIVITY REPORT\n========================================\nApplication: KurdiKeyboard\nVersion: ").append(version).append("\nPlatform: Android / ").append(android.os.Build.VERSION.RELEASE).append("\nGenerated: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())).append("\nTotal Events: ").append(sorted.size()).append("\n----------------------------------------\n");for(int i=0;i<sorted.size();i++)b.append(eventBlock(sorted.get(i),i+1)).append('\n');return b.append("========================================\nEND OF REPORT\n========================================").toString();}
    private void notice(String s){Toast.makeText(activity,s,Toast.LENGTH_SHORT).show();}
    private boolean hasEvents(List<JSONObject> e){if(!e.isEmpty())return true;notice(tr("No reports selected","هیچ ڕاپۆرتێک هەڵنەبژێردراوە"));return false;}
    private void copy(List<JSONObject> e){if(!hasEvents(e))return;String report=report(e);if(report.length()>180000){notice(tr("Report too large to copy; use Export","ڕاپۆرتەکە گەورەیە؛ هەناردەی بکە"));return;}try{((ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Activity report",report));notice(tr("Copied","کۆپی کرا"));}catch(Exception ex){notice(tr("Copy failed","کۆپیکردن سەرکەوتوو نەبوو"));}}
    private void share(List<JSONObject> e){if(!hasEvents(e))return;String report=report(e);if(report.length()>180000){notice(tr("Report too large to share; use Export","ڕاپۆرتەکە گەورەیە؛ هەناردەی بکە"));return;}try{activity.startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,report),tr("Share report","هاوبەشکردنی ڕاپۆرت")));}catch(Exception ex){notice(tr("Share unavailable","هاوبەشکردن بەردەست نییە"));}}
    private void export(List<JSONObject> e){if(hasEvents(e))activity.exportActivityReport(report(e));}
    private void confirmDelete(Set<String> targets){if(targets.isEmpty()){notice(tr("No reports selected","هیچ ڕاپۆرتێک هەڵنەبژێردراوە"));return;}new AlertDialog.Builder(activity).setMessage(tr("Delete ","سڕینەوەی ")+targets.size()+tr(" report(s)?"," ڕاپۆرت؟")).setNegativeButton(tr("Cancel","پاشگەزبوونەوە"),null).setPositiveButton(tr("Delete","بیسڕەوە"),(d,w)->{try{synchronized(MainActivity.class){JSONArray existing=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]")),keep=new JSONArray();for(int i=0;i<existing.length();i++){JSONObject e=existing.optJSONObject(i);if(e==null||!targets.contains(id(e)))keep.put(existing.get(i));}prefs.edit().putString(MainActivity.DIAG_LOGS_KEY,keep.toString()).apply();}selected.removeAll(targets);expanded.removeAll(targets);removeCallbacks(delayedReload);reload();}catch(Exception ex){notice(tr("Delete failed","سڕینەوە سەرکەوتوو نەبوو"));}}).show();}
}
