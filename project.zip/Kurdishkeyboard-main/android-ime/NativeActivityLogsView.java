package io.kurdikebord.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Native version of ActivityLogsScreen: filters, report cards and explicit export actions. */
final class NativeActivityLogsView extends LinearLayout {
    private static final String[] CATEGORIES = {"ALL","APPLICATION","USER_OPERATIONS","NETWORK","STORAGE","BACKGROUND_TASKS","WARNINGS","ERRORS","CRASHES"};
    private static final String[] CATEGORY_EN = {"All Events","Application","User Operations","Network","Storage","Background Tasks","Warnings","Errors","Crashes"};
    private static final String[] CATEGORY_KU = {"هەموو ڕووداوەکان","بەرنامە","کردارەکان","تۆڕ و API","بیرگە و فایل","پاشبنەما","ئاگادارکردنەوە","هەڵەکان","پەککەوتن"};
    private static final String[] SEVERITIES = {"ALL","DEBUG","INFO","SUCCESS","WARNING","ERROR","CRITICAL"};
    private final MainActivity activity;
    private final NativeImeAppearance a;
    private final boolean light, english;
    private final String font;
    private final int ink, muted, border, surface, subtle;
    private final SharedPreferences prefs;
    private final ArrayList<JSONObject> logs = new ArrayList<>(), filtered = new ArrayList<>();
    private final Set<String> selected = new HashSet<>(), expanded = new HashSet<>();
    private final LinearLayout categoryChips, severityChips, cards, selectionActions, noticeArea, confirmArea, categoryActions;
    private final Runnable delayedFilter = this::filter;
    private final java.util.Map<String,String> searchIndex = new java.util.HashMap<>();
    private final TextView summary, selectButton, copyAllButton, copyFilteredButton, shareButton, exportButton;
    private final Runnable dismissNotice = () -> clearNotice();
    private final EditText search;
    private String category="ALL", severity="ALL", query="";
    private boolean selecting;
    private static final int PAGE_SIZE = 50;
    private int limit = PAGE_SIZE;
    private final Runnable delayedReload = this::reload;
    private final SharedPreferences.OnSharedPreferenceChangeListener logListener = (p, key) -> {
        if (MainActivity.DIAG_LOGS_KEY.equals(key)) {
            removeCallbacks(delayedReload);
            postDelayed(delayedReload, 180);
        }
    };
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        prefs.registerOnSharedPreferenceChangeListener(logListener);
        reload();
    }
    @Override protected void onDetachedFromWindow() {
        prefs.unregisterOnSharedPreferenceChangeListener(logListener);
        removeCallbacks(delayedReload);
        removeCallbacks(delayedFilter);
        removeCallbacks(dismissNotice);
        super.onDetachedFromWindow();
    }

    NativeActivityLogsView(MainActivity activity, String theme, String font, JSONObject data, Runnable back) {
        super(activity); this.activity=activity; this.font=font; a=new NativeImeAppearance(activity,null);
        light="light".equals(theme); english="en".equals(data.optString("appLanguage"));
        ink=light?0xff0f172a:Color.WHITE; muted=light?0xff64748b:0xffa1a1aa; border=light?0xffe2e8f0:0x14ffffff;
        surface=light?Color.WHITE:0xff12141a; subtle=light?0xfff1f5f9:0xff181b23;
        prefs=activity.getSharedPreferences(MainActivity.DIAG_PREFS_NAME,Context.MODE_PRIVATE);
        setOrientation(VERTICAL);setLayoutDirection(english||"kmr".equals(data.optString("appLanguage"))?LAYOUT_DIRECTION_LTR:LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light?0xfff8fafc:0xff0c0e12);
        LinearLayout header=row(); header.setPadding(dp(16),0,dp(16),0); header.setLayoutDirection(LAYOUT_DIRECTION_RTL); header.setBackgroundColor(light?0xfff8fafc:Color.BLACK);
        ImageView backButton=iconButton("arrow_right",tr("Back","گەڕانەوە"),back);header.addView(backButton,new LayoutParams(dp(40),dp(40)));
        TextView title=text(tr("Activity Logs & Reports","تۆماری چالاکی و ڕاپۆرتەکان"),16,ink,800);header.addView(title,new LayoutParams(0,-1,1));
        title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);header.addView(iconButton("refresh_cw",tr("Refresh reports","نوێکردنەوە"),this::manualRefresh),new LayoutParams(dp(36),dp(36)));addView(header,new LayoutParams(-1,dp(56)));View divider=new View(activity);divider.setBackgroundColor(border);addView(divider,new LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));
        LinearLayout body=column();body.setPadding(dp(16),dp(12),dp(16),dp(16));scroll.addView(body);
        LinearLayout counts=row();counts.setBackground(a.background(surface,16,1,border));counts.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout summaryWords=column();summaryWords.addView(text("Activity Logs & Reports",12,ink,800));summary=text("",11,muted,400);summaryWords.addView(summary);counts.addView(summaryWords,new LayoutParams(0,-2,1));
        selectButton=button(tr("Select","هەڵبژاردن"),false,()->{selecting=!selecting;selected.clear();cancelConfirmation();refreshCards();});counts.addView(selectButton,new LayoutParams(-2,dp(32)));append(body,counts,0);
        noticeArea=column();noticeArea.setVisibility(GONE);append(body,noticeArea,0);confirmArea=column();confirmArea.setVisibility(GONE);append(body,confirmArea,0);
        search=new EditText(activity);search.setSingleLine(true);search.setTextColor(ink);search.setHintTextColor(muted);search.setTextSize(13);search.setTypeface(a.font(font,400));search.setHint(tr("Search events, errors, components, operations...","گەڕان لە ناونیشان، هەڵە، پێکهاتە، کردار..."));search.setPadding(dp(6),0,dp(6),0);search.setBackgroundColor(Color.TRANSPARENT);LinearLayout searchRow=row();searchRow.setBackground(a.background(surface,16,1,border));searchRow.addView(iconButton("search",tr("Search","گەڕان"),()->{search.requestFocus();((android.view.inputmethod.InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(search,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}),new LayoutParams(dp(36),dp(40)));searchRow.addView(search,new LayoutParams(0,dp(40),1));ImageView clearSearch=iconButton("logs_close",tr("Clear search","پاککردنەوەی گەڕان"),()->search.setText(""));clearSearch.setVisibility(GONE);searchRow.addView(clearSearch,new LayoutParams(dp(32),dp(40)));append(body,searchRow,12);
        categoryChips=chipStrip(body);severityChips=chipStrip(body);severityChips.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        LinearLayout actions=row();copyAllButton=actionButton(tr("Copy All","کۆپی هەمووی"),"logs_copy",true,()->copy(logs,"All Saved Reports",false));copyFilteredButton=actionButton(tr("Copy Filtered","کۆپی فلتەرکراو"),"logs_copy",false,()->{filter();copy(filtered,filterScope(),false);});pair(actions,copyAllButton,copyFilteredButton);append(body,actions,12);
        actions=row();shareButton=actionButton(tr("Share","هاوبەشکردن"),"logs_share",false,()->{filter();share(filtered);});exportButton=actionButton(tr("Export .txt","دابەزاندن .txt"),"logs_download",false,()->{filter();export(filtered);});pair(actions,shareButton,exportButton);append(body,actions,8);
        categoryActions=row();append(body,categoryActions,6);
        selectionActions=column();append(body,selectionActions,8);
        cards=column();append(body,cards,8);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString();clearSearch.setVisibility(query.isEmpty()?GONE:VISIBLE);limit=PAGE_SIZE;removeCallbacks(delayedFilter);postDelayed(delayedFilter,120);}public void afterTextChanged(Editable e){}});
        setFocusableInTouchMode(true);requestFocus();
        // First load happens on attachment.
    }
    private void cancelConfirmation(){confirmArea.removeAllViews();confirmArea.setVisibility(GONE);}
    private ImageView iconButton(String name,String description,Runnable action){ImageView v=new ImageView(activity);v.setImageDrawable(a.icon(name,muted,16));v.setScaleType(ImageView.ScaleType.CENTER);v.setContentDescription(description);v.setFocusable(true);v.setOnClickListener(w->action.run());return v;}
    private String tr(String en,String ku){return english?en:ku;}
    private int dp(int n){return a.dp(n);}
    private LinearLayout row(){LinearLayout r=new LinearLayout(activity);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private LinearLayout column(){LinearLayout c=new LinearLayout(activity);c.setOrientation(VERTICAL);return c;}
    private TextView text(String s,int size,int color,int weight){TextView v=a.text(s,size,color,font,weight);v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return v;}
    private TextView button(String label,boolean primary,Runnable action){TextView b=text(label,12,primary?Color.WHITE:ink,700);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(36));b.setPadding(dp(9),dp(6),dp(9),dp(6));b.setBackground(a.background(primary?0xff0b5fa8:subtle,12,1,primary?0xff0b5fa8:border));b.setOnClickListener(v->action.run());return b;}
    private void setIcon(TextView b,String name,int color){android.graphics.drawable.Drawable icon=a.icon(name,color,14);if(icon!=null){icon.setBounds(0,0,dp(14),dp(14));b.setCompoundDrawablesRelative(icon,null,null,null);b.setCompoundDrawablePadding(dp(6));}}
    private TextView actionButton(String label,String icon,boolean primary,Runnable action){TextView b=button(label,primary,action);b.setTextSize(11);b.setSingleLine(true);b.setEllipsize(TextUtils.TruncateAt.END);setIcon(b,icon,primary?Color.WHITE:ink);return b;}
    private void enabled(TextView b,boolean enabled){b.setEnabled(enabled);b.setAlpha(enabled?1f:0.4f);}
    private TextView destructive(String label,String icon,boolean warning,Runnable action){TextView b=actionButton(label,icon,false,action);String level=warning?"WARNING":"ERROR";int color=severityColor(level);b.setTextColor(color);setIcon(b,icon,color);b.setBackground(a.background(severityFill(level),12,1,severityBorder(level)));return b;}
    private void append(LinearLayout parent,View v,int gap){LayoutParams p=new LayoutParams(-1,-2);p.topMargin=dp(gap);parent.addView(v,p);}
    private void pair(LinearLayout r,View first,View second){r.addView(first,new LayoutParams(0,-2,1));LayoutParams p=new LayoutParams(0,-2,1);p.setMarginStart(dp(6));r.addView(second,p);}
    private LinearLayout chipStrip(LinearLayout parent){HorizontalScrollView s=new HorizontalScrollView(activity);s.setHorizontalScrollBarEnabled(false);LinearLayout r=row();s.addView(r);append(parent,s,8);return r;}
    private void chips(){
        categoryChips.removeAllViews();severityChips.removeAllViews();
        for(int i=0;i<CATEGORIES.length;i++){
            String cat=CATEGORIES[i];int count=0;for(JSONObject event:logs)if("ALL".equals(cat)||cat.equals(event.optString("category")))count++;
            boolean active=cat.equals(category); LinearLayout chip=row();chip.setPadding(dp(12),0,dp(12),0);chip.setBackground(a.background(active?0xff0b5fa8:subtle,12,1,active?0xff0b5fa8:border));
            chip.addView(text(english?CATEGORY_EN[i]:CATEGORY_KU[i],11,active?Color.WHITE:ink,700));TextView n=pill(String.valueOf(count),active?Color.WHITE:muted,active?0x33ffffff:light?0xffe2e8f0:0x1affffff);LayoutParams np=new LayoutParams(-2,-2);np.setMarginStart(dp(6));chip.addView(n,np);chip.setSelected(active);chip.setOnClickListener(v->{category=cat;limit=PAGE_SIZE;filter();chips();});LayoutParams lp=new LayoutParams(-2,dp(32));lp.setMarginEnd(dp(6));categoryChips.addView(chip,lp);
        }
        for(String sev:SEVERITIES){boolean active=sev.equals(severity);TextView b=button(sev,false,()->{severity=sev;limit=PAGE_SIZE;filter();chips();});b.setTextSize(10.5f);b.setMinHeight(0);b.setPadding(dp(10),0,dp(10),0);b.setTextColor(active?Color.WHITE:"ALL".equals(sev)?ink:severityColor(sev));b.setBackground(a.background(active?0xff0ea5e9:"ALL".equals(sev)?subtle:severityFill(sev),8,1,active?0xff0ea5e9:"ALL".equals(sev)?border:severityBorder(sev)));b.setSelected(active);LayoutParams lp=new LayoutParams(-2,dp(28));lp.setMarginEnd(dp(6));severityChips.addView(b,lp);}
    }
    private void manualRefresh(){reload();notice(tr("Refreshed (","نوێکرایەوە (")+logs.size()+tr(" saved reports)."," ڕاپۆرتی هەڵگیراو)."));}
    private void reload(){logs.clear();searchIndex.clear();try{JSONArray values=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]"));for(int i=0;i<values.length();i++){JSONObject e=values.optJSONObject(i);if(e!=null){logs.add(e);searchIndex.put(id(e),searchText(e));}}}catch(Exception ignored){}selected.retainAll(ids(logs));expanded.retainAll(ids(logs));chips();filter();}
    private void filter(){removeCallbacks(delayedFilter);filtered.clear();String q=query.trim().toLowerCase(Locale.ROOT);for(JSONObject e:logs){if(!"ALL".equals(category)&&!category.equals(e.optString("category")))continue;if(!"ALL".equals(severity)&&!severity.equals(e.optString("severity")))continue;if(!q.isEmpty()&&!searchable(e).contains(q))continue;filtered.add(e);}refreshCards();}
    private String searchable(JSONObject e){String value=searchIndex.get(id(e));return value==null?searchText(e):value;}
    private String searchText(JSONObject e){StringBuilder out=new StringBuilder();for(String field:new String[]{"id","title","description","component","operation","status","category","severity","errorMessage","operationId","metadata"})out.append(e.optString(field)).append(' ');return out.toString().toLowerCase(Locale.ROOT);}
    private String id(JSONObject event){return event.optString("id");}
    private Set<String> ids(List<JSONObject> events){Set<String> ids=new HashSet<>();for(JSONObject e:events)ids.add(id(e));return ids;}
    private List<JSONObject> chosen(){List<JSONObject> result=new ArrayList<>();for(JSONObject event:logs)if(selected.contains(id(event)))result.add(event);return result;}
    private boolean hasActiveFilter(){return !"ALL".equals(category)||!"ALL".equals(severity)||!query.trim().isEmpty();}
    private void resetFilters(){category="ALL";severity="ALL";query="";search.setText("");limit=PAGE_SIZE;chips();filter();}
    private void refreshCards(){
        enabled(copyAllButton,!logs.isEmpty());enabled(copyFilteredButton,!filtered.isEmpty());enabled(shareButton,!logs.isEmpty());enabled(exportButton,!logs.isEmpty());
        categoryActions.removeAllViews();categoryActions.setVisibility(logs.isEmpty()?GONE:VISIBLE);
        TextView clearAll=destructive(tr("Clear All Reports","سڕینەوەی هەموو ڕاپۆرتەکان"),"trash_2",false,()->confirmDelete(ids(logs)));
        if(!"ALL".equals(category)){Set<String> targets=new HashSet<>();for(JSONObject event:logs)if(category.equals(event.optString("category")))targets.add(id(event));if(!targets.isEmpty()){TextView clearCat=destructive(tr("Clear ","پاککردنەوەی بەشی ")+category,"trash_2",true,()->confirmDelete(targets));pair(categoryActions,clearCat,clearAll);}else categoryActions.addView(clearAll,new LayoutParams(-2,dp(32)));}else categoryActions.addView(clearAll,new LayoutParams(-2,dp(32)));
        summary.setText(logs.size()+tr(" saved · "," تۆمار هەڵگیراوە · ")+filtered.size()+tr(" matching"," پیشاندراوە"));selectButton.setText(tr("Select","هەڵبژاردن"));selectButton.setTextSize(11);selectButton.setBackground(a.background(selecting?0xff0b5fa8:subtle,12,1,selecting?0xff0b5fa8:border));selectButton.setTextColor(selecting?Color.WHITE:ink);setIcon(selectButton,"logs_checked",selecting?Color.WHITE:ink);
        selectionActions.removeAllViews();selectionActions.setVisibility(selecting?VISIBLE:GONE);if(selecting){selectionActions.setPadding(dp(10),dp(10),dp(10),dp(10));selectionActions.setBackground(a.background(light?0xfff0f9ff:0xff0c1a2b,16,1,light?0xffbae6fd:0x4d0ea5e9));LinearLayout r=row();TextView selectAll=button(!filtered.isEmpty()&&selected.equals(ids(filtered))?tr("Deselect All","لابردنی هەمووی"):tr("Select All (","هەڵبژاردنی هەمووی (")+filtered.size()+")",false,()->{Set<String> all=ids(filtered);boolean allSelected=selected.equals(all);selected.clear();if(!allSelected)selected.addAll(all);refreshCards();});r.addView(selectAll,new LayoutParams(-2,dp(32)));TextView selectedCount=text(selected.size()+tr(" selected"," هەڵبژێردراو"),11,ink,700);selectedCount.setPadding(dp(8),0,0,0);r.addView(selectedCount);append(selectionActions,r,0);r=row();TextView delete=actionButton(tr("Delete Selected","سڕینەوەی هەڵبژێردراو"),"trash_2",true,()->confirmDelete(new HashSet<>(selected)));delete.setBackground(a.background(0xffe11d48,12,0,0));enabled(delete,!selected.isEmpty());pair(r,delete,button(tr("Done","تەواو"),false,()->{selecting=false;selected.clear();cancelConfirmation();refreshCards();}));append(selectionActions,r,8);}
        cards.removeAllViews();if(filtered.isEmpty()){LinearLayout empty=column();empty.setPadding(dp(22),dp(28),dp(22),dp(28));empty.setBackground(a.background(surface,24,1,border));TextView heading=text(logs.isEmpty()?tr("No Activity Reports Recorded Yet","هێشتا هیچ ڕاپۆرتێک تۆمار نەکراوە"):tr("No Matching Reports Found","هیچ ڕاپۆرتێک بەپێی ئەم فلتەرە نەدۆزرایەوە"),14,ink,800);heading.setGravity(Gravity.CENTER);empty.addView(heading);TextView info=text(logs.isEmpty()?tr("Application operations, network activity, storage events, warnings, and errors are recorded silently here.","چالاکییەکانی بەرنامە، تۆڕ، بیرگە، ئاگادارکردنەوە و هەڵەکان بە بێدەنگی لێرەدا تۆمار دەکرێن."):tr("Try clearing your search or switching filters.","گەڕانەکە پاک بکەرەوە یان فلتەرەکان بگۆڕە."),12,muted,400);info.setGravity(Gravity.CENTER);append(empty,info,8);if(hasActiveFilter())append(empty,button(tr("Reset Filters","پاککردنەوەی فلتەرەکان"),true,this::resetFilters),8);append(cards,empty,0);return;}for(int i=0;i<Math.min(limit,filtered.size());i++)addCard(filtered.get(i));if(limit<filtered.size())append(cards,button(tr("Load More (","پیشاندانی زیاتر (")+(filtered.size()-limit)+tr(" remaining)"," ماوە)"),false,()->{limit+=PAGE_SIZE;refreshCards();}),8);}
    private int severityColor(String s){switch(s){case "CRITICAL":return light?0xff991b1b:0xfffca5a5;case "ERROR":return light?0xffbe123c:0xfffda4af;case "WARNING":return light?0xff92400e:0xfffcd34d;case "SUCCESS":return light?0xff065f46:0xff6ee7b7;case "INFO":return light?0xff0369a1:0xff7dd3fc;default:return muted;}}
    private int severityFill(String s){switch(s){case "CRITICAL":return light?0xfffee2e2:0x33ef4444;case "ERROR":return light?0xffffe4e6:0x33f43f5e;case "WARNING":return light?0xfffef3c7:0x33f59e0b;case "SUCCESS":return light?0xffd1fae5:0x3310b981;case "INFO":return light?0xffe0f2fe:0x330ea5e9;default:return subtle;}}
    private int severityBorder(String s){switch(s){case "CRITICAL":return light?0xfffca5a5:0x66ef4444;case "ERROR":return light?0xfffda4af:0x59f43f5e;case "WARNING":return light?0xfffcd34d:0x59f59e0b;case "SUCCESS":return light?0xff6ee7b7:0x5910b981;case "INFO":return light?0xff7dd3fc:0x590ea5e9;default:return light?0xffcbd5e1:0x66666b75;}}
    private TextView pill(String value,int color,int fill){TextView tag=text(value,10,color,800);tag.setGravity(Gravity.CENTER);tag.setPadding(dp(6),dp(3),dp(6),dp(3));tag.setBackground(a.background(fill,6,0,0));return tag;}
    private void addCard(JSONObject e){
        String key=id(e);boolean open=expanded.contains(key);boolean checked=selected.contains(key);
        LinearLayout card=column();card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackground(a.background(surface,16,checked?2:1,checked?0xff38bdf8:border));
        LinearLayout top=row();top.setGravity(Gravity.TOP);card.addView(top);
        if(selecting){ImageView check=iconButton(checked?"logs_checked":"logs_square",tr("Select event","هەڵبژاردنی ڕووداو"),()->{if(!selected.add(key))selected.remove(key);refreshCards();});check.setSelected(checked);top.addView(check,new LayoutParams(dp(24),dp(28)));}
        LinearLayout words=column();top.addView(words,new LayoutParams(0,-2,1));
        LinearLayout tags=row();tags.setLayoutDirection(LAYOUT_DIRECTION_LTR);String sev=e.optString("severity");int sevColor=severityColor(sev);
        TextView severityTag=pill(sev,sevColor,severityFill(sev));severityTag.setBackground(a.background(severityFill(sev),6,1,severityBorder(sev)));tags.addView(severityTag);LayoutParams catLp=new LayoutParams(-2,-2);catLp.setMarginStart(dp(6));tags.addView(pill(e.optString("category"),muted,subtle),catLp);words.addView(tags);
        if(e.has("httpStatus")||e.has("durationMs")){LinearLayout metrics=row();metrics.setLayoutDirection(LAYOUT_DIRECTION_LTR);if(e.has("httpStatus"))metrics.addView(pill("HTTP "+e.optString("httpStatus"),severityColor(e.optInt("httpStatus")>=400?"ERROR":"SUCCESS"),subtle));if(e.has("durationMs")){TextView duration=text(e.optString("durationMs")+"ms",10,muted,400);duration.setTypeface(android.graphics.Typeface.MONOSPACE);duration.setPadding(dp(6),0,0,0);metrics.addView(duration);}append(words,metrics,3);}
        TextView title=text(e.optString("title"),12,ink,800);title.setTextDirection(TEXT_DIRECTION_LTR);title.setGravity(Gravity.LEFT);append(words,title,6);
        String description=e.optString("description");if(!description.isEmpty()){TextView desc=text(description,11,muted,400);desc.setTextDirection(TEXT_DIRECTION_LTR);desc.setGravity(Gravity.LEFT);desc.setMaxLines(2);desc.setEllipsize(TextUtils.TruncateAt.END);append(words,desc,4);}
        TextView meta=text(time(e)+" · "+e.optString("component")+" · "+e.optString("status"),11,muted,400);meta.setTextDirection(TEXT_DIRECTION_LTR);meta.setGravity(Gravity.LEFT);meta.setTypeface(android.graphics.Typeface.MONOSPACE);meta.setTextSize(10.5f);append(words,meta,4);
        Runnable toggle=()->{if(!expanded.add(key))expanded.remove(key);refreshCards();};words.setOnClickListener(v->toggle.run());ImageView chevron=iconButton("chevron_down",open?tr("Collapse details","داخستنی وردەکاری"):tr("Expand details","کردنەوەی وردەکاری"),toggle);chevron.setRotation(open?180:0);top.addView(chevron,new LayoutParams(dp(24),dp(28)));
        if(open){LinearLayout detail=column();detail.setLayoutDirection(LAYOUT_DIRECTION_LTR);detail.setPadding(dp(10),dp(10),dp(10),dp(10));detail.setBackground(a.background(subtle,12,1,border));
            for(String[] field:new String[][]{{"Event ID","id"},{"Time (ISO)","timestamp"},{"Component","component"},{"Operation","operation"},{"Status","status"},{"App Version","appVersion"},{"Platform","platform"},{"OS Version","osVersion"},{"Operation ID","operationId"},{"Related Event","relatedEventId"}}){String value=e.optString(field[1]);if(!value.isEmpty()){TextView line=text(field[0]+": "+value,11,ink,400);line.setTextIsSelectable(true);append(detail,line,4);}}
            for(String[] field:new String[][]{{"Error Message","errorMessage"},{"Sanitized Metadata","metadata"},{"Stack Trace","stackTrace"}}){String value=e.isNull(field[1])?"":e.optString(field[1]);if("metadata".equals(field[1])){JSONObject metaObject=e.optJSONObject("metadata");StringBuilder formatted=new StringBuilder();if(metaObject!=null){java.util.Iterator<String> keys=metaObject.keys();while(keys.hasNext()){String keyName=keys.next();formatted.append(keyName).append(": ").append(metaObject.opt(keyName)).append('\n');}}value=formatted.toString().trim();}if(value.isEmpty())continue;TextView label=text(field[0],10,field[1].equals("errorMessage")?severityColor("ERROR"):field[1].equals("stackTrace")?severityColor("WARNING"):muted,800);append(detail,label,8);TextView block=text(value,11,ink,400);block.setTextIsSelectable(true);block.setTypeface(android.graphics.Typeface.MONOSPACE);append(detail,block,4);}
            append(card,detail,10);LinearLayout actions=row();TextView copy=actionButton(tr("Copy Report","کۆپیکردنی ڕاپۆرت"),"logs_copy",true,()->copy(java.util.Collections.singletonList(e),null,true));TextView delete=destructive(tr("Delete","سڕینەوە"),"trash_2",false,()->confirmDelete(java.util.Collections.singleton(key)));pair(actions,copy,delete);append(card,actions,8);
        }append(cards,card,10);
    }
    private String time(JSONObject e){long epoch=e.optLong("epochMs",0);return epoch>0?new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(epoch)):e.optString("timestamp");}
    private String filterScope(){return "Category="+category+", Severity="+severity+(query.trim().isEmpty()?"":", Search=\""+query.trim()+"\"");}
    private String report(List<JSONObject> events,String scope,boolean single){String version="unknown";try{version=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName;}catch(Exception ignored){}return NativeActivityReport.format(events,scope,single,version,"Android",android.os.Build.VERSION.RELEASE,new Date());}
    private void clearNotice(){removeCallbacks(dismissNotice);noticeArea.removeAllViews();noticeArea.setVisibility(GONE);}
    private void notice(String message){notice(message,"SUCCESS",null);}
    private void notice(String message,String tone,String payload){clearNotice();noticeArea.setVisibility(VISIBLE);LinearLayout box=column();box.setPadding(dp(12),dp(12),dp(12),dp(12));box.setBackground(a.background(severityFill(tone),16,1,severityBorder(tone)));LinearLayout strip=row();ImageView icon=new ImageView(activity);icon.setImageDrawable(a.icon("check",severityColor(tone),16));strip.addView(icon,new LayoutParams(dp(16),dp(16)));TextView messageView=text(message,12,severityColor(tone),700);messageView.setPadding(dp(8),0,dp(8),0);strip.addView(messageView,new LayoutParams(0,-2,1));strip.addView(iconButton("logs_close",tr("Dismiss message","داخستنی پەیام"),this::clearNotice),new LayoutParams(dp(28),dp(28)));box.addView(strip);if(payload!=null){LinearLayout actions=row();pair(actions,actionButton(tr("Export .txt File","دابەزاندنی فایل (.txt)"),"logs_download",false,()->activity.exportActivityReport(payload)),actionButton(tr("Share","هاوبەشکردن"),"logs_share",false,()->shareText(payload)));append(box,actions,8);}else postDelayed(dismissNotice,3800);append(noticeArea,box,12);}
    private boolean hasEvents(List<JSONObject> e){if(!e.isEmpty())return true;notice(tr("No reports available.","هیچ ڕاپۆرتێک نییە."),"WARNING",null);return false;}
    private void copy(List<JSONObject> e,String scope,boolean single){if(!hasEvents(e))return;String report=report(e,scope,single);if(report.length()>180000){notice(tr("Report batch exceeds safe clipboard size. Use Export (.txt) or Share below.","قەبارەی ڕاپۆرتەکان زۆر گەورەیە بۆ کۆپیکردن. تکایە دابەزاندن یان هاوبەشکردن بەکاربهێنە."),"WARNING",report);return;}try{((ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Activity report",report));notice(tr("Copied report","ڕاپۆرت کۆپی کرا"));}catch(Exception ex){notice(tr("Copy failed","کۆپیکردن سەرکەوتوو نەبوو"),"ERROR",null);}}
    private void share(List<JSONObject> e){if(hasEvents(e))shareText(report(e,hasActiveFilter()?filterScope():"All Saved Reports",false));}
    private void shareText(String report){if(report.length()>180000){activity.exportActivityReport(report);return;}try{activity.startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,report),tr("Share report","هاوبەشکردنی ڕاپۆرت")));notice(tr("Opened Android share sheet.","پەنجەرەی هاوبەشکردنی ئەندرۆید کرایەوە."));}catch(Exception ex){activity.exportActivityReport(report);}}
    private void export(List<JSONObject> e){if(hasEvents(e))activity.exportActivityReport(report(e,hasActiveFilter()?filterScope():"All Saved Reports",false));}
    private void confirmDelete(Set<String> targets){
        if(targets.isEmpty()){notice(tr("No reports selected","هیچ ڕاپۆرتێک هەڵنەبژێردراوە"));return;}
        Set<String> snapshot=new HashSet<>(targets);confirmArea.removeAllViews();confirmArea.setVisibility(VISIBLE);LinearLayout box=column();box.setPadding(dp(14),dp(12),dp(14),dp(12));box.setBackground(a.background(light?0xfffff1f2:0x33be123c,16,1,0xffbe123c));
        String message=tr("Permanently delete ","دڵنیایت لە سڕینەوەی ")+snapshot.size()+tr(" report(s)?"," ڕاپۆرت؟");if(snapshot.size()==1){for(JSONObject event:logs)if(snapshot.contains(id(event))){message=tr("Delete report \"","دڵنیایت لە سڕینەوەی ڕاپۆرتی \"")+event.optString("title")+tr("\" permanently?","\"؟");break;}}box.addView(text(message,12,severityColor("ERROR"),800));LinearLayout actions=row();TextView yes=button(tr("Confirm Delete","بەڵێ، بیسڕەوە"),true,()->deleteConfirmed(snapshot));yes.setBackground(a.background(0xffbe123c,12,0,0));pair(actions,yes,button(tr("Cancel","پاشگەزبوونەوە"),false,this::cancelConfirmation));append(box,actions,10);append(confirmArea,box,12);
        confirmArea.post(()->confirmArea.requestRectangleOnScreen(new android.graphics.Rect(0,0,confirmArea.getWidth(),Math.max(confirmArea.getHeight(),dp(110))),false));
    }
    private void deleteConfirmed(Set<String> targets){try{synchronized(MainActivity.class){JSONArray existing=new JSONArray(prefs.getString(MainActivity.DIAG_LOGS_KEY,"[]")),keep=new JSONArray();for(int i=0;i<existing.length();i++){JSONObject e=existing.optJSONObject(i);if(e==null||!targets.contains(id(e)))keep.put(existing.get(i));}prefs.edit().putString(MainActivity.DIAG_LOGS_KEY,keep.toString()).apply();}selected.removeAll(targets);expanded.removeAll(targets);if(selecting&&selected.isEmpty())selecting=false;cancelConfirmation();removeCallbacks(delayedReload);reload();notice(tr("Reports deleted","ڕاپۆرتەکان سڕانەوە"));}catch(Exception ex){notice(tr("Delete failed","سڕینەوە سەرکەوتوو نەبوو"),"ERROR",null);}}
}
