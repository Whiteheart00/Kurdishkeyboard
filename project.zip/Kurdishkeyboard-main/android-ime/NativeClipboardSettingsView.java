package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.IOException;

final class NativeClipboardSettingsView extends LinearLayout {
    interface Change { void accept(String key, Object value); }

    private static final String[][] SWITCHES = {
        {"clipboardEnabled", "بەشی لەبەرگیراوەکان", "بەکارهێنانی بەشی لەبەرگیراوەکان بۆ هەڵگرتنی شتەکان", "ic_clipboards"},
        {"clipboardHistoryEnabled", "مێژووی لەبەرگیراوەکان", "هێشتنەوە و ڕێکخستنی لەبەرگیراوەکان", "ic_history1"},
        {"clipboardSuggestLatest", "پێشنیارکردنی دوایین لەبەرگیراوەکان", "پێشنیارکردنی ئەو دەق یان وێنانەی پێشتر کۆپی کراون", "ic_smart"},
        {"clipboardSuggestLimit60s", "سنووردارکردنی پێشنیارەکان", "ئەو شتانەی لە 60 چرکەی ڕابردوودا کۆپی کراون", "ic_history1"},
        {"clipboardAutoDeleteOld", "سڕینەوەی لەبەرگیراوە کۆنەکان", "سڕینەوەی خۆکاری دوای ٢٠ خولەک", "ic_trash"},
        {"clipboardHideOnPaste", "داخستنی پانێڵ دوای لکاندن", "گەڕانەوەی خۆکار بۆ پیتەکان ڕاستەوخۆ دوای لکاندنی هەر لەبەرگیراوێک", "ic_pastes"},
        {"captureHiddenClipboard", "تۆمارکردنی خۆکاری کۆپی", "کاتێک کیبۆرد داخراوە، دەقە کۆپیکراوەکان لە مێژووی ناوخۆیی هەڵدەگیرێن. تەنها کاتێک ئەم کیبۆردە سەرەکییە؛ دەقی هەستیار فلتەر دەکرێت.", "ic_history1"},
    };

    private final NativeImeAppearance appearance;
    private final String font;
    private final int foreground;
    private final Change change;

    NativeClipboardSettingsView(Context context, String theme, String font, JSONObject data, Runnable back, Change change) {
        super(context);
        this.font = font;
        this.change = change;
        NativeImeEngine icons = null;
        try { icons = new NativeImeEngine(context); } catch (IOException ignored) { }
        appearance = new NativeImeAppearance(context, icons);
        boolean light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("لەبەرگیراوەکان", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        divider(this, light ? 0xffe2e8f0 : 0x0dffffff);

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(20));
        scroll.addView(body);
        if (!data.optBoolean("notificationsEnabled")) addNotification(body);
        for (int i = 0; i < SWITCHES.length; i++) {
            String[] entry = SWITCHES[i];
            LinearLayout row = row();
            if (icons != null) addIcon(row, entry[3]);
            LinearLayout copy = column();
            LinearLayout caption = row();
            caption.addView(label(entry[1], 14, foreground, 700), new LayoutParams(0, -2, 1));
            if ((i == 3 || i == 4) && !data.optBoolean("proUnlocked")) {
                TextView badge = appearance.text("PRO", 10, Color.WHITE, "system", 800);
                badge.setPadding(dp(6), dp(2), dp(6), dp(2));
                badge.setBackground(appearance.background(0xff465bcb, 6, 0, 0));
                caption.addView(badge);
            }
            copy.addView(caption);
            copy.addView(label(entry[2], 12, 0xffa1a1aa, 400));
            LayoutParams copyPosition = new LayoutParams(0, -2, 1);
            copyPosition.setMarginEnd(dp(12));
            row.addView(copy, copyPosition);
            FrameLayout toggle = new FrameLayout(context);
            toggle.setLayoutDirection(LAYOUT_DIRECTION_LTR);
            toggle.setContentDescription(entry[1]);
            toggle.setFocusable(true);
            View knob = new View(context);
            toggle.addView(knob);
            paintToggle(toggle, knob, data.optBoolean(entry[0], i == 5));
            toggle.setOnClickListener(v -> {
                boolean checked = !toggle.isSelected();
                paintToggle(toggle, knob, checked);
                change.accept(entry[0], checked);
            });
            row.addView(toggle, new LayoutParams(dp(52), dp(30)));
            append(body, row, i == 0 && data.optBoolean("notificationsEnabled") ? 0 : 20);
        }
        addOptions(body, "clipboardGridColumns", "ژمارەی ستوونەکان", new int[]{1, 2},
                data.optInt("clipboardGridColumns", 2), icons == null ? null : "ic_clipboards");
        addOptions(body, "clipboardMaxItems", "زۆرترین ڕێژەی هەڵگرتن", new int[]{10, 20, 40},
                data.optInt("clipboardMaxItems", 20), icons == null ? null : "ic_number");
        if (icons != null) icons.close();
    }

    private void addNotification(LinearLayout body) {
        LinearLayout banner = column();
        banner.setPadding(dp(20), dp(20), dp(20), dp(20));
        banner.setBackground(appearance.background(0xffb71c1c, 24, 0, 0));
        banner.addView(appearance.text("ئاگادارکردنەوە کوژاوەتەوە", 18, Color.WHITE, font, 800));
        append(banner, appearance.text("ئاگادارکردنەوەکان کارا بکە بۆ وەرگرتنی زانیاری لەکاتی بڵاوکردنەوەی ڕووکار، فۆنت و وەشانی نوێی بەرنامەکە!",
                12, 0xffffebee, font, 400), 10);
        TextView enable = appearance.text("کاراکردن", 14, Color.WHITE, font, 700);
        enable.setMinHeight(dp(44));
        enable.setBackground(appearance.background(0x33ffffff, 12, 1, 0x40ffffff));
        enable.setOnClickListener(v -> { banner.setVisibility(GONE); change.accept("notificationsEnabled", true); });
        append(banner, enable, 10);
        append(body, banner, 0);
    }

    private void paintToggle(FrameLayout toggle, View knob, boolean checked) {
        toggle.setSelected(checked);
        toggle.setBackground(appearance.background(checked ? 0xff9ac5ff : 0xff1d1f24, 15, checked ? 0 : 2, 0xff6c707a));
        int size = dp(checked ? 22 : 16);
        FrameLayout.LayoutParams position = new FrameLayout.LayoutParams(size, size, Gravity.CENTER_VERTICAL | (checked ? Gravity.RIGHT : Gravity.LEFT));
        position.setMargins(dp(5), 0, dp(5), 0);
        knob.setLayoutParams(position);
        knob.setBackground(appearance.background(checked ? 0xff0b3263 : 0xff8e939e, 12, 0, 0));
    }

    private void addOptions(LinearLayout body, String key, String title, int[] choices, int initial, String icon) {
        LinearLayout block = column();
        divider(block, 0x0dffffff);
        LinearLayout row = row();
        if (icon != null) addIcon(row, icon);
        LinearLayout copy = column();
        copy.addView(label(title, 14, foreground, 700));
        TextView status = label(optionText(key, initial), 12, 0xffa1a1aa, 400);
        copy.addView(status);
        row.addView(copy, new LayoutParams(0, -2, 1));
        LinearLayout options = row();
        options.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        for (int choice : choices) {
            TextView button = appearance.text(String.valueOf(choice), 12, foreground, "system", 700);
            button.setPadding(dp(12), 0, dp(12), 0);
            paintOption(button, choice == initial);
            button.setOnClickListener(v -> {
                for (int i = 0; i < options.getChildCount(); i++) paintOption((TextView) options.getChildAt(i), options.getChildAt(i) == button);
                status.setText(optionText(key, choice));
                change.accept(key, choice);
            });
            LayoutParams position = new LayoutParams(-2, dp(32));
            position.setMarginStart(dp(6));
            options.addView(button, position);
        }
        row.addView(options);
        append(block, row, 8);
        append(body, block, 20);
    }

    private String optionText(String key, int value) {
        if (!"clipboardGridColumns".equals(key)) return value + " دانە";
        return value == 1 ? "١ ستوون (فراوان)" : "٢ ستوون (تۆڕی)";
    }

    private void paintOption(TextView view, boolean selected) {
        view.setSelected(selected);
        view.setTextColor(selected ? 0xff051b3a : 0xffa1a1aa);
        view.setBackground(appearance.background(selected ? 0xffa4c9ff : 0xff18181b, 8, 0, 0));
    }

    private void addIcon(LinearLayout row, String name) {
        ImageView image = new ImageView(getContext());
        image.setImageDrawable(appearance.icon(name, 0xffa1a1aa, 20));
        LayoutParams position = new LayoutParams(dp(20), dp(20));
        position.setMarginEnd(dp(12));
        row.addView(image, position);
    }

    private TextView label(String text, int size, int color, int weight) {
        TextView view = appearance.text(text, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private void divider(LinearLayout parent, int color) {
        View divider = new View(getContext());
        divider.setBackgroundColor(color);
        parent.addView(divider, new LayoutParams(-1, dp(1)));
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams position = new LayoutParams(-1, -2);
        position.topMargin = dp(gap);
        parent.addView(child, position);
    }

    private int dp(int size) { return appearance.dp(size); }
    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }
    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }
}
