package io.kurdikebord.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import androidx.credentials.*;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Date;

/** Native opt-in cloud backup screen. No account credentials are collected by keyboard code. */
public final class NativeFirebaseBackupActivity extends Activity {
    private int fg,muted,card,background,blue;private boolean light,busy;
    private LinearLayout content;private TextView account,status;private CheckBox pinned,auto;
    private Button signIn,signOut,save,restore,delete,stop;
    private NativeImeAppearance appearance;private String font;private CancellationSignal cancellation;
    @Override public void onCreate(Bundle state){
        org.json.JSONObject settings=ImeStateStore.effectiveSettings(this,ImeStateStore.read(this));
        light="light".equals(settings.optString("appTheme"));font=settings.optString("fontStyle","system");
        if(light)setTheme(android.R.style.Theme_Material_Light_NoActionBar);super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);appearance=new NativeImeAppearance(this,null);
        fg=light?0xff172033:Color.WHITE;muted=light?0xff526173:0xffa1a1aa;card=light?Color.WHITE:0xff17181c;background=light?0xfff8fafc:0xff090a0c;blue=light?0xff0965b5:0xffa4c9ff;
        getWindow().setStatusBarColor(background);getWindow().setNavigationBarColor(background);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(background);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);content.setPadding(dp(16),dp(12),dp(16),dp(24));scroll.addView(content);setContentView(scroll);
        button("→  گەڕانەوە",false,()->finish());content.addView(text("Firebase · پاشەکەوتی Cloud",20,blue));
        content.addView(text("داتا لە Firebase هەڵدەگیرێت و پێش ناردن شفرە دەکرێت.",13,muted));
        account=text("",15,fg);content.addView(account);signIn=button("بەستنەوەی هەژماری Google",true,()->signIn());signOut=button("جیاکردنەوەی هەژمار",false,()->signOut());
        content.addView(text("ڕێکخستن، زمان، ڕووکار، ئیمۆجییە دڵخوازەکان و مێژوویان",15,fg));
        pinned=new CheckBox(this);pinned.setText("Clipboard ـی پینکراو لە پاشەکەوتدا بێت");pinned.setTextColor(fg);pinned.setButtonTintList(ColorStateList.valueOf(blue));content.addView(pinned);
        content.addView(text("تەنها دەقە پینکراوەکان بە ڕەزامەندی خۆت. ئەگەر پاشەکەوتی خۆکار چالاک بێت، دەقە پینکراوە نوێکانیش دەنێردرێن. وشەی نهێنی و داتای بانکی پین مەکە. هەموو Clipboard و وشە فێربووەکان نانێردرێن.",13,muted));
        auto=new CheckBox(this);auto.setText("پاشەکەوتی خۆکار (ڕۆژانە)");auto.setTextColor(fg);auto.setButtonTintList(ColorStateList.valueOf(blue));content.addView(auto);
        content.addView(text("بۆ چالاککردن یان گۆڕینی بژاردەکان، پاشەکەوتی ئێستا بکە. Android کاتی ورد دیاری دەکات؛ ئینتەرنێت و باتری پێویستن.",13,muted));
        save=button("ئێستا پاشەکەوتی بکە",true,()->beginSave());restore=button("گەڕاندنەوە لە Cloud",false,()->beginRestore());stop=button("ناچالاککردنی پاشەکەوتی خۆکار",false,()->{NativeFirebaseBackup.stop(this);refresh(true);message("پاشەکەوتی خۆکار ناچالاک کرا.");});
        delete=button("سڕینەوەی پاشەکەوتی Cloud",false,()->confirmDelete());status=text("",14,blue);content.addView(status);
        refresh(true);
        auto.setOnClickListener(v->{if(!auto.isChecked()&&NativeFirebaseBackup.automatic(this)){NativeFirebaseBackup.stop(this);refresh(true);message("پاشەکەوتی خۆکار ناچالاک کرا.");}});
        pinned.setOnClickListener(v->{if(!pinned.isChecked()&&NativeFirebaseBackup.automatic(this)&&(NativeFirebaseBackup.prefs(this).getInt("mask",0)&NativeCloudBackup.PINNED)!=0){NativeFirebaseBackup.stop(this);auto.setChecked(false);message("پاشەکەوتی خۆکار وەستێنرا؛ پاشەکەوتی نوێ بەبێ Clipboard دروست بکە.");}});
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color){TextView t=appearance.text(s,size,color,font,500);t.setPadding(dp(6),dp(8),dp(6),dp(8));return t;}
    private Button button(String label,boolean primary,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(primary?(light?Color.WHITE:0xff062c55):fg);GradientDrawable bg=new GradientDrawable();bg.setColor(primary?blue:card);bg.setCornerRadius(dp(14));b.setBackground(bg);b.setOnClickListener(v->action.run());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(9);content.addView(b,lp);return b;}
    private void refresh(boolean reset){NativeFirebaseRest.User u=NativeFirebaseBackup.user(this);boolean signed=u!=null,ready=signed&&android.os.Build.VERSION.SDK_INT>=26;
        boolean enabled=ready&&NativeFirebaseBackup.automatic(this);String uid=signed?u.getUid():"";
        long last=NativeFirebaseBackup.associated(this,uid)?NativeFirebaseBackup.prefs(this).getLong("last",0):0;
        account.setText((signed?"هەژمار: "+(u.getEmail()==null?"Google":u.getEmail()):"هێشتا هەژمار نەبەستراوەتەوە")+"\n"+(enabled?"پاشەکەوتی خۆکار چالاکە":"پاشەکەوتی خۆکار ناچالاکە")+(last>0?"\nدوا پاشەکەوت/گەڕاندنەوە: "+DateFormat.getDateTimeInstance().format(new Date(last)):""));
        if(reset){auto.setChecked(enabled);pinned.setChecked(NativeFirebaseBackup.associated(this,uid)&&(NativeFirebaseBackup.prefs(this).getInt("mask",0)&NativeCloudBackup.PINNED)!=0);}
        signIn.setEnabled(!busy&&!signed&&android.os.Build.VERSION.SDK_INT>=26);signOut.setEnabled(!busy&&signed);save.setEnabled(!busy&&ready);restore.setEnabled(!busy&&ready);delete.setEnabled(!busy&&ready);stop.setEnabled(!busy&&enabled);auto.setEnabled(!busy&&ready);pinned.setEnabled(!busy&&ready);
        if(!busy&&android.os.Build.VERSION.SDK_INT<26)message("پاشەکەوتی شفرەکراو Android 8 یان نوێتر دەوێت.");
    }
    private void message(String s){if(status!=null&&!isDestroyed()&&!isFinishing())status.setText(s);}
    private void busy(boolean value){busy=value;refresh(false);}
    private void finishWork(String message){if(isDestroyed()||isFinishing())return;busy=false;refresh(true);message(message);}
    private void signIn(){if(busy)return;busy(true);cancellation=new CancellationSignal();try{
        GetSignInWithGoogleOption option=new GetSignInWithGoogleOption.Builder(getString(R.string.default_web_client_id)).build();
        GetCredentialRequest request=new GetCredentialRequest.Builder().addCredentialOption(option).build();
        CredentialManager.create(this).getCredentialAsync(this,request,cancellation,this::runOnUiThread,new CredentialManagerCallback<GetCredentialResponse,GetCredentialException>(){
            @Override public void onResult(GetCredentialResponse response){try{
                Credential cred=response.getCredential();if(!(cred instanceof CustomCredential)||!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(cred.getType()))throw new IllegalStateException();
                String token=GoogleIdTokenCredential.createFrom(cred.getData()).getIdToken();
                NativeFirebaseBackup.WORK.execute(()->{boolean ok=false;try{
                    NativeFirebaseRest.signIn(NativeFirebaseBackupActivity.this,token);
                    if(!NativeFirebaseBackup.associated(NativeFirebaseBackupActivity.this,NativeFirebaseBackup.uid(NativeFirebaseBackupActivity.this)))NativeFirebaseBackup.clear(NativeFirebaseBackupActivity.this);
                    ok=true;
                }catch(Exception ignored){}final boolean success=ok;runOnUiThread(()->finishWork(success?"هەژمار بەستراوەتەوە. بۆ پاشەکەوتکردن یان گەڕاندنەوە دوگمەکە هەڵبژێرە.":"چوونەژوورەوە سەرکەوتوو نەبوو. SHA-1 و ڕێکخستنی Firebase بپشکنە."));});
            }catch(Exception ex){finishWork("ناسینەوەی هەژمار سەرکەوتوو نەبوو.");}}
            @Override public void onError(GetCredentialException error){finishWork("هەژمار نەبەستراوەتەوە. Google Play services و ئینتەرنێت بپشکنە.");}
        });
    }catch(Exception e){finishWork("بەستنەوەی هەژمار سەرکەوتوو نەبوو.");}}
    private void signOut(){
        if(busy)return;busy(true);NativeFirebaseBackup.stop(this);
        NativeFirebaseBackup.WORK.execute(()->{NativeFirebaseBackup.clear(this);NativeFirebaseRest.signOut(this);runOnUiThread(()->{
            if(isDestroyed()||isFinishing())return;
            try{CredentialManager.create(this).clearCredentialStateAsync(new ClearCredentialStateRequest(),null,this::runOnUiThread,new CredentialManagerCallback<Void,androidx.credentials.exceptions.ClearCredentialException>(){public void onResult(Void ignored){}public void onError(androidx.credentials.exceptions.ClearCredentialException ignored){}});}catch(Exception ignored){}
            finishWork("هەژمار جیا کرایەوە. داتای مۆبایل و Cloud ناسڕدرێنەوە.");
        });});
    }
    private interface PassAction{void run(char[] password);}
    private EditText field(){EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);e.setSaveEnabled(false);if(android.os.Build.VERSION.SDK_INT>=26){e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);e.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);}return e;}
    private char[] chars(EditText e){char[] a=new char[e.length()];e.getText().getChars(0,a.length,a,0);return a;}
    private void password(boolean confirm,PassAction action){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),0,dp(20),0);TextView hint=text("وشەی نهێنیی پاشەکەوت (لانیکەم ١٢ پیت). بەبێ ئەم وشەیە گەڕاندنەوە ناکرێت. لە Cloud هەڵناگیرێت.",13,muted);l.addView(hint);EditText first=field(),second=field();first.setHint("وشەی نهێنی");second.setHint("دووبارە");l.addView(first);if(confirm)l.addView(second);AlertDialog d=new AlertDialog.Builder(this).setTitle("شفرەکردنی Cloud").setView(l).setNegativeButton("پاشگەزبوونەوە",(a,b)->finishWork("هەڵوەشایەوە.")).setPositiveButton("بەردەوامبوون",null).create();d.setOnCancelListener(a->finishWork("هەڵوەشایەوە."));d.setOnDismissListener(a->{first.getText().clear();second.getText().clear();});d.show();d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{char[] p=chars(first),p2=chars(second);boolean ok=p.length>=12&&(!confirm||Arrays.equals(p,p2));Arrays.fill(p2,'\0');if(!ok){Arrays.fill(p,'\0');first.setError("وشەی نهێنی کەمە یان یەکسان نییە");return;}d.dismiss();action.run(p);});}
    private void beginSave(){if(busy)return;final boolean automatic=auto.isChecked();final boolean clips=pinned.isChecked();final int mask=NativeFirebaseBackup.BASIC|(clips?NativeCloudBackup.PINNED:0);final String uid=NativeFirebaseBackup.uid(NativeFirebaseBackupActivity.this);
        if(uid.isEmpty())return;busy(true);
        new AlertDialog.Builder(this).setTitle("پاشەکەوتی شفرەکراو").setMessage("هەموو بەشە دیاریکراوەکان لە Firebase هەڵدەگیرێن."+(clips?"\nClipboard ـی پینکراو تێدایە؛ تەنها ئەو دەقانە بنێرە کە دەتەوێت پاشەکەوت بکرێن.":"")+(automatic?"\nپاشەکەوتی ڕۆژانە چالاک دەبێت. کلیلی شفرە لە مۆبایلەکەت بە Android Keystore دەپارێزرێت.":"")).setNegativeButton("پاشگەزبوونەوە",(d,w)->finishWork("هەڵوەشایەوە.")).setOnCancelListener(d->finishWork("هەڵوەشایەوە.")).setPositiveButton("بەڵێ",(d,w)->password(true,pass->{message("پاشەکەوت دەکرێت…");NativeFirebaseBackup.WORK.execute(()->{String result;try{
            // Verify the existing passphrase before replacing a known cloud snapshot.
            String rev=NativeFirebaseBackup.revision(this,uid);if(!rev.isEmpty()){NativeFirebaseBackup.Download existing=NativeFirebaseBackup.download(this,uid,pass);if(existing==null||!rev.equals(existing.revision)){NativeFirebaseBackup.stop(this);throw new IllegalStateException("Conflict");}}
            NativeFirebaseBackup.stop(this);boolean ok=NativeFirebaseBackup.upload(this,uid,pass,mask,false);if(ok&&automatic)NativeFirebaseBackup.enable(this,uid,pass,mask);result=ok?"پاشەکەوت سەرکەوتوو بوو.":"پاشەکەوتی مۆبایلێکی تر هەیە؛ سەرەتا گەڕاندنەوە بکە.";
        }catch(Exception e){result="پاشەکەوت سەرکەوتوو نەبوو. وشەی نهێنی، ئینتەرنێت، یاساکان و قەبارەی داتا (750 KB) بپشکنە.";}finally{Arrays.fill(pass,'\0');}final String msg=result;runOnUiThread(()->finishWork(msg));});})).show();
    }
    private void beginRestore(){if(busy)return;String uid=NativeFirebaseBackup.uid(NativeFirebaseBackupActivity.this);if(uid.isEmpty())return;busy(true);password(false,pass->{message("خوێندنەوەی Cloud…");NativeFirebaseBackup.WORK.execute(()->{try{NativeFirebaseBackup.Download data=NativeFirebaseBackup.download(this,uid,pass);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;if(data==null){finishWork("پاشەکەوت نەدۆزرایەوە.");return;}new AlertDialog.Builder(this).setTitle("گەڕاندنەوەی پاشەکەوت").setMessage("ڕێکخستنەکان دەگۆڕدرێن. Clipboard ـی ئێستا ناسڕدرێتەوە، دەقە پینکراوەکان تێکەڵ دەکرێن. پاشەکەوتی خۆکار تا چالاککردنەوە ناچالاک دەبێت.").setNegativeButton("پاشگەزبوونەوە",(d,w)->finishWork("هەڵوەشایەوە.")).setOnCancelListener(d->finishWork("هەڵوەشایەوە.")).setPositiveButton("گەڕاندنەوە",(d,w)->NativeFirebaseBackup.WORK.execute(()->{boolean ok=false;try{ok=NativeFirebaseBackup.restore(this,uid,data);}catch(Exception ignored){}final boolean success=ok;runOnUiThread(()->{if(success)setResult(RESULT_OK);finishWork(success?"داتاکان گەڕێندرانەوە.":"گەڕاندنەوە سەرکەوتوو نەبوو.");});})).show();});}catch(Exception e){runOnUiThread(()->finishWork("وشەی نهێنی هەڵەیە یان Cloud بەردەست نییە."));}finally{Arrays.fill(pass,'\0');}});});}
    private void confirmDelete(){String uid=NativeFirebaseBackup.uid(NativeFirebaseBackupActivity.this);new AlertDialog.Builder(this).setTitle("سڕینەوەی پاشەکەوتی Cloud؟").setMessage("تەنها کۆپیی Firebase دەسڕدرێتەوە؛ داتای مۆبایل دەمێنێتەوە.").setNegativeButton("نەخێر",null).setPositiveButton("سڕینەوە",(d,w)->{busy(true);NativeFirebaseBackup.WORK.execute(()->{boolean ok=false;try{NativeFirebaseBackup.delete(this,uid);ok=true;}catch(Exception ignored){}final boolean success=ok;runOnUiThread(()->finishWork(success?"پاشەکەوت سڕایەوە.":"سڕینەوە سەرکەوتوو نەبوو."));});}).show();}
    @Override public void onBackPressed(){if(!busy)super.onBackPressed();}
    @Override protected void onDestroy(){if(cancellation!=null)cancellation.cancel();super.onDestroy();}
}
