package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Reads the previous APK's same-origin storage once, without starting its React app. */
final class ImeLegacyMigration {
    private static final String URL = "https://localhost/__native-ime-migration";
    private static ImeLegacyMigration active;

    static void start(Context context) {
        if (active != null || !ImeStateStore.unlocked(context) || ImeStateStore.read(context).optBoolean("legacyImported")) return;
        try {
            active = new ImeLegacyMigration(context.getApplicationContext());
            active.web.loadUrl(URL);
        } catch (IOException | RuntimeException e) {
            if (active != null) active.finish(null);
        }
    }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final WebView web;
    private final Runnable timeout = () -> finish(null);

    private ImeLegacyMigration(Context context) throws IOException {
        this.context = context;
        String script = NativeImeEngine.asset(context, "native-ime/migrate.js");
        web = new WebView(context);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new MigrationBridge(), "KurdiMigration");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                boolean match = request.isForMainFrame() && URL.equals(uri.toString());
                byte[] body = (match ? "<!doctype html><meta charset=utf-8>" : "").getBytes(StandardCharsets.UTF_8);
                return new WebResourceResponse("text/html", "UTF-8", match ? 200 : 404, match ? "OK" : "Not Found",
                        Collections.singletonMap("Content-Security-Policy", "default-src 'none'"), new ByteArrayInputStream(body));
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap icon) {
                if (!URL.equals(url)) finish(null);
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (active == ImeLegacyMigration.this && URL.equals(url)) view.evaluateJavascript(script, null);
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                finish(null);
                return true;
            }
        });
        main.postDelayed(timeout, 15000);
    }

    public final class MigrationBridge {
        @JavascriptInterface public String recoverySettings() { return NativeSettingsBackup.read(context); }
        @JavascriptInterface public void complete(String raw) { main.post(() -> finish(raw)); }
        @JavascriptInterface public void failed() { main.post(() -> finish(null)); }
    }

    private void finish(String raw) {
        if (active != this) return;
        active = null;
        main.removeCallbacks(timeout);
        if (raw != null && ImeStateStore.importLegacy(context, raw)) {
            android.util.Log.i("KurdiKeyboardIme", "Keyboard settings migration complete");
        }
        web.removeJavascriptInterface("KurdiMigration");
        web.destroy();
    }
}
