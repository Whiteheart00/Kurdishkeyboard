package io.kurdikebord.app;

import java.util.ArrayList;
import java.util.List;

/** Limits for large clipboard text. Pure Java so it can be tested without Android. */
final class ImeLargeText {
    static final int CHUNK = 32 * 1024;
    static final int PREVIEW = 300;
    static final int HISTORY_CHARS = 2 * 1024 * 1024;

    /** Never splits a surrogate pair. */
    private static int boundary(String text, int end) {
        if (end >= text.length()) return text.length();
        return Character.isHighSurrogate(text.charAt(end - 1)) ? end - 1 : end;
    }

    static String preview(String text, int max) {
        return text.length() <= max ? text : text.substring(0, boundary(text, max)) + "\u2026";
    }

    static List<String> chunks(String text, int size) {
        List<String> result = new ArrayList<>();
        for (int start = 0; start < text.length(); ) {
            int end = boundary(text, Math.min(text.length(), start + size));
            result.add(text.substring(start, end));
            start = end;
        }
        return result;
    }

    /** Items are newest first. The newest and pinned items are always kept; older ones fill what is left. */
    static boolean[] keep(int[] lengths, boolean[] pinned, int budget) {
        boolean[] keep = new boolean[lengths.length];
        long used = 0;
        for (int i = 0; i < lengths.length; i++) {
            if (i == 0 || pinned[i]) { keep[i] = true; used += lengths[i]; }
        }
        for (int i = 1; i < lengths.length; i++) {
            if (!keep[i] && used + lengths[i] <= budget) { keep[i] = true; used += lengths[i]; }
        }
        return keep;
    }
}
