package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class NativeSettingsHeader {
    private NativeSettingsHeader() {}
    static void add(LinearLayout parent, NativeImeAppearance a, String title, String font, boolean light, Runnable back) {
        Context context=parent.getContext(); int ink=light?0xff0f172a:Color.WHITE;
        LinearLayout header=new LinearLayout(context);
        header.setGravity(Gravity.CENTER_VERTICAL); header.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        header.setPadding(a.dp(16),0,a.dp(16),0); header.setBackgroundColor(light?0xfff8fafc:Color.BLACK);
        ImageView arrow=new ImageView(context); arrow.setImageDrawable(a.icon("arrow_right",ink,20));
        arrow.setScaleType(ImageView.ScaleType.CENTER); arrow.setContentDescription("گەڕانەوە");
        arrow.setFocusable(true); arrow.setOnClickListener(v->back.run());
        header.addView(arrow,new LinearLayout.LayoutParams(a.dp(40),a.dp(40)));
        TextView label=a.text(title,16,ink,font,700); label.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        label.setSingleLine(true); label.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.setMarginStart(a.dp(12)); header.addView(label,lp);
        parent.addView(header,new LinearLayout.LayoutParams(-1,a.dp(55)));
        View divider=new View(context); divider.setBackgroundColor(light?0xffe2e8f0:0x0dffffff);
        parent.addView(divider,new LinearLayout.LayoutParams(-1,a.dp(1)));
    }
}
