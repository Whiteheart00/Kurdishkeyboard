package io.kurdikebord.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashSet;
import java.util.Set;

/** Scope resets and portable settings to configuration, never cloud identity or stored user text. */
final class NativeSettingsSections {
    private static final String[] DATA = {"personalDictionary","textShortcuts","quickSnippets","emojiPinned","kaomojiPinned","zikrHistories","recentEmojis","recentKaomoji","recentZikr","emojiLastUsedCategory","proUnlocked","notificationsEnabled","ratingDismissed","userRating","aiServerUrl"};
    static boolean portable(String key, JSONObject defaults) {
        for(String excluded:DATA) if(excluded.equals(key)) return false;
        return defaults.has(key) || "bottomRowKeys".equals(key) || "emojiLanguageBottom".equals(key);
    }
    static JSONObject portableSettings(JSONObject source, JSONObject core) {
        JSONObject defaults=NativeImeData.obj(NativeImeData.obj(core,"defaults"),"settings"), result=new JSONObject();
        java.util.Iterator<String> keys=source.keys();
        while(keys.hasNext()) {
            String k=keys.next(); Object v=source.opt(k), d=defaults.opt(k);
            if(!portable(k,defaults))continue;
            if(d instanceof Number ? !(v instanceof Number) : d!=null && d!=JSONObject.NULL && !d.getClass().isInstance(v))continue;
            if("bottomRowKeys".equals(k)&&!(v instanceof JSONArray))continue;
            if("emojiLanguageBottom".equals(k)&&!(v instanceof Boolean))continue;
            ImeStateStore.put(result,k,v);
        }
        return result;
    }
    static boolean supported(String page){return keys(page).length>0 || "all".equals(page);}
    private static String[] keys(String page){
        switch(page){
            case "keyboard_prefs": case "typing": return ("fontSizePercent iconSizePercent keySpacingPercent keySpacingHorizontal keySpacingVertical keyboardHeightPx keyboardWidthPercent keyboardBottomOffsetPx keyboardHorizontalOffsetPx numberStyle numberRowMode longPressDelayMs spaceBarSwitchesToCharacters capitalizationBehavior flyingLettersEnabled flyingLettersSizeMultiplier keyAnimation dynamicBackgroundGlow keyPopupPreview showSecondaryHints showTopToolbar showBottomKeys bottomRowPreset bottomRowKeys emojiLanguageBottom showGlobeKey showLanguagePickerOnLongPress showEmojiKey showCommaKey swapGlobeAndEmoji spacebarLabelMode customSpacebarText oneHandedMode toolsOrder").split(" ");
            case "bottom_row": return "bottomRowPreset bottomRowKeys emojiLanguageBottom showBottomKeys showGlobeKey showEmojiKey showCommaKey swapGlobeAndEmoji".split(" ");
            case "gestures": return "swipeUpAction swipeDownAction swipeLeftAction swipeRightAction spaceBarSwipeUpAction spaceBarSwipeLeftAction spaceBarSwipeRightAction spaceBarLongPressAction deleteKeySwipeLeftAction deleteKeyLongPressAction swipeDistanceThreshold swipeVelocityThreshold spacebarSwipeAction backspaceSwipeDeleteWord spaceCursorChoiceV9".split(" ");
            case "clipboard_settings": return "clipboardEnabled clipboardHistoryEnabled clipboardSuggestLatest clipboardSuggestLimit60s clipboardAutoDeleteOld clipboardMaxItems clipboardHideOnPaste clipboardGridColumns".split(" ");
            case "predictions": return "wordSuggestions smartAutoCorrection multilingualSuggestions autoComplete doubleSpacePeriod autoCapitalization autoSpacePunctuation rememberCapsLockState personalDictionaryEnabled textShortcutsEnabled".split(" ");
            case "sound_vibration": return "soundEnabled soundPack soundVolume vibrationEnabled vibrationDurationMs".split(" ");
            case "themes": return "activeThemeId keyShapeStyle downloadedThemeIds customTheme keyboardThemeMode appAccentColor".split(" ");
            case "custom_theme": return "customTheme activeThemeId".split(" ");
            case "theme_store": return "downloadedThemeIds activeThemeId".split(" ");
            case "languages": return "enabledLanguages activeLanguage translationEngine appLanguage fontStyle".split(" ");
            case "layout_editor": return new String[]{"customLayouts"};
            case "font_style": return new String[]{"fontStyle"};
            case "media": return ("emojiStyle emojiSkinTone emojiHairStyle emojiFontSizePx zikrFontSizePx emojiSuggestions emojiSuggestionType emojiSuggestionQueryMinLength emojiSuggestionMaxCount emojiSuggestionShowName emojiSuggestionUpdateHistory emojiHistoryEnabled emojiHistoryUpdateStrategy emojiHistoryPinnedMaxSize emojiHistoryRecentMaxSize emojiInitialTab emojiCategoryOrder emojiDisabledCategories emojiColumns").split(" ");
            case "ai_settings": return "smartReplyEnabled aiTextSource translationEngine".split(" ");
            case "more_settings": return "appLanguage appTheme showTopToolbar physicalKeyboardSync".split(" ");
            default: return new String[0];
        }
    }
    static JSONObject reset(JSONObject stored, JSONObject core, String page){
        JSONObject defaults=NativeImeData.obj(NativeImeData.obj(core,"defaults"),"settings"), result=NativeImeData.copy(stored);
        Set<String> selected=new LinkedHashSet<>();
        if("all".equals(page)) {java.util.Iterator<String> it=defaults.keys();while(it.hasNext()){String k=it.next();if(portable(k,defaults))selected.add(k);}selected.add("bottomRowKeys");selected.add("emojiLanguageBottom");}
        else java.util.Collections.addAll(selected,keys(page));
        for(String k:selected) if(portable(k,defaults))result.remove(k);
        if("all".equals(page)||"gestures".equals(page))result.remove("spaceCursorChoiceV9");
        return result;
    }
}
