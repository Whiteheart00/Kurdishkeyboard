package io.kurdikebord.app;
import java.util.concurrent.atomic.AtomicInteger;
/** Bounded admission for main-looper operations; contains no editor data. */
final class ImeOperationGate {
    private final int limit;
    private final AtomicInteger count = new AtomicInteger();
    ImeOperationGate(int limit) { this.limit=limit; }
    boolean tryAcquire() {
        int n;
        do { n=count.get(); if(n>=limit) return false; } while(!count.compareAndSet(n,n+1));
        return true;
    }
    void release() { count.decrementAndGet(); }
    static boolean isCurrent(long epoch,long currentEpoch,long generation,long currentGeneration,boolean visible) {
        return visible && epoch==currentEpoch && generation==currentGeneration;
    }
}
