package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.put;
import static io.kurdikebord.app.NativeImeData.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

final class NativeImeSettings {
    private static final String[] SWIPES = {
            "swipeUpAction", "swipeDownAction", "swipeLeftAction", "swipeRightAction",
            "spaceBarSwipeUpAction", "spaceBarSwipeLeftAction", "spaceBarSwipeRightAction",
            "spaceBarLongPressAction", "deleteKeySwipeLeftAction", "deleteKeyLongPressAction"
    };
    private final JSONObject defaults;
    private final JSONArray subtypes;
    private final JSONArray actions;

    NativeImeSettings(JSONObject core) {
        defaults = obj(obj(core, "defaults"), "settings");
        subtypes = arr(core, "subtypes");
        actions = arr(core, "swipeActions");
    }

    JSONObject hydrate(JSONObject stored) {
        JSONObject result = copy(defaults);
        put(result,"smartAutoCorrection",stored.optBoolean("smartAutoCorrection",false));
        put(result,"multilingualSuggestions",stored.optBoolean("multilingualSuggestions",false));
        merge(result, stored);
        Iterator<String> keys = defaults.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object fallback = defaults.opt(key);
            Object value = result.opt(key);
            if (fallback instanceof Number ? !(value instanceof Number)
                    : fallback != null && fallback != JSONObject.NULL && !fallback.getClass().isInstance(value)) {
                put(result, key, fallback);
            }
        }
        restrict(result, "appLanguage", "ckb", "kmr", "en", "ar", "fa");
        restrict(result, "numberRowMode", "always", "per_language", "never");
        restrict(result, "capitalizationBehavior", "capslock_by_double_tap", "capslock_by_cycle");
        range(result, "swipeDistanceThreshold", 16, Integer.MAX_VALUE);
        range(result, "swipeVelocityThreshold", 50, Integer.MAX_VALUE);
        range(result, "emojiFontSizePx", 16, Integer.MAX_VALUE);
        range(result, "zikrFontSizePx", 9, Integer.MAX_VALUE);
        range(result, "keyboardWidthPercent", 70, 100);
        range(result, "keyboardBottomOffsetPx", 0, 96);
        range(result, "keyboardHorizontalOffsetPx", -80, 80);
        range(result, "longPressDelayMs", 150, 600);
        range(result, "flyingLettersSizeMultiplier", 60, Integer.MAX_VALUE);
        range(result, "vibrationDurationMs", 6, 60);
        double columns = result.optDouble("clipboardGridColumns");
        if (columns != 1 && columns != 2) put(result, "clipboardGridColumns", defaults.opt("clipboardGridColumns"));
        if (result.optString("keyShapeStyle").isEmpty()) put(result, "keyShapeStyle", "default");
        if (arr(result, "emojiCategoryOrder").length() == 0) put(result, "emojiCategoryOrder", defaults.opt("emojiCategoryOrder"));

        JSONArray enabled = normalizeLanguages(arr(result, "enabledLanguages"));
        put(result, "enabledLanguages", enabled);
        if (find(enabled, "code", result.optString("activeLanguage")) == null) {
            put(result, "activeLanguage", enabled.optJSONObject(0).optString("code"));
        }

        JSONArray original = arr(result, "toolsOrder");
        JSONArray tools = new JSONArray();
        JSONArray standard = arr(defaults, "toolsOrder");
        for (int i = 0; i < standard.length(); i++) {
            String tool = standard.optString(i);
            if (!contains(original, tool)) tools.put(tool);
        }
        for (int i = 0; i < original.length(); i++) tools.put(original.opt(i));
        put(result, "toolsOrder", tools);

        for (String key : SWIPES) {
            Object value = stored.opt(key);
            if (value == null || value == JSONObject.NULL) {
                String oldSpace = stored.optString("spacebarSwipeAction");
                switch (key) {
                    case "spaceBarSwipeLeftAction":
                    case "spaceBarSwipeRightAction":
                        if ("move_cursor".equals(oldSpace)) value = key.contains("Left") ? "move_cursor_left" : "move_cursor_right";
                        else if ("none".equals(oldSpace)) value = "no_action";
                        break;
                    case "deleteKeySwipeLeftAction":
                        if (Boolean.FALSE.equals(stored.opt("backspaceSwipeDeleteWord"))) value = "no_action";
                        break;
                    default: break;
                }
            }
            put(result, key, normalizeSwipe(value, defaults.optString(key)));
        }

        JSONObject histories = copy(obj(defaults, "zikrHistories"));
        JSONObject savedHistories = obj(result, "zikrHistories");
        for (String group : new String[]{"duaa", "quran", "salawat"}) {
            JSONObject history = savedHistories.optJSONObject(group);
            if (history != null) put(histories, group, history);
        }
        put(result, "zikrHistories", histories);
        return result;
    }

    private JSONArray normalizeLanguages(JSONArray enabled) {
        JSONArray result = new JSONArray();
        for (int i = 0; i < enabled.length(); i++) {
            JSONObject language = enabled.optJSONObject(i);
            if (language == null) continue;
            String code = language.optString("code");
            JSONObject preset = find(subtypes, "code", code.isEmpty() ? "ckb" : code);
            if (preset == null) preset = subtypes.optJSONObject(0);
            JSONObject hydrated = copy(preset);
            merge(hydrated, language);
            result.put(hydrated);
        }
        return result.length() == 0 ? arr(defaults, "enabledLanguages") : result;
    }

    private String normalizeSwipe(Object raw, String fallback) {
        if (!(raw instanceof String)) return fallback;
        String value = (String) raw;
        if (contains(actions, value)) return value;
        switch (value) {
            case "none": return "no_action";
            case "hide": return "hide_keyboard";
            case "numbers": return "switch_to_symbols_keyboard";
            case "next_lang": return "switch_to_next_subtype";
            case "prev_lang": return "switch_to_prev_subtype";
            default: return fallback;
        }
    }

    private void range(JSONObject settings, String key, double min, double max) {
        double value = settings.optDouble(key);
        if (Double.isNaN(value) || value < min || value > max) put(settings, key, defaults.opt(key));
    }

    private void restrict(JSONObject settings, String key, String... options) {
        String value = settings.optString(key);
        for (String option : options) if (option.equals(value)) return;
        put(settings, key, defaults.opt(key));
    }
}
