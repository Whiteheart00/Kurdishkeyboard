package io.kurdikebord.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

final class NativeKeyboardPrefsView extends LinearLayout {
    private static final int BLUE = 0xff8ec2ff;
    private static final int MUTED = 0xffa1a1aa;
    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final boolean locked;
    private final int foreground;
    private final int surface;
    private final int border;
    private final Map<String, JSONObject> ranges = new HashMap<>();
    private final Map<String, TextView> summaries = new HashMap<>();
    private final Map<String, LinearLayout> metricCards = new HashMap<>();
    private final Map<String, LinearLayout> metricPanels = new HashMap<>();
    private final Map<String, Integer> values = new HashMap<>();
    private final boolean hasIcons;
    private String openMetric = "";

    NativeKeyboardPrefsView(Context context, String theme, String font, JSONObject data, Runnable back,
                            NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        light = "light".equals(theme);
        locked = !data.optBoolean("proUnlocked");
        foreground = light ? 0xff0f172a : Color.WHITE;
        surface = light ? Color.WHITE : 0xff17181b;
        border = light ? 0xffe2e8f0 : 0x1affffff;
        NativeImeEngine icons = null;
        try { icons = new NativeImeEngine(context); } catch (IOException ignored) { }
        hasIcons = icons != null;
        appearance = new NativeImeAppearance(context, icons);
        JSONArray rangeData = data.optJSONArray("ranges");
        for (int index = 0; rangeData != null && index < rangeData.length(); index++) {
            JSONObject range = rangeData.optJSONObject(index);
            if (range != null) {
                String key = range.optString("key");
                ranges.put(key, range);
                values.put(key, range.optInt("value"));
            }
        }
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = horizontal();
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        header.setPadding(dp(16), 0, dp(16), 0);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("قیاسی فۆنت، مەودا و ئامرازەکان", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        divider(this, 0);

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(24));
        body.setFocusableInTouchMode(true);
        scroll.addView(body);
        body.requestFocus();
        boolean notifications = data.optBoolean("notificationsEnabled");
        if (!notifications) append(body, NativeSettingsNotification.create(context, appearance, font, change), 0);

        LinearLayout topMetrics = horizontal();
        equal(topMetrics, metric("font", "قیاسی فۆنت", "ic_number", false), 0);
        equal(topMetrics, metric("icon", "قەبارەی ئایکۆنەکان", "ic_ui_settings", false), 12);
        append(body, topMetrics, notifications ? 0 : 16);
        LinearLayout bottomMetrics = horizontal();
        equal(bottomMetrics, metric("spacing", "مەودای نێوان دوگمەکان", "resize_move", locked), 0);
        equal(bottomMetrics, numberStyle(data), 12);
        append(body, bottomMetrics, 12);
        addMetricPanel(body, "font", "fontSizePercent");
        addMetricPanel(body, "icon", "iconSizePercent");
        addMetricPanel(body, "spacing", "keySpacingHorizontal", "keySpacingVertical");
        refreshSummaries();

        LinearLayout inputCard = card(24);
        append(inputCard, slider("longPressDelayMs"), 0);
        LinearLayout examples = horizontal();
        equal(examples, label("خێرا (150ms)", 10, MUTED, 400), 0);
        equal(examples, appearance.text("ئاسایی (300ms)", 10, MUTED, font, 400), 0);
        TextView slow = label("هێواش (600ms)", 10, MUTED, 400);
        slow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        equal(examples, slow, 0);
        append(inputCard, examples, 4);
        divider(inputCard, 12);
        append(inputCard, options(option(data, "numberRowMode"), false, null), 8);
        divider(inputCard, 12);
        append(inputCard, options(option(data, "capitalizationBehavior"), false, null), 8);
        append(body, inputCard, 16);

        LinearLayout bottomRow = card(24);
        append(bottomRow, options(option(data, "bottomRowPreset"), true, null), 0);
        append(body, bottomRow, 16);

        LinearLayout flying = card(16);
        append(flying, slider("flyingLettersSizeMultiplier"), 0);
        JSONArray switches = data.optJSONArray("switches");
        for (int index = 0; switches != null && index < switches.length(); index++) {
            JSONObject entry = switches.optJSONObject(index);
            if (entry == null) continue;
            append(body, toggleRow(entry, flying), 16);
        }
        append(body, flying, 16);

        JSONObject spacebar = option(data, "spacebarLabelMode");
        EditText custom = new EditText(context);
        custom.setSingleLine(true);
        custom.setTextColor(foreground);
        custom.setHintTextColor(MUTED);
        custom.setTextSize(12);
        custom.setTypeface(appearance.text("", 12, foreground, font, 400).getTypeface());
        custom.setPadding(dp(12), 0, dp(12), 0);
        custom.setBackground(appearance.background(light ? 0xfff8fafc : 0x66000000, 12, 1, border));
        custom.setMinHeight(dp(40));
        custom.setHint("ناوی سەر دوگمەی بۆشایی بنووسە...");
        custom.setText(data.optString("customSpacebarText"));
        custom.setVisibility("custom".equals(spacebar.optString("value")) ? VISIBLE : GONE);
        custom.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence text, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence text, int start, int before, int count) {
                change.accept("customSpacebarText", text.toString());
            }
            @Override public void afterTextChanged(Editable text) {}
        });
        LinearLayout spaceCard = card(16);
        append(spaceCard, options(spacebar, false, custom), 0);
        append(spaceCard, custom, 10);
        append(body, spaceCard, 16);
        if (icons != null) icons.close();
    }

    private JSONObject option(JSONObject data, String key) {
        JSONArray items = data.optJSONArray("options");
        for (int index = 0; items != null && index < items.length(); index++) {
            JSONObject item = items.optJSONObject(index);
            if (item != null && key.equals(item.optString("key"))) return item;
        }
        return new JSONObject();
    }

    private LinearLayout metric(String key, String title, String icon, boolean pro) {
        LinearLayout card = card(24);
        LinearLayout top = horizontal();
        addIcon(top, icon, BLUE, 24);
        if (pro) {
            top.addView(new View(getContext()), new LayoutParams(0, 1, 1));
            top.addView(badge());
        }
        append(card, top, 0);
        append(card, label(title, 14, foreground, 700), 6);
        TextView summary = label("", 12, MUTED, 400);
        append(card, summary, 6);
        summaries.put(key, summary);
        if (!"numbers".equals(key)) {
            metricCards.put(key, card);
            card.setOnClickListener(v -> {
                openMetric = key.equals(openMetric) ? "" : key;
                for (Map.Entry<String, LinearLayout> entry : metricPanels.entrySet()) {
                    boolean active = entry.getKey().equals(openMetric);
                    entry.getValue().setVisibility(active ? VISIBLE : GONE);
                    metricCards.get(entry.getKey()).setBackground(appearance.background(surface, 24, 1, active ? BLUE : border));
                }
            });
        }
        return card;
    }

    private LinearLayout numberStyle(JSONObject data) {
        LinearLayout card = metric("numbers", "لیستی ژمارەکان", "ic_number", false);
        JSONArray styles = data.optJSONArray("numberStyles");
        if (styles == null || styles.length() == 0) return card;
        String current = data.optString("numberStyle");
        int[] selection = {-1};
        TextView summary = summaries.get("numbers");
        summary.setText("لاتینی (123)");
        for (int i = 0; i < styles.length(); i++) {
            JSONObject style = styles.optJSONObject(i);
            if (style != null && current.equals(style.optString("id"))) {
                selection[0] = i;
                summary.setText(style.optString("label"));
                break;
            }
        }
        card.setOnClickListener(v -> {
            selection[0] = (selection[0] + 1) % styles.length();
            JSONObject style = styles.optJSONObject(selection[0]);
            if (style != null) {
                summary.setText(style.optString("label"));
                change.accept("numberStyle", style.optString("id"));
            }
        });
        return card;
    }

    private void addMetricPanel(LinearLayout body, String metric, String... keys) {
        LinearLayout panel = card(16);
        for (int index = 0; index < keys.length; index++) {
            if (index > 0) divider(panel, 8);
            append(panel, slider(keys[index]), index == 0 ? 0 : 8);
        }
        metricPanels.put(metric, panel);
        panel.setVisibility(GONE);
        append(body, panel, 16);
    }

    private void refreshSummaries() {
        int fontSize = values.getOrDefault("fontSizePercent", 100);
        int iconSize = values.getOrDefault("iconSizePercent", 100);
        int x = values.getOrDefault("keySpacingHorizontal", 100);
        int y = values.getOrDefault("keySpacingVertical", 100);
        summaries.get("font").setText(fontSize + "% / " + fontSize + "%");
        summaries.get("icon").setText(iconSize + "% / " + iconSize + "%");
        summaries.get("spacing").setText(x + "% / " + y + "%");
    }

    private View slider(String key) {
        JSONObject definition = ranges.get(key);
        LinearLayout group = column();
        if (definition == null) return group;
        int min = definition.optInt("min");
        int max = definition.optInt("max");
        int step = Math.max(1, definition.optInt("step"));
        String unit = definition.optString("unit");
        String title = definition.optString("title");
        int initial = values.getOrDefault(key, min);
        LinearLayout caption = horizontal();
        caption.addView(label(title, 12, foreground, 700), new LayoutParams(0, -2, 1));
        TextView readout = appearance.text(initial + unit, 12, BLUE, "system", 700);
        readout.setTextDirection(TEXT_DIRECTION_LTR);
        caption.addView(readout);
        append(group, caption, 0);
        SeekBar slider = new SeekBar(getContext());
        slider.setContentDescription(title);
        slider.setMax(Math.max(0, (max - min) / step));
        slider.setProgress(Math.round((initial - min) / (float) step));
        slider.setProgressTintList(ColorStateList.valueOf(BLUE));
        slider.setThumbTintList(ColorStateList.valueOf(BLUE));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!fromUser) return;
                int value = min + progress * step;
                readout.setText(value + unit);
                values.put(key, value);
                refreshSummaries();
                change.accept(key, value);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        append(group, slider, 4);
        return group;
    }

    private View options(JSONObject data, boolean showSelection, EditText custom) {
        LinearLayout group = column();
        String key = data.optString("key");
        boolean bottom = "bottomRowPreset".equals(key);
        LinearLayout header = horizontal();
        header.addView(label(data.optString("title"), bottom || custom != null ? 14 : 12, foreground, 700),
                new LayoutParams(0, -2, 1));
        TextView current = label("", 11, BLUE, 700);
        if (showSelection) header.addView(current);
        if (custom != null && locked) header.addView(badge());
        append(group, header, 0);
        JSONArray options = data.optJSONArray("options");
        int columns = Math.max(1, data.optInt("columns", 2));
        TextView[] buttons = new TextView[options == null ? 0 : options.length()];
        LinearLayout line = horizontal();
        for (int index = 0; options != null && index < options.length(); index++) {
            JSONObject choice = options.optJSONObject(index);
            if (choice == null) continue;
            if (index % columns == 0) {
                line = horizontal();
                append(group, line, index == 0 ? 8 : 6);
            }
            String id = choice.optString("id");
            String name = choice.optString("label");
            TextView button = appearance.text(name, 11, foreground, font, 700);
            if (bottom) {
                button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                button.setPaddingRelative(dp(12), 0, dp(8), 0);
            }
            button.setMinHeight(dp(36));
            buttons[index] = button;
            boolean active = id.equals(data.optString("value"));
            paintOption(button, active);
            if (active) current.setText(name);
            button.setOnClickListener(v -> {
                for (TextView item : buttons) if (item != null) paintOption(item, item == button);
                current.setText(name);
                if (custom != null) custom.setVisibility("custom".equals(id) ? VISIBLE : GONE);
                change.accept(key, id);
            });
            equal(line, button, index % columns == 0 ? 0 : 6);
        }
        if (buttons.length % columns != 0) {
            for (int i = buttons.length % columns; i < columns; i++) equal(line, new View(getContext()), 6);
        }
        return group;
    }

    private void paintOption(TextView button, boolean active) {
        button.setSelected(active);
        button.setTextColor(active ? light ? 0xff075985 : BLUE : light ? 0xff475569 : MUTED);
        button.setBackground(appearance.background(active ? light ? 0xffe0f2fe : 0x3328a1e8 : Color.TRANSPARENT,
                12, 1, active ? BLUE : border));
    }

    private View toggleRow(JSONObject entry, View flying) {
        LinearLayout row = horizontal();
        row.setPadding(0, dp(4), 0, dp(4));
        addIcon(row, entry.optString("icon"), MUTED, 20);
        LinearLayout copy = column();
        LinearLayout header = horizontal();
        String title = entry.optString("title");
        header.addView(label(title, 14, foreground, 700), new LayoutParams(0, -2, 1));
        if (locked && entry.optBoolean("pro")) header.addView(badge());
        append(copy, header, 0);
        append(copy, label(entry.optString("subtitle"), 12, MUTED, 400), 2);
        LayoutParams copyParams = new LayoutParams(0, -2, 1);
        copyParams.setMarginStart(dp(12));
        copyParams.setMarginEnd(dp(12));
        row.addView(copy, copyParams);
        String key = entry.optString("key");
        boolean controlsFlying = "flyingLettersEnabled".equals(key);
        boolean initial = entry.optBoolean("value");
        if (controlsFlying) flying.setVisibility(initial ? VISIBLE : GONE);
        Toggle toggle = new Toggle(title, initial);
        toggle.setOnClickListener(v -> {
            boolean enabled = !toggle.isSelected();
            toggle.paint(enabled);
            if (controlsFlying) flying.setVisibility(enabled ? VISIBLE : GONE);
            change.accept(key, enabled);
        });
        row.addView(toggle, new LayoutParams(dp(52), dp(30)));
        return row;
    }

    private final class Toggle extends FrameLayout {
        private final View knob;

        Toggle(String title, boolean value) {
            super(NativeKeyboardPrefsView.this.getContext());
            setLayoutDirection(LAYOUT_DIRECTION_LTR);
            setContentDescription(title);
            setFocusable(true);
            knob = new View(getContext());
            addView(knob);
            paint(value);
        }

        void paint(boolean selected) {
            setSelected(selected);
            setBackground(appearance.background(selected ? 0xff9ac5ff : 0xff1d1f24, 15, selected ? 0 : 2, 0xff6c707a));
            int side = dp(selected ? 22 : 16);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                    side, side, Gravity.CENTER_VERTICAL | (selected ? Gravity.RIGHT : Gravity.LEFT));
            params.setMargins(dp(5), 0, dp(5), 0);
            knob.setLayoutParams(params);
            knob.setBackground(appearance.background(selected ? 0xff0b3263 : 0xff8e939e, 12, 0, 0));
        }

        @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
            super.onInitializeAccessibilityNodeInfo(info);
            info.setClassName("android.widget.Switch");
            info.setCheckable(true);
            info.setChecked(isSelected());
        }
    }

    private TextView badge() {
        TextView badge = appearance.text("PRO", 10, Color.WHITE, "system", 800);
        badge.setPadding(dp(6), dp(2), dp(6), dp(2));
        badge.setBackground(appearance.background(0xff465bcb, 6, 0, 0));
        return badge;
    }

    private void addIcon(LinearLayout parent, String name, int color, int size) {
        ImageView icon = new ImageView(getContext());
        if (hasIcons) icon.setImageDrawable(appearance.icon(name, color, size));
        parent.addView(icon, new LayoutParams(dp(size), dp(size)));
    }

    private TextView label(String text, int size, int color, int weight) {
        TextView view = appearance.text(text, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout card(int corner) {
        LinearLayout card = column();
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(appearance.background(surface, corner, 1, border));
        return card;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setOrientation(VERTICAL);
        return layout;
    }

    private void divider(LinearLayout parent, int gap) {
        View line = new View(getContext());
        line.setBackgroundColor(border);
        LayoutParams params = new LayoutParams(-1, dp(1));
        params.topMargin = dp(gap);
        parent.addView(line, params);
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(-1, -2);
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private void equal(LinearLayout parent, View child, int gap) {
        LayoutParams params = new LayoutParams(0, -2, 1);
        params.setMarginStart(dp(gap));
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
