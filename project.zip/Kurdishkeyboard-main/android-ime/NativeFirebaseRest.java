package io.kurdikebord.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

/** Google ID token exchange and user-scoped Firestore REST. No admin credentials. */
final class NativeFirebaseRest {
    private static final String PREF="kk_firebase_session_v1", ALIAS="kk_firebase_session_key_v1";
    private static String cachedUid="", cachedToken="";
    private static long expiresAt;
    private static final int MAX_RESPONSE=1500000;
    static final class User {
        private final String uid,email;
        User(String uid,String email){this.uid=uid;this.email=email;}
        String getUid(){return uid;} String getEmail(){return email;}
    }
    static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static User user(Context c){
        String uid=prefs(c).getString("uid","");
        return uid.isEmpty()?null:new User(uid,prefs(c).getString("email",""));
    }
    private static void checkUid(String uid)throws IOException{
        if(uid==null||!uid.matches("[A-Za-z0-9_-]{1,128}"))throw new IOException("Invalid account");
    }
    private static String enc(String value)throws Exception{return URLEncoder.encode(value,"UTF-8");}
    private static SecretKey key()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        java.security.Key old=ks.getKey(ALIAS,null);
        if(old instanceof SecretKey)return (SecretKey)old;
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return gen.generateKey();
    }
    private static String seal(String uid,String token)throws Exception{
        byte[] plain=token.getBytes(StandardCharsets.UTF_8);
        try{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));
            ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(cipher.getIV());out.write(cipher.doFinal(plain));
            return Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
        }finally{Arrays.fill(plain,(byte)0);}
    }
    private static String open(String uid,String value)throws Exception{
        byte[] bytes=Base64.decode(value,Base64.NO_WRAP);if(bytes.length<29)throw new IOException("Missing session");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,bytes,0,12));cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));
        byte[] plain=cipher.doFinal(bytes,12,bytes.length-12);
        try{return new String(plain,StandardCharsets.UTF_8);}finally{Arrays.fill(plain,(byte)0);}
    }
    private static String sha1(Context c)throws Exception{
        // Firebase Android API-key restrictions use the package and signing certificate.
        android.content.pm.Signature[] signatures=c.getPackageManager().getPackageInfo(c.getPackageName(),PackageManager.GET_SIGNATURES).signatures;
        if(signatures==null||signatures.length!=1)throw new IOException("Signing certificate unavailable");
        byte[] digest=MessageDigest.getInstance("SHA-1").digest(signatures[0].toByteArray());StringBuilder s=new StringBuilder();
        for(byte b:digest)s.append(String.format(Locale.US,"%02X",b&255));return s.toString();
    }
    static final class Failure extends IOException {
        final int status;final String code;
        Failure(int status,String code){super("Cloud HTTP "+status);this.status=status;this.code=code;}
        boolean conflict(){return "FAILED_PRECONDITION".equals(code)||"ALREADY_EXISTS".equals(code)||"ABORTED".equals(code)||status==412;}
    }
    private static JSONObject request(Context c,String method,String url,String contentType,String body,String token,boolean authApi)throws Exception{
        URL endpoint=new URL(url);
        String host=endpoint.getHost();
        String attestation=("firestore.googleapis.com".equals(host)||"identitytoolkit.googleapis.com".equals(host)||"securetoken.googleapis.com".equals(host)) ? NativeAppCheck.token(c) : null;
        HttpsURLConnection conn=(HttpsURLConnection)endpoint.openConnection();
        conn.setConnectTimeout(15000);conn.setReadTimeout(25000);conn.setInstanceFollowRedirects(false);conn.setUseCaches(false);conn.setRequestMethod(method);
        conn.setRequestProperty("Accept","application/json");
        if(token!=null)conn.setRequestProperty("Authorization","Bearer "+token);
        if(attestation!=null&&!attestation.isEmpty())conn.setRequestProperty("X-Firebase-AppCheck",attestation);
        if(authApi){conn.setRequestProperty("X-Android-Package",c.getPackageName());conn.setRequestProperty("X-Android-Cert",sha1(c));}
        try{
            if(body!=null){byte[] bytes=body.getBytes(StandardCharsets.UTF_8);conn.setDoOutput(true);conn.setRequestProperty("Content-Type",contentType);conn.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=conn.getOutputStream()){out.write(bytes);}finally{Arrays.fill(bytes,(byte)0);}}
            int status=conn.getResponseCode();NativeSecurityStatus.note(c,"firebase",status);boolean ok=status>=200&&status<300;InputStream raw=ok?conn.getInputStream():conn.getErrorStream();
            ByteArrayOutputStream result=new ByteArrayOutputStream();
            if(raw!=null)try(InputStream in=raw){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(result.size()+n>MAX_RESPONSE)throw new IOException("Cloud response too large");result.write(buf,0,n);}}
            String text=new String(result.toByteArray(),StandardCharsets.UTF_8);
            if(!ok){String code="";try{code=new JSONObject(text).getJSONObject("error").optString("status","");}catch(Exception ignored){}throw new Failure(status,code);}
            return text.trim().isEmpty()?new JSONObject():new JSONObject(text);
        }finally{conn.disconnect();}
    }
    private static JSONObject json(Context c,String method,String url,JSONObject body,String token,boolean authApi)throws Exception{
        return request(c,method,url,"application/json; charset=UTF-8",body==null?null:body.toString(),token,authApi);
    }
    private static void cache(String uid,String token,long seconds)throws IOException{
        if(token.isEmpty()||seconds<=0)throw new IOException("Invalid session expiry");
        cachedUid=uid;cachedToken=token;expiresAt=android.os.SystemClock.elapsedRealtime()+Math.min(seconds,3600L)*1000L;
    }
    static synchronized void signIn(Context c,String googleIdToken)throws Exception{
        if(googleIdToken==null||googleIdToken.isEmpty())throw new IOException("Missing Google credential");
        JSONObject payload=new JSONObject().put("postBody","id_token="+enc(googleIdToken)+"&providerId=google.com").put("requestUri","http://localhost").put("returnSecureToken",true);
        JSONObject reply=json(c,"POST","https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key="+enc(c.getString(R.string.google_api_key)),payload,null,true);
        String uid=reply.getString("localId"),refresh=reply.getString("refreshToken"),token=reply.getString("idToken");checkUid(uid);
        long seconds=reply.getLong("expiresIn");if(refresh.isEmpty()||token.isEmpty()||seconds<=0)throw new IOException("Invalid sign-in response");
        String sealed=seal(uid,refresh);
        if(!prefs(c).edit().clear().putString("uid",uid).putString("email",reply.optString("email","")).putString("refresh",sealed).commit())throw new IOException("Session storage failed");
        cache(uid,token,seconds);
    }
    static synchronized void signOut(Context c){cachedUid="";cachedToken="";expiresAt=0;prefs(c).edit().clear().commit();}
    private static synchronized String idToken(Context c,String uid)throws Exception{
        checkUid(uid);User u=user(c);if(u==null||!uid.equals(u.getUid()))throw new IOException("Account changed");
        if(uid.equals(cachedUid)&&!cachedToken.isEmpty()&&expiresAt-android.os.SystemClock.elapsedRealtime()>60000)return cachedToken;
        String refresh=open(uid,prefs(c).getString("refresh",""));
        JSONObject reply=request(c,"POST","https://securetoken.googleapis.com/v1/token?key="+enc(c.getString(R.string.google_api_key)),"application/x-www-form-urlencoded","grant_type=refresh_token&refresh_token="+enc(refresh),null,true);
        if(!uid.equals(reply.getString("user_id")))throw new IOException("Account changed");
        String next=reply.getString("refresh_token"),token=reply.getString("id_token");long seconds=reply.getLong("expires_in");
        if(next.isEmpty()||token.isEmpty()||seconds<=0)throw new IOException("Invalid refreshed session");
        if(!refresh.equals(next)&&!prefs(c).edit().putString("refresh",seal(uid,next)).commit())throw new IOException("Session storage failed");
        cache(uid,token,seconds);return cachedToken;
    }
    private static String db(Context c)throws IOException{
        String project=c.getString(R.string.project_id);
        if(!project.matches("[a-z0-9-]{1,63}"))throw new IOException("Invalid project");
        return "projects/"+project+"/databases/(default)";
    }
    private static String doc(Context c,String uid)throws Exception{checkUid(uid);return db(c)+"/documents/keyboardBackups/"+uid;}
    private static final String API="https://firestore.googleapis.com/v1/";
    static final class Snapshot {
        final String revision,updateTime;final byte[] ciphertext;
        Snapshot(String r,String t,byte[] b){revision=r;updateTime=t;ciphertext=b;}
    }
    static Snapshot get(Context c,String uid)throws Exception{
        JSONObject reply;try{reply=json(c,"GET",API+doc(c,uid),null,idToken(c,uid),false);}catch(Failure e){if(e.status==404)return null;throw e;}
        JSONObject fields=reply.getJSONObject("fields");String revision=fields.getJSONObject("revision").getString("stringValue");
        if(fields.getJSONObject("version").getLong("integerValue")!=1||revision.length()!=36)throw new IOException("Invalid cloud document");
        byte[] blob=Base64.decode(fields.getJSONObject("ciphertext").getString("bytesValue"),Base64.DEFAULT);
        if(blob.length>NativeFirebaseBackup.LIMIT)throw new IOException("Backup too large");
        return new Snapshot(revision,reply.getString("updateTime"),blob);
    }
    static boolean put(Context c,String uid,Snapshot old,String revision,byte[] encrypted)throws Exception{
        JSONObject fields=new JSONObject().put("version",new JSONObject().put("integerValue","1"))
            .put("revision",new JSONObject().put("stringValue",revision))
            .put("ciphertext",new JSONObject().put("bytesValue",Base64.encodeToString(encrypted,Base64.NO_WRAP)));
        JSONObject precondition=old==null?new JSONObject().put("exists",false):new JSONObject().put("updateTime",old.updateTime);
        JSONObject transform=new JSONObject().put("fieldPath","updatedAt").put("setToServerValue","REQUEST_TIME");
        JSONObject write=new JSONObject().put("update",new JSONObject().put("name",doc(c,uid)).put("fields",fields))
            .put("currentDocument",precondition).put("updateTransforms",new JSONArray().put(transform));
        try{json(c,"POST",API+db(c)+"/documents:commit",new JSONObject().put("writes",new JSONArray().put(write)),idToken(c,uid),false);return true;}
        catch(Failure e){if(e.conflict())return false;throw e;}
    }
    static void delete(Context c,String uid)throws Exception{
        try{json(c,"DELETE",API+doc(c,uid),null,idToken(c,uid),false);}catch(Failure e){if(e.status!=404)throw e;}
    }
}
