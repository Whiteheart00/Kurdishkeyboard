package io.kurdikebord.app;

/** State shared by voice toolbar and controller; independent of Android for unit tests. */
final class ImeVoiceSessionState {
    enum Action { START, STOP, CANCEL }
    static Action action(boolean mangaActive, boolean nativeActive, boolean recording) {
        if (!mangaActive && !nativeActive) return Action.START;
        return recording ? Action.STOP : Action.CANCEL;
    }
    static boolean terminal(String state) {
        return !"connecting".equals(state) && !"starting".equals(state)
            && !"recording".equals(state) && !"transcribing".equals(state);
    }
}
