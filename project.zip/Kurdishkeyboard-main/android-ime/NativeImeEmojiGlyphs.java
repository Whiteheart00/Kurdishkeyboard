package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import org.json.JSONArray;

final class NativeImeEmojiGlyphs {
    private static final String FACEBOOK = "https://cdn.jsdelivr.net/npm/emoji-datasource-facebook@16.0.0/img/facebook/64/";
    private static final int MAX_REQUESTS = 96;
    private final NativeImeView keyboard;
    private final Context context;
    private final NativeImeAppearance appearance;
    private final JSONArray missingCodes;
    private final int settingsColor;
    private final Handler main = new Handler(Looper.getMainLooper());
    // Shared across settings and IME instances; capped at 8 MiB.
    private static final LruCache<String, Bitmap> images = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getAllocationByteCount(); }
    };
    // Bundled, offline-safe emoji artwork is independent from the optional remote style.
    private static final LruCache<String, Bitmap> offlineImages = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getAllocationByteCount(); }
    };
    private static final ExecutorService offlineLoader = Executors.newFixedThreadPool(2, task -> new Thread(task, "ime-emoji-local"));
    private static final Handler offlineMain = new Handler(Looper.getMainLooper());
    private final List<WeakReference<Glyph>> deferred = new ArrayList<>();
    private final Runnable retryDeferred = this::drainDeferred;
    private final Set<String> missing = new HashSet<>();
    private final Map<String, List<WeakReference<Glyph>>> awaiting = new HashMap<>();
    private ExecutorService loader;
    private long retryAfter;
    private boolean initialized;
    private boolean closed;
    private int session;

    NativeImeEmojiGlyphs(NativeImeView keyboard) { this.keyboard = keyboard; context=keyboard.getContext(); appearance=keyboard.appearance; missingCodes=null; settingsColor=Color.WHITE; }
    NativeImeEmojiGlyphs(Context context, NativeImeAppearance appearance, JSONArray missingCodes, int color) {this.keyboard=null; this.context=context;this.appearance=appearance;this.missingCodes=missingCodes;this.settingsColor=color;}
    TextView view(String value, int size, String style) {return new Glyph(context,value,appearance.px(size),style);}
    void resize(TextView view,int size){if(view instanceof Glyph){Glyph glyph=(Glyph)view;glyph.size=appearance.px(size);glyph.setTextSize(TypedValue.COMPLEX_UNIT_PX,glyph.size);glyph.invalidate();}}


    TextView view(String value, int size) {
        return view(value,size,keyboard.settings.optString("emojiStyle", "system"));
    }

    private static void loadOffline(Glyph glyph, Context context) {
        String code = glyph.code;
        if (code.isEmpty()) return;
        Bitmap cached = offlineImages.get(code);
        if (cached != null) { glyph.setOfflineBitmap(cached); return; }
        Context app = context.getApplicationContext();
        WeakReference<Glyph> reference = new WeakReference<>(glyph);
        int generation = glyph.generation;
        offlineLoader.execute(() -> {
            Glyph current = reference.get();
            if (current == null || current.generation != generation) return;
            Bitmap result = offlineImages.get(code);
            if (result == null) {
                try (InputStream input = app.getAssets().open("native-ime/emoji/" + code + ".png")) {
                    result = BitmapFactory.decodeStream(input);
                } catch (IOException | RuntimeException ignored) {
                    // Custom/history glyphs outside the original catalog use native text.
                }
                if (result != null) offlineImages.put(code, result);
            }
            Bitmap bitmap = result;
            if (bitmap != null) offlineMain.post(() -> {
                Glyph view = reference.get();
                if (view != null && view.generation == generation && view.isAttachedToWindow()) view.setOfflineBitmap(bitmap);
            });
        });
    }

    private void load(Glyph glyph) {
        if (closed) return;
        if (!initialized) {
            initialized = true;
            JSONArray data = keyboard==null?missingCodes:keyboard.engine.object("media", null).optJSONArray("missingFacebook");
            for (int i = 0; data != null && i < data.length(); i++) {
                String code = data.optString(i);
                missing.add(code);
                if (code.contains("-fe0f")) missing.add(code.replace("-fe0f", ""));
            }
        }
        String code = glyph.code;
        String alternative = ImeEmojiCodes.alternative(code);
        if (missing.contains(code)) {
            code = alternative;
            alternative = "";
        }
        if (code.isEmpty() || missing.contains(code)) return;
        Bitmap cached = images.get(code);
        if (cached != null) { glyph.setBitmap(cached); return; }
        if (SystemClock.uptimeMillis() < retryAfter) { defer(glyph); return; }
        List<WeakReference<Glyph>> pending = awaiting.get(code);
        if (pending != null) {
            for (java.util.Iterator<WeakReference<Glyph>> it = pending.iterator(); it.hasNext();) {
                Glyph view = it.next().get();
                if (view == null || !view.isAttachedToWindow()) it.remove();
                else if (view == glyph) return;
            }
            pending.add(new WeakReference<>(glyph)); return;
        }
        if (awaiting.size() >= MAX_REQUESTS) { defer(glyph); return; }
        pending = new ArrayList<>();
        pending.add(new WeakReference<>(glyph));
        awaiting.put(code, pending);
        if (loader == null) loader = Executors.newFixedThreadPool(3, task -> new Thread(task, "ime-emoji-image"));
        String requested = code;
        String retry = missing.contains(alternative) ? "" : alternative;
        int requestSession = session;
        loader.execute(() -> {
            Bitmap result = null;
            boolean absent = false;
            boolean failed = false;
            try {
                result = fetch(requested);
                if (result == null && !retry.isEmpty()) result = fetch(retry);
                absent = result == null;
            } catch (IOException | RuntimeException error) {
                failed = true;
            }
            Bitmap bitmap = result;
            boolean notFound = absent, unavailable = failed;
            main.post(() -> { if (session == requestSession) complete(requested, bitmap, notFound, unavailable); });
        });
    }

    private void complete(String code, Bitmap bitmap, boolean absent, boolean failed) {
        List<WeakReference<Glyph>> listeners = awaiting.remove(code);
        if (listeners == null || closed) return;
        if (failed) retryAfter = SystemClock.uptimeMillis() + 10_000;
        if (absent) missing.add(code);
        if (bitmap != null) {
            images.put(code, bitmap);
            for (WeakReference<Glyph> listener : listeners) {
                Glyph view = listener.get();
                if (view != null && view.isAttachedToWindow()) view.setBitmap(bitmap);
            }
        }
        if (!deferred.isEmpty()) drainDeferred();
    }

    private void defer(Glyph glyph) {
        for (java.util.Iterator<WeakReference<Glyph>> it = deferred.iterator(); it.hasNext();) {
            Glyph view = it.next().get();
            if (view == null || !view.isAttachedToWindow()) it.remove();
            else if (view == glyph) return;
        }
        if (deferred.size() < 256) deferred.add(new WeakReference<>(glyph));
        if (SystemClock.uptimeMillis() < retryAfter) {
            main.removeCallbacks(retryDeferred);
            main.postAtTime(retryDeferred, retryAfter);
        }
    }

    private void drainDeferred() {
        if (closed || deferred.isEmpty()) return;
        if (SystemClock.uptimeMillis() < retryAfter) {
            main.removeCallbacks(retryDeferred);
            main.postAtTime(retryDeferred, retryAfter);
            return;
        }
        List<WeakReference<Glyph>> pending = new ArrayList<>(deferred);
        deferred.clear();
        for (WeakReference<Glyph> ref : pending) {
            Glyph glyph = ref.get();
            if (glyph != null && glyph.isAttachedToWindow()) load(glyph);
        }
    }

    private static Bitmap fetch(String code) throws IOException {
        HttpURLConnection request = (HttpURLConnection) new URL(FACEBOOK + code + ".png").openConnection();
        try {
            request.setConnectTimeout(1800);
            request.setReadTimeout(1800);
            request.setInstanceFollowRedirects(false);
            int status = request.getResponseCode();
            if (status == 404 || status == 410) return null;
            if (status != 200) throw new IOException("Emoji image HTTP " + status);
            try (InputStream input = request.getInputStream()) { return BitmapFactory.decodeStream(input); }
        } finally { request.disconnect(); }
    }

    void reopen() { if (closed) { closed = false; loader = null; retryAfter = 0; } }

    void close() {
        closed = true;
        session++;
        awaiting.clear();
        deferred.clear();
        main.removeCallbacks(retryDeferred);
        if (loader != null) loader.shutdownNow();
    }

    private static Paint drawPaint(String style) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ColorMatrix matrix = new ColorMatrix();
        switch (style) {
            case "twemoji": case "minimal":
                matrix.setSaturation(1.22f);
                matrix.postConcat(contrast(1.06f));
                break;
            case "rounded": matrix.setSaturation(1.1f); break;
            case "classic":
                matrix.set(new float[]{
                        .90288f, .12304f, .03024f, 0, 0, .05584f, .94976f, .02688f, 0, 0,
                        .04352f, .08544f, .86096f, 0, 0, 0, 0, 0, 1, 0});
                matrix.postConcat(contrast(1.12f));
                break;
            default: return paint;
        }
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        return paint;
    }

    private static ColorMatrix contrast(float amount) {
        float offset = (1 - amount) * 127.5f;
        return new ColorMatrix(new float[]{amount, 0, 0, 0, offset, 0, amount, 0, 0, offset,
                0, 0, amount, 0, offset, 0, 0, 0, 1, 0});
    }

    private final class Glyph extends TextView {
        final String code;
        private final boolean facebook;
        private volatile int generation;
        private float size;
        private final Paint paint;
        private final RectF bounds = new RectF();
        private Bitmap bitmap;
        private Bitmap offlineBitmap;

        Glyph(Context context, String value, float size, String style) {
            super(context);
            code = ImeEmojiCodes.hex(value);
            facebook = "facebook".equals(style);
            this.size = size;
            paint = drawPaint(style);
            setText(value);
            setTypeface(Typeface.DEFAULT);
            setContentDescription(value);
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            int tint = keyboard==null?settingsColor:keyboard.textColor();
            setTextColor(tint | 0xff000000);
            setIncludeFontPadding(true);
            setPadding(0, 0, 0, 0);
            setGravity(Gravity.CENTER);
            setSingleLine(true);
            if ("rounded".equals(style)) setShadowLayer(2, 0, 1, Color.argb(56, 0, 0, 0));
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            generation++;
            loadOffline(this, getContext());
            if (facebook && !code.isEmpty()) load(this);
        }

        @Override protected void onDetachedFromWindow() {
            generation++;
            super.onDetachedFromWindow();
        }

        void setBitmap(Bitmap image) { bitmap = image; invalidate(); }
        void setOfflineBitmap(Bitmap image) { offlineBitmap = image; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            Bitmap image = bitmap != null ? bitmap : offlineBitmap;
            if (image != null) {
                // Fit to the actual cell, including narrow preview or 9-column layouts.
                float edge = Math.min(size, Math.min(getWidth(), getHeight()));
                if (edge <= 0) return;
                float left = (getWidth() - edge) / 2f, top = (getHeight() - edge) / 2f;
                bounds.set(left, top, left + edge, top + edge);
                canvas.drawBitmap(image, null, bounds, paint);
            } else {
                // Never use a filtered saveLayer for platform color glyphs. It can clip or
                // erase their pixels on some devices; show native text until artwork is ready.
                super.onDraw(canvas);
            }
        }
    }
}
