package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;

final class NativeImeEmojiGlyphs {
    private static final String FACEBOOK_DIR = "native-ime/facebook-emoji/";
    private static final String NOTO_DIR = "native-ime/emoji/";
    private final NativeImeView keyboard;
    private final Context context;
    private final NativeImeAppearance appearance;
    private final int settingsColor;
    private static final LruCache<String, Bitmap> images = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getAllocationByteCount(); }
    };
    private static volatile Set<String> facebookCodes;

    NativeImeEmojiGlyphs(NativeImeView keyboard) { this.keyboard = keyboard; context=keyboard.getContext(); appearance=keyboard.appearance; settingsColor=Color.WHITE; }
    NativeImeEmojiGlyphs(Context context, NativeImeAppearance appearance, JSONArray missingCodes, int color) {this.keyboard=null;this.context=context;this.appearance=appearance;this.settingsColor=color;}
    private static Set<String> facebookCodes(Context context) {
        Set<String> current = facebookCodes;
        if (current != null) return current;
        synchronized (NativeImeEmojiGlyphs.class) {
            if (facebookCodes == null) {
                Set<String> found = new HashSet<>();
                try {
                    String[] names = context.getAssets().list("native-ime/facebook-emoji");
                    if (names != null) for (String name : names) if (name.endsWith(".png")) found.add(name.substring(0,name.length()-4));
                } catch (IOException ignored) {}
                facebookCodes = java.util.Collections.unmodifiableSet(found);
            }
            return facebookCodes;
        }
    }
    static int facebookCount(Context context) { return facebookCodes(context).size(); }
    View view(String value, int size, String style) {
        return new Glyph(context, value, appearance.px(size), style);
    }
    void resize(View view, int size) {
        if (view instanceof Glyph) ((Glyph) view).resize(appearance.px(size));
    }
    View view(String value, int size) {
        return view(value, size, keyboard == null ? "system" : keyboard.settings.optString("emojiStyle", "system"));
    }

    // Both settings and the IME read exactly the same packaged artwork, with no network request.
    private static Bitmap localBitmap(Context context, String directory, String code) {
        if (code.isEmpty() || code.length() > 160 || !code.matches("[0-9a-f]+(?:-[0-9a-f]+)*")) return null;
        if (FACEBOOK_DIR.equals(directory) && !facebookCodes(context).contains(code)) return null;
        String key = directory + code;
        Bitmap cached = images.get(key);
        if (cached != null) return cached;
        try (InputStream input = context.getAssets().open(key + ".png")) {
            Bitmap decoded = BitmapFactory.decodeStream(input);
            if (decoded != null) images.put(key, decoded);
            return decoded;
        } catch (IOException | RuntimeException ignored) { return null; }
    }
    private static Bitmap resolve(Context context, String directory, String code) {
        Bitmap image = localBitmap(context, directory, code);
        if (image == null) image = localBitmap(context, directory, ImeEmojiCodes.alternative(code));
        return image;
    }
    void reopen() {} // No network workers to restart.
    void close() {}

    private static ColorMatrixColorFilter styleFilter(String style) {
        ColorMatrix matrix = new ColorMatrix();
        switch (style) {
            case "twemoji": case "minimal":
                matrix.setSaturation(1.22f);
                matrix.postConcat(contrast(1.06f));
                break;
            case "rounded": matrix.setSaturation(1.1f); break;
            case "classic":
                matrix.set(new float[]{
                        .90288f, .12304f, .03024f, 0, 0, .05584f, .94976f, .02688f, 0, 0,
                        .04352f, .08544f, .86096f, 0, 0, 0, 0, 0, 1, 0});
                matrix.postConcat(contrast(1.12f));
                break;
            default: return null;
        }
        return new ColorMatrixColorFilter(matrix);
    }

    private static ColorMatrix contrast(float amount) {
        float offset = (1 - amount) * 127.5f;
        return new ColorMatrix(new float[]{amount, 0, 0, 0, offset, 0, amount, 0, 0, offset,
                0, 0, amount, 0, offset, 0, 0, 0, 1, 0});
    }

    private final class Glyph extends FrameLayout {
        final String code;

        private final ImageView picture;
        private final TextView fallback;

        Glyph(Context context, String value, float size, String style) {
            super(context);
            code = ImeEmojiCodes.hex(value);

            setContentDescription(value);
            setClipChildren(false);
            setClipToPadding(false);
            picture = new ImageView(context);
            picture.setScaleType(ImageView.ScaleType.FIT_CENTER);
            picture.setImageTintList(null);
            picture.setImageAlpha(255);
            picture.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            ColorMatrixColorFilter filter = styleFilter(style);
            if (filter != null) picture.setColorFilter(filter);
            fallback = new TextView(context);
            fallback.setText(value);
            fallback.setTypeface(Typeface.DEFAULT);
            fallback.setTextColor((keyboard == null ? settingsColor : keyboard.textColor()) | 0xff000000);
            fallback.setIncludeFontPadding(true);
            fallback.setPadding(0, 0, 0, 0);
            fallback.setGravity(Gravity.CENTER);
            fallback.setSingleLine(true);
            fallback.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            addView(fallback, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            addView(picture, new FrameLayout.LayoutParams(1, 1, Gravity.CENTER));
            resize(size);
            Bitmap local = "facebook".equals(style) ? resolve(context, FACEBOOK_DIR, code) : null;
            if (local == null) local = resolve(context, NOTO_DIR, code);
            if (local != null) setBitmap(local);
            else picture.setVisibility(View.INVISIBLE);
        }

        void resize(float size) {
            int edge = Math.max(1, Math.round(size));
            picture.setLayoutParams(new FrameLayout.LayoutParams(edge, edge, Gravity.CENTER));
            fallback.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
        }

        void setBitmap(Bitmap image) {
            if (image == null || image.isRecycled() || image.getWidth() <= 0 || image.getHeight() <= 0) return;
            picture.setImageBitmap(image);
            picture.setVisibility(View.VISIBLE);
            fallback.setVisibility(View.INVISIBLE);
        }
    }
}
