package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import org.json.JSONArray;

final class NativeImeEmojiGlyphs {
    private static final String FACEBOOK = "https://cdn.jsdelivr.net/npm/emoji-datasource-facebook@16.0.0/img/facebook/64/";
    private static final int MAX_REQUESTS = 96;
    private final NativeImeView keyboard;
    private final Context context;
    private final NativeImeAppearance appearance;
    private final JSONArray missingCodes;
    private final int settingsColor;
    private final Handler main = new Handler(Looper.getMainLooper());
    // Shared across settings and IME instances; capped at 8 MiB.
    private static final LruCache<String, Bitmap> images = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getAllocationByteCount(); }
    };
    // Bundled, offline-safe emoji artwork is independent from the optional remote style.
    private static final LruCache<String, Bitmap> offlineImages = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getAllocationByteCount(); }
    };
    private final List<WeakReference<Glyph>> deferred = new ArrayList<>();
    private final Runnable retryDeferred = this::drainDeferred;
    private final Set<String> missing = new HashSet<>();
    private final Map<String, List<WeakReference<Glyph>>> awaiting = new HashMap<>();
    private ExecutorService loader;
    private long retryAfter;
    private boolean initialized;
    private boolean closed;
    private int session;

    NativeImeEmojiGlyphs(NativeImeView keyboard) { this.keyboard = keyboard; context=keyboard.getContext(); appearance=keyboard.appearance; missingCodes=null; settingsColor=Color.WHITE; }
    NativeImeEmojiGlyphs(Context context, NativeImeAppearance appearance, JSONArray missingCodes, int color) {this.keyboard=null; this.context=context;this.appearance=appearance;this.missingCodes=missingCodes;this.settingsColor=color;}
    View view(String value, int size, String style) {
        return new Glyph(context, value, appearance.px(size), style);
    }
    void resize(View view, int size) {
        if (view instanceof Glyph) ((Glyph) view).resize(appearance.px(size));
    }
    View view(String value, int size) {
        return view(value, size, keyboard == null ? "system" : keyboard.settings.optString("emojiStyle", "system"));
    }

    // Load only the small, visible 64x64 assets. No attachment or network callback is
    // required before the first frame. ListView creates rows on demand, not all 1,617 cells.
    private static Bitmap localBitmap(Context context, String code) {
        if (code.isEmpty() || code.length() > 160) return null;
        Bitmap cached = offlineImages.get(code);
        if (cached != null) return cached;
        try (InputStream input = context.getAssets().open("native-ime/emoji/" + code + ".png")) {
            Bitmap decoded = BitmapFactory.decodeStream(input);
            if (decoded != null) offlineImages.put(code, decoded);
            return decoded;
        } catch (IOException | RuntimeException ignored) {
            return null;
        }
    }

    private void load(Glyph glyph) {
        if (closed) return;
        if (!initialized) {
            initialized = true;
            JSONArray data = keyboard==null?missingCodes:keyboard.engine.object("media", null).optJSONArray("missingFacebook");
            for (int i = 0; data != null && i < data.length(); i++) {
                String code = data.optString(i);
                missing.add(code);
                if (code.contains("-fe0f")) missing.add(code.replace("-fe0f", ""));
            }
        }
        String code = glyph.code;
        String alternative = ImeEmojiCodes.alternative(code);
        if (missing.contains(code)) {
            code = alternative;
            alternative = "";
        }
        if (code.isEmpty() || missing.contains(code)) return;
        Bitmap cached = images.get(code);
        if (cached != null) { glyph.setBitmap(cached); return; }
        if (SystemClock.uptimeMillis() < retryAfter) { defer(glyph); return; }
        List<WeakReference<Glyph>> pending = awaiting.get(code);
        if (pending != null) {
            for (java.util.Iterator<WeakReference<Glyph>> it = pending.iterator(); it.hasNext();) {
                Glyph view = it.next().get();
                if (view == null || !view.isAttachedToWindow()) it.remove();
                else if (view == glyph) return;
            }
            pending.add(new WeakReference<>(glyph)); return;
        }
        if (awaiting.size() >= MAX_REQUESTS) { defer(glyph); return; }
        pending = new ArrayList<>();
        pending.add(new WeakReference<>(glyph));
        awaiting.put(code, pending);
        if (loader == null) loader = Executors.newFixedThreadPool(3, task -> new Thread(task, "ime-emoji-image"));
        String requested = code;
        String retry = missing.contains(alternative) ? "" : alternative;
        int requestSession = session;
        loader.execute(() -> {
            Bitmap result = null;
            boolean absent = false;
            boolean failed = false;
            try {
                result = fetch(requested);
                if (result == null && !retry.isEmpty()) result = fetch(retry);
                absent = result == null;
            } catch (IOException | RuntimeException error) {
                failed = true;
            }
            Bitmap bitmap = result;
            boolean notFound = absent, unavailable = failed;
            main.post(() -> { if (session == requestSession) complete(requested, bitmap, notFound, unavailable); });
        });
    }

    private void complete(String code, Bitmap bitmap, boolean absent, boolean failed) {
        List<WeakReference<Glyph>> listeners = awaiting.remove(code);
        if (listeners == null || closed) return;
        if (failed) retryAfter = SystemClock.uptimeMillis() + 10_000;
        if (absent) missing.add(code);
        if (bitmap != null) {
            images.put(code, bitmap);
            for (WeakReference<Glyph> listener : listeners) {
                Glyph view = listener.get();
                if (view != null && view.isAttachedToWindow()) view.setBitmap(bitmap);
            }
        }
        if (!deferred.isEmpty()) drainDeferred();
    }

    private void defer(Glyph glyph) {
        for (java.util.Iterator<WeakReference<Glyph>> it = deferred.iterator(); it.hasNext();) {
            Glyph view = it.next().get();
            if (view == null || !view.isAttachedToWindow()) it.remove();
            else if (view == glyph) return;
        }
        if (deferred.size() < 256) deferred.add(new WeakReference<>(glyph));
        if (SystemClock.uptimeMillis() < retryAfter) {
            main.removeCallbacks(retryDeferred);
            main.postAtTime(retryDeferred, retryAfter);
        }
    }

    private void drainDeferred() {
        if (closed || deferred.isEmpty()) return;
        if (SystemClock.uptimeMillis() < retryAfter) {
            main.removeCallbacks(retryDeferred);
            main.postAtTime(retryDeferred, retryAfter);
            return;
        }
        List<WeakReference<Glyph>> pending = new ArrayList<>(deferred);
        deferred.clear();
        for (WeakReference<Glyph> ref : pending) {
            Glyph glyph = ref.get();
            if (glyph != null && glyph.isAttachedToWindow()) load(glyph);
        }
    }

    private static Bitmap fetch(String code) throws IOException {
        HttpURLConnection request = (HttpURLConnection) new URL(FACEBOOK + code + ".png").openConnection();
        try {
            request.setConnectTimeout(1800);
            request.setReadTimeout(1800);
            request.setInstanceFollowRedirects(false);
            int status = request.getResponseCode();
            if (status == 404 || status == 410) return null;
            if (status != 200) throw new IOException("Emoji image HTTP " + status);
            try (InputStream input = request.getInputStream()) {
                Bitmap image = BitmapFactory.decodeStream(input);
                // A missing/transparent CDN image must not replace the visible local artwork.
                if (image == null || image.getWidth() > 256 || image.getHeight() > 256) return null;
                for (int y = 0; y < image.getHeight(); y++) {
                    for (int x = 0; x < image.getWidth(); x++) {
                        if (Color.alpha(image.getPixel(x, y)) > 0) return image;
                    }
                }
                return null;
            }
        } finally { request.disconnect(); }
    }

    void reopen() { if (closed) { closed = false; loader = null; retryAfter = 0; } }

    void close() {
        closed = true;
        session++;
        awaiting.clear();
        deferred.clear();
        main.removeCallbacks(retryDeferred);
        if (loader != null) loader.shutdownNow();
    }

    private static ColorMatrixColorFilter styleFilter(String style) {
        ColorMatrix matrix = new ColorMatrix();
        switch (style) {
            case "twemoji": case "minimal":
                matrix.setSaturation(1.22f);
                matrix.postConcat(contrast(1.06f));
                break;
            case "rounded": matrix.setSaturation(1.1f); break;
            case "classic":
                matrix.set(new float[]{
                        .90288f, .12304f, .03024f, 0, 0, .05584f, .94976f, .02688f, 0, 0,
                        .04352f, .08544f, .86096f, 0, 0, 0, 0, 0, 1, 0});
                matrix.postConcat(contrast(1.12f));
                break;
            default: return null;
        }
        return new ColorMatrixColorFilter(matrix);
    }

    private static ColorMatrix contrast(float amount) {
        float offset = (1 - amount) * 127.5f;
        return new ColorMatrix(new float[]{amount, 0, 0, 0, offset, 0, amount, 0, 0, offset,
                0, 0, amount, 0, offset, 0, 0, 0, 1, 0});
    }

    private final class Glyph extends FrameLayout {
        final String code;
        private final boolean facebook;
        private final ImageView picture;
        private final TextView fallback;

        Glyph(Context context, String value, float size, String style) {
            super(context);
            code = ImeEmojiCodes.hex(value);
            facebook = "facebook".equals(style);
            setContentDescription(value);
            setClipChildren(false);
            setClipToPadding(false);
            picture = new ImageView(context);
            picture.setScaleType(ImageView.ScaleType.FIT_CENTER);
            picture.setImageTintList(null);
            picture.setImageAlpha(255);
            picture.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            ColorMatrixColorFilter filter = styleFilter(style);
            if (filter != null) picture.setColorFilter(filter);
            fallback = new TextView(context);
            fallback.setText(value);
            fallback.setTypeface(Typeface.DEFAULT);
            fallback.setTextColor((keyboard == null ? settingsColor : keyboard.textColor()) | 0xff000000);
            fallback.setIncludeFontPadding(true);
            fallback.setPadding(0, 0, 0, 0);
            fallback.setGravity(Gravity.CENTER);
            fallback.setSingleLine(true);
            fallback.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            addView(fallback, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            addView(picture, new FrameLayout.LayoutParams(1, 1, Gravity.CENTER));
            resize(size);
            // Apply the bitmap before this view is attached, even if the CDN is offline.
            Bitmap local = localBitmap(context, code);
            if (local == null) {
                String alternate = ImeEmojiCodes.alternative(code);
                if (!alternate.isEmpty()) local = localBitmap(context, alternate);
            }
            if (local != null) setBitmap(local);
            else picture.setVisibility(View.INVISIBLE);
        }

        void resize(float size) {
            int edge = Math.max(1, Math.round(size));
            picture.setLayoutParams(new FrameLayout.LayoutParams(edge, edge, Gravity.CENTER));
            fallback.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (facebook && !code.isEmpty()) load(this);
        }

        void setBitmap(Bitmap image) {
            if (image == null || image.isRecycled() || image.getWidth() <= 0 || image.getHeight() <= 0) return;
            picture.setImageBitmap(image);
            picture.setVisibility(View.VISIBLE);
            fallback.setVisibility(View.INVISIBLE);
        }
    }
}
