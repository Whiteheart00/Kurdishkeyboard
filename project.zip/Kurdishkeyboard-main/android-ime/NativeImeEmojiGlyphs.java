package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import org.json.JSONArray;

final class NativeImeEmojiGlyphs {
    private static final String FACEBOOK = "https://cdn.jsdelivr.net/npm/emoji-datasource-facebook@16.0.0/img/facebook/64/";
    private static final int MAX_REQUESTS = 96;
    private final NativeImeView keyboard;
    private final Context context;
    private final NativeImeAppearance appearance;
    private final JSONArray missingCodes;
    private final int settingsColor;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> images = new LruCache<>(96);
    private final Set<String> missing = new HashSet<>();
    private final Map<String, List<WeakReference<Glyph>>> awaiting = new HashMap<>();
    private ExecutorService loader;
    private long retryAfter;
    private boolean initialized;
    private boolean closed;

    NativeImeEmojiGlyphs(NativeImeView keyboard) { this.keyboard = keyboard; context=keyboard.getContext(); appearance=keyboard.appearance; missingCodes=null; settingsColor=Color.WHITE; }
    NativeImeEmojiGlyphs(Context context, NativeImeAppearance appearance, JSONArray missingCodes, int color) {this.keyboard=null; this.context=context;this.appearance=appearance;this.missingCodes=missingCodes;this.settingsColor=color;}
    TextView view(String value, int size, String style) {return new Glyph(context,value,appearance.px(size),style);}
    void resize(TextView view,int size){if(view instanceof Glyph){Glyph glyph=(Glyph)view;glyph.size=appearance.px(size);glyph.setTextSize(TypedValue.COMPLEX_UNIT_PX,glyph.size);glyph.invalidate();}}


    TextView view(String value, int size) {
        return view(value,size,keyboard.settings.optString("emojiStyle", "system"));
    }

    private void load(Glyph glyph) {
        if (closed) return;
        if (!initialized) {
            initialized = true;
            JSONArray data = keyboard==null?missingCodes:keyboard.engine.object("media", null).optJSONArray("missingFacebook");
            for (int i = 0; data != null && i < data.length(); i++) {
                String code = data.optString(i);
                missing.add(code);
                missing.add(code.replace("-fe0f", ""));
            }
        }
        String code = glyph.code;
        String alternative = code.contains("-fe0f") ? code.replace("-fe0f", "")
                : code.length() == 4 ? code + "-fe0f" : "";
        if (missing.contains(code)) {
            code = alternative;
            alternative = "";
        }
        if (code.isEmpty() || missing.contains(code)) return;
        Bitmap cached = images.get(code);
        if (cached != null) { glyph.setBitmap(cached); return; }
        if (SystemClock.uptimeMillis() < retryAfter) return;
        List<WeakReference<Glyph>> pending = awaiting.get(code);
        if (pending != null) { pending.add(new WeakReference<>(glyph)); return; }
        if (awaiting.size() >= MAX_REQUESTS) return;
        pending = new ArrayList<>();
        pending.add(new WeakReference<>(glyph));
        awaiting.put(code, pending);
        if (loader == null) loader = Executors.newFixedThreadPool(3, task -> new Thread(task, "ime-emoji-image"));
        String requested = code;
        String retry = missing.contains(alternative) ? "" : alternative;
        loader.execute(() -> {
            Bitmap result = null;
            boolean absent = false;
            boolean failed = false;
            try {
                result = fetch(requested);
                if (result == null && !retry.isEmpty()) result = fetch(retry);
                absent = result == null;
            } catch (IOException | RuntimeException error) {
                failed = true;
            }
            Bitmap bitmap = result;
            boolean notFound = absent, unavailable = failed;
            main.post(() -> complete(requested, bitmap, notFound, unavailable));
        });
    }

    private void complete(String code, Bitmap bitmap, boolean absent, boolean failed) {
        List<WeakReference<Glyph>> listeners = awaiting.remove(code);
        if (listeners == null || closed) return;
        if (failed) retryAfter = SystemClock.uptimeMillis() + 10_000;
        if (absent) missing.add(code);
        if (bitmap == null) return;
        images.put(code, bitmap);
        for (WeakReference<Glyph> listener : listeners) {
            Glyph view = listener.get();
            if (view != null && view.isAttachedToWindow()) view.setBitmap(bitmap);
        }
    }

    private static Bitmap fetch(String code) throws IOException {
        HttpURLConnection request = (HttpURLConnection) new URL(FACEBOOK + code + ".png").openConnection();
        try {
            request.setConnectTimeout(1800);
            request.setReadTimeout(1800);
            request.setInstanceFollowRedirects(false);
            int status = request.getResponseCode();
            if (status == 404 || status == 410) return null;
            if (status != 200) throw new IOException("Emoji image HTTP " + status);
            try (InputStream input = request.getInputStream()) { return BitmapFactory.decodeStream(input); }
        } finally { request.disconnect(); }
    }

    void close() {
        closed = true;
        awaiting.clear();
        images.evictAll();
        if (loader != null) loader.shutdownNow();
    }

    private static String hex(String text) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < text.length();) {
            int cp = text.codePointAt(index);
            if (builder.length() != 0) builder.append('-');
            builder.append(String.format(Locale.ROOT, "%04x", cp));
            index += Character.charCount(cp);
        }
        return builder.toString();
    }

    private static Paint drawPaint(String style) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ColorMatrix matrix = new ColorMatrix();
        switch (style) {
            case "twemoji": case "minimal":
                matrix.setSaturation(1.22f);
                matrix.postConcat(contrast(1.06f));
                break;
            case "rounded": matrix.setSaturation(1.1f); break;
            case "classic":
                matrix.set(new float[]{
                        .9029f, .1230f, .0302f, 0, 0, .0558f, .9498f, .0269f, 0, 0,
                        .0435f, .0854f, .8610f, 0, 0, 0, 0, 0, 1, 0});
                matrix.postConcat(contrast(1.12f));
                break;
            default: return paint;
        }
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        return paint;
    }

    private static ColorMatrix contrast(float amount) {
        float offset = (1 - amount) * 127.5f;
        return new ColorMatrix(new float[]{amount, 0, 0, 0, offset, 0, amount, 0, 0, offset,
                0, 0, amount, 0, offset, 0, 0, 0, 1, 0});
    }

    private final class Glyph extends TextView {
        final String code;
        private float size;
        private final Paint paint;
        private final RectF bounds = new RectF();
        private Bitmap bitmap;

        Glyph(Context context, String value, float size, String style) {
            super(context);
            code = "facebook".equals(style) ? hex(value) : "";
            this.size = size;
            paint = drawPaint(style);
            setText(value);
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            setTextColor(keyboard==null?settingsColor:keyboard.textColor());
            setIncludeFontPadding(false);
            setPadding(0, 0, 0, 0);
            setGravity(Gravity.CENTER);
            setSingleLine(true);
            if ("rounded".equals(style)) setShadowLayer(2, 0, 1, Color.argb(56, 0, 0, 0));
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (!code.isEmpty()) load(this);
        }

        void setBitmap(Bitmap image) { bitmap = image; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            if (bitmap != null) {
                float left = (getWidth() - size) / 2f, top = (getHeight() - size) / 2f;
                bounds.set(left, top, left + size, top + size);
                canvas.drawBitmap(bitmap, null, bounds, paint);
            } else if (paint.getColorFilter() != null) {
                int layer = canvas.saveLayer(0, 0, getWidth(), getHeight(), paint);
                super.onDraw(canvas);
                canvas.restoreToCount(layer);
            } else super.onDraw(canvas);
        }
    }
}
