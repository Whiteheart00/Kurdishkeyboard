package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Native layout arrangement editor matching the original Kurdish keyboard UI:
 * - Letters / Symbols tabs
 * - Number row
 * - Live keyboard preview with Drag / Edit / Select modes
 * - Bottom-row style sub-screen
 * - Save / Reset
 */
final class NativeLayoutEditorView extends LinearLayout {
    private static final int ACCENT = 0xffa4c9ff;
    private static final int ACCENT_SOFT = 0xff1d2838;
    private static final int SAVE_BLUE = 0xff8eb8ff;
    private static final int SAVE_INK = 0xff0b1f3d;
    private static final int WARN_BG = 0x22c4a484;
    private static final int WARN_BORDER = 0x55c4a484;
    private static final int WARN_TEXT = 0xffd4b89a;
    private static final int TEAL = 0xff2dd4bf;
    private static final int DANGER = 0xfff87171;
    private static final int MUTED = 0xff9ca3af;

    private static final String[] DEFAULT_NUMBERS = {"1","2","3","4","5","6","7","8","9","0"};
    private static final String[] DEFAULT_QWERTY = {
            "q","w","e","r","t","y","u","i","o","p",
            "a","s","d","f","g","h","j","k","l",
            "z","x","c","v","b","n","m"
    };
    private static final String[] SYMBOL_ROW1 = {"1","2","3","4","5","6","7","8","9","0"};
    private static final String[] SYMBOL_ROW2 = {"@","#","$","%","&","-","+","(",")"};
    private static final String[] SYMBOL_ROW3 = {"*","\"","'",":",";","!","?",",","."};
    private static final String[] EXTRA_POOL = {
            "ئ","ڤ","ڕ","ڵ","ۆ","وو","ێ","ە","ح","ع","غ","ص","ض","ط","ظ","ث","ذ","أ","إ","آ",
            "!","؟","،",".",":",";","«","»","(",")","[","]","{","}","@","#","$","%","&","*","/","\\","-","_"
    };
    private static final String[] BOTTOM_AVAILABLE = {
            "هێماکان 123?","فاریزە ،","نیشانەی سەرسوڕمان !","گەڕانی دەنگی","لەبەرگیراوەکان",
            "ڕێکخستنەکان","دواتر","پێشوو","گۆڕینی زمان","خەندە","ناردن","سڕینەوە"
    };
    private static final String[] BOTTOM_DEFAULT = {"گۆڕینی زمان",".","بۆشایی","خەندە","ناردن"};

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int surface;
    private final int surfaceAlt;
    private final int border;
    private final int pageBg;

    private final FrameLayout rootHost;
    private final LinearLayout mainPage;
    private final LinearLayout bottomPage;
    // View references are assigned by buildMainPage/buildBottomPage during construction.
    private LinearLayout lettersTab;
    private LinearLayout symbolsTab;
    private TextView lettersTabText;
    private TextView symbolsTabText;
    private LinearLayout numbersRow;
    private LinearLayout keyboardHost;
    private TextView layoutTitle;
    private TextView layoutMeta;
    private TextView modeDrag;
    private TextView modeEdit;
    private TextView modeSelect;
    private TextView saveBtn;
    private LinearLayout bottomPreviewRow;
    private LinearLayout bottomAvailableHost;
    private Switch moveDownSwitch;

    private final Map<String, JSONArray> savedLayouts = new HashMap<>();
    private final List<List<String>> letterRows = new ArrayList<>();
    private final List<List<String>> symbolRows = new ArrayList<>();
    private final List<String> numbers = new ArrayList<>(Arrays.asList(DEFAULT_NUMBERS));
    private final List<String> bottomKeys = new ArrayList<>(Arrays.asList(BOTTOM_DEFAULT));
    private final List<JSONObject> languages = new ArrayList<>();

    private JSONObject language;
    private String layoutId = "qwerty";
    private String layoutName = "QWERTY";
    private boolean showingLetters = true;
    private int editMode = 0; // 0 drag, 1 edit, 2 select
    private int selectedR = -1, selectedC = -1;
    private String selectedExtra;
    private final Runnable clearSave = this::resetSaveLabel;

    NativeLayoutEditorView(Context context, String theme, String font, JSONObject data, Runnable back,
                           NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        pageBg = light ? 0xfff1f5f9 : 0xff0a0b0e;
        surface = light ? Color.WHITE : 0xff12141a;
        surfaceAlt = light ? 0xffeef2f7 : 0xff181b22;
        border = light ? 0xffe2e8f0 : 0x22ffffff;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(pageBg);

        // Header
        LinearLayout header = row();
        header.setPadding(dp(12), dp(8), dp(12), dp(8));
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView backBtn = pill("←", 20, foreground, surfaceAlt, 20);
        header.addView(backBtn, new LayoutParams(dp(40), dp(40)));
        TextView title = label("دەستکاریکردنی ڕیزبەندی", 17, foreground);
        title.setGravity(Gravity.CENTER);
        LayoutParams titleLp = new LayoutParams(0, -2, 1);
        header.addView(title, titleLp);
        header.addView(spacer(40), new LayoutParams(dp(40), dp(40)));
        addView(header, new LayoutParams(-1, dp(56)));

        rootHost = new FrameLayout(context);
        addView(rootHost, new LayoutParams(-1, 0, 1));

        mainPage = column();
        bottomPage = column();
        bottomPage.setVisibility(GONE);
        rootHost.addView(mainPage, new FrameLayout.LayoutParams(-1, -1));
        rootHost.addView(bottomPage, new FrameLayout.LayoutParams(-1, -1));

        backBtn.setOnClickListener(v -> {
            if (bottomPage.getVisibility() == VISIBLE) showMain();
            else back.run();
        });

        buildMainPage(data);
        buildBottomPage();
        loadFromData(data);
        renderKeyboard();
        paintTabs();
        paintModes();
    }

    private void buildMainPage(JSONObject data) {
        ScrollView scroll = new ScrollView(getContext());
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        mainPage.addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(14), dp(6), dp(14), dp(18));
        scroll.addView(body);

        // Tabs: هێماکان | پیتەکان
        LinearLayout tabs = row();
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(appearance.background(surfaceAlt, 22, 0, 0));
        symbolsTab = tabChip("هێماکان", false);
        lettersTab = tabChip("پیتەکان", true);
        symbolsTabText = (TextView) symbolsTab.getChildAt(0);
        lettersTabText = (TextView) lettersTab.getChildAt(0);
        symbolsTab.setOnClickListener(v -> { showingLetters = false; selectedR = selectedC = -1; paintTabs(); renderKeyboard(); });
        lettersTab.setOnClickListener(v -> { showingLetters = true; selectedR = selectedC = -1; paintTabs(); renderKeyboard(); });
        LayoutParams half = new LayoutParams(0, dp(40), 1);
        tabs.addView(symbolsTab, half);
        tabs.addView(lettersTab, half);
        append(body, tabs, 0);

        // Number row
        numbersRow = row();
        numbersRow.setPadding(0, dp(10), 0, dp(4));
        numbersRow.setGravity(Gravity.CENTER);
        append(body, numbersRow, 8);

        // Hint
        TextView hint = label("⋮⋮  دەست لەسەر پیت یان هێمایەک ڕاگرە و ڕایکێشە بۆ ناو کیبۆردەکە بۆ زیادکردن", 11, MUTED);
        hint.setPadding(dp(4), 0, dp(4), 0);
        append(body, hint, 6);

        // Layout info card
        LinearLayout info = card(surface, 20);
        LinearLayout infoTop = row();
        infoTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView reset = pill("↻", 18, DANGER, 0x33ef4444, 22);
        reset.setOnClickListener(v -> resetLayout());
        infoTop.addView(reset, new LayoutParams(dp(44), dp(44)));
        LinearLayout mid = column();
        mid.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        layoutTitle = label("QWERTY", 16, foreground);
        layoutTitle.setTypeface(layoutTitle.getTypeface(), Typeface.BOLD);
        layoutMeta = label("3 ڕیز · 26 دوگمە", 11, MUTED);
        mid.addView(layoutTitle);
        mid.addView(layoutMeta);
        LayoutParams midLp = new LayoutParams(0, -2, 1);
        midLp.setMarginEnd(dp(10));
        infoTop.addView(mid, midLp);
        TextView kbIcon = pill("⌨", 16, ACCENT, ACCENT_SOFT, 12);
        infoTop.addView(kbIcon, new LayoutParams(dp(40), dp(40)));
        append(info, infoTop, 0);

        TextView warn = label("هەر گۆڕانکارییەک لێرەدا ئەنجام بدەیت تەنها بۆ ئەم زمان و شێوازە دەستکاریکراوە پاشەکەوت دەبێت!", 11, WARN_TEXT);
        warn.setPadding(dp(12), dp(10), dp(12), dp(10));
        warn.setBackground(appearance.background(WARN_BG, 14, 1, WARN_BORDER));
        append(info, warn, 12);
        append(body, info, 12);

        // Keyboard preview card
        LinearLayout kbCard = card(surface, 22);
        keyboardHost = column();
        keyboardHost.setPadding(dp(6), dp(8), dp(6), dp(8));
        append(kbCard, keyboardHost, 0);

        // Mode chips
        LinearLayout modes = row();
        modes.setGravity(Gravity.CENTER);
        modeDrag = modeChip("⋮⋮  ڕاکێشان");
        modeEdit = modeChip("✎  دەستکاری");
        modeSelect = modeChip("☝  دیاریکردن");
        modeDrag.setOnClickListener(v -> { editMode = 0; paintModes(); });
        modeEdit.setOnClickListener(v -> { editMode = 1; paintModes(); });
        modeSelect.setOnClickListener(v -> { editMode = 2; paintModes(); selectedR = selectedC = -1; renderKeyboard(); });
        LayoutParams modeLp = new LayoutParams(0, dp(40), 1);
        modeLp.setMarginStart(dp(4));
        modes.addView(modeDrag, modeLp);
        modes.addView(modeEdit, modeLp);
        modes.addView(modeSelect, modeLp);
        append(kbCard, modes, 10);

        TextView tip = label("ⓘ  زانیاری: پەنجە بدە لە دوگمەکان بۆ بینینی ڕێنمایی تایبەت بە خۆیان", 10, MUTED);
        tip.setPadding(dp(4), 0, dp(4), 0);
        append(kbCard, tip, 8);
        append(body, kbCard, 12);

        // Bottom row style entry
        LinearLayout bottomEntry = row();
        bottomEntry.setPadding(dp(14), dp(14), dp(14), dp(14));
        bottomEntry.setBackground(appearance.background(surface, 18, 1, border));
        bottomEntry.setGravity(Gravity.CENTER_VERTICAL);
        TextView chevron = pill("‹", 18, foreground, surfaceAlt, 16);
        bottomEntry.addView(chevron, new LayoutParams(dp(36), dp(36)));
        LinearLayout bottomCopy = column();
        TextView bottomTitle = label("شێوازی بەشی خوارەوە", 14, foreground);
        TextView bottomDesc = label("ڕێکخستنی شوێن و قەبارەی دوگمەکان", 11, MUTED);
        bottomCopy.addView(bottomTitle);
        bottomCopy.addView(bottomDesc);
        LayoutParams bcLp = new LayoutParams(0, -2, 1);
        bcLp.setMarginStart(dp(10));
        bottomEntry.addView(bottomCopy, bcLp);
        TextView bottomIcon = pill("▭", 14, SAVE_INK, SAVE_BLUE, 12);
        bottomEntry.addView(bottomIcon, new LayoutParams(dp(40), dp(40)));
        bottomEntry.setOnClickListener(v -> showBottom());
        append(body, bottomEntry, 12);

        // Extra keys pool
        LinearLayout pool = card(surface, 18);
        append(pool, label("پیت و هێما زیادەکان — کرتە یان ڕاکێشان بۆ زیادکردن", 11, ACCENT), 0);
        LinearLayout extras = row();
        extras.setPadding(0, dp(4), 0, 0);
        for (int i = 0; i < EXTRA_POOL.length; i++) {
            final String ch = EXTRA_POOL[i];
            TextView key = keyFace(ch, 13, false);
            key.setOnClickListener(v -> {
                selectedExtra = ch;
                if (selectedR >= 0) applyExtraToSelected();
            });
            LayoutParams lp = new LayoutParams(dp(40), dp(40));
            lp.setMarginStart(dp(i == 0 ? 0 : 6));
            extras.addView(key, lp);
        }
        append(pool, horizontal(extras), 10);
        append(body, pool, 12);

        // Language chips
        LinearLayout langRow = row();
        JSONArray langs = data != null ? data.optJSONArray("languages") : null;
        if (langs != null) {
            for (int i = 0; i < langs.length(); i++) {
                JSONObject lang = langs.optJSONObject(i);
                if (lang == null) continue;
                languages.add(lang);
                final JSONObject pick = lang;
                TextView chip = pill(lang.optString("nativeName", lang.optString("code")), 12, foreground, surfaceAlt, 14);
                chip.setPadding(dp(12), 0, dp(12), 0);
                chip.setOnClickListener(v -> selectLanguage(pick));
                LayoutParams lp = new LayoutParams(-2, dp(36));
                lp.setMarginStart(dp(i == 0 ? 0 : 8));
                langRow.addView(chip, lp);
            }
        }
        if (!languages.isEmpty()) append(body, horizontal(langRow), 8);

        // Sticky save
        saveBtn = pill("💾  پاشەکەوتکردنی گۆڕانکارییەکان", 14, SAVE_INK, SAVE_BLUE, 18);
        saveBtn.setOnClickListener(v -> save());
        LinearLayout saveWrap = column();
        saveWrap.setPadding(dp(14), dp(8), dp(14), dp(14));
        saveWrap.setBackgroundColor(pageBg);
        append(saveWrap, saveBtn, 0, 52);
        mainPage.addView(saveWrap, new LayoutParams(-1, -2));
    }

    private void buildBottomPage() {
        ScrollView scroll = new ScrollView(getContext());
        scroll.setVerticalScrollBarEnabled(false);
        bottomPage.addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(14), dp(8), dp(14), dp(24));
        scroll.addView(body);

        // Replace header title when on bottom page is handled by showBottom/showMain via back button

        // Teal banner
        LinearLayout banner = row();
        banner.setPadding(dp(16), dp(16), dp(16), dp(16));
        banner.setBackground(appearance.background(TEAL, 20, 0, 0));
        banner.setGravity(Gravity.CENTER_VERTICAL);
        TextView bannerIcon = text("☝", 28, 0xff0f766e);
        banner.addView(bannerIcon, new LayoutParams(dp(48), dp(48)));
        LinearLayout bannerCopy = column();
        TextView bannerTitle = label("تەختەکلیل هەڵنەبژێردراوە!", 15, 0xff042f2e);
        bannerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        TextView bannerDesc = label("پێویستە تەختەکلیل هەڵبژێریت بۆ نووسین", 12, 0xff134e4a);
        bannerCopy.addView(bannerTitle);
        bannerCopy.addView(bannerDesc);
        LayoutParams bcl = new LayoutParams(0, -2, 1);
        bcl.setMarginStart(dp(10));
        banner.addView(bannerCopy, bcl);
        TextView bannerBack = pill("‹", 18, 0xff042f2e, 0x33042f2e, 14);
        bannerBack.setOnClickListener(v -> showMain());
        banner.addView(bannerBack, new LayoutParams(dp(36), dp(36)));
        append(body, banner, 0);

        // Help card
        TextView help = label("کەمێک دەست ڕاگرە و بیجوڵێنە بۆ لای ڕاست یان چەپ بۆ گۆڕینی شوێن، پەنجەی یەکدا بنێ بۆ گۆڕینی قەبارەکەی", 11, MUTED);
        help.setPadding(dp(14), dp(12), dp(14), dp(12));
        help.setBackground(appearance.background(surface, 16, 1, border));
        append(body, help, 12);

        // Bottom row preview
        LinearLayout previewCard = card(surface, 18);
        bottomPreviewRow = row();
        bottomPreviewRow.setGravity(Gravity.CENTER_VERTICAL);
        append(previewCard, bottomPreviewRow, 0);
        append(body, previewCard, 12);
        renderBottomPreview();

        // Available keys
        LinearLayout availCard = card(surface, 18);
        LinearLayout availHead = row();
        availHead.addView(label("دوگمە بەردەستەکان", 13, ACCENT), new LayoutParams(0, -2, 1));
        availHead.addView(label("+", 18, ACCENT), new LayoutParams(dp(28), dp(28)));
        append(availCard, availHead, 0);
        bottomAvailableHost = column();
        append(availCard, bottomAvailableHost, 10);
        renderBottomAvailable();
        append(body, availCard, 12);

        // Reset default
        TextView resetDefault = pill("↻  گێڕانەوە بۆ بنەڕەتی", 13, WARN_TEXT, 0x22c4a484, 16);
        resetDefault.setOnClickListener(v -> {
            bottomKeys.clear();
            bottomKeys.addAll(Arrays.asList(BOTTOM_DEFAULT));
            renderBottomPreview();
            renderBottomAvailable();
            change.accept("bottomRowPreset", "default");
        });
        append(body, resetDefault, 8, 48);

        // Move down toggle
        LinearLayout toggleCard = row();
        toggleCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        toggleCard.setBackground(appearance.background(surface, 16, 1, border));
        toggleCard.setGravity(Gravity.CENTER_VERTICAL);
        moveDownSwitch = new Switch(getContext());
        if (Build.VERSION.SDK_INT >= 31) {
            try { moveDownSwitch.setThumbTintList(android.content.res.ColorStateList.valueOf(SAVE_BLUE)); } catch (Throwable ignored) {}
        }
        toggleCard.addView(moveDownSwitch, new LayoutParams(-2, -2));
        LinearLayout toggleCopy = column();
        toggleCopy.addView(label("گواستنەوە بۆ خوارەوە", 13, foreground));
        toggleCopy.addView(label("دوگمەی ئیمۆجی و زمان بگۆڕە بۆ ژێر تەختەکلیل", 11, MUTED));
        LayoutParams tcl = new LayoutParams(0, -2, 1);
        tcl.setMarginStart(dp(10));
        toggleCard.addView(toggleCopy, tcl);
        TextView toggleIcon = text("↓", 20, MUTED);
        toggleCard.addView(toggleIcon, new LayoutParams(dp(28), dp(28)));
        moveDownSwitch.setOnCheckedChangeListener((b, on) -> change.accept("emojiLanguageBottom", String.valueOf(on)));
        append(body, toggleCard, 12);
    }

    private void showMain() {
        bottomPage.setVisibility(GONE);
        mainPage.setVisibility(VISIBLE);
    }

    private void showBottom() {
        mainPage.setVisibility(GONE);
        bottomPage.setVisibility(VISIBLE);
        renderBottomPreview();
        renderBottomAvailable();
    }

    private void loadFromData(JSONObject data) {
        if (data == null) {
            setDefaultLetters();
            setDefaultSymbols();
            return;
        }
        JSONArray langs = data.optJSONArray("languages");
        if (langs != null && langs.length() > 0) {
            language = langs.optJSONObject(0);
            for (int i = 0; i < langs.length(); i++) {
                JSONObject l = langs.optJSONObject(i);
                if (l != null && l.optBoolean("active")) language = l;
            }
        }
        if (language == null) language = new JSONObject();
        layoutId = language.optString("layout", language.optString("characterLayoutId", "qwerty"));
        layoutName = language.optString("layoutName", layoutId.toUpperCase());
        layoutTitle.setText(layoutName.isEmpty() ? layoutId.toUpperCase() : layoutName);

        JSONArray rows = data.optJSONArray("rows");
        if (rows == null) rows = language.optJSONArray("rows");
        letterRows.clear();
        if (rows != null && rows.length() > 0) {
            for (int r = 0; r < rows.length(); r++) {
                JSONArray row = rows.optJSONArray(r);
                List<String> line = new ArrayList<>();
                if (row != null) for (int c = 0; c < row.length(); c++) line.add(row.optString(c));
                if (!line.isEmpty()) letterRows.add(line);
            }
        }
        if (letterRows.isEmpty()) setDefaultLetters();
        setDefaultSymbols();
        updateMeta();
    }

    private void setDefaultLetters() {
        letterRows.clear();
        letterRows.add(new ArrayList<>(Arrays.asList("q","w","e","r","t","y","u","i","o","p")));
        letterRows.add(new ArrayList<>(Arrays.asList("a","s","d","f","g","h","j","k","l")));
        letterRows.add(new ArrayList<>(Arrays.asList("z","x","c","v","b","n","m")));
    }

    private void setDefaultSymbols() {
        symbolRows.clear();
        symbolRows.add(new ArrayList<>(Arrays.asList(SYMBOL_ROW1)));
        symbolRows.add(new ArrayList<>(Arrays.asList(SYMBOL_ROW2)));
        symbolRows.add(new ArrayList<>(Arrays.asList(SYMBOL_ROW3)));
    }

    private void selectLanguage(JSONObject lang) {
        language = lang;
        layoutId = lang.optString("layout", lang.optString("characterLayoutId", "qwerty"));
        layoutName = lang.optString("layoutName", layoutId.toUpperCase());
        layoutTitle.setText(layoutName.isEmpty() ? layoutId.toUpperCase() : layoutName);
        JSONArray cached = savedLayouts.get(layoutId);
        if (cached != null) {
            letterRows.clear();
            for (int r = 0; r < cached.length(); r++) {
                JSONArray row = cached.optJSONArray(r);
                List<String> line = new ArrayList<>();
                if (row != null) for (int c = 0; c < row.length(); c++) line.add(row.optString(c));
                letterRows.add(line);
            }
        } else {
            setDefaultLetters();
        }
        selectedR = selectedC = -1;
        updateMeta();
        renderKeyboard();
    }

    private void updateMeta() {
        int keys = 0;
        for (List<String> row : letterRows) keys += row.size();
        layoutMeta.setText(letterRows.size() + " ڕیز · " + keys + " دوگمە");
    }

    private void renderKeyboard() {
        keyboardHost.removeAllViews();
        numbersRow.removeAllViews();

        // Numbers always visible for letters tab
        List<String> nums = showingLetters ? numbers : new ArrayList<>(Arrays.asList(SYMBOL_ROW1));
        for (int i = 0; i < nums.size(); i++) {
            final int idx = i;
            final String ch = nums.get(i);
            TextView key = keyFace(ch, 15, false);
            key.setOnClickListener(v -> onNumberClick(idx, ch));
            LayoutParams lp = new LayoutParams(0, dp(42), 1);
            lp.setMarginStart(dp(i == 0 ? 0 : 4));
            numbersRow.addView(key, lp);
        }

        List<List<String>> rows = showingLetters ? letterRows : symbolRows;
        for (int r = 0; r < rows.size(); r++) {
            LinearLayout line = row();
            line.setGravity(Gravity.CENTER);
            List<String> cols = rows.get(r);
            // Shift-like spacer on last letter row
            if (showingLetters && r == rows.size() - 1) {
                TextView shift = keyFace("⇧", 14, true);
                LayoutParams slp = new LayoutParams(0, dp(46), 1.4f);
                line.addView(shift, slp);
            }
            for (int c = 0; c < cols.size(); c++) {
                final int rr = r, cc = c;
                final String ch = cols.get(c);
                boolean sel = selectedR == rr && selectedC == cc;
                TextView key = keyFace(ch, 15, sel);
                key.setOnClickListener(v -> onKeyClick(rr, cc));
                key.setOnLongClickListener(v -> {
                    if (editMode == 0) {
                        selectedR = rr;
                        selectedC = cc;
                        renderKeyboard();
                        return true;
                    }
                    return false;
                });
                LayoutParams lp = new LayoutParams(0, dp(46), 1);
                lp.setMarginStart(dp(c == 0 && !(showingLetters && r == rows.size() - 1) ? 0 : 4));
                line.addView(key, lp);
            }
            if (showingLetters && r == rows.size() - 1) {
                TextView del = keyFace("⌫", 14, true);
                LayoutParams dlp = new LayoutParams(0, dp(46), 1.4f);
                dlp.setMarginStart(dp(4));
                line.addView(del, dlp);
            }
            // Bottom functional row preview on last
            append(keyboardHost, line, r == 0 ? 0 : 6, 46);
        }

        // Fake bottom functional row for visual parity
        LinearLayout bottom = row();
        bottom.setGravity(Gravity.CENTER);
        String[] fake = {"🌐", ".", "Space", "☺", "↵"};
        float[] weights = {1.1f, 1f, 3.2f, 1.1f, 1.3f};
        for (int i = 0; i < fake.length; i++) {
            TextView key = keyFace(fake[i], "Space".equals(fake[i]) ? 13 : 14, true);
            LayoutParams lp = new LayoutParams(0, dp(46), weights[i]);
            lp.setMarginStart(dp(i == 0 ? 0 : 4));
            bottom.addView(key, lp);
        }
        append(keyboardHost, bottom, 6, 46);
        updateMeta();
    }

    private void onKeyClick(int r, int c) {
        List<List<String>> rows = showingLetters ? letterRows : symbolRows;
        if (r < 0 || r >= rows.size() || c < 0 || c >= rows.get(r).size()) return;

        if (selectedExtra != null && (editMode == 1 || editMode == 2)) {
            rows.get(r).set(c, selectedExtra);
            selectedExtra = null;
            selectedR = selectedC = -1;
            renderKeyboard();
            return;
        }

        if (editMode == 2) { // select + swap
            if (selectedR < 0) {
                selectedR = r;
                selectedC = c;
            } else if (selectedR == r && selectedC == c) {
                selectedR = selectedC = -1;
            } else {
                String a = rows.get(selectedR).get(selectedC);
                String b = rows.get(r).get(c);
                rows.get(selectedR).set(selectedC, b);
                rows.get(r).set(c, a);
                selectedR = selectedC = -1;
            }
            renderKeyboard();
            return;
        }

        if (editMode == 1) { // edit: cycle select for replacement from pool
            selectedR = r;
            selectedC = c;
            renderKeyboard();
            return;
        }

        // drag mode: first tap select, second swap
        if (selectedR < 0) {
            selectedR = r;
            selectedC = c;
        } else if (selectedR == r && selectedC == c) {
            selectedR = selectedC = -1;
        } else {
            String a = rows.get(selectedR).get(selectedC);
            String b = rows.get(r).get(c);
            rows.get(selectedR).set(selectedC, b);
            rows.get(r).set(c, a);
            selectedR = selectedC = -1;
        }
        renderKeyboard();
    }

    private void onNumberClick(int idx, String ch) {
        if (selectedExtra != null) {
            if (showingLetters && idx < numbers.size()) numbers.set(idx, selectedExtra);
            selectedExtra = null;
            renderKeyboard();
        }
    }

    private void applyExtraToSelected() {
        if (selectedExtra == null || selectedR < 0) return;
        List<List<String>> rows = showingLetters ? letterRows : symbolRows;
        if (selectedR < rows.size() && selectedC < rows.get(selectedR).size()) {
            rows.get(selectedR).set(selectedC, selectedExtra);
        }
        selectedExtra = null;
        selectedR = selectedC = -1;
        renderKeyboard();
    }

    private void renderBottomPreview() {
        bottomPreviewRow.removeAllViews();
        for (int i = 0; i < bottomKeys.size(); i++) {
            final int idx = i;
            final String label = bottomKeys.get(i);
            FrameLayout cell = new FrameLayout(getContext());
            TextView key = keyFace(shortLabel(label), 11, true);
            cell.addView(key, new FrameLayout.LayoutParams(-1, -1));
            TextView x = pill("×", 11, Color.WHITE, 0xffef4444, 10);
            FrameLayout.LayoutParams xlp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.START);
            xlp.topMargin = dp(2);
            xlp.setMarginStart(dp(2));
            x.setOnClickListener(v -> {
                bottomKeys.remove(idx);
                renderBottomPreview();
                renderBottomAvailable();
            });
            cell.addView(x, xlp);
            float w = label.contains("بۆشایی") || label.equalsIgnoreCase("space") ? 2.4f : 1f;
            LayoutParams lp = new LayoutParams(0, dp(52), w);
            lp.setMarginStart(dp(i == 0 ? 0 : 6));
            bottomPreviewRow.addView(cell, lp);
        }
        if (bottomKeys.isEmpty()) {
            TextView empty = label("دوگمەیەک زیاد بکە…", 12, MUTED);
            empty.setGravity(Gravity.CENTER);
            bottomPreviewRow.addView(empty, new LayoutParams(-1, dp(52)));
        }
    }

    private void renderBottomAvailable() {
        bottomAvailableHost.removeAllViews();
        LinearLayout line = null;
        int count = 0;
        for (String item : BOTTOM_AVAILABLE) {
            if (bottomKeys.contains(item)) continue;
            if (line == null || count % 3 == 0) {
                line = row();
                line.setPadding(0, dp(count == 0 ? 0 : 8), 0, 0);
                bottomAvailableHost.addView(line, new LayoutParams(-1, -2));
            }
            final String add = item;
            TextView chip = pill("+  " + item, 11, foreground, surfaceAlt, 14);
            chip.setPadding(dp(10), 0, dp(10), 0);
            chip.setOnClickListener(v -> {
                if (!bottomKeys.contains(add)) {
                    bottomKeys.add(add);
                    renderBottomPreview();
                    renderBottomAvailable();
                }
            });
            LayoutParams lp = new LayoutParams(0, dp(40), 1);
            lp.setMarginStart(dp(count % 3 == 0 ? 0 : 6));
            line.addView(chip, lp);
            count++;
        }
        // fill remaining cells for alignment
        if (line != null) {
            while (count % 3 != 0) {
                View spacer = new View(getContext());
                LayoutParams lp = new LayoutParams(0, dp(40), 1);
                lp.setMarginStart(dp(6));
                line.addView(spacer, lp);
                count++;
            }
        }
    }

    private String shortLabel(String label) {
        if (label.contains("بۆشایی") || label.equalsIgnoreCase("space")) return "Space";
        if (label.contains("زمان")) return "🌐";
        if (label.contains("خەندە") || label.contains("ئیمۆجی")) return "☺";
        if (label.contains("ناردن")) return "↵";
        if (label.contains("هێما")) return "123";
        if (label.contains("فاریزە")) return "،";
        if (label.contains("سەرسوڕمان")) return "!";
        if (label.contains("دەنگ")) return "🎤";
        if (label.contains("لەبەرگیر")) return "📋";
        if (label.contains("ڕێکخستن")) return "⚙";
        if (label.contains("دواتر")) return "↷";
        if (label.contains("پێشوو")) return "↶";
        if (label.contains("سڕینەوە")) return "⌫";
        return label.length() > 8 ? label.substring(0, 7) + "…" : label;
    }

    private void resetLayout() {
        if (showingLetters) {
            setDefaultLetters();
            numbers.clear();
            numbers.addAll(Arrays.asList(DEFAULT_NUMBERS));
        } else {
            setDefaultSymbols();
        }
        selectedR = selectedC = -1;
        selectedExtra = null;
        renderKeyboard();
        if (language != null) send("resetLayout", null);
    }

    private void save() {
        JSONArray rows = new JSONArray();
        for (List<String> row : letterRows) {
            JSONArray line = new JSONArray();
            for (String c : row) line.put(c);
            rows.put(line);
        }
        if (language != null) savedLayouts.put(layoutId, rows);
        send("saveLayout", rows);
        try {
            JSONArray bottom = new JSONArray();
            for (String k : bottomKeys) bottom.put(k);
            change.accept("saveBottomRow", bottom.toString());
        } catch (Throwable ignored) {}
        saveBtn.setText("✓  گۆڕانکارییەکان پاشەکەوت کران!");
        removeCallbacks(clearSave);
        postDelayed(clearSave, 2200);
    }

    private void send(String action, JSONArray rows) {
        try {
            JSONObject payload = new JSONObject();
            if (language != null) payload.put("code", language.optString("code"));
            payload.put("layout", layoutId);
            if (rows != null) payload.put("rows", rows);
            change.accept(action, payload.toString());
        } catch (JSONException ignored) {}
    }

    private void resetSaveLabel() {
        saveBtn.setText("💾  پاشەکەوتکردنی گۆڕانکارییەکان");
    }

    private void paintTabs() {
        boolean l = showingLetters;
        lettersTab.setBackground(appearance.background(l ? (light ? 0xff0f172a : 0xff0a0a0c) : Color.TRANSPARENT, 18, 0, 0));
        symbolsTab.setBackground(appearance.background(!l ? (light ? 0xff0f172a : 0xff0a0a0c) : Color.TRANSPARENT, 18, 0, 0));
        lettersTabText.setTextColor(l ? Color.WHITE : MUTED);
        symbolsTabText.setTextColor(!l ? Color.WHITE : MUTED);
    }

    private void paintModes() {
        styleMode(modeDrag, editMode == 0);
        styleMode(modeEdit, editMode == 1);
        styleMode(modeSelect, editMode == 2);
    }

    private void styleMode(TextView view, boolean on) {
        view.setBackground(appearance.background(on ? ACCENT_SOFT : surfaceAlt, 14, on ? 1 : 0, on ? ACCENT : 0));
        view.setTextColor(on ? ACCENT : MUTED);
    }

    private LinearLayout tabChip(String title, boolean on) {
        LinearLayout box = row();
        box.setGravity(Gravity.CENTER);
        box.setBackground(appearance.background(on ? (light ? 0xff0f172a : 0xff0a0a0c) : Color.TRANSPARENT, 18, 0, 0));
        TextView t = text(title, 13, on ? Color.WHITE : MUTED);
        box.addView(t);
        return box;
    }

    private TextView modeChip(String title) {
        TextView t = pill(title, 11, MUTED, surfaceAlt, 14);
        t.setPadding(dp(6), 0, dp(6), 0);
        return t;
    }

    private TextView keyFace(String value, int size, boolean special) {
        int bg = special ? (light ? 0xffe2e8f0 : 0xff1c1f27) : (light ? 0xfff8fafc : 0xff0e1016);
        int fg = special ? (light ? 0xff334155 : 0xffcbd5e1) : foreground;
        TextView key = text(value, size, fg);
        key.setBackground(appearance.background(bg, 12, 1, border));
        key.setGravity(Gravity.CENTER);
        key.setMinHeight(dp(40));
        key.setSingleLine(true);
        key.setEllipsize(TextUtils.TruncateAt.END);
        if (Build.VERSION.SDK_INT >= 21) key.setElevation(appearance.px(2));
        return key;
    }

    private TextView pill(String value, int size, int color, int bg, int radius) {
        TextView view = text(value, size, color);
        view.setGravity(Gravity.CENTER);
        view.setBackground(appearance.background(bg, radius, 0, 0));
        view.setPadding(dp(8), 0, dp(8), 0);
        return view;
    }

    private TextView text(String value, int size, int color) {
        return appearance.text(value, size, color, font, 700);
    }

    private TextView label(String value, int size, int color) {
        TextView view = text(value, size, color);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout card(int color, int radius) {
        LinearLayout view = column();
        view.setPadding(dp(14), dp(14), dp(14), dp(14));
        view.setBackground(appearance.background(color, radius, 1, border));
        return view;
    }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private View spacer(int w) {
        View v = new View(getContext());
        v.setLayoutParams(new LayoutParams(dp(w), dp(w)));
        return v;
    }

    private HorizontalScrollView horizontal(LinearLayout contents) {
        HorizontalScrollView scroll = new HorizontalScrollView(getContext());
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setLayoutDirection(LAYOUT_DIRECTION_RTL);
        scroll.addView(contents);
        return scroll;
    }

    private void append(LinearLayout parent, View child, int gap) { append(parent, child, gap, -2); }

    private void append(LinearLayout parent, View child, int gap, int height) {
        LayoutParams params = new LayoutParams(-1, height < 0 ? height : dp(height));
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(clearSave);
        super.onDetachedFromWindow();
    }
}
