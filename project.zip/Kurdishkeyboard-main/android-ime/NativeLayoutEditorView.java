package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class NativeLayoutEditorView extends LinearLayout {
    private static final int BLUE = 0xffa4c9ff;
    private static final int INK = 0xff051b3a;
    private static final int MUTED = 0xffa1a1aa;
    private static final String SAVE = "پاشەکەوتکردنی گۆڕانکارییەکان";

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int foreground;
    private final int border;
    private final TextView layoutLabel;
    private final LinearLayout languages;
    private final LinearLayout extras;
    private final LinearLayout keyboard;
    private final TextView save;
    private final Map<String, JSONArray> savedLayouts = new HashMap<>();
    private final List<JSONObject> choices = new ArrayList<>();
    private final List<List<Cell>> cells = new ArrayList<>();
    private final Runnable clearSave = () -> resetSaveText();

    private JSONObject language;
    private Cell selectedCell;
    private TextView selectedExtra;

    NativeLayoutEditorView(Context context, String theme, String font, JSONObject data, Runnable back,
                           NativeClipboardSettingsView.Change change) {
        super(context);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        border = light ? 0xffe2e8f0 : 0x1affffff;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = text("→", 20, foreground);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("دەستکاریکردنی ڕیزبەندی", 16, foreground);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        TextView reset = text("↻", 19, 0xfff87171);
        reset.setBackground(appearance.background(0x33ef4444, 20, 0, 0));
        reset.setContentDescription("گەڕاندنەوە بۆ بنەڕەتی");
        reset.setOnClickListener(v -> resetLayout());
        header.addView(reset, new LayoutParams(dp(40), dp(40)));
        addView(header, new LayoutParams(-1, dp(55)));
        View divider = new View(context);
        divider.setBackgroundColor(border);
        addView(divider, new LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(24));
        scroll.addView(body);
        LinearLayout info = card(0xff101318, 24);
        LinearLayout infoLine = row();
        TextView tool = text("⚒", 20, BLUE);
        tool.setBackground(appearance.background(0xff1d2838, 16, 0, 0));
        infoLine.addView(tool, new LayoutParams(dp(44), dp(44)));
        LinearLayout copy = column();
        LinearLayout heading = row();
        heading.addView(label("ڕیزبەندی تایبەت", 14, foreground));
        layoutLabel = text("", 11, BLUE);
        layoutLabel.setPadding(dp(8), dp(2), dp(8), dp(2));
        layoutLabel.setBackground(appearance.background(0xff1d2838, 8, 0, 0));
        LayoutParams labelPosition = new LayoutParams(-2, -2);
        labelPosition.setMarginStart(dp(8));
        heading.addView(layoutLabel, labelPosition);
        append(copy, heading, 0);
        append(copy, label("پیتەکان ڕابکێشە یان دایانگرە بۆ گۆڕینی شوێنیان", 12, MUTED), 2);
        LayoutParams copyPosition = new LayoutParams(0, -2, 1);
        copyPosition.setMarginStart(dp(14));
        infoLine.addView(copy, copyPosition);
        append(info, infoLine, 0);
        languages = row();
        append(info, horizontal(languages, true), 12);
        append(body, info, 0);

        LinearLayout pool = card(0xff101215, 24);
        append(pool, label("◇  پیت و هێما زیادەکان", 12, BLUE), 0);
        extras = row();
        append(pool, horizontal(extras, false), 12);
        JSONArray extraKeys = data.optJSONArray("extra");
        for (int i = 0; extraKeys != null && i < extraKeys.length(); i++) {
            String character = extraKeys.optString(i);
            TextView key = text(character, 14, Color.WHITE);
            key.setMinWidth(dp(44));
            key.setPadding(dp(10), 0, dp(10), 0);
            paintKey(key, false);
            key.setOnClickListener(v -> selectExtra(key));
            key.setOnLongClickListener(v -> beginKeyDrag(key, character));
            LayoutParams params = new LayoutParams(-2, dp(44));
            params.setMarginStart(dp(i == 0 ? 0 : 8));
            extras.addView(key, params);
        }
        append(body, pool, 16);

        keyboard = column();
        keyboard.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        keyboard.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable dashed = new GradientDrawable();
        dashed.setColor(0xff08090c);
        dashed.setCornerRadius(dp(24));
        dashed.setStroke(dp(2), 0x26ffffff, dp(5), dp(4));
        keyboard.setBackground(dashed);
        append(body, keyboard, 16);

        save = text(SAVE, 14, INK);
        save.setBackground(appearance.background(BLUE, 16, 0, 0));
        save.setOnClickListener(v -> saveLayout());
        append(body, save, 16, 52);
        TextView instructions = text("فێرکاری و ڕێنمایی  ▶", 14, foreground);
        instructions.setBackground(appearance.background(Color.TRANSPARENT, 16, 1, 0x598ec2ff));
        append(body, instructions, 16, 48);
        LinearLayout tutorial = card(0xff13161c, 16);
        append(tutorial, label("• بۆ گۆڕینی شوێنی دوو پیت: لەسەر پیتی یەکەم و پاشان پیتی دووەم دابگرە (یان ڕایبکێشە سەری).", 12, foreground), 0);
        append(tutorial, label("• بۆ دانانی پیتێکی زیادە: لە لیستی «پیت و هێما زیادەکان» پیتێک هەڵبژێرە و لەسەر هەر خانەیەکی تەختەکلیل دابگرە.", 12, foreground), 8);
        append(tutorial, label("• لە کۆتاییدا لەسەر «پاشەکەوتکردنی گۆڕانکارییەکان» دابگرە بۆ ئەوەی ڕاستەوخۆ لەسەر تەختەکلیل جێبەجێ ببێت.", 12, foreground), 8);
        tutorial.setVisibility(GONE);
        instructions.setOnClickListener(v -> tutorial.setVisibility(tutorial.isShown() ? GONE : VISIBLE));
        append(body, tutorial, 12);

        JSONArray definitions = data.optJSONArray("languages");
        JSONObject active = null;
        for (int i = 0; definitions != null && i < definitions.length(); i++) {
            JSONObject option = definitions.optJSONObject(i);
            if (option == null) continue;
            choices.add(option);
            savedLayouts.put(option.optString("layout"), option.optJSONArray("rows"));
            if (option.optString("code").equals(data.optString("activeLanguage"))) active = option;
            TextView button = text(option.optString("nativeName"), 12, foreground);
            button.setPadding(dp(12), 0, dp(12), 0);
            button.setOnClickListener(v -> openLanguage(option));
            LayoutParams params = new LayoutParams(-2, dp(32));
            params.setMarginStart(dp(i == 0 ? 0 : 6));
            languages.addView(button, params);
        }
        if (!choices.isEmpty()) openLanguage(active == null ? choices.get(0) : active);
        else {
            save.setEnabled(false);
            reset.setEnabled(false);
        }
    }

    private void openLanguage(JSONObject option) {
        language = option;
        layoutLabel.setText(option.optString("label"));
        for (int i = 0; i < languages.getChildCount(); i++) {
            TextView button = (TextView) languages.getChildAt(i);
            boolean active = choices.get(i) == option;
            button.setSelected(active);
            button.setTextColor(active ? INK : foreground);
            button.setBackground(appearance.background(active ? BLUE : light ? 0xfff1f5f9 : 0x66000000,
                    12, 1, active ? BLUE : border));
        }
        displayRows(savedLayouts.get(option.optString("layout")));
    }

    private void displayRows(JSONArray rows) {
        clearSelection();
        keyboard.removeAllViews();
        cells.clear();
        if (rows == null) return;
        JSONArray first = rows.optJSONArray(0);
        for (int r = 0; r < rows.length(); r++) {
            JSONArray values = rows.optJSONArray(r);
            List<Cell> rowCells = new ArrayList<>();
            cells.add(rowCells);
            if (values == null) continue;
            LinearLayout line = row();
            if (r == 1 && values.length() <= 9 && first != null && first.length() >= 10) {
                line.setPadding(dp(12), 0, dp(12), 0);
            }
            boolean bottom = r == rows.length() - 1;
            if (bottom) addModifier(line, "⇧");
            for (int c = 0; c < values.length(); c++) {
                Cell cell = new Cell(values.optString(c));
                rowCells.add(cell);
                LayoutParams params = new LayoutParams(0, dp(44), 1);
                if (line.getChildCount() > 0) params.leftMargin = dp(4);
                line.addView(cell, params);
            }
            if (bottom) addModifier(line, "⌫");
            append(keyboard, line, r == 0 ? 0 : 8);
        }
    }

    private void addModifier(LinearLayout line, String symbol) {
        TextView modifier = text(symbol, 15, 0xff71717a);
        modifier.setBackground(appearance.background(0xff14161a, 12, 1, 0x1affffff));
        LayoutParams params = new LayoutParams(dp(40), dp(44));
        if (line.getChildCount() > 0) params.leftMargin = dp(4);
        line.addView(modifier, params);
    }

    private final class Cell extends TextView {
        Cell(String value) {
            super(NativeLayoutEditorView.this.getContext());
            setGravity(Gravity.CENTER);
            setTextSize(14);
            setTypeface(appearance.text("", 14, Color.WHITE, font, 700).getTypeface());
            setSingleLine(true);
            setEllipsize(TextUtils.TruncateAt.END);
            setText(value);
            paintKey(this, false);
            setOnClickListener(v -> clickCell(this));
            setOnLongClickListener(v -> beginKeyDrag(this, this));
            setOnDragListener((view, event) -> {
                Object source = event.getLocalState();
                if (!(source instanceof Cell || source instanceof String)) return false;
                if (event.getAction() == DragEvent.ACTION_DROP) {
                    if (source instanceof Cell) swap((Cell) source, this);
                    else setText((String) source);
                    clearSelection();
                }
                return true;
            });
        }
    }

    private boolean beginKeyDrag(View view, Object value) {
        View.DragShadowBuilder shadow = new View.DragShadowBuilder(view);
        if (Build.VERSION.SDK_INT >= 24) return view.startDragAndDrop(null, shadow, value, 0);
        return view.startDrag(null, shadow, value, 0);
    }

    private void selectExtra(TextView key) {
        boolean wasSelected = selectedExtra == key;
        clearSelection();
        if (!wasSelected) {
            selectedExtra = key;
            paintKey(key, true);
        }
    }

    private void clickCell(Cell cell) {
        if (selectedExtra != null) {
            cell.setText(selectedExtra.getText());
            clearSelection();
        } else if (selectedCell == null) {
            selectedCell = cell;
            paintKey(cell, true);
        } else {
            swap(selectedCell, cell);
            clearSelection();
        }
    }

    private void swap(Cell from, Cell to) {
        if (from == to) return;
        CharSequence first = from.getText();
        from.setText(to.getText());
        to.setText(first);
    }

    private void clearSelection() {
        if (selectedCell != null) paintKey(selectedCell, false);
        if (selectedExtra != null) paintKey(selectedExtra, false);
        selectedCell = null;
        selectedExtra = null;
    }

    private void paintKey(TextView key, boolean active) {
        key.setSelected(active);
        key.setTextColor(active ? INK : Color.WHITE);
        key.setBackground(appearance.background(active ? BLUE : 0xff191b20, 12, 1, active ? BLUE : 0x1affffff));
    }

    private void resetLayout() {
        if (language == null) return;
        JSONArray defaults = language.optJSONArray("defaults");
        savedLayouts.put(language.optString("layout"), defaults);
        displayRows(defaults);
        send("resetLayout", null);
    }

    private void saveLayout() {
        if (language == null) return;
        JSONArray rows = new JSONArray();
        for (List<Cell> line : cells) {
            JSONArray row = new JSONArray();
            for (Cell cell : line) row.put(cell.getText().toString());
            rows.put(row);
        }
        savedLayouts.put(language.optString("layout"), rows);
        send("saveLayout", rows);
        save.setText("✓ گۆڕانکارییەکان پاشەکەوت کران!");
        removeCallbacks(clearSave);
        postDelayed(clearSave, 2200);
    }

    private void send(String action, JSONArray rows) {
        try {
            JSONObject payload = new JSONObject().put("code", language.optString("code"));
            if (rows != null) payload.put("rows", rows);
            change.accept(action, payload.toString());
        } catch (JSONException ignored) { }
    }

    private void resetSaveText() { save.setText(SAVE); }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(clearSave);
        super.onDetachedFromWindow();
    }

    private HorizontalScrollView horizontal(LinearLayout contents, boolean rtl) {
        HorizontalScrollView scroll = new HorizontalScrollView(getContext());
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setLayoutDirection(rtl ? LAYOUT_DIRECTION_RTL : LAYOUT_DIRECTION_LTR);
        scroll.addView(contents);
        return scroll;
    }

    private TextView text(String value, int size, int color) {
        return appearance.text(value, size, color, font, 700);
    }

    private TextView label(String value, int size, int color) {
        TextView view = text(value, size, color);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout card(int darkColor, int radius) {
        LinearLayout view = column();
        view.setPadding(dp(16), dp(16), dp(16), dp(16));
        view.setBackground(appearance.background(light ? Color.WHITE : darkColor, radius, 1, border));
        return view;
    }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private void append(LinearLayout parent, View child, int gap) { append(parent, child, gap, -2); }

    private void append(LinearLayout parent, View child, int gap, int height) {
        LayoutParams params = new LayoutParams(-1, height < 0 ? height : dp(height));
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
