package io.kurdikebord.app;

/** Native default character rows copied from the bundled keyboard layouts. */
final class NativeTypingLayouts {
    static boolean supports(String lang) { return "ckb".equals(lang)||"en".equals(lang)||"ar".equals(lang); }
    static boolean supportsLayout(String lang, String id) {
        if(!supports(lang))return false;
        if(id==null||id.isEmpty())return true;
        return ("ckb".equals(lang)&&"kurdi_qvfgh".equals(id)) || ("en".equals(lang)&&"qwerty".equals(id)) || ("ar".equals(lang)&&"arabic1".equals(id));
    }
    static String[] alternatives(String key) {
        switch(key) {
            case "ا":return new String[]{"أ","إ","آ","ٱ"};
            case "ھ":return new String[]{"ه","ح"};
            case "ه":return new String[]{"ة","ھ"};
            case "ی":case "ي":return new String[]{"ى","ئ","ی","ي"};
            case "و":return new String[]{"ؤ","ۏ","ۆ"};
            case "ۆ":return new String[]{"ؤ","ۇ","ۉ"};
            case "ئ":return new String[]{"ء","أ","إ"};
            case "ز":return new String[]{"ظ","ژ"};
            case "د":return new String[]{"ذ"};
            case "پ":return new String[]{"ث"};
            case "ک":return new String[]{"ك"};
            case "a":return new String[]{"á","à","â","ä","ã","æ"};
            case "e":return new String[]{"é","è","ê","ë"};
            case "i":return new String[]{"í","ì","î","ï"};
            case "o":return new String[]{"ó","ò","ô","ö","õ","ø"};
            case "u":return new String[]{"ú","ù","û","ü"};
            case "n":return new String[]{"ñ"};
            case "c":return new String[]{"ç"};
            default:return new String[0];
        }
    }
    static String[][] rows(String lang) {
        switch (lang) {
            case "ckb": return new String[][] {
                {"ق", "ڤ", "ف", "غ", "ع", "ھ", "ە", "ت", "ح", "خ"},
                {"ش", "س", "ی", "ێ", "ل", "ڵ", "ا", "ن", "ج", "چ"},
                {"ب", "ز", "ر", "ڕ", "د", "وو", "و", "ۆ", "ک", "گ"},
                {"ـ", "ئ", "پ", "ژ", "م", "؟", "،", ":"},
            };
            case "en": return new String[][] {
                {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
                {"a", "s", "d", "f", "g", "h", "j", "k", "l"},
                {"z", "x", "c", "v", "b", "n", "m"},
            };
            case "ar": return new String[][] {
                {"ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"},
                {"ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"},
                {"ذ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ", "د"},
            };
            default: return rows("ckb");
        }
    }
    static String[][] symbols(boolean second) {
        return second ? new String[][] {{"~","`","|","•","√","π","÷","×","§","Δ"},{"£","€","¥","¢","°","^","_","=","{","}"},{"\\","©","®","™","<",">","[","]","…"}} : new String[][] {{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\"","'",":",";","!","?",",","."}};
    }
}
