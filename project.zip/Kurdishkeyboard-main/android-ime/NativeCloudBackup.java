package io.kurdikebord.app;

import android.content.Context;
import org.json.*;
import java.util.*;

/** Encrypted backup data selection shared by capture and restore. Never includes diagnostic logs, entitlements or API configuration. */
final class NativeCloudBackup {
    static final int SETTINGS=1, LANGUAGES=2, THEMES=4, WORDS=8, EMOJI=16, PINNED=32, ALL_CLIPS=64;
    static final int ALL=127;
    private static final Set<String> LANG = set("enabledLanguages","activeLanguage","customLayouts");
    private static final Set<String> THEME = set("activeThemeId","keyShapeStyle","downloadedThemeIds","customTheme","keyboardThemeMode","appTheme","appAccentColor","fontStyle");
    private static final Set<String> PERSONAL = set("personalDictionary","textShortcuts","quickSnippets");
    private static final Set<String> FAVORITES = set("emojiPinned","kaomojiPinned","zikrHistories","recentEmojis","recentKaomoji","recentZikr");
    private static final Set<String> EXCLUDED = set("aiServerUrl","proUnlocked","notificationsEnabled","ratingDismissed","userRating");
    private static final Set<String> EXTRA = set("bottomRowKeys","emojiLanguageBottom");
    private static Set<String> set(String... keys){return new HashSet<>(Arrays.asList(keys));}
    static int group(String key){
        if(EXCLUDED.contains(key))return 0;
        if(LANG.contains(key))return LANGUAGES;if(THEME.contains(key))return THEMES;
        if(PERSONAL.contains(key))return WORDS;if(FAVORITES.contains(key))return EMOJI;
        return SETTINGS;
    }
    private static JSONObject defaults(JSONObject core){return NativeImeData.obj(NativeImeData.obj(core,"defaults"),"settings");}
    static JSONObject filterSettings(JSONObject source,JSONObject core,int mask) throws JSONException {
        JSONObject result=new JSONObject(), defs=defaults(core);
        Iterator<String> it=source.keys();while(it.hasNext()){
            String key=it.next();Object value=source.opt(key), fallback=defs.opt(key);
            if((group(key)&mask)==0 || !(defs.has(key)||EXTRA.contains(key)))continue;
            if(fallback instanceof Number ? !(value instanceof Number) : fallback!=null&&fallback!=JSONObject.NULL&&!fallback.getClass().isInstance(value))continue;
            if("bottomRowKeys".equals(key)&&!(value instanceof JSONArray))continue;
            if("emojiLanguageBottom".equals(key)&&!(value instanceof Boolean))continue;
            result.put(key,value);
        }return result;
    }
    // A conservative heuristic; users must still review clipboard text. Cannot recognize arbitrary passwords.
    static boolean obviousSecret(String text){
        return NativePrivacy.looksSensitive(text);
    }
    static JSONObject capture(Context c,JSONObject core,int mask) throws Exception {
        if(!ImeStateStore.unlocked(c))throw new IllegalStateException("Locked");
        JSONObject state=ImeStateStore.snapshot(c), hydrated=new NativeImeSettings(core).hydrate(ImeStateStore.effectiveSettings(c,state));
        JSONObject out=new JSONObject().put("format","kurdikeyboard-cloud").put("version",1).put("mask",mask).put("created",System.currentTimeMillis());
        out.put("settings",filterSettings(hydrated,core,mask));
        if((mask&LANGUAGES)!=0)for(String key:new String[]{"sourceLanguage","targetLanguage"}){
            String code=state.optString(key);if(validLanguage(core,key,code))out.put(key,code);
        }
        if((mask&WORDS)!=0){
            JSONObject learned=NativeImeData.obj(state,"learned"), safe=new JSONObject();Iterator<String> keys=learned.keys();
            while(keys.hasNext()){String word=keys.next();if(!obviousSecret(word))safe.put(word,learned.opt(word));}out.put("learned",safe);
        }
        if((mask&(PINNED|ALL_CLIPS))!=0){
            JSONArray clips=state.optJSONArray("clipboard"), selected=new JSONArray(); int skipped=0;
            if(clips!=null)for(int i=0;i<clips.length();i++){
                JSONObject item=clips.optJSONObject(i);if(item==null||((mask&ALL_CLIPS)==0&&!item.optBoolean("pinned")))continue;
                String text=item.optString("text");if(text.isEmpty()||obviousSecret(text)){skipped++;continue;}
                selected.put(new JSONObject().put("text",text).put("pinned",item.optBoolean("pinned")).put("timestamp",item.optLong("timestamp")));
            }out.put("clipboard",selected).put("skipped",skipped);
        }return out;
    }
    static boolean validLanguage(JSONObject core,String key,String code){
        return !code.isEmpty() && !("targetLanguage".equals(key)&&"auto".equals(code)) && NativeImeData.find(NativeImeData.arr(core,"languages"),"code",code)!=null;
    }
    static int validate(JSONObject payload) throws JSONException {
        if(!"kurdikeyboard-cloud".equals(payload.optString("format"))||payload.optInt("version")!=1)throw new JSONException("Unsupported format");
        int mask=payload.optInt("mask");if(mask<=0||(mask&~ALL)!=0)throw new JSONException("Invalid selection");
        payload.getJSONObject("settings");
        if((mask&WORDS)!=0)payload.getJSONObject("learned");
        if((mask&(PINNED|ALL_CLIPS))!=0){JSONArray clips=payload.getJSONArray("clipboard");if(clips.length()>10000)throw new JSONException("Too many clips");for(int i=0;i<clips.length();i++){JSONObject item=clips.getJSONObject(i);if(!(item.opt("text") instanceof String)||item.getString("text").length()>524288)throw new JSONException("Invalid clip");}}
        return mask;
    }
    static JSONArray mergeClips(JSONArray current,JSONArray imported,boolean all) throws JSONException {
        JSONArray out=new JSONArray(); Map<String,JSONObject> byText=new HashMap<>();
        for(int i=0;current!=null&&i<current.length();i++){JSONObject v=current.optJSONObject(i);if(v==null)continue;JSONObject copy=new JSONObject(v.toString());out.put(copy);byText.put(copy.optString("text"),copy);}
        for(int i=0;imported!=null&&i<imported.length();i++){
            JSONObject v=imported.getJSONObject(i);String text=v.getString("text");boolean pinned=v.optBoolean("pinned");
            if(text.isEmpty()||obviousSecret(text)||(!all&&!pinned))continue;
            JSONObject found=byText.get(text);if(found!=null){if(pinned)found.put("pinned",true);continue;}
            JSONObject copy=new JSONObject().put("id","clip_"+UUID.randomUUID()).put("text",text).put("pinned",pinned).put("timestamp",v.optLong("timestamp",System.currentTimeMillis()));out.put(copy);byText.put(text,copy);
        }return out;
    }
}
