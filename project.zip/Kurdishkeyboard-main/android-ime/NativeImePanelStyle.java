package io.kurdikebord.app;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class NativeImePanelStyle {
    static final int MATCH = -1;
    static final int WRAP = -2;
    static final int BLUE = 0xff0b5fa8;
    static final int SKY = 0xff38bdf8;
    static final int MUTED = 0xff71717a;

    private final NativeImeView keyboard;

    NativeImePanelStyle(NativeImeView keyboard) { this.keyboard = keyboard; }

    int dp(double size) { return size < 0 ? (int) size : keyboard.dp(size); }
    int color(int light, int dark) { return keyboard.light() ? light : dark; }
    int foreground() { return color(0xff0f172a, Color.WHITE); }
    int border() { return color(0xffe2e8f0, 0x1affffff); }
    int mutedFill() { return color(0xffe2e8f0, 0xff27272a); }
    int mutedText() { return color(0xff334155, 0xffd4d4d8); }

    Drawable face(int fill, int radius, int stroke) {
        return keyboard.appearance.background(fill, radius, stroke == 0 ? 0 : 1, stroke);
    }

    LinearLayout panel(int height, int side, int vertical) {
        LinearLayout panel = column();
        panel.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(height)));
        padding(panel, side, vertical);
        return panel;
    }

    LinearLayout row() {
        LinearLayout row = keyboard.row();
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    LinearLayout column() {
        LinearLayout column = keyboard.column();
        column.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return column;
    }

    void padding(View view, int horizontal, int vertical) {
        view.setPadding(dp(horizontal), dp(vertical), dp(horizontal), dp(vertical));
    }

    void add(LinearLayout parent, View child, int width, int height, int gap) {
        LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(dp(width), dp(height));
        if (parent.getOrientation() == LinearLayout.HORIZONTAL) position.setMarginStart(dp(gap));
        else position.topMargin = dp(gap);
        parent.addView(child, position);
    }

    void flex(LinearLayout parent, View child, int cross, int gap) {
        boolean row = parent.getOrientation() == LinearLayout.HORIZONTAL;
        LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(row ? 0 : dp(cross), row ? dp(cross) : 0, 1);
        if (row) position.setMarginStart(dp(gap));
        else position.topMargin = dp(gap);
        parent.addView(child, position);
    }

    TextView text(String title, double size, int tint, int weight) {
        return keyboard.appearance.text(title, size, tint, keyboard.font(), weight);
    }

    void truncate(TextView text) {
        text.setSingleLine(true);
        text.setEllipsize(TextUtils.TruncateAt.END);
    }

    TextView button(String title, double size, int tint, int weight, int fill, int radius, int outline, int inset, Runnable action) {
        TextView button = text(title, size, tint, weight);
        button.setBackground(face(fill, radius, outline));
        padding(button, inset, 0);
        truncate(button);
        press(button, action);
        return button;
    }

    void press(View view, Runnable action) {
        view.setFocusable(true);
        view.setSoundEffectsEnabled(false);
        view.setOnClickListener(button -> { keyboard.feedback("special"); action.run(); });
    }

    ImageView icon(String name, int tint, int size) {
        ImageView icon = new ImageView(keyboard.getContext());
        icon.setImageDrawable(keyboard.appearance.icon(name, tint, size));
        return icon;
    }

    ImageView iconButton(String name, String label, int tint, int size, int fill, int radius, Runnable action) {
        ImageView icon = icon(name, tint, size);
        icon.setScaleType(ImageView.ScaleType.CENTER);
        icon.setContentDescription(label);
        if (fill != 0) icon.setBackground(face(fill, radius, 0));
        press(icon, action);
        return icon;
    }

    ImageView close(Runnable action, int size) {
        return iconButton("close", "داخستن", foreground(), size, mutedFill(), 16, action);
    }

    void startIcon(TextView text, String name, int tint, int size, int gap) {
        text.setCompoundDrawablesRelativeWithIntrinsicBounds(keyboard.appearance.icon(name, tint, size), null, null, null);
        text.setCompoundDrawablePadding(dp(gap));
    }

    void titleIcon(TextView text, String name, int size, int gap) {
        startIcon(text, name, text.getCurrentTextColor(), size, gap);
    }

    ScrollView scroll(View child) {
        ScrollView view = new ScrollView(keyboard.getContext());
        view.setVerticalScrollBarEnabled(false);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.addView(child, new ScrollView.LayoutParams(MATCH, WRAP));
        return view;
    }

    HorizontalScrollView horizontal(LinearLayout child) {
        HorizontalScrollView view = new HorizontalScrollView(keyboard.getContext());
        view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        view.setHorizontalScrollBarEnabled(false);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.addView(child, new HorizontalScrollView.LayoutParams(WRAP, MATCH));
        return view;
    }

    void enabled(View view, boolean enabled) {
        view.setEnabled(enabled);
        view.setAlpha(enabled ? 1f : .4f);
    }
}
