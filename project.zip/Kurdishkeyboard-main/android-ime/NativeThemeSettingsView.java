package io.kurdikebord.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.IntConsumer;

final class NativeThemeSettingsView extends LinearLayout {
    private static final int BLUE = 0xffa4c9ff;
    private static final int INK = 0xff051b3a;
    private static final int MUTED = 0xffa1a1aa;
    private static final String[][] COLOR_FIELDS = {
        {"bg", "ڕەنگی پاشبنەما"}, {"keyBg", "ڕەنگی دوگمەکان"}, {"keyText", "ڕەنگی پیتەکان"},
        {"keyBorder", "ڕەنگی لێواری دوگمە"}, {"enterBg", "ڕەنگی دوگمەی ناردن (Enter)"},
    };

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final int foreground;
    private final boolean light;
    private final Set<String> downloaded = new HashSet<>();
    private final List<StoreCard> cards = new ArrayList<>();
    private JSONObject custom;
    private String active;
    private AlertDialog colorPicker;

    NativeThemeSettingsView(Context context, String theme, String font, JSONObject data, Runnable back, NativeClipboardSettingsView.Change change) {
        this(context,theme,font,data,"themes",back,change);
    }
    NativeThemeSettingsView(Context context, String theme, String font, JSONObject data, boolean store, Runnable back, NativeClipboardSettingsView.Change change) {
        this(context,theme,font,data,store?"store":"custom",back,change);
    }
    private NativeThemeSettingsView(Context context, String theme, String font, JSONObject data, String page, Runnable back,
                            NativeClipboardSettingsView.Change change) {
        super(context);
        boolean store = "store".equals(page);
        this.font = font;
        this.change = change;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);
        LinearLayout header = row();
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        header.setPadding(dp(16), 0, dp(16), 0);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("themes".equals(page) ? "ڕووکار، ڕەنگ و دۆخەکان" : store ? "داگرتنی ڕووکار" : "دروستکردنی ڕووکاری تایبەت", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        divider(this, 0, light ? 0xffe2e8f0 : 0x0dffffff);
        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(store ? 12 : 16), dp(16), dp(24));
        scroll.addView(body);
        if ("themes".equals(page)) renderThemes(body,data);
        else if (store) renderStore(body, data);
        else renderCustom(body, data);
    }

    private void renderThemes(LinearLayout body, JSONObject data) {
        if (!data.optBoolean("notificationsEnabled")) append(body,NativeSettingsNotification.create(getContext(),appearance,font,change),0,-2);
        LinearLayout options=row();
        String mode=data.optString("keyboardThemeMode","dark");
        TextView modeButton=themeTile("دۆخی ڕووکار\n"+("light".equals(mode)?"هەمیشە ڕووناک":"auto".equals(mode)?"خۆکار":"هەمیشە تاریک"));
        modeButton.setOnClickListener(v->change.accept("themeMode","dark".equals(mode)?"light":"light".equals(mode)?"auto":"dark"));
        options.addView(modeButton,new LayoutParams(0,dp(100),1));
        TextView accent=themeTile("ڕەنگی بەرنامەکە\n●");accent.setTextColor(appearance.color(data.optString("appAccentColor"),BLUE));
        accent.setOnClickListener(v->{String[] colors={"#2990FF","#14F1D9","#A855F7","#10B981","#F59E0B","#EF4444"};new AlertDialog.Builder(getContext()).setTitle("ڕەنگی سەرەکی").setItems(colors,(d,i)->change.accept("appAccentColor",colors[i])).show();});
        LayoutParams second=new LayoutParams(0,dp(100),1);second.setMarginStart(dp(12));options.addView(accent,second);append(body,options,16,-2);
        TextView store=themeTile("فرۆشگای ڕووکارەکان\nڕووکارە مۆدێرنەکان ببینە\n↓ داگرتنی ڕووکارەکان");store.setOnClickListener(v->change.accept("openPage","theme_store"));append(body,store,16,112);
        String[] shapes={"default","flat","three_dimensional","pill_rounded","glass_crystal","outline_only","borderless","soft_neumorphic","animated_glow"};
        String[] shapeLabels={"بنەڕەتی","تەخت","سێ ڕەهەندی","خڕ","شووشەیی","هێڵی دەورە","بێ لێوار","نەرم","درەوشاوە"};
        JSONArray all=NativeImeData.arr(data,"builtins");
        JSONObject current=NativeImeData.find(all,"id",data.optString("activeThemeId"));
        if(current==null) current=NativeImeData.find(NativeImeData.arr(data,"themes"),"id",data.optString("activeThemeId"));
        if(current==null && "custom_user_theme".equals(data.optString("activeThemeId"))) current=NativeImeData.obj(data,"custom");
        if(current==null) current=all.optJSONObject(0);
        if(current==null) current=new JSONObject();
        LinearLayout shapeCard=column(); shapeCard.setPadding(dp(16),dp(16),dp(16),dp(16));
        shapeCard.setBackground(appearance.background(light?Color.WHITE:0xff121316,24,1,light?0xffe2e8f0:0x0fffffff));
        TextView shapeTitle=label("شێوازی دوگمەکان (9)",14,foreground,700);shapeTitle.setGravity(Gravity.CENTER);shapeCard.addView(shapeTitle);
        TextView shapeDescription=label("لێرە دەتوانی ستایلی دوگمەکانی کیبۆردەکەت دیاری بکەیت (شوشەیی، نیۆن، سێ ڕەهەندی، هەمەڕەنگ..)",11,MUTED,400);shapeDescription.setGravity(Gravity.CENTER);append(shapeCard,shapeDescription,4,-2);
        double bw=current.optDouble("keyBorderWidth",current.optBoolean("hasKeyBorder")?1:0);
        String keyBorder=bw>0?bw+"px solid "+current.optString("keyBorder"):"none";
        for(int i=0;i<shapes.length;i+=3){
            LinearLayout shapeRow=row();
            for(int j=i;j<i+3;j++){
                final String shapeId=shapes[j];boolean selected=shapeId.equals(data.optString("keyShapeStyle","default"));
                LinearLayout cell=column();cell.setGravity(Gravity.CENTER);cell.setPadding(dp(8),dp(8),dp(8),dp(8));
                cell.setBackground(appearance.background(selected?0x1a0ea5e9:light?0xfff8fafc:0x05ffffff,16,2,selected?BLUE:light?0xffe2e8f0:0x0fffffff));
                LinearLayout sample=row();sample.setPadding(dp(6),dp(6),dp(6),dp(6));sample.setBackground(appearance.background(color(current,"bg",Color.BLACK),12,0,0));
                for(String letter:new String[]{"ک","و","ر"}){
                    TextView key=appearance.text(letter,11,color(current,"keyText",Color.WHITE),font,700);
                    key.setBackground(appearance.keyFace(NativeImeKeyFaces.shape(shapeId,current,current.optString("keyBg"),keyBorder,false,false),0xff252525));
                    LayoutParams lp=new LayoutParams(0,dp(24),1);if(sample.getChildCount()>0)lp.setMarginStart(dp(4));sample.addView(key,lp);
                }
                cell.addView(sample,new LayoutParams(-1,-2));TextView name=label(shapeLabels[j],10,foreground,700);name.setGravity(Gravity.CENTER);append(cell,name,6,-2);
                cell.setOnClickListener(v->change.accept("keyShapeStyle",shapeId));LayoutParams cellLp=new LayoutParams(0,-2,1);if(j>i)cellLp.setMarginStart(dp(8));shapeRow.addView(cell,cellLp);
            }
            append(shapeCard,shapeRow,8,-2);
        }
        append(body,shapeCard,16,-2);
        JSONObject dark=NativeImeData.find(all,"id","rukar_futodark"), bright=null;
        for(int i=0;i<all.length();i++){JSONObject t=all.optJSONObject(i);if(t!=null && t.optBoolean("isLight")){bright=t;break;}}
        if(dark!=null && bright!=null){
            FrameLayout auto=new FrameLayout(getContext());LinearLayout split=row();split.setLayoutDirection(LAYOUT_DIRECTION_LTR);
            split.addView(compactPreview(dark,false),new LayoutParams(0,-2,1));split.addView(compactPreview(bright,false),new LayoutParams(0,-2,1));auto.addView(split,new FrameLayout.LayoutParams(-1,-2));
            TextView badge=appearance.text("خۆکار",12,Color.WHITE,font,700);badge.setPadding(dp(16),dp(4),dp(16),dp(4));badge.setBackground(appearance.background(0xff094a82,20,0,0));FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);badgeLp.topMargin=dp(12);auto.addView(badge,badgeLp);auto.setOnClickListener(v->change.accept("themeMode","auto"));append(body,auto,16,-2);
        }
        JSONArray themes=NativeImeData.arr(data,"builtins");append(body,label("ڕووکارە فەرمییەکان ("+themes.length()+")",15,foreground,800),20,36);
        TextView custom=themeTile("＋ دروستکردنی ڕووکاری تایبەت");custom.setOnClickListener(v->change.accept("openPage","custom_theme"));append(body,custom,8,72);
        LinearLayout gridRow=null;
        LinearLayout previewGrid=column(); append(body,previewGrid,0,-2);
        java.util.ArrayList<View> extraRows=new java.util.ArrayList<>();
        for(int i=0;i<themes.length();i++) {
            JSONObject t=themes.optJSONObject(i);if(t==null)continue;
            if(i%2==0){gridRow=row();append(previewGrid,gridRow,12,-2);if(i>=6){gridRow.setVisibility(GONE);extraRows.add(gridRow);}}
            LinearLayout cell=column();cell.setPadding(dp(4),dp(4),dp(4),dp(4));boolean selected=t.optString("id").equals(data.optString("activeThemeId"));cell.setBackground(appearance.background(light?Color.WHITE:0xff121316,16,selected?2:1,selected?BLUE:0x22ffffff));
            cell.addView(compactPreview(t,selected));TextView title=label(t.optString("nameKu"),11,foreground,700);title.setGravity(Gravity.CENTER);append(cell,title,6,30);cell.setOnClickListener(v->change.accept("activeThemeId",t.optString("id")));LayoutParams lp=new LayoutParams(0,-2,1);if(i%2!=0)lp.setMarginStart(dp(12));gridRow.addView(cell,lp);if(i==themes.length()-1 && i%2==0)gridRow.addView(new View(getContext()),new LayoutParams(0,1,1));
        }
        if(!extraRows.isEmpty()){TextView more=themeTile("بینینی هەمووی ("+themes.length()+" ڕووکار)");more.setOnClickListener(v->{boolean show=extraRows.get(0).getVisibility()!=VISIBLE;for(View extra:extraRows)extra.setVisibility(show?VISIBLE:GONE);more.setText(show?"کەمتر پیشان بدە":"بینینی هەمووی ("+themes.length()+" ڕووکار)");});append(body,more,12,44);}
    }
    // The compact preview follows SettingsUI.tsx: four rows, no dedicated number row.
    private View compactPreview(JSONObject theme,boolean selected){
        FrameLayout frame=new FrameLayout(getContext());frame.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        frame.setBackground(appearance.background(color(theme,"bg",Color.BLACK),14,0,0));
        LinearLayout mini=column();mini.setLayoutDirection(LAYOUT_DIRECTION_LTR);mini.setPadding(dp(6),dp(10),dp(6),dp(10));
        String[] letters={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
        for(int i=0;i<letters.length;i++){
            LinearLayout line=row();line.setLayoutDirection(LAYOUT_DIRECTION_LTR);if(i==1)line.setPadding(dp(6),0,dp(6),0);
            if(i==2)miniKey(line,theme,"↑","shiftBg","shiftText",20);
            for(char letter:letters[i].toCharArray())miniKey(line,theme,String.valueOf(letter),"keyBg","keyText",0);
            if(i==2)miniKey(line,theme,"⌫","backspaceBg","backspaceText",20);
            append(mini,line,i==0?0:4,16);
        }
        LinearLayout last=row();last.setLayoutDirection(LAYOUT_DIRECTION_LTR);miniKey(last,theme,"!#1","symbolsBg","symbolsText",28);miniKey(last,theme,"","spaceBg","spaceText",0);miniKey(last,theme,"↵","enterBg","enterText",28);append(mini,last,4,16);
        frame.addView(mini,new FrameLayout.LayoutParams(-1,-2));
        if(selected){TextView check=appearance.text("✓",13,INK,font,800);check.setBackground(appearance.background(BLUE,10,0,0));FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.TOP|Gravity.LEFT);pos.setMargins(dp(8),dp(8),0,0);frame.addView(check,pos);}
        return frame;
    }
    private void miniKey(LinearLayout line,JSONObject theme,String value,String fill,String text,int width){
        int bg=color(theme,fill,color(theme,"specialKeyBg",0xff252525));int ink=color(theme,text,color(theme,"specialKeyText",Color.WHITE));
        if("spaceText".equals(text))ink=color(theme,text,color(theme,"secondaryText",ink));
        double bw=theme.optDouble("keyBorderWidth",theme.optBoolean("hasKeyBorder")?1:0);
        if("enterBg".equals(fill))bw=theme.optString("enterBorder").isEmpty()?0:1;
        int border=color(theme,"enterBg".equals(fill)?"enterBorder":"keyBorder",0);
        TextView key=appearance.text(value,"!#1".equals(value)?6:7,ink,"system",700);key.setSingleLine(true);
        key.setBackground(appearance.background(bg,5,Math.min(bw,1.5),border));
        LayoutParams lp=new LayoutParams(width==0?0:dp(width),dp(16),width==0?1:0);if(line.getChildCount()>0)lp.leftMargin=dp(4);line.addView(key,lp);
    }
    private TextView themeTile(String value){TextView t=appearance.text(value,14,foreground,font,700);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(8),dp(12),dp(8));t.setBackground(appearance.background(light?0xfff0f9ff:0xff071d31,24,1,light?0xffbae6fd:0x3338bdf8));return t;}

    private void renderStore(LinearLayout body, JSONObject data) {
        active = data.optString("active");
        JSONArray ids = data.optJSONArray("downloaded");
        for (int i = 0; ids != null && i < ids.length(); i++) downloaded.add(ids.optString(i));
        boolean notifications = data.optBoolean("notificationsEnabled");
        if (!notifications) append(body, NativeSettingsNotification.create(getContext(), appearance, font, change), 0, -2);
        append(body, label("▣  ڕووکارە بەردەستەکان", 16, foreground, 800), notifications ? 0 : 20, 36);
        JSONArray themes = data.optJSONArray("themes");
        for (int i = 0; themes != null && i < themes.length(); i++) {
            JSONObject theme = themes.optJSONObject(i);
            if (theme == null) continue;
            StoreCard card = new StoreCard(theme, data.optBoolean("proUnlocked"));
            cards.add(card);
            append(body, card, 24, -2);
        }
    }

    private final class StoreCard extends LinearLayout {
        final String id;
        final TextView status;
        final TextView apply;
        final FrameLayout preview;

        StoreCard(JSONObject theme, boolean unlocked) {
            super(NativeThemeSettingsView.this.getContext());
            id = theme.optString("id");
            setOrientation(VERTICAL);
            LinearLayout heading = row();
            heading.setPadding(dp(4), 0, dp(4), 0);
            heading.addView(label(theme.optString("nameKu"), 12, foreground, 700), new LayoutParams(0, -2, 1));
            status = label("✓ چالاکە", 12, 0xff34d399, 700);
            heading.addView(status);
            append(this, heading, 0, -2);
            preview = new FrameLayout(getContext());
            preview.setPadding(dp(2), dp(2), dp(2), dp(2));
            preview.addView(preview(theme), new FrameLayout.LayoutParams(-1, -2));
            if (theme.optBoolean("isPro") && !unlocked) {
                TextView badge = appearance.text("PRO", 9, Color.WHITE, "system", 800);
                badge.setPadding(dp(6), 0, dp(6), 0);
                badge.setBackground(appearance.background(0xff465bcb, 6, 0, 0));
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-2, dp(18), Gravity.TOP | Gravity.RIGHT);
                params.setMargins(0, dp(8), dp(8), 0);
                preview.addView(badge, params);
            }
            append(this, preview, 10, -2);
            apply = appearance.text("", 14, INK, font, 800);
            apply.setOnClickListener(v -> {
                active = id;
                downloaded.add(id);
                for (StoreCard card : cards) card.paint();
                change.accept("applyTheme", id);
            });
            append(this, apply, 10, 48);
            paint();
        }

        void paint() {
            boolean selected = id.equals(active);
            status.setVisibility(selected ? VISIBLE : INVISIBLE);
            preview.setBackground(appearance.background(selected ? BLUE : 0x1affffff, 16, 0, 0));
            apply.setText(selected ? "✓ بەکارهێنراوە" : downloaded.contains(id) ? "بەکارهێنان" : "↓ داگرتن");
            apply.setTextColor(selected ? 0xff34d399 : INK);
            apply.setBackground(appearance.background(selected ? 0x3310b981 : BLUE, 16, selected ? 1 : 0, 0x6610b981));
        }
    }

    private void renderCustom(LinearLayout body, JSONObject data) {
        custom = data.optJSONObject("custom");
        if (custom == null) custom = new JSONObject();
        FrameLayout sample = new FrameLayout(getContext());
        append(body, sample, 0, -2);
        Runnable redraw = () -> {
            sample.removeAllViews();
            sample.addView(preview(custom), new FrameLayout.LayoutParams(-1, -2));
        };
        redraw.run();

        LinearLayout controls = column();
        controls.setPadding(dp(16), dp(16), dp(16), dp(16));
        controls.setBackground(appearance.background(0xff14161a, 24, 1, 0x1affffff));
        for (String[] field : COLOR_FIELDS) {
            String key = field[0];
            LinearLayout line = row();
            line.addView(label(field[1], 14, Color.WHITE, 700), new LayoutParams(0, -2, 1));
            TextView hex = appearance.text(custom.optString(key), 12, MUTED, "system", 500);
            hex.setTextDirection(TEXT_DIRECTION_LTR);
            line.addView(hex);
            View swatch = new View(getContext());
            swatch.setContentDescription(field[1]);
            swatch.setBackground(appearance.background(color(custom, key, Color.BLACK), 8, 1, 0x33ffffff));
            swatch.setOnClickListener(v -> chooseColor(field[1], color(custom, key, Color.BLACK), selected -> {
                String value = String.format(Locale.ROOT, "#%06X", selected & 0xffffff);
                update(key, value);
                if ("bg".equals(key)) put("toolbarBg", value);
                if ("keyBg".equals(key)) put("spaceBg", value);
                if ("enterBg".equals(key)) put("accent", value);
                hex.setText(value);
                swatch.setBackground(appearance.background(selected, 8, 1, 0x33ffffff));
                redraw.run();
            }));
            LayoutParams swatchParams = new LayoutParams(dp(36), dp(36));
            swatchParams.setMarginStart(dp(8));
            line.addView(swatch, swatchParams);
            append(controls, line, controls.getChildCount() == 0 ? 0 : 14, -2);
        }
        divider(controls, 12, 0x0dffffff);
        LinearLayout radiusLine = row();
        radiusLine.addView(label("خڕبوونی گۆشەکان", 12, Color.WHITE, 700), new LayoutParams(0, -2, 1));
        int radius = Math.max(4, Math.min(18, custom.optInt("borderRadius", 8)));
        TextView readout = appearance.text(radius + "px", 12, BLUE, "system", 500);
        radiusLine.addView(readout);
        append(controls, radiusLine, 8, -2);
        SeekBar corners = slider(14, radius - 4, value -> {
            int size = value + 4;
            readout.setText(size + "px");
            int previous = custom.optInt("borderRadius", 8);
            update("borderRadius", size);
            if (Math.min(previous, 8) != Math.min(size, 8)) redraw.run();
        });
        corners.setContentDescription("خڕبوونی گۆشەکان");
        append(controls, corners, 0, -2);
        divider(controls, 8, 0x0dffffff);
        LinearLayout edge = row();
        edge.addView(label("پیشاندانی لێواری دوگمەکان", 14, Color.WHITE, 700), new LayoutParams(0, -2, 1));
        TextView toggle = appearance.text("", 12, Color.WHITE, font, 700);
        toggle.setPadding(dp(12), 0, dp(12), 0);
        paintBorderToggle(toggle);
        toggle.setOnClickListener(v -> {
            update("hasKeyBorder", !custom.optBoolean("hasKeyBorder"));
            paintBorderToggle(toggle);
            redraw.run();
        });
        edge.addView(toggle, new LayoutParams(-2, dp(32)));
        append(controls, edge, 8, -2);
        append(body, controls, 20, -2);
        TextView save = appearance.text("پاشەکەوت و جێبەجێکردن", 14, INK, font, 800);
        save.setBackground(appearance.background(BLUE, 16, 0, 0));
        save.setOnClickListener(v -> change.accept("applyCustom", true));
        append(body, save, 20, 48);
    }

    private void paintBorderToggle(TextView toggle) {
        boolean enabled = custom.optBoolean("hasKeyBorder");
        toggle.setSelected(enabled);
        toggle.setText(enabled ? "چالاکە" : "ناچالاکە");
        toggle.setBackground(appearance.background(enabled ? 0xff0ea5e9 : 0xff27272a, 12, 0, 0));
    }

    private void update(String key, Object value) {
        put(key, value);
        change.accept(key, value);
    }

    private void put(String key, Object value) {
        try { custom.put(key, value); } catch (JSONException ignored) {}
    }

    private void chooseColor(String title, int initial, IntConsumer select) {
        LinearLayout controls = column();
        controls.setPadding(dp(20), dp(8), dp(20), dp(8));
        View swatch = new View(getContext());
        append(controls, swatch, 0, 48);
        int[] channels = {Color.red(initial), Color.green(initial), Color.blue(initial)};
        Runnable paint = () -> swatch.setBackground(appearance.background(Color.rgb(channels[0], channels[1], channels[2]), 10, 1, MUTED));
        paint.run();
        String[] names = {"سوور", "سەوز", "شین"};
        for (int i = 0; i < channels.length; i++) {
            int index = i;
            TextView value = label(names[i] + " " + channels[i], 12, foreground, 700);
            append(controls, value, 8, -2);
            SeekBar bar = slider(255, channels[i], next -> {
                channels[index] = next;
                value.setText(names[index] + " " + next);
                paint.run();
            });
            bar.setContentDescription(names[i]);
            append(controls, bar, 0, -2);
        }
        controls.setLayoutDirection(LAYOUT_DIRECTION_RTL);
        int dialogTheme = light ? android.R.style.Theme_Material_Light_Dialog_Alert : android.R.style.Theme_Material_Dialog_Alert;
        colorPicker = new AlertDialog.Builder(getContext(), dialogTheme).setTitle(title).setView(controls)
                .setNegativeButton("پاشگەزبوونەوە", null)
                .setPositiveButton("هەڵبژاردن", (dialog, button) -> select.accept(Color.rgb(channels[0], channels[1], channels[2])))
                .create();
        colorPicker.setOnDismissListener(dialog -> colorPicker = null);
        colorPicker.show();
    }

    @Override protected void onDetachedFromWindow() {
        if (colorPicker != null) colorPicker.dismiss();
        super.onDetachedFromWindow();
    }

    private SeekBar slider(int max, int initial, IntConsumer select) {
        SeekBar bar = new SeekBar(getContext());
        bar.setMax(max);
        bar.setProgress(initial);
        bar.setProgressTintList(ColorStateList.valueOf(BLUE));
        bar.setThumbTintList(ColorStateList.valueOf(BLUE));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seek, int value, boolean fromUser) { if (fromUser) select.accept(value); }
            @Override public void onStartTrackingTouch(SeekBar seek) {}
            @Override public void onStopTrackingTouch(SeekBar seek) {}
        });
        return bar;
    }

    private View preview(JSONObject theme) {
        LinearLayout board = column();
        board.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        board.setPadding(dp(12), dp(10), dp(12), dp(10));
        board.setBackground(appearance.background(color(theme, "bg", Color.BLACK), 14, 0, 0));
        String[] keys = {"1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"};
        for (int i = 0; i < keys.length; i++) {
            LinearLayout line = row();
            if (i == 2) line.setPadding(dp(12), 0, dp(12), 0);
            if (i == 3) key(line, theme, "↑", "shiftBg", "shiftText", 40, 32);
            for (char character : keys[i].toCharArray()) key(line, theme, String.valueOf(character), "keyBg", "keyText", 0, i == 0 ? 28 : 32);
            if (i == 3) key(line, theme, "⌫", "backspaceBg", "backspaceText", 40, 32);
            append(board, line, i == 0 ? 0 : 4, -2);
        }
        LinearLayout bottom = row();
        key(bottom, theme, "!#1", "symbolsBg", "symbolsText", 48, 32);
        key(bottom, theme, "‹ کوردی ›", "spaceBg", "spaceText", 0, 32);
        key(bottom, theme, "↵", "enterBg", "enterText", 48, 32);
        append(board, bottom, 4, -2);
        return board;
    }

    private void key(LinearLayout line, JSONObject theme, String glyph, String bg, String fg, int width, int height) {
        int background = color(theme, bg, color(theme, "specialKeyBg", 0xff20242c));
        int text = color(theme, fg, color(theme, "spaceText".equals(fg) ? "secondaryText" : "specialKeyText", Color.WHITE));
        boolean enter = "enterBg".equals(bg);
        double stroke = enter ? (theme.optString("enterBorder").isEmpty() ? 0 : 1)
                : Math.max(0, Math.min(1.5, theme.optDouble("keyBorderWidth", theme.optBoolean("hasKeyBorder") ? 1 : 0)));
        int edge = color(theme, enter ? "enterBorder" : "keyBorder", 0x1affffff);
        TextView key = appearance.text(glyph, 11, text, "system", 700);
        key.setBackground(appearance.background(background, Math.min(8, theme.optInt("borderRadius", 8)), stroke, edge));
        LayoutParams params = new LayoutParams(dp(width), dp(height), width == 0 ? 1 : 0);
        if (line.getChildCount() > 0) params.leftMargin = dp(4);
        line.addView(key, params);
    }

    private int color(JSONObject theme, String name, int fallback) { return appearance.color(theme, name, fallback); }
    private int dp(int value) { return appearance.dp(value); }

    private TextView label(String value, int size, int color, int weight) {
        TextView view = appearance.text(value, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout row() {
        LinearLayout line = new LinearLayout(getContext());
        line.setGravity(Gravity.CENTER_VERTICAL);
        return line;
    }

    private LinearLayout column() {
        LinearLayout line = new LinearLayout(getContext());
        line.setOrientation(VERTICAL);
        return line;
    }

    private void divider(LinearLayout parent, int gap, int color) {
        View divider = new View(getContext());
        divider.setBackgroundColor(color);
        append(parent, divider, gap, 1);
    }

    private void append(LinearLayout parent, View child, int gap, int height) {
        LayoutParams params = new LayoutParams(-1, height < 0 ? height : dp(height));
        params.topMargin = dp(gap);
        parent.addView(child, params);
    }
}
