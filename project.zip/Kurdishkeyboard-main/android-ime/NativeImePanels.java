package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;

import android.graphics.Color;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.Selection;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashSet;

final class NativeImePanels implements AutoCloseable {
    private static final String[][] TOOLS = {
            {"live_translate", "وەرگێڕانی ڕاستەوخۆ", "ic_translate"}, {"text_edit", "کۆنترۆڵی دەق و کێرسەر", "ic_select_all"},
            {"snippets_calc", "کلێشە و بژمێری خێرا", "ic_note"}, {"translate", "وەرگێڕان", "ic_translate"},
            {"resize", "گۆڕینی قەبارە", "ic_resize"}, {"decorate", "جوانکاری نووسین", "ic_text"}, {"themes", "ڕووکارەکان", "ic_themes"},
            {"voice", "گەڕانی دەنگی", "ic_mic"}, {"settings", "ڕێکخستنەکان", "ic_settings"}, {"redo", "دواتر", "ic_redo"},
            {"undo", "پێشتر", "ic_undo"}, {"one_handed", "دۆخی یەکدەست", "ic_accessibility_one_handed"},
            {"switch_lang", "گۆڕینی زمان", "ic_language"}, {"ai_smart", "وەڵامدەرەوەی زیرەک", "ic_smart"}, {"clipboard", "لەبەرگیراوەکان", "ic_clipboard_manager"},
    };
    private final NativeImeView keyboard;
    private final KurdiKeyboardImeService.AndroidImeBridge editor;
    private final NativeImeEngine engine;
    final NativeImeClipboardPanel clipboardPanel;
    private final NativeImeCalculatorPanel calculatorPanel;
    private final NativeImePanelStyle ui;
    private final NativeImeWritingPanels writing;
    private final NativeImeMediaPanel mediaPanel;
    private boolean cursorSelect;
    private boolean reorderTools;
    private String swapTool = "";
    private String typed = "";
    private NativeImeView.StringAction typingAction;
    private NativeImeView.StringAction typingEnterAction;
    private String typingReturn = "";
    private EditText toolField;
    private boolean fieldTransition;
    private TextView typedDisplay;
    private View searchClear;
    private LinearLayout searchResults;
    private boolean emojiSearch;

    NativeImePanels(NativeImeView keyboard) {
        this.keyboard = keyboard;
        editor = keyboard.editor;
        engine = keyboard.engine;
        ui = new NativeImePanelStyle(keyboard);
        mediaPanel = new NativeImeMediaPanel(keyboard, ui, keyboard::openEmojiSearch);
        writing = new NativeImeWritingPanels(keyboard, this, ui);
        calculatorPanel = new NativeImeCalculatorPanel(keyboard, ui, this);
        clipboardPanel = new NativeImeClipboardPanel(keyboard, writing::translateClipboard);
    }

    void readState(JSONObject state) { writing.readState(state); }

    void panelChanged(String panel) {
        if (!fieldTransition) {
            clearToolField();
            calculatorPanel.reset();
        }
        emojiSearch = false;
        writing.panelChanged(panel, fieldTransition);
        if ("emoji".equals(panel)) mediaPanel.open();
        else mediaPanel.closePanel();
        clipboardPanel.reset();
    }

    View render(String panel) {
        if ("clipboard".equals(panel)) return clipboardPanel.render();
        if ("emoji".equals(panel)) return mediaPanel.render();
        if ("snippets_calc".equals(panel)) return calculatorPanel.render();
        if (NativeImeWritingPanels.isWritingPanel(panel)) return writing.render("ai_smart".equals(panel));
        LinearLayout shell = keyboard.column();
        shell.setPadding(keyboard.dp(12), keyboard.dp(10), keyboard.dp(12), keyboard.dp(10));
        shell.setMinimumHeight(keyboard.dp(Math.max(keyboard.settings.optInt("keyboardHeightPx") + 36, 315)));
        shell.setBackgroundColor(keyboard.bg());
        switch (panel) {
            case "tools": tools(shell); break;
            case "themes": themes(shell); break;
            case "decorate": decorate(shell); break;
            case "cursor_control": cursor(shell); break;
            default: title(shell, "", null);
        }
        return shell;
    }

    private void title(LinearLayout shell, String label, View action) {
        LinearLayout row = keyboard.row();
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = keyboard.appearance.text(label, 14, keyboard.textColor(), keyboard.font(), 700);
        heading.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(heading, new LinearLayout.LayoutParams(0, -1, 1));
        if (action != null) row.addView(action);
        row.addView(keyboard.iconButton("close", "گەڕانەوە بۆ تەختەکلیل", 18, keyboard.textColor(), () -> keyboard.openPanel("keys")), new LinearLayout.LayoutParams(keyboard.dp(36), -1));
        shell.addView(row, new LinearLayout.LayoutParams(-1, keyboard.dp(38)));
    }

    private LinearLayout scroller(LinearLayout outer, int height) {
        ScrollView scroll = new ScrollView(keyboard.getContext());
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        LinearLayout content = keyboard.column();
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, keyboard.dp(height)));
        return content;
    }

    private void tile(LinearLayout row, View view, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, keyboard.dp(height), 1);
        p.setMargins(keyboard.dp(3), keyboard.dp(3), keyboard.dp(3), keyboard.dp(3));
        row.addView(view, p);
    }

    private TextView line(String text) {
        TextView view = keyboard.appearance.text(text, 12, keyboard.textColor(), keyboard.font(), 500);
        view.setGravity(Gravity.TOP | Gravity.RIGHT);
        view.setPadding(keyboard.dp(8), keyboard.dp(6), keyboard.dp(8), keyboard.dp(6));
        return view;
    }

    private void tools(LinearLayout shell) {
        title(shell, "", keyboard.button(reorderTools ? "تەواوکردنی ڕێکخستن" : "گۆڕینی شوێن", () -> {
            reorderTools = !reorderTools;
            swapTool = "";
            keyboard.render();
        }));
        if (reorderTools) shell.addView(line("لەسەر دوو ئامراز دابگرە بۆ گۆڕینی شوێنەکانیان"));
        JSONArray order = keyboard.settings.optJSONArray("toolsOrder");
        LinearLayout grid = scroller(shell, 248);
        LinearLayout row = null;
        int count = 0;
        for (int i = 0; order != null && i < order.length(); i++) {
            String id = order.optString(i);
            String[] entry = null;
            for (String[] tool : TOOLS) if (id.equals(tool[0])) { entry = tool; break; }
            if (entry == null) continue;
            if (count++ % 2 == 0) { row = keyboard.row(); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); grid.addView(row); }
            TextView button = keyboard.button(entry[1], () -> tool(id, order));
            android.graphics.drawable.Drawable icon = keyboard.appearance.icon(entry[2], keyboard.accent(), 18);
            button.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, null, null, null);
            if (id.equals(swapTool)) button.setBackgroundColor(keyboard.accent());
            tile(row, button, 48);
        }
        if (row != null && count % 2 != 0) tile(row, new View(keyboard.getContext()), 48);
    }

    private void tool(String id, JSONArray order) {
        if (reorderTools) {
            if (swapTool.isEmpty()) { swapTool = id; keyboard.render(); return; }
            JSONArray next = new JSONArray();
            for (int i = 0; i < order.length(); i++) {
                String key = order.optString(i);
                next.put(key.equals(swapTool) ? id : key.equals(id) ? swapTool : key);
            }
            swapTool = "";
            keyboard.settingsPatch(json("toolsOrder", next));
            return;
        }
        switch (id) {
            case "live_translate": writing.startLive(); break;
            case "text_edit": keyboard.openPanel("cursor_control"); break;
            case "resize": keyboard.beginResize(); break;
            case "voice": keyboard.toggleVoice(); break;
            case "settings": editor.openSettings(); keyboard.openPanel("keys"); break;
            case "undo": editor.undo(); break;
            case "redo": editor.redo(); break;
            case "one_handed":
                String handed = keyboard.settings.optString("oneHandedMode");
                keyboard.settingsPatch(json("oneHandedMode", "off".equals(handed) ? "right" : "right".equals(handed) ? "left" : "off"));
                keyboard.openPanel("keys");
                break;
            case "switch_lang": keyboard.swipeAction("switch_to_next_subtype", null); keyboard.openPanel("keys"); break;
            default: keyboard.openPanel(id);
        }
    }

    private void cursor(LinearLayout shell) {
        title(shell, "کۆنترۆڵی دەق و کێرسەر", keyboard.button(cursorSelect ? "هەڵبژاردن ✓" : "هەڵبژاردن", () -> { cursorSelect = !cursorSelect; keyboard.render(); }));
        String[][] labels = {{"سەرەتا", "↑", "کۆتایی"}, {"←", "هەموو", "→"}, {"⌫", "↓", "سڕینەوەی وشە"}, {"کۆپی", "بڕین", "پەیست"}};
        Runnable[][] handlers = {
                {() -> editor.moveLineEdge(false, cursorSelect), () -> keyboard.moveCursor(0, -1, cursorSelect), () -> editor.moveLineEdge(true, cursorSelect)},
                {() -> keyboard.moveCursor(-1, 0, cursorSelect), editor::selectAll, () -> keyboard.moveCursor(1, 0, cursorSelect)},
                {editor::deleteBackward, () -> keyboard.moveCursor(0, 1, cursorSelect), editor::deleteWord},
                {editor::copy, editor::cut, editor::paste}};
        for (int r = 0; r < labels.length; r++) {
            LinearLayout row = keyboard.row();
            for (int c = 0; c < labels[r].length; c++) {
                Runnable action = handlers[r][c];
                TextView button = keyboard.button(labels[r][c], action);
                if ("↑↓←→⌫".contains(labels[r][c])) repeat(button, action);
                tile(row, button, 49);
            }
            shell.addView(row);
        }
    }

    private void repeat(View view, Runnable action) {
        Runnable repeat = new Runnable() {
            @Override public void run() { if (view.isPressed() && view.isAttachedToWindow()) { action.run(); view.postDelayed(this, 78); } }
        };
        view.setOnTouchListener((target, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                action.run(); target.setPressed(true); target.postDelayed(repeat, 350);
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                target.setPressed(false); target.removeCallbacks(repeat);
            }
            return true;
        });
    }

    void enableEmojiSearch() {
        emojiSearch = true;
        typed = "";
    }

    void recordRich(String kind, String value) { mediaPanel.record(kind, value); }

    private void themes(LinearLayout shell) {
        title(shell, "ڕووکارەکان", null);
        LinearLayout list = scroller(shell, 240);
        JSONArray themes = engine.array("themes", null);
        JSONArray downloaded = keyboard.settings.optJSONArray("downloadedThemeIds");
        themes.put(keyboard.settings.optJSONObject("customTheme"));
        LinearLayout row = null;
        int count = 0;
        for (int i = 0; i < themes.length(); i++) {
            JSONObject item = themes.optJSONObject(i);
            if (item == null || item.optBoolean("isStore") && !NativeImeData.contains(downloaded, item.optString("id"))) continue;
            if (count++ % 2 == 0) { row = keyboard.row(); list.addView(row); }
            String id = item.optString("id");
            TextView button = keyboard.button(item.optString("nameKu", item.optString("name")), () -> keyboard.settingsPatch(json("activeThemeId", id)));
            button.setTextColor(keyboard.appearance.color(item, "keyText", keyboard.textColor()));
            boolean selected = id.equals(keyboard.settings.optString("activeThemeId"));
            button.setBackground(keyboard.appearance.background(keyboard.appearance.color(item, "bg", keyboard.keyColor()), 14, selected ? 2 : 1, keyboard.appearance.color(item, "accent", keyboard.accent())));
            tile(row, button, 65);
        }
        if (row != null && count % 2 != 0) tile(row, new View(keyboard.getContext()), 65);
    }

    private void decorate(LinearLayout shell) {
        title(shell, "جوانکاری نووسین", null);
        LinearLayout list = scroller(shell, 248);
        JSONArray styles = engine.array("decorators", null);
        for (int i = 0; i < styles.length(); i++) {
            JSONObject style = styles.optJSONObject(i);
            String id = style.optString("id");
            TextView button = keyboard.button(style.optString("label") + "\n" + style.optString("sample"), () -> {
                keyboard.decorator = id;
                keyboard.openPanel("keys");
            });
            list.addView(button, new LinearLayout.LayoutParams(-1, keyboard.dp(48)));
        }
    }

    TextView input(String placeholder, String value, Runnable action) {
        TextView field = ui.button(value.isEmpty() ? placeholder : value, 12, value.isEmpty() ? NativeImePanelStyle.MUTED : ui.foreground(), 400,
                ui.color(Color.WHITE, 0xff16181d), 12, ui.border(), 12, action);
        field.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        return field;
    }

    void beginTyping(String title, String value, String returnPanel, NativeImeView.StringAction action) {
        beginTyping(title, value, returnPanel, action, action);
    }

    void beginTyping(String title, String value, String returnPanel, NativeImeView.StringAction done, NativeImeView.StringAction enter) {
        typingReturn = returnPanel;
        typingAction = done;
        typingEnterAction = enter;
        toolField = new EditText(keyboard.getContext());
        toolField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        toolField.setSingleLine(true);
        toolField.setShowSoftInputOnFocus(false);
        toolField.setImeOptions(EditorInfo.IME_ACTION_DONE);
        toolField.setOnEditorActionListener((field, id, event) -> {
            if (id != EditorInfo.IME_ACTION_DONE) return false;
            finishTyping(typingEnterAction);
            return true;
        });
        toolField.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        toolField.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        toolField.setTextSize(TypedValue.COMPLEX_UNIT_PX, keyboard.appearance.px(12));
        toolField.setTypeface(keyboard.appearance.font(keyboard.font(), 400));
        toolField.setTextColor(ui.foreground());
        toolField.setHintTextColor(0xffa1a1aa);
        toolField.setBackground(ui.face(ui.color(Color.WHITE, 0xff16181d), 12, NativeImePanelStyle.SKY));
        toolField.setIncludeFontPadding(false);
        ui.padding(toolField, 10, 0);
        toolField.setHint(title);
        toolField.setText(value);
        toolField.setSelection(toolField.length());
        fieldTransition = true;
        try {
            keyboard.mode = "characters";
            keyboard.openPanel("keys");
        } finally {
            fieldTransition = false;
        }
    }

    boolean editingToolField() { return toolField != null; }
    boolean showingLivePicker() { return !editingToolField() && writing.pickingLiveLanguage(); }
    View livePicker() { return writing.picker(true); }

    boolean renderTypingStrip(LinearLayout outer) {
        if (editingToolField()) {
            LinearLayout bar = ui.row();
            ui.padding(bar, 8, 6);
            if (toolField.getParent() instanceof ViewGroup) ((ViewGroup) toolField.getParent()).removeView(toolField);
            ui.flex(bar, toolField, 34, 0);
            ui.add(bar, ui.button("تەواو", 12, Color.WHITE, 700, NativeImePanelStyle.BLUE, 8, 0, 12,
                    () -> finishTyping(typingAction)), NativeImePanelStyle.WRAP, 34, 6);
            ui.add(bar, ui.close(() -> finishTyping(null), 14), 30, 30, 6);
            outer.addView(bar);
            return true;
        }
        if (writing.live()) {
            writing.addLive(outer);
            return true;
        }
        if (!emojiSearch) return false;
        LinearLayout bar = ui.row();
        ui.padding(bar, 6, 4);
        ui.add(bar, ui.iconButton("arrow_right", "گەڕانەوە بۆ خەندەکان", ui.foreground(), 16,
                ui.color(0xffe2e8f0, 0x1affffff), 16, () -> keyboard.openPanel("emoji")), 32, 32, 0);
        LinearLayout field = ui.row();
        field.setBackground(ui.face(ui.color(Color.WHITE, 0x14ffffff), 12, 0x8038bdf8));
        ui.padding(field, 10, 0);
        ui.add(field, ui.icon("search", NativeImePanelStyle.SKY, 14), 14, 14, 0);
        typedDisplay = ui.text("", 12, ui.foreground(), 500);
        typedDisplay.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        ui.truncate(typedDisplay);
        ui.flex(field, typedDisplay, 32, 6);
        searchClear = ui.iconButton("close", "پاککردنەوە", ui.mutedText(), 14, Color.TRANSPARENT, 10,
                () -> { typed = ""; refreshEmojiSearch(); });
        ui.add(field, searchClear, 20, 28, 6);
        ui.flex(bar, field, 32, 6);
        outer.addView(bar);
        HorizontalScrollView scroll = new HorizontalScrollView(keyboard.getContext());
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        searchResults = keyboard.row();
        scroll.addView(searchResults, new FrameLayout.LayoutParams(-2, -1));
        ui.add(outer, scroll, -1, 40, 0);
        refreshEmojiSearch();
        return true;
    }

    boolean type(String value) {
        if (clipboardPanel.editing()) { clipboardPanel.insertInEdit(value); return true; }
        if (insertToolField(value)) return true;
        if (writing.live()) { writing.liveType(value); return true; }
        if (!emojiSearch) return false;
        if (typed.length() < 12000) typed += value;
        refreshEmojiSearch();
        return true;
    }

    boolean insertToolField(String value) {
        if (!editingToolField()) return false;
        Editable editable = toolField.getText();
        int start = Math.max(0, Math.min(toolField.getSelectionStart(), toolField.getSelectionEnd()));
        int end = Math.max(start, Math.max(toolField.getSelectionStart(), toolField.getSelectionEnd()));
        editable.replace(start, end, value);
        toolField.setSelection(start + value.length());
        return true;
    }

    boolean typingDelete(boolean word) {
        if (editingToolField()) {
            Editable editable = toolField.getText();
            int start = Math.max(0, Math.min(toolField.getSelectionStart(), toolField.getSelectionEnd()));
            int end = Math.max(start, Math.max(toolField.getSelectionStart(), toolField.getSelectionEnd()));
            if (start == end && start > 0) {
                if (word) {
                    while (start > 0 && Character.isWhitespace(editable.charAt(start - 1))) start--;
                    while (start > 0 && !Character.isWhitespace(editable.charAt(start - 1))) start--;
                } else start = Character.offsetByCodePoints(editable, start, -1);
            }
            editable.delete(start, end);
            toolField.setSelection(start);
            return true;
        }
        if (writing.live()) { writing.liveDelete(); return true; }
        if (!emojiSearch) return false;
        if (!typed.isEmpty()) typed = typed.substring(0, typed.offsetByCodePoints(typed.length(), -1));
        refreshEmojiSearch();
        return true;
    }

    boolean typingEnter() {
        if (clipboardPanel.editing()) { clipboardPanel.insertInEdit("\n"); return true; }
        if (editingToolField()) { finishTyping(typingEnterAction); return true; }
        if (writing.live()) { writing.commitLive(); return true; }
        if (!emojiSearch) return false;
        JSONArray matches = engine.array("emojiSearch", typed);
        if (!typed.trim().isEmpty() && matches.length() > 0) insertSearched(matches.optJSONObject(0).optString("c"));
        else keyboard.openPanel("emoji");
        return true;
    }

    private void finishTyping(NativeImeView.StringAction action) {
        String value = toolField.getText().toString();
        String previous = typingReturn;
        clearToolField();
        fieldTransition = true;
        try {
            keyboard.openPanel(previous);
        } finally {
            fieldTransition = false;
        }
        if (action != null) action.accept(value);
    }

    private void clearToolField() {
        toolField = null;
        typingAction = typingEnterAction = null;
        typingReturn = "";
    }

    boolean moveToolField(int x, int y, boolean extend, boolean lineEdge) {
        if (!editingToolField()) return false;
        Editable editable = toolField.getText();
        Layout layout = toolField.getLayout();
        if (layout == null) return true;
        if (lineEdge && x < 0) {
            if (extend) Selection.extendToLeftEdge(editable, layout); else Selection.moveToLeftEdge(editable, layout);
        } else if (lineEdge && x > 0) {
            if (extend) Selection.extendToRightEdge(editable, layout); else Selection.moveToRightEdge(editable, layout);
        } else if (y < 0) {
            if (extend) Selection.extendUp(editable, layout); else Selection.moveUp(editable, layout);
        } else if (y > 0) {
            if (extend) Selection.extendDown(editable, layout); else Selection.moveDown(editable, layout);
        } else if (x < 0) {
            if (extend) Selection.extendLeft(editable, layout); else Selection.moveLeft(editable, layout);
        } else if (x > 0) {
            if (extend) Selection.extendRight(editable, layout); else Selection.moveRight(editable, layout);
        }
        return true;
    }

    boolean editToolField(int command) {
        if (!editingToolField()) return false;
        toolField.onTextContextMenuItem(command);
        return true;
    }

    private void insertSearched(String emoji) {
        keyboard.feedback("char");
        keyboard.insert(emoji);
        recordRich("emoji", emoji);
    }

    private void refreshEmojiSearch() {
        if (!emojiSearch || typedDisplay == null || searchResults == null) return;
        typedDisplay.setText(typed.isEmpty() ? "بە کوردی یان ئینگلیزی بنووسە (دڵ، پێکەنین، heart)..." : typed);
        searchClear.setVisibility(typed.isEmpty() ? View.GONE : View.VISIBLE);
        typedDisplay.setTextColor(typed.isEmpty() ? ui.mutedText() : ui.foreground());
        searchResults.removeAllViews();
        LinkedHashSet<String> values = new LinkedHashSet<>();
        int limit = typed.trim().isEmpty() ? 36 : 48;
        if (typed.trim().isEmpty()) {
            JSONArray recent = NativeImeData.arr(keyboard.settings, "recentEmojis");
            for (int i = 0; i < recent.length() && values.size() < limit; i++) values.add(recent.optString(i));
            JSONArray categories = NativeImeData.arr(engine.object("media", null), "categories");
            JSONArray entries = NativeImeData.arr(categories.optJSONObject(0), "items");
            for (int i = 0; i < Math.min(28, entries.length()); i++) values.add(entries.optJSONObject(i).optString("c"));
        } else {
            JSONArray entries = engine.array("emojiSearch", typed);
            for (int i = 0; i < Math.min(limit, entries.length()); i++) values.add(entries.optJSONObject(i).optString("c"));
        }
        if (values.isEmpty()) {
            ui.flex(searchResults, ui.text("هیچ خەندەیەک نەدۆزرایەوە", 12, ui.mutedText(), 500), 40, 0);
            return;
        }
        int count = 0;
        for (String emoji : values) {
            if (count++ >= limit) break;
            View cell = mediaPanel.searchGlyph(emoji, 24);
            mediaPanel.bindInsert(cell, () -> insertSearched(emoji));
            ui.add(searchResults, cell, 40, 36, 4);
        }
    }

    void endSession() {
        writing.endSession();
        calculatorPanel.reset();
        mediaPanel.closePanel();
        clearToolField();
        typed = "";
        emojiSearch = false;
        clipboardPanel.reset();
    }

    @Override public void close() { writing.close(); mediaPanel.close(); }
}
