package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;

import android.graphics.Color;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.Selection;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

final class NativeImePanels implements AutoCloseable {
    private static final String[][] TOOLS = {
            {"live_translate", "وەرگێڕانی ڕاستەوخۆ", "ic_translate"}, {"text_edit", "کۆنترۆڵی دەق و کێرسەر", "ic_select_all"},
            {"snippets_calc", "کلێشە و بژمێری خێرا", "ic_note"}, {"translate", "وەرگێڕان", "ic_translate"},
            {"resize", "گۆڕینی قەبارە", "ic_resize"}, {"decorate", "جوانکاری نووسین", "ic_text"}, {"themes", "ڕووکارەکان", "ic_themes"},
            {"voice", "گەڕانی دەنگی", "ic_mic"}, {"settings", "ڕێکخستنەکان", "ic_settings"}, {"redo", "دواتر", "ic_redo"},
            {"undo", "پێشتر", "ic_undo"}, {"one_handed", "دۆخی یەکدەست", "ic_accessibility_one_handed"},
            {"switch_lang", "گۆڕینی زمان", "ic_language"}, {"ai_smart", "وەڵامدەرەوەی زیرەک", "ic_smart"}, {"clipboard", "لەبەرگیراوەکان", "ic_clipboard_manager"},
    };
    private final NativeImeView keyboard;
    private final KurdiKeyboardImeService.AndroidImeBridge editor;
    private final NativeImeEngine engine;
    final NativeImeClipboardPanel clipboardPanel;
    private final NativeImeCalculatorPanel calculatorPanel;
    private final NativeImePanelStyle ui;
    private final NativeImeWritingPanels writing;
    private JSONObject media;
    private String emojiCategory = "recent";
    private String richTab = "emoji";
    private String zikrGroup = "duaa";
    private boolean cursorSelect;
    private boolean reorderTools;
    private String swapTool = "";
    private String typed = "";
    private NativeImeView.StringAction typingAction;
    private NativeImeView.StringAction typingEnterAction;
    private String typingReturn = "";
    private EditText toolField;
    private boolean fieldTransition;
    private TextView typedDisplay;
    private LinearLayout searchResults;
    private boolean emojiSearch;

    NativeImePanels(NativeImeView keyboard) {
        this.keyboard = keyboard;
        editor = keyboard.editor;
        engine = keyboard.engine;
        ui = new NativeImePanelStyle(keyboard);
        writing = new NativeImeWritingPanels(keyboard, this, ui);
        calculatorPanel = new NativeImeCalculatorPanel(keyboard, ui, this);
        clipboardPanel = new NativeImeClipboardPanel(keyboard, writing::translateClipboard);
    }

    void readState(JSONObject state) { writing.readState(state); }

    void panelChanged(String panel) {
        if (!fieldTransition) {
            clearToolField();
            calculatorPanel.reset();
        }
        emojiSearch = false;
        writing.panelChanged(panel, fieldTransition);
        if ("emoji".equals(panel)) {
            emojiCategory = "recent".equals(keyboard.settings.optString("emojiInitialTab")) ? "recent" : keyboard.settings.optString("emojiLastUsedCategory", "recent");
        }
        clipboardPanel.reset();
    }

    View render(String panel) {
        if ("clipboard".equals(panel)) return clipboardPanel.render();
        if ("snippets_calc".equals(panel)) return calculatorPanel.render();
        if (NativeImeWritingPanels.isWritingPanel(panel)) return writing.render("ai_smart".equals(panel));
        LinearLayout shell = keyboard.column();
        shell.setPadding(keyboard.dp(12), keyboard.dp(10), keyboard.dp(12), keyboard.dp(10));
        shell.setMinimumHeight(keyboard.dp(Math.max(keyboard.settings.optInt("keyboardHeightPx") + 36, 315)));
        shell.setBackgroundColor(keyboard.bg());
        switch (panel) {
            case "tools": tools(shell); break;
            case "emoji": rich(shell); break;
            case "themes": themes(shell); break;
            case "decorate": decorate(shell); break;
            case "cursor_control": cursor(shell); break;
            default: title(shell, "", null);
        }
        return shell;
    }

    private void title(LinearLayout shell, String label, View action) {
        LinearLayout row = keyboard.row();
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = keyboard.appearance.text(label, 14, keyboard.textColor(), keyboard.font(), 700);
        heading.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(heading, new LinearLayout.LayoutParams(0, -1, 1));
        if (action != null) row.addView(action);
        row.addView(keyboard.iconButton("close", "گەڕانەوە بۆ تەختەکلیل", 18, keyboard.textColor(), () -> keyboard.openPanel("keys")), new LinearLayout.LayoutParams(keyboard.dp(36), -1));
        shell.addView(row, new LinearLayout.LayoutParams(-1, keyboard.dp(38)));
    }

    private LinearLayout scroller(LinearLayout outer, int height) {
        ScrollView scroll = new ScrollView(keyboard.getContext());
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        LinearLayout content = keyboard.column();
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, keyboard.dp(height)));
        return content;
    }

    private LinearLayout strip(LinearLayout outer) {
        HorizontalScrollView view = new HorizontalScrollView(keyboard.getContext());
        view.setHorizontalScrollBarEnabled(false);
        LinearLayout row = keyboard.row();
        view.addView(row, new FrameLayout.LayoutParams(-2, -2));
        outer.addView(view, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    private void tile(LinearLayout row, View view, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, keyboard.dp(height), 1);
        p.setMargins(keyboard.dp(3), keyboard.dp(3), keyboard.dp(3), keyboard.dp(3));
        row.addView(view, p);
    }

    private TextView line(String text) {
        TextView view = keyboard.appearance.text(text, 12, keyboard.textColor(), keyboard.font(), 500);
        view.setGravity(Gravity.TOP | Gravity.RIGHT);
        view.setPadding(keyboard.dp(8), keyboard.dp(6), keyboard.dp(8), keyboard.dp(6));
        return view;
    }

    private void tools(LinearLayout shell) {
        title(shell, "", keyboard.button(reorderTools ? "تەواوکردنی ڕێکخستن" : "گۆڕینی شوێن", () -> {
            reorderTools = !reorderTools;
            swapTool = "";
            keyboard.render();
        }));
        if (reorderTools) shell.addView(line("لەسەر دوو ئامراز دابگرە بۆ گۆڕینی شوێنەکانیان"));
        JSONArray order = keyboard.settings.optJSONArray("toolsOrder");
        LinearLayout grid = scroller(shell, 248);
        LinearLayout row = null;
        int count = 0;
        for (int i = 0; order != null && i < order.length(); i++) {
            String id = order.optString(i);
            String[] entry = null;
            for (String[] tool : TOOLS) if (id.equals(tool[0])) { entry = tool; break; }
            if (entry == null) continue;
            if (count++ % 2 == 0) { row = keyboard.row(); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); grid.addView(row); }
            TextView button = keyboard.button(entry[1], () -> tool(id, order));
            android.graphics.drawable.Drawable icon = keyboard.appearance.icon(entry[2], keyboard.accent(), 18);
            button.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, null, null, null);
            if (id.equals(swapTool)) button.setBackgroundColor(keyboard.accent());
            tile(row, button, 48);
        }
        if (row != null && count % 2 != 0) tile(row, new View(keyboard.getContext()), 48);
    }

    private void tool(String id, JSONArray order) {
        if (reorderTools) {
            if (swapTool.isEmpty()) { swapTool = id; keyboard.render(); return; }
            JSONArray next = new JSONArray();
            for (int i = 0; i < order.length(); i++) {
                String key = order.optString(i);
                next.put(key.equals(swapTool) ? id : key.equals(id) ? swapTool : key);
            }
            swapTool = "";
            keyboard.settingsPatch(json("toolsOrder", next));
            return;
        }
        switch (id) {
            case "live_translate": writing.startLive(); break;
            case "text_edit": keyboard.openPanel("cursor_control"); break;
            case "resize": keyboard.beginResize(); break;
            case "voice": keyboard.toggleVoice(); break;
            case "settings": editor.openSettings(); keyboard.openPanel("keys"); break;
            case "undo": editor.undo(); break;
            case "redo": editor.redo(); break;
            case "one_handed":
                String handed = keyboard.settings.optString("oneHandedMode");
                keyboard.settingsPatch(json("oneHandedMode", "off".equals(handed) ? "right" : "right".equals(handed) ? "left" : "off"));
                keyboard.openPanel("keys");
                break;
            case "switch_lang": keyboard.swipeAction("switch_to_next_subtype", null); keyboard.openPanel("keys"); break;
            default: keyboard.openPanel(id);
        }
    }

    private void cursor(LinearLayout shell) {
        title(shell, "کۆنترۆڵی دەق و کێرسەر", keyboard.button(cursorSelect ? "هەڵبژاردن ✓" : "هەڵبژاردن", () -> { cursorSelect = !cursorSelect; keyboard.render(); }));
        String[][] labels = {{"سەرەتا", "↑", "کۆتایی"}, {"←", "هەموو", "→"}, {"⌫", "↓", "سڕینەوەی وشە"}, {"کۆپی", "بڕین", "پەیست"}};
        Runnable[][] handlers = {
                {() -> editor.moveLineEdge(false, cursorSelect), () -> keyboard.moveCursor(0, -1, cursorSelect), () -> editor.moveLineEdge(true, cursorSelect)},
                {() -> keyboard.moveCursor(-1, 0, cursorSelect), editor::selectAll, () -> keyboard.moveCursor(1, 0, cursorSelect)},
                {editor::deleteBackward, () -> keyboard.moveCursor(0, 1, cursorSelect), editor::deleteWord},
                {editor::copy, editor::cut, editor::paste}};
        for (int r = 0; r < labels.length; r++) {
            LinearLayout row = keyboard.row();
            for (int c = 0; c < labels[r].length; c++) {
                Runnable action = handlers[r][c];
                TextView button = keyboard.button(labels[r][c], action);
                if ("↑↓←→⌫".contains(labels[r][c])) repeat(button, action);
                tile(row, button, 49);
            }
            shell.addView(row);
        }
    }

    private void repeat(View view, Runnable action) {
        Runnable repeat = new Runnable() {
            @Override public void run() { if (view.isPressed() && view.isAttachedToWindow()) { action.run(); view.postDelayed(this, 78); } }
        };
        view.setOnTouchListener((target, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                action.run(); target.setPressed(true); target.postDelayed(repeat, 350);
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                target.setPressed(false); target.removeCallbacks(repeat);
            }
            return true;
        });
    }

    private void rich(LinearLayout shell) {
        if (media == null) media = engine.object("media", null);
        title(shell, "", keyboard.button("گەڕان", () -> {
            keyboard.openPanel("keys");
            emojiSearch = true;
            typed = "";
            keyboard.render();
        }));
        LinearLayout tabs = keyboard.row();
        String[][] labels = {{"emoji", "خەندەکان"}, {"zikr", "زیکر"}, {"kaomoji", "Kaomoji"}};
        for (String[] entry : labels) tile(tabs, keyboard.button(entry[1], () -> { richTab = entry[0]; keyboard.render(); }), 34);
        shell.addView(tabs);
        LinearLayout body = scroller(shell, 213);
        switch (richTab) {
            case "zikr":
                LinearLayout sections = keyboard.row();
                String[][] groups = {{"duaa", "دوعا"}, {"quran", "قورئان"}, {"salawat", "سەڵاوات"}};
                for (String[] group : groups) tile(sections, keyboard.button(group[1], () -> { zikrGroup = group[0]; keyboard.render(); }), 31);
                shell.addView(sections, 2);
                JSONObject zikr = media.optJSONObject("zikr");
                richCells(body, zikr.optJSONArray(zikrGroup), 2, zikrGroup);
                break;
            case "kaomoji":
                richCells(body, historyValues("kaomoji"), 3, "kaomoji");
                richCells(body, media.optJSONArray("kaomoji"), 3, "kaomoji");
                break;
            default:
                JSONArray categories = media.optJSONArray("categories");
                LinearLayout categoryTabs = strip(shell);
                categoryTabs.addView(keyboard.button("◷", () -> chooseCategory("recent")));
                JSONArray order = keyboard.settings.optJSONArray("emojiCategoryOrder");
                JSONArray disabled = keyboard.settings.optJSONArray("emojiDisabledCategories");
                JSONArray entries = null;
                for (int i = 0; order != null && i < order.length(); i++) {
                    String id = order.optString(i);
                    if (contains(disabled, id)) continue;
                    JSONObject category = byId(categories, id);
                    if (category == null) continue;
                    categoryTabs.addView(keyboard.button(category.optString("icon", category.optString("label")), () -> chooseCategory(id)));
                    if (id.equals(emojiCategory)) entries = category.optJSONArray("items");
                }
                int columns = Math.max(4, Math.min(12, keyboard.settings.optInt("emojiColumns", 7)));
                richCells(body, entries == null ? historyValues("emoji") : entries, columns, "emoji");
        }
    }

    private void chooseCategory(String value) {
        emojiCategory = value;
        keyboard.settingsPatch(json("emojiLastUsedCategory", value));
        keyboard.render();
    }

    private static JSONObject byId(JSONArray values, String id) {
        for (int i = 0; values != null && i < values.length(); i++) {
            JSONObject value = values.optJSONObject(i);
            if (value != null && id.equals(value.optString("id"))) return value;
        }
        return null;
    }

    private static boolean contains(JSONArray values, String item) {
        for (int i = 0; values != null && i < values.length(); i++) if (item.equals(values.optString(i))) return true;
        return false;
    }

    private JSONObject history(String kind) {
        if ("emoji".equals(kind)) return json("pinned", keyboard.settings.optJSONArray("emojiPinned"), "recent", keyboard.settings.optJSONArray("recentEmojis"));
        if ("kaomoji".equals(kind)) return json("pinned", keyboard.settings.optJSONArray("kaomojiPinned"), "recent", keyboard.settings.optJSONArray("recentKaomoji"));
        JSONObject histories = keyboard.settings.optJSONObject("zikrHistories");
        return histories != null && histories.optJSONObject(kind) != null ? histories.optJSONObject(kind) : json("pinned", new JSONArray(), "recent", new JSONArray());
    }

    private JSONArray historyValues(String kind) {
        JSONObject history = history(kind);
        JSONArray result = new JSONArray();
        Set<String> seen = new HashSet<>();
        for (String group : new String[]{"pinned", "recent"}) {
            JSONArray items = history.optJSONArray(group);
            for (int i = 0; items != null && i < items.length(); i++) {
                String value = items.optString(i);
                if (seen.add(value)) result.put(value);
            }
        }
        return result;
    }

    void recordRich(String kind, String value) {
        if (!keyboard.settings.optBoolean("emojiHistoryEnabled")) return;
        JSONObject current = history(kind);
        JSONObject next = engine.object("recordHistory", new JSONArray().put(current).put(value)
                .put(keyboard.settings.optString("emojiHistoryUpdateStrategy", "auto_prepend")).put(keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40)));
        if (!next.toString().equals(current.toString())) saveHistory(kind, next);
    }

    private void toggleRichPin(String kind, String value) {
        JSONObject next = engine.object("togglePin", new JSONArray().put(history(kind)).put(value)
                .put(keyboard.settings.optInt("emojiHistoryPinnedMaxSize", 24)).put(keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40)));
        saveHistory(kind, next);
    }

    private void saveHistory(String kind, JSONObject next) {
        if ("emoji".equals(kind)) keyboard.settingsPatch(json("emojiPinned", next.optJSONArray("pinned"), "recentEmojis", next.optJSONArray("recent")));
        else if ("kaomoji".equals(kind)) keyboard.settingsPatch(json("kaomojiPinned", next.optJSONArray("pinned"), "recentKaomoji", next.optJSONArray("recent")));
        else {
            JSONObject histories = ImeStateStore.parse(keyboard.settings.optJSONObject("zikrHistories").toString());
            put(histories, kind, next);
            JSONArray combined = new JSONArray();
            Set<String> seen = new HashSet<>();
            for (String group : new String[]{"pinned", "recent"}) for (String section : new String[]{"duaa", "quran", "salawat"}) {
                JSONObject store = histories.optJSONObject(section);
                JSONArray entries = store == null ? null : store.optJSONArray(group);
                for (int i = 0; entries != null && i < entries.length(); i++) {
                    String value = entries.optString(i);
                    if (seen.add(value) && combined.length() < keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40)) combined.put(value);
                }
            }
            keyboard.settingsPatch(json("zikrHistories", histories, "recentZikr", combined));
        }
    }

    private void richCells(LinearLayout parent, JSONArray entries, int columns, String kind) {
        LinearLayout row = null;
        for (int i = 0; entries != null && i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            String label;
            String value;
            if (entry == null) { value = entries.optString(i); label = value; }
            else if ("emoji".equals(kind)) {
                value = engine.text("emojiModifier", json("entry", entry, "skin", keyboard.settings.optString("emojiSkinTone"), "hair", keyboard.settings.optString("emojiHairStyle")));
                label = value;
            } else { label = entry.optString("d"); value = entry.optString("v"); }
            if (i % columns == 0) { row = keyboard.row(); parent.addView(row); }
            String text = value;
            TextView button = keyboard.button(label, () -> { keyboard.insert(text); recordRich(kind, text); });
            if ("emoji".equals(kind)) {
                button.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, keyboard.appearance.px(keyboard.settings.optInt("emojiFontSizePx", 24)));
                button.setPadding(0, 0, 0, 0);
                if (entry != null) button.setContentDescription(entry.optString("k", entry.optString("e", text)));
            }
            if ("duaa".equals(kind) || "quran".equals(kind) || "salawat".equals(kind)) {
                button.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, keyboard.appearance.px(keyboard.settings.optInt("zikrFontSizePx", 12)));
                button.setMaxLines(2);
                button.setEllipsize(TextUtils.TruncateAt.END);
            }
            button.setOnLongClickListener(v -> { toggleRichPin(kind, text); return true; });
            tile(row, button, "emoji".equals(kind) ? 38 : 48);
        }
        if (row != null) for (int i = entries.length() % columns; i != 0 && i < columns; i++) tile(row, new View(keyboard.getContext()), 38);
    }

    private void themes(LinearLayout shell) {
        title(shell, "ڕووکارەکان", null);
        LinearLayout list = scroller(shell, 240);
        JSONArray themes = engine.array("themes", null);
        JSONArray downloaded = keyboard.settings.optJSONArray("downloadedThemeIds");
        themes.put(keyboard.settings.optJSONObject("customTheme"));
        LinearLayout row = null;
        int count = 0;
        for (int i = 0; i < themes.length(); i++) {
            JSONObject item = themes.optJSONObject(i);
            if (item == null || item.optBoolean("isStore") && !contains(downloaded, item.optString("id"))) continue;
            if (count++ % 2 == 0) { row = keyboard.row(); list.addView(row); }
            String id = item.optString("id");
            TextView button = keyboard.button(item.optString("nameKu", item.optString("name")), () -> keyboard.settingsPatch(json("activeThemeId", id)));
            button.setTextColor(keyboard.appearance.color(item, "keyText", keyboard.textColor()));
            boolean selected = id.equals(keyboard.settings.optString("activeThemeId"));
            button.setBackground(keyboard.appearance.background(keyboard.appearance.color(item, "bg", keyboard.keyColor()), 14, selected ? 2 : 1, keyboard.appearance.color(item, "accent", keyboard.accent())));
            tile(row, button, 65);
        }
        if (row != null && count % 2 != 0) tile(row, new View(keyboard.getContext()), 65);
    }

    private void decorate(LinearLayout shell) {
        title(shell, "جوانکاری نووسین", null);
        LinearLayout list = scroller(shell, 248);
        JSONArray styles = engine.array("decorators", null);
        for (int i = 0; i < styles.length(); i++) {
            JSONObject style = styles.optJSONObject(i);
            String id = style.optString("id");
            TextView button = keyboard.button(style.optString("label") + "\n" + style.optString("sample"), () -> {
                keyboard.decorator = id;
                keyboard.openPanel("keys");
            });
            list.addView(button, new LinearLayout.LayoutParams(-1, keyboard.dp(48)));
        }
    }

    void addResizeFrame(FrameLayout deck) {
        FrameLayout frame = new FrameLayout(keyboard.getContext());
        frame.setBackground(keyboard.appearance.background(0x0dff6d00, 12, 2, 0xffff6d00));
        deck.addView(frame, new FrameLayout.LayoutParams(-1, -1));
        TextView badge = line(resizeDimensions(new JSONObject()));
        badge.setTextColor(0xffffb070);
        badge.setGravity(Gravity.CENTER);
        frame.addView(badge, new FrameLayout.LayoutParams(keyboard.dp(130), keyboard.dp(30), Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        LinearLayout tools = keyboard.row();
        tools.setGravity(Gravity.CENTER);
        tools.addView(keyboard.button("↻", () -> keyboard.settingsPatch(json("keyboardHeightPx", 248, "keyboardWidthPercent", 100,
                "keyboardBottomOffsetPx", 0, "keyboardHorizontalOffsetPx", 0, "oneHandedMode", "off"))));
        TextView move = keyboard.button("✥", () -> {});
        move.setContentDescription("جووڵاندنی شوێنی کیبۆرد");
        move.setOnTouchListener(new ResizeDrag(deck, badge, 0, 1, true));
        tools.addView(move);
        tools.addView(keyboard.button("تەواو", keyboard::finishResize));
        frame.addView(tools, new FrameLayout.LayoutParams(-1, keyboard.dp(48), Gravity.CENTER));
        resizeHandle(frame, deck, badge, Gravity.TOP | Gravity.LEFT, -1, -1);
        resizeHandle(frame, deck, badge, Gravity.TOP | Gravity.RIGHT, 1, -1);
        resizeHandle(frame, deck, badge, Gravity.BOTTOM | Gravity.LEFT, -1, 1);
        resizeHandle(frame, deck, badge, Gravity.BOTTOM | Gravity.RIGHT, 1, 1);
        resizeHandle(frame, deck, badge, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, -1);
        resizeHandle(frame, deck, badge, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 1);
        resizeHandle(frame, deck, badge, Gravity.CENTER_VERTICAL | Gravity.LEFT, -1, 0);
        resizeHandle(frame, deck, badge, Gravity.CENTER_VERTICAL | Gravity.RIGHT, 1, 0);
    }

    private String resizeDimensions(JSONObject patch) {
        int height = patch.optInt("keyboardHeightPx", keyboard.settings.optInt("keyboardHeightPx", 248));
        int width = patch.optInt("keyboardWidthPercent", keyboard.settings.optInt("keyboardWidthPercent", 100));
        int bottom = patch.optInt("keyboardBottomOffsetPx", keyboard.settings.optInt("keyboardBottomOffsetPx", 0));
        return height + "px · " + width + "%" + (bottom > 0 ? " · ↑" + bottom + "px" : "");
    }

    private void resizeHandle(FrameLayout frame, FrameLayout deck, TextView badge, int gravity, int horizontal, int vertical) {
        String mark = horizontal == 0 ? "━" : vertical == 0 ? "┃" : horizontal == vertical ? "↘" : "↗";
        TextView handle = keyboard.appearance.text(mark, 22, 0xffff6d00, "system", 700);
        handle.setContentDescription("گۆڕینی قەبارە");
        frame.addView(handle, new FrameLayout.LayoutParams(keyboard.dp(44), keyboard.dp(44), gravity));
        handle.setOnTouchListener(new ResizeDrag(deck, badge, horizontal, vertical, false));
    }

    private final class ResizeDrag implements View.OnTouchListener {
        final FrameLayout deck;
        final TextView badge;
        final int horizontal;
        final int vertical;
        final boolean move;
        float x;
        float y;
        JSONObject patch;

        ResizeDrag(FrameLayout deck, TextView badge, int horizontal, int vertical, boolean move) {
            this.deck = deck;
            this.badge = badge;
            this.horizontal = horizontal;
            this.vertical = vertical;
            this.move = move;
        }

        @Override public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x = event.getRawX();
                    y = event.getRawY();
                    patch = new JSONObject();
                    break;
                case MotionEvent.ACTION_MOVE:
                    float dx = (event.getRawX() - x) / keyboard.appearance.px(1);
                    float dy = (event.getRawY() - y) / keyboard.appearance.px(1);
                    int width = keyboard.settings.optInt("keyboardWidthPercent", 100);
                    float container = Math.max(260, keyboard.getWidth() / keyboard.appearance.px(1) * width / 100);
                    if (horizontal != 0) {
                        width = Math.max(72, Math.min(100, width + Math.round(dx * horizontal / container * 135)));
                        put(patch, "keyboardWidthPercent", width);
                    }
                    if (horizontal != 0 || move) {
                        int maxShift = Math.round((100 - width) * container / 200);
                        int offset = keyboard.settings.optInt("keyboardHorizontalOffsetPx") + Math.round(dx * (move ? 1 : 0.35f));
                        put(patch, "keyboardHorizontalOffsetPx", Math.max(-maxShift, Math.min(maxShift, offset)));
                    }
                    if (vertical < 0) {
                        int maxHeight = Math.max(380, Math.min(540, Math.round(editor.getScreenHeightDp() * 0.5f)));
                        put(patch, "keyboardHeightPx", Math.max(195, Math.min(maxHeight, keyboard.settings.optInt("keyboardHeightPx") - Math.round(dy))));
                    } else if (vertical > 0) {
                        put(patch, "keyboardBottomOffsetPx", Math.max(0, Math.min(84, keyboard.settings.optInt("keyboardBottomOffsetPx") - Math.round(dy))));
                    }
                    keyboard.previewResize(deck, patch);
                    badge.setText(resizeDimensions(patch));
                    break;
                case MotionEvent.ACTION_UP:
                    if (patch != null && patch.length() > 0) keyboard.settingsPatch(patch);
                    patch = null;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    patch = null;
                    keyboard.render();
                    break;
                default: break;
            }
            return true;
        }
    }

    TextView input(String placeholder, String value, Runnable action) {
        TextView field = ui.button(value.isEmpty() ? placeholder : value, 12, value.isEmpty() ? NativeImePanelStyle.MUTED : ui.foreground(), 400,
                ui.color(Color.WHITE, 0xff16181d), 12, ui.border(), 12, action);
        field.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        return field;
    }

    void beginTyping(String title, String value, String returnPanel, NativeImeView.StringAction action) {
        beginTyping(title, value, returnPanel, action, action);
    }

    void beginTyping(String title, String value, String returnPanel, NativeImeView.StringAction done, NativeImeView.StringAction enter) {
        typingReturn = returnPanel;
        typingAction = done;
        typingEnterAction = enter;
        toolField = new EditText(keyboard.getContext());
        toolField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        toolField.setSingleLine(true);
        toolField.setShowSoftInputOnFocus(false);
        toolField.setImeOptions(EditorInfo.IME_ACTION_DONE);
        toolField.setOnEditorActionListener((field, id, event) -> {
            if (id != EditorInfo.IME_ACTION_DONE) return false;
            finishTyping(typingEnterAction);
            return true;
        });
        toolField.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        toolField.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        toolField.setTextSize(TypedValue.COMPLEX_UNIT_PX, keyboard.appearance.px(12));
        toolField.setTypeface(keyboard.appearance.font(keyboard.font(), 400));
        toolField.setTextColor(ui.foreground());
        toolField.setHintTextColor(0xffa1a1aa);
        toolField.setBackground(ui.face(ui.color(Color.WHITE, 0xff16181d), 12, NativeImePanelStyle.SKY));
        toolField.setIncludeFontPadding(false);
        ui.padding(toolField, 10, 0);
        toolField.setHint(title);
        toolField.setText(value);
        toolField.setSelection(toolField.length());
        fieldTransition = true;
        try {
            keyboard.mode = "characters";
            keyboard.openPanel("keys");
        } finally {
            fieldTransition = false;
        }
    }

    boolean editingToolField() { return toolField != null; }
    boolean showingLivePicker() { return !editingToolField() && writing.pickingLiveLanguage(); }
    View livePicker() { return writing.picker(true); }

    boolean renderTypingStrip(LinearLayout outer) {
        if (editingToolField()) {
            LinearLayout bar = ui.row();
            ui.padding(bar, 8, 6);
            if (toolField.getParent() instanceof ViewGroup) ((ViewGroup) toolField.getParent()).removeView(toolField);
            ui.flex(bar, toolField, 34, 0);
            ui.add(bar, ui.button("تەواو", 12, Color.WHITE, 700, NativeImePanelStyle.BLUE, 8, 0, 12,
                    () -> finishTyping(typingAction)), NativeImePanelStyle.WRAP, 34, 6);
            ui.add(bar, ui.close(() -> finishTyping(null), 14), 30, 30, 6);
            outer.addView(bar);
            return true;
        }
        if (writing.live()) {
            writing.addLive(outer);
            return true;
        }
        if (!emojiSearch) return false;
        LinearLayout bar = keyboard.row();
        typedDisplay = line("");
        typedDisplay.setSingleLine(true);
        typedDisplay.setEllipsize(TextUtils.TruncateAt.START);
        bar.addView(typedDisplay, new LinearLayout.LayoutParams(0, keyboard.dp(34), 1));
        bar.addView(keyboard.button("تەواو", this::typingEnter));
        bar.addView(keyboard.iconButton("close", "داخستن", 16, keyboard.textColor(), () -> keyboard.openPanel("emoji")),
                new LinearLayout.LayoutParams(keyboard.dp(35), keyboard.dp(35)));
        outer.addView(bar);
        searchResults = strip(outer);
        refreshEmojiSearch();
        return true;
    }

    boolean type(String value) {
        if (clipboardPanel.editing()) { clipboardPanel.insertInEdit(value); return true; }
        if (insertToolField(value)) return true;
        if (writing.live()) { writing.liveType(value); return true; }
        if (!emojiSearch) return false;
        if (typed.length() < 12000) typed += value;
        refreshEmojiSearch();
        return true;
    }

    boolean insertToolField(String value) {
        if (!editingToolField()) return false;
        Editable editable = toolField.getText();
        int start = Math.max(0, Math.min(toolField.getSelectionStart(), toolField.getSelectionEnd()));
        int end = Math.max(start, Math.max(toolField.getSelectionStart(), toolField.getSelectionEnd()));
        editable.replace(start, end, value);
        toolField.setSelection(start + value.length());
        return true;
    }

    boolean typingDelete(boolean word) {
        if (editingToolField()) {
            Editable editable = toolField.getText();
            int start = Math.max(0, Math.min(toolField.getSelectionStart(), toolField.getSelectionEnd()));
            int end = Math.max(start, Math.max(toolField.getSelectionStart(), toolField.getSelectionEnd()));
            if (start == end && start > 0) {
                if (word) {
                    while (start > 0 && Character.isWhitespace(editable.charAt(start - 1))) start--;
                    while (start > 0 && !Character.isWhitespace(editable.charAt(start - 1))) start--;
                } else start = Character.offsetByCodePoints(editable, start, -1);
            }
            editable.delete(start, end);
            toolField.setSelection(start);
            return true;
        }
        if (writing.live()) { writing.liveDelete(); return true; }
        if (!emojiSearch) return false;
        if (!typed.isEmpty()) typed = typed.substring(0, typed.offsetByCodePoints(typed.length(), -1));
        refreshEmojiSearch();
        return true;
    }

    boolean typingEnter() {
        if (clipboardPanel.editing()) { clipboardPanel.insertInEdit("\n"); return true; }
        if (editingToolField()) { finishTyping(typingEnterAction); return true; }
        if (writing.live()) { writing.commitLive(); return true; }
        if (!emojiSearch) return false;
        JSONArray matches = engine.array("emojiSearch", typed);
        if (!typed.trim().isEmpty() && matches.length() > 0) insertSearched(matches.optJSONObject(0));
        else keyboard.openPanel("emoji");
        return true;
    }

    private void finishTyping(NativeImeView.StringAction action) {
        String value = toolField.getText().toString();
        String previous = typingReturn;
        clearToolField();
        fieldTransition = true;
        try {
            keyboard.openPanel(previous);
        } finally {
            fieldTransition = false;
        }
        if (action != null) action.accept(value);
    }

    private void clearToolField() {
        toolField = null;
        typingAction = typingEnterAction = null;
        typingReturn = "";
    }

    boolean moveToolField(int x, int y, boolean extend, boolean lineEdge) {
        if (!editingToolField()) return false;
        Editable editable = toolField.getText();
        Layout layout = toolField.getLayout();
        if (layout == null) return true;
        if (lineEdge && x < 0) {
            if (extend) Selection.extendToLeftEdge(editable, layout); else Selection.moveToLeftEdge(editable, layout);
        } else if (lineEdge && x > 0) {
            if (extend) Selection.extendToRightEdge(editable, layout); else Selection.moveToRightEdge(editable, layout);
        } else if (y < 0) {
            if (extend) Selection.extendUp(editable, layout); else Selection.moveUp(editable, layout);
        } else if (y > 0) {
            if (extend) Selection.extendDown(editable, layout); else Selection.moveDown(editable, layout);
        } else if (x < 0) {
            if (extend) Selection.extendLeft(editable, layout); else Selection.moveLeft(editable, layout);
        } else if (x > 0) {
            if (extend) Selection.extendRight(editable, layout); else Selection.moveRight(editable, layout);
        }
        return true;
    }

    boolean editToolField(int command) {
        if (!editingToolField()) return false;
        toolField.onTextContextMenuItem(command);
        return true;
    }

    private void insertSearched(JSONObject entry) {
        if (entry == null) return;
        String emoji = engine.text("emojiModifier", json("entry", entry, "skin", keyboard.settings.optString("emojiSkinTone"), "hair", keyboard.settings.optString("emojiHairStyle")));
        keyboard.insert(emoji);
        recordRich("emoji", emoji);
        typed = "";
        refreshEmojiSearch();
    }

    private void refreshEmojiSearch() {
        if (!emojiSearch || typedDisplay == null || searchResults == null) return;
        typedDisplay.setText(typed.isEmpty() ? "بە کوردی یان ئینگلیزی بنووسە" : typed);
        searchResults.removeAllViews();
        JSONArray entries = engine.array("emojiSearch", typed);
        for (int i = 0; i < Math.min(24, entries.length()); i++) {
            JSONObject entry = entries.optJSONObject(i);
            searchResults.addView(keyboard.button(entry.optString("c"), () -> insertSearched(entry)));
        }
    }

    void endSession() {
        writing.endSession();
        calculatorPanel.reset();
        clearToolField();
        typed = "";
        emojiSearch = false;
        clipboardPanel.reset();
    }

    @Override public void close() { writing.close(); }
}
