package io.kurdikebord.app;

import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Weighted rows and pointer capture for native key views. */
final class NativeImeKeyGrid extends ViewGroup {
    private static final int NO_POINTER = -1;
    private final NativeImeView keyboard;
    private final NativeImeAppearance appearance;
    private final List<Row> rows = new ArrayList<>();
    private final SparseArray<Touch> pointers = new SparseArray<>();
    private final int horizontalGap;
    private final int verticalGap;
    private int owner = NO_POINTER;
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Runnable hold = this::holdOwner;

    NativeImeKeyGrid(NativeImeView keyboard, JSONObject deck) {
        super(keyboard.getContext());
        this.keyboard = keyboard;
        appearance = keyboard.appearance;
        horizontalGap = appearance.dp(deck.optDouble("hGap", 3.5));
        verticalGap = appearance.dp(deck.optDouble("vGap", 6));
        boolean numeric = "numeric_advanced".equals(keyboard.mode);
        int side = appearance.dp(numeric ? 6 : 3);
        setPadding(side, appearance.dp(numeric ? 6 : 4), side, appearance.dp(numeric ? 8 : 6));
        setClipChildren(false);
        setClipToPadding(false);
        JSONArray model = deck.optJSONArray("rows");
        if (model == null) return;
        for (int r = 0; r < model.length(); r++) {
            JSONObject rowModel = model.optJSONObject(r);
            rows.add(new Row(rowModel));
        }
    }

    @Override protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        int height = MeasureSpec.getSize(h);
        setMeasuredDimension(width, height);
        arrange(width, height, false);
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        arrange(r - l, b - t, true);
    }

    private void arrange(int width, int height, boolean layout) {
        double weight = 0;
        for (Row row : rows) weight += row.weight;
        int availableHeight = Math.max(0, height - getPaddingTop() - getPaddingBottom() - verticalGap * (rows.size() - 1));
        double y = getPaddingTop();
        for (Row row : rows) {
            double rowHeight = availableHeight * row.weight / weight;
            int rowWidth = Math.max(0, width - getPaddingLeft() - getPaddingRight() - 2 * row.inset - horizontalGap * (row.keys.size() - 1));
            double x = getPaddingLeft() + row.inset;
            for (Key key : row.keys) {
                double keyWidth = rowWidth * key.model.optDouble("width", 1) / row.keyWeight;
                int left = (int) Math.round(x);
                int right = (int) Math.round(x + keyWidth);
                int top = (int) Math.round(y);
                int bottom = (int) Math.round(y + rowHeight);
                if (layout) key.layout(left, top, right, bottom);
                else key.measure(MeasureSpec.makeMeasureSpec(right - left, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(bottom - top, MeasureSpec.EXACTLY));
                x += keyWidth + horizontalGap;
            }
            y += rowHeight + verticalGap;
        }
    }

    @Override protected void dispatchDraw(Canvas canvas) {
        // CSS shadows belong outside the face, so draw them behind the entire row.
        for (Row row : rows) for (Key key : row.keys) {
            float dy = key.active ? key.downShadow : key.idleShadow;
            int tint = key.active ? key.downShadowColor : key.idleShadowColor;
            float scale = key.getScaleX();
            float dx = key.getWidth() * (1-scale)/2, insetY = key.getHeight() * (1-scale)/2;
            float top = key.getTop()+insetY+key.getTranslationY();
            float radius = Math.min(key.radius, Math.min(key.getWidth(),key.getHeight())/2f)*scale;
            float left = key.getLeft()+dx, right=key.getRight()-dx, bottom=top+key.getHeight()*scale;
            if (key.glowColor != Color.TRANSPARENT) {
                // Light-weight native halo; no per-key software layer or expensive blur.
                for (int i=3;i>=1;i--) {
                    float spread=appearance.px(i);
                    shadowPaint.setColor((key.glowColor&0x00ffffff)|((i==1?35:i==2?18:9)<<24));
                    canvas.drawRoundRect(left-spread,top-spread,right+spread,bottom+spread,radius+spread,radius+spread,shadowPaint);
                }
            }
            if (dy > 0 && tint != Color.TRANSPARENT) {
                shadowPaint.setColor(tint);
                canvas.drawRoundRect(left, top+dy, right, bottom+dy, radius,radius,shadowPaint);
            }
        }
        super.dispatchDraw(canvas);
    }

    private Key find(float x, float y) {
        for (Row row : rows) for (Key key : row.keys) {
            if (x >= key.getLeft() && x < key.getRight() && y >= key.getTop() && y < key.getBottom()) return key;
        }
        return null;
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent event) { return true; }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int index = event.getActionIndex();
        int pointer = event.getPointerId(index);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) cancel();
                start(pointer, event.getX(index), event.getY(index), event.getEventTime());
                return true;
            case MotionEvent.ACTION_MOVE:
                int active = event.findPointerIndex(owner);
                if (active >= 0) move(pointers.get(owner), event.getX(active), event.getY(active));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                end(pointer, event.getX(index), event.getY(index), event.getEventTime());
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancel();
                return true;
            default: return true;
        }
    }

    private void start(int pointer, float x, float y, long time) {
        Key key = find(x, y);
        Touch touch = new Touch(key, x, y, time);
        pointers.put(pointer, touch);
        if (key != null) key.highlight(true);
        if (owner != NO_POINTER) return;
        owner = pointer;
        if (key == null) return;
        String type = key.model.optString("type");
        int delay = Math.max(150, Math.min(600, keyboard.settings.optInt("longPressDelayMs", 300)));
        if ("space".equals(type)) delay = Math.round(delay * 1.35f);
        if ("globe".equals(type)) delay = Math.round(delay * 1.3f);
        if ("backspace".equals(type) || "emoji".equals(type)) delay = Math.round(delay * 1.15f);
        keyboard.keyPreview(key, key.model);
        postDelayed(hold, delay);
    }

    private void holdOwner() {
        Touch touch = pointers.get(owner);
        if (touch == null || touch.key == null) return;
        String type = touch.key.model.optString("type");
        if ("backspace".equals(type)) {
            String action = keyboard.settings.optString("deleteKeyLongPressAction");
            if ("no_action".equals(action)) return;
            touch.used = true;
            boolean word = action.contains("word");
            keyboard.backspace(word);
            postDelayed(hold, word ? 180 : 75);
        } else {
            touch.used = keyboard.keyHold(touch.key, touch.key.model);
        }
    }

    private void move(Touch touch, float x, float y) {
        if (touch == null) return;
        if (keyboard.slidePopup(this, x, y)) return;
        float dx = x - touch.x;
        float dy = y - touch.y;
        String type = touch.key == null ? "" : touch.key.model.optString("type");
        double threshold = "space".equals(type) ? 12 : "backspace".equals(type) ? 14 : 18;
        if (Math.hypot(dx, dy) > appearance.px(threshold)) {
            removeCallbacks(hold);
            keyboard.dismissPreview();
        }
        if (Math.abs(dx) <= Math.abs(dy)) return;
        float step = x - touch.stepX;
        if ("space".equals(type) && Math.abs(step) >= appearance.px(15)) {
            String action = keyboard.settings.optString(step < 0 ? "spaceBarSwipeLeftAction" : "spaceBarSwipeRightAction");
            if (action.startsWith("move_cursor_") || "select_characters_precisely".equals(action)) {
                keyboard.moveCursor(step < 0 ? -1 : 1, 0, action.startsWith("select"));
                touch.used = true;
                touch.stepX = x;
            }
        } else if ("backspace".equals(type) && step < -appearance.px(20)) {
            String action = keyboard.settings.optString("deleteKeySwipeLeftAction");
            if (action.equals("delete_words_precisely") || action.equals("delete_characters_precisely")) {
                keyboard.backspace(action.contains("word"));
                touch.used = true;
                touch.stepX = x;
            }
        }
    }

    private void end(int pointer, float x, float y, long time) {
        Touch touch = pointers.get(pointer);
        if (touch == null) return;
        pointers.remove(pointer);
        if (touch.key != null) touch.key.highlight(false);
        float dx = x - touch.x;
        float dy = y - touch.y;
        if (pointer != owner) {
            if (touch.key != null && Math.hypot(dx, dy) <= appearance.px(24) && !keyboard.hasAlternates()) {
                touch.key.performClick();
            }
            return;
        }
        owner = NO_POINTER;
        removeCallbacks(hold);
        keyboard.dismissPreview();
        if (keyboard.hasAlternates() && Math.hypot(dx, dy) > appearance.px(4)) keyboard.slidePopup(this, x, y);
        if (keyboard.releaseAlternates()) return;
        if (touch.used) return;
        if (keyboard.swipe(touch.key == null ? null : touch.key.model, dx / appearance.px(1), dy / appearance.px(1), Math.max(1, time - touch.time))) return;
        if (touch.key != null && (Math.hypot(dx, dy) < appearance.px(28)
                || "space".equals(touch.key.model.optString("type")) || "backspace".equals(touch.key.model.optString("type")))) {
            touch.key.performClick();
        }
    }

    boolean ownsTouch() { return pointers.size() != 0; }

    void cancel() {
        removeCallbacks(hold);
        for (int i = 0; i < pointers.size(); i++) {
            Key key = pointers.valueAt(i).key;
            if (key != null) key.highlight(false);
        }
        pointers.clear();
        owner = NO_POINTER;
        keyboard.dismissPreview();
        keyboard.cancelAlternates();
    }

    @Override protected void onDetachedFromWindow() {
        cancel();
        super.onDetachedFromWindow();
    }

    private final class Row {
        final double weight;
        final int inset;
        final List<Key> keys = new ArrayList<>();
        double keyWeight;

        Row(JSONObject model) {
            weight = model.optDouble("weight", 1);
            inset = appearance.dp(model.optDouble("inset", 0));
            JSONArray values = model.optJSONArray("keys");
            for (int i = 0; values != null && i < values.length(); i++) {
                Key key = new Key(values.optJSONObject(i));
                keys.add(key);
                keyWeight += key.model.optDouble("width", 1);
                addView(key);
            }
        }
    }

    private final class Key extends FrameLayout {
        final JSONObject model;
        final Drawable normal;
        final Drawable pressed;
        private TextView phraseHint;
        private float phraseHintWidth;
        boolean active;
        final float radius, idleShadow, downShadow;
        final int idleShadowColor, downShadowColor, glowColor;

        private float shadowOffset(JSONObject face) {
            switch (face.optString("depth")) {
                case "raised3d": return appearance.px(3);
                case "flat3d": return appearance.px(1);
                case "default": case "enter": return appearance.px(1.5);
                case "glass": case "neuOut": return appearance.px(2);
                case "theme": return appearance.px(1.5);
                default: return 0;
            }
        }
        private int shadowColor(JSONObject face) {
            String depth = face.optString("depth"); boolean light=face.optBoolean("light");
            if ("enter".equals(depth)) return 0x73000000;
            if ("glass".equals(depth)) return 0x2e000000;
            if ("raised3d".equals(depth)) return light ? 0x330f172a : 0xcc000000;
            if ("flat3d".equals(depth)) return light ? 0x380f172a : 0xd9000000;
            if ("neuOut".equals(depth)) return light ? 0x1f0f172a : 0xa6000000;
            return light ? 0x2e0f172a : 0xb8000000;
        }

        Key(JSONObject model) {
            super(NativeImeKeyGrid.this.getContext());
            this.model = model;
            JSONObject idleFace = NativeImeData.obj(model,"face"), downFace = NativeImeData.obj(model,"pressed");
            normal = appearance.keyFace(idleFace, keyboard.keyColor());
            pressed = appearance.keyFace(downFace, keyboard.keyColor());
            radius = appearance.px(NativeImeAppearance.cssNumber(idleFace.optString("borderRadius"),9));
            idleShadow=shadowOffset(idleFace); downShadow=shadowOffset(downFace);
            idleShadowColor=shadowColor(idleFace); downShadowColor=shadowColor(downFace);
            glowColor = NativeImeAppearance.color(idleFace.optString("glow"), Color.TRANSPARENT);
            setBackground(normal);
            setFocusable(true);
            setSoundEffectsEnabled(false);
            setClipToPadding(false);
            setClipChildren(false);
            String label = model.optString("label");
            String type = model.optString("type");
            setContentDescription(label.isEmpty() ? type : label);
            setOnClickListener(v -> keyboard.keyTap(model));
            setOnLongClickListener(v -> keyboard.keyHold(v, model));
            int color = appearance.color(model, "color", Color.WHITE);
            String icon = model.optString("icon");
            Drawable drawable = icon.isEmpty() ? null : appearance.icon(icon, color, model.optDouble("iconSize", 20));
            if (drawable != null) {
                ImageView image = new ImageView(getContext());
                image.setImageDrawable(drawable);
                addView(image, new LayoutParams(drawable.getIntrinsicWidth(), appearance.dp(model.optDouble("iconHeight", model.optDouble("iconSize",20))), Gravity.CENTER));
            } else {
                TextView text = appearance.text(label, model.optDouble("size", 20), color, keyboard.font(), 600);
                if ("space".equals(type) && !label.isEmpty()) {
                    android.text.SpannableString space = new android.text.SpannableString("‹   " + label + "   ›");
                    int muted = (color & 0x00ffffff) | (Math.round(Color.alpha(color)*.65f)<<24);
                    space.setSpan(new android.text.style.ForegroundColorSpan(muted),0,1,0);
                    space.setSpan(new android.text.style.ForegroundColorSpan(muted),space.length()-1,space.length(),0);
                    text.setText(space);
                }
                text.setSingleLine(true);
                text.setEllipsize(TextUtils.TruncateAt.END);
                text.setPadding(appearance.dp("space".equals(type) ? 8 : 1), 0, appearance.dp("space".equals(type) ? 8 : 1), 0);
                text.setTranslationY(appearance.px(model.optDouble("labelOffset", 0)) / 2);
                addView(text, new LayoutParams(-1, -1));
            }
            String hint = model.optString("hint");
            if (!hint.isEmpty()) {
                int length = NativeImeKeyFaces.hintLength(hint);
                boolean phrase = length > 2;
                TextView text = appearance.text(hint, model.optDouble("hintSize", 10.5), keyboard.secondaryColor(), keyboard.font(), 600);
                text.setGravity(Gravity.TOP | (phrase ? Gravity.CENTER_HORIZONTAL : Gravity.RIGHT));
                int inset = appearance.dp(phrase ? .5 : 4);
                text.setPadding(inset, appearance.dp(phrase ? 2.5 : 3), inset, 0);
                text.setSingleLine(true);
                if (phrase) {
                    if (length > 12) text.setLetterSpacing(-.025f);
                    phraseHint = text;
                    phraseHintWidth = text.getPaint().measureText(hint);
                }
                addView(text, new LayoutParams(-1, -2, Gravity.TOP | Gravity.RIGHT));
            }
        }

        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            if (phraseHint != null && phraseHintWidth > 0) {
                int available = MeasureSpec.getSize(widthSpec) - phraseHint.getPaddingLeft() - phraseHint.getPaddingRight();
                float fit = Math.min(1f, Math.max(0, available - 1) / phraseHintWidth);
                if (fit > 0 && phraseHint.getTextScaleX() != fit) phraseHint.setTextScaleX(fit);
            }
            super.onMeasure(widthSpec, heightSpec);
        }

        void highlight(boolean active) {
            this.active = active;
            setBackground(active ? pressed : normal);
            boolean animate = keyboard.settings.optBoolean("keyAnimation");
            float scale = active && animate ? 0.94f : 1f;
            setScaleX(scale); setScaleY(scale);
            setTranslationY(active && "three_dimensional".equals(keyboard.settings.optString("keyShapeStyle")) ? appearance.px(2) : 0);
            NativeImeKeyGrid.this.invalidate();
        }
    }

    private static final class Touch {
        final Key key;
        final float x;
        final float y;
        final long time;
        float stepX;
        boolean used;
        Touch(Key key, float x, float y, long time) {
            this.key = key;
            this.x = x;
            this.y = y;
            this.time = time;
            stepX = x;
        }
    }
}
