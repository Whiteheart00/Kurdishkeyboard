package io.kurdikebord.app;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

final class NativeImeNetwork implements AutoCloseable {
    private final android.content.Context context;
    NativeImeNetwork(android.content.Context c){context=c.getApplicationContext();}
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private int generation;
    private volatile HttpURLConnection active;

    interface Result { void accept(String text, boolean done); }
    interface Request { String fetch(Result partial) throws Exception; }

    void request(Request request, Result result) {
        cancel();
        int token = generation;
        pending = worker.submit(() -> {
            try {
                String text = request.fetch((value, ignored) -> deliver(token, result, value, false));
                deliver(token, result, text, true);
            } catch (Exception failure) {
                deliver(token, result, "", true);
            }
        });
    }

    private void deliver(int token, Result result, String text, boolean done) {
        main.post(() -> { if (generation == token) result.accept(text, done); });
    }

    void cancel() {
        generation++;
        if (pending != null) pending.cancel(true);
        pending = null;
        HttpURLConnection current = active;
        if (current != null) current.disconnect();
    }

    static String apiBase(String configured, String fallback) {
        return configured == null || configured.trim().isEmpty() ? normalizeBase(fallback) : normalizeBase(configured);
    }

    private static String normalizeBase(String raw) {
        raw = raw == null ? "" : raw.trim();
        if (raw.isEmpty()) return "";
        try {
            URI uri = new URI(raw.contains("://") ? raw : "https://" + raw);
            String scheme = uri.getScheme();
            if (!"https".equalsIgnoreCase(scheme) || uri.getHost() == null || uri.getUserInfo() != null || uri.getRawQuery() != null || uri.getRawFragment() != null) return "";
            String path = uri.getRawPath().replaceFirst("/+$", "").replaceFirst("(?i)/api(?:/health)?$", "");
            return scheme + "://" + uri.getRawAuthority() + path;
        } catch (Exception e) { return ""; }
    }

    String translate(String base, JSONObject payload, boolean fluent, Result partial) throws Exception {
        if (fluent && !base.isEmpty()) {
            String translated = read(base + "/api/ai/translate", payload, "translated", partial);
            if (!translated.isEmpty()) return translated;
        }
        try {
            String translated = translateGoogle(payload);
            if (translated.isEmpty()) throw new IOException("No translation returned");
            return translated;
        } catch (IOException | org.json.JSONException failure) {
            if (fluent || base.isEmpty() || Thread.currentThread().isInterrupted()) throw failure;
            return read(base + "/api/ai/translate", payload, "translated", partial);
        }
    }

    private String translateGoogle(JSONObject payload) throws IOException, org.json.JSONException {
        String source = payload.optString("sourceLang", "auto");
        String target = payload.optString("targetLang", "en");
        String query = payload.optString("text");
        String address = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl="
                + encode(source) + "&tl=" + encode(target) + "&q=" + encode(query);
        JSONArray rows = new JSONArray(read(address, null, null, null)).optJSONArray(0);
        StringBuilder value = new StringBuilder();
        for (int i = 0; rows != null && i < rows.length(); i++) {
            JSONArray row = rows.optJSONArray(i);
            if (row != null) value.append(row.optString(0, ""));
        }
        return value.toString().trim();
    }

    String rewrite(String base, JSONObject payload) throws Exception {
        return base.isEmpty() ? "" : read(base + "/api/ai/rewrite", payload, "result", null);
    }

    private static String encode(String value) throws IOException { return URLEncoder.encode(value, "UTF-8"); }

    private String read(String url, JSONObject payload, String key, Result partial) throws IOException, org.json.JSONException {
        if (Thread.currentThread().isInterrupted()) throw new IOException("Cancelled");
        URL endpoint = new URL(url);
        if (!"https".equalsIgnoreCase(endpoint.getProtocol())) throw new IOException("HTTPS required");
        HttpURLConnection connection = (HttpURLConnection) endpoint.openConnection();
        active = connection;
        try {
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(18000);
            connection.setInstanceFollowRedirects(false);
            if (payload != null) {
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream stream = connection.getOutputStream()) { stream.write(bytes); }
            }
            int status=connection.getResponseCode();
            NativeSecurityStatus.note(context,"api",status);
            if (status < 200 || status >= 300) throw new IOException("Server request failed");
            String contentType = connection.getContentType();
            boolean jsonBody = contentType != null && contentType.toLowerCase(java.util.Locale.ROOT).contains("application/json");
            StringBuilder text = new StringBuilder();
            try (InputStreamReader reader = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)) {
                char[] buffer = new char[2048];
                long last = 0;
                int count;
                while ((count = reader.read(buffer)) != -1) {
                    if (Thread.currentThread().isInterrupted() || text.length() + count > 1024 * 1024) throw new IOException("Response interrupted or too large");
                    text.append(buffer, 0, count);
                    long now = android.os.SystemClock.elapsedRealtime();
                    if (partial != null && !jsonBody && now - last > 75) {
                        last = now;
                        partial.accept(text.toString().trim(), false);
                    }
                }
            }
            String value = text.toString().trim();
            return key != null && jsonBody ? new JSONObject(value).optString(key).trim() : value;
        } finally {
            active = null;
            connection.disconnect();
        }
    }

    @Override public void close() { cancel(); worker.shutdownNow(); }
}
