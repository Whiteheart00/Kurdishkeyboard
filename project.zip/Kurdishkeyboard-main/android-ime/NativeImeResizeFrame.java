package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Resize controls stay attached while the IME window changes size beneath a held pointer. */
final class NativeImeResizeFrame extends FrameLayout {
    private static final int ORANGE = 0xffff6d00;
    private static final int DARK = 0xff111318;
    private static final int NO_POINTER = -1;
    private final NativeImeView keyboard;
    private final FrameLayout deck;
    private final TextView badge;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path corner = new Path();
    private final float density;
    private final int shade;
    private Drag drag;
    private boolean completing;

    NativeImeResizeFrame(NativeImeView keyboard, FrameLayout deck) {
        super(keyboard.getContext());
        this.keyboard = keyboard;
        this.deck = deck;
        density = keyboard.appearance.px(1);
        shade = keyboard.light() ? 0x380f172a : 0x5c06080c;
        setWillNotDraw(false);
        setClickable(true);
        setSoundEffectsEnabled(false);
        setMotionEventSplittingEnabled(false);
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        badge = keyboard.appearance.text("", 11, 0xffffb070, "system", 700);
        badge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        badge.setPadding(dp(10), 0, dp(10), 0);
        badge.setBackground(keyboard.appearance.background(0xdb0f1116, 99, 1, 0x73ff6d00));
        LayoutParams badgePosition = new LayoutParams(-2, dp(19), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        badgePosition.topMargin = dp(14);
        addView(badge, badgePosition);
        showDimensions(new JSONObject());

        LinearLayout actions = keyboard.row();
        actions.setGravity(Gravity.CENTER_VERTICAL);
        ImageView reset = control("resize_reset", "گەڕاندنەوە بۆ بنەڕەتی", 20, true, keyboard::resetResize);
        actions.addView(reset, new LinearLayout.LayoutParams(dp(48), dp(48)));
        ImageView move = control("resize_move", "جووڵاندنی شوێنی کیبۆرد", 20, false, null);
        move.setOnTouchListener((view, event) -> handleTouch(view, event, 0, 1, true));
        LinearLayout.LayoutParams movePosition = new LinearLayout.LayoutParams(dp(52), dp(52));
        movePosition.leftMargin = dp(24);
        actions.addView(move, movePosition);
        ImageView confirm = control("resize_check", "پاشەکەوت و تەواو", 24, true, keyboard::finishResize);
        LinearLayout.LayoutParams confirmPosition = new LinearLayout.LayoutParams(dp(48), dp(48));
        confirmPosition.leftMargin = dp(24);
        actions.addView(confirm, confirmPosition);
        addView(actions, new LayoutParams(dp(196), dp(52), Gravity.CENTER));

        handle("گۆشەی سەرەوە-چەپ", Gravity.TOP | Gravity.LEFT, 44, 44, -1, -1);
        handle("گۆشەی سەرەوە-ڕاست", Gravity.TOP | Gravity.RIGHT, 44, 44, 1, -1);
        handle("گۆشەی خوارەوە-چەپ", Gravity.BOTTOM | Gravity.LEFT, 44, 44, -1, 1);
        handle("گۆشەی خوارەوە-ڕاست", Gravity.BOTTOM | Gravity.RIGHT, 44, 44, 1, 1);
        handle("بەرزی کیبۆرد", Gravity.TOP | Gravity.CENTER_HORIZONTAL, 112, 32, 0, -1);
        handle("بەرزکردنەوەی خوارەوە", Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 112, 32, 0, 1);
        handle("پانی لە چەپەوە", Gravity.CENTER_VERTICAL | Gravity.LEFT, 32, 96, -1, 0);
        handle("پانی لە ڕاستەوە", Gravity.CENTER_VERTICAL | Gravity.RIGHT, 32, 96, 1, 0);
    }

    private int dp(int value) { return keyboard.dp(value); }

    private ImageView control(String icon, String label, int size, boolean orange, Runnable action) {
        ImageView view = new ImageView(getContext());
        view.setScaleType(ImageView.ScaleType.CENTER);
        view.setImageDrawable(keyboard.appearance.icon(icon, orange ? DARK : Color.WHITE, size));
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(orange ? 0x20111318 : 0x30ffffff),
                keyboard.appearance.background(orange ? ORANGE : DARK, 30, orange ? 0 : 1, 0x26ffffff), null));
        view.setElevation(dp(orange ? 6 : 8));
        view.setContentDescription(label);
        view.setSoundEffectsEnabled(false);
        if (action != null) {
            view.setFocusable(true);
            view.setOnClickListener(v -> { if (!isDragging()) { keyboard.feedback("special"); action.run(); } });
        }
        return view;
    }

    private void handle(String label, int gravity, int width, int height, int horizontal, int vertical) {
        View target = new View(getContext());
        target.setContentDescription(label);
        target.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        target.setOnTouchListener((view, event) -> handleTouch(view, event, horizontal, vertical, false));
        addView(target, new LayoutParams(dp(width), dp(height), gravity));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int saved = canvas.save();
        canvas.scale(density, density);
        float width = getWidth() / density, height = getHeight() / density;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(shade);
        canvas.drawRoundRect(0, 0, width, height, 12, 12, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f);
        paint.setColor(0x8cff6d00);
        canvas.drawRoundRect(.75f, .75f, width - .75f, height - .75f, 12, 12, paint);
        paint.setColor(ORANGE);
        paint.setStrokeWidth(4);
        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int x = 1; x >= -1; x -= 2) for (int y = 1; y >= -1; y -= 2) {
            int transform = canvas.save();
            canvas.translate(x == 1 ? 0 : width, y == 1 ? 0 : height);
            canvas.scale(x, y);
            corner.rewind();
            corner.moveTo(2, 26);
            corner.lineTo(2, 13);
            corner.quadTo(2, 2, 13, 2);
            corner.lineTo(26, 2);
            canvas.drawPath(corner, paint);
            canvas.restoreToCount(transform);
        }
        paint.setStyle(Paint.Style.FILL);
        for (int y = 0; y < 2; y++) {
            float top = y == 0 ? 0 : height - 5;
            canvas.drawRoundRect(width / 2 - 28, top, width / 2 + 28, top + 5, 2.5f, 2.5f, paint);
        }
        for (int x = 0; x < 2; x++) {
            float left = x == 0 ? 0 : width - 5;
            canvas.drawRoundRect(left, height / 2 - 24, left + 5, height / 2 + 24, 2.5f, 2.5f, paint);
        }
        canvas.restoreToCount(saved);
    }

    boolean isDragging() { return drag != null || completing; }

    boolean cancelDrag() {
        boolean wasDragging = isDragging();
        if (drag != null) drag.target.setPressed(false);
        drag = null;
        completing = false;
        return wasDragging;
    }

    private boolean handleTouch(View target, MotionEvent event, int horizontal, int vertical, boolean move) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (isDragging()) return true;
                drag = new Drag(target, event, horizontal, vertical, move);
                target.setPressed(true);
                requestDisallowInterceptTouchEvent(true);
                badge.setAlpha(1);
                break;
            case MotionEvent.ACTION_MOVE:
                if (drag != null) {
                    int index = event.findPointerIndex(drag.pointer);
                    if (index != NO_POINTER) update(event, index);
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP:
                if (drag != null && event.getPointerId(event.getActionIndex()) == drag.pointer) {
                    update(event, event.getActionIndex());
                    finish(drag.patch);
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                if (drag != null) finish(null);
                break;
            default: break;
        }
        return true;
    }

    private void update(MotionEvent event, int index) {
        float rawX = event.getRawX() + event.getX(index) - event.getX();
        float rawY = event.getRawY() + event.getY(index) - event.getY();
        float dx = (rawX - drag.x) / density;
        float dy = (rawY - drag.y) / density;
        JSONObject patch = drag.patch;
        if (dx == 0 && dy == 0 && patch.length() == 0) return;
        if (drag.horizontal != 0) {
            int width = clamp(Math.round(drag.width + dx * drag.horizontal / drag.container * 135), 72, 100);
            int limit = Math.min(60, Math.round((100 - width) * drag.container / 200));
            put(patch, "keyboardWidthPercent", width);
            put(patch, "keyboardHorizontalOffsetPx", clamp(Math.round(drag.offset + dx * .35f), -limit, limit));
        } else if (drag.move) {
            int limit = Math.min(60, Math.round((100 - drag.width) * drag.container / 200));
            if (limit > 2) put(patch, "keyboardHorizontalOffsetPx", clamp(Math.round(drag.offset + dx), -limit, limit));
        }
        if (drag.vertical < 0) {
            put(patch, "keyboardHeightPx", clamp(Math.round(drag.height - dy), 195, drag.maxHeight));
        } else if (drag.vertical > 0) {
            put(patch, "keyboardBottomOffsetPx", clamp(Math.round(drag.bottom - dy), 0, 84));
        }
        keyboard.previewResize(deck, patch);
        showDimensions(patch);
    }

    private void finish(JSONObject patch) {
        drag.target.setPressed(false);
        drag = null;
        badge.setAlpha(.8f);
        requestDisallowInterceptTouchEvent(false);
        completing = true;
        // Finish outside touch dispatch. A settings update can replace this frame.
        post(() -> {
            if (!completing) return;
            completing = false;
            keyboard.resizeDragFinished(this, patch);
        });
    }

    void restorePreview() {
        JSONObject saved = new JSONObject();
        keyboard.previewResize(deck, saved);
        showDimensions(saved);
    }

    private void showDimensions(JSONObject preview) {
        int height = preview.optInt("keyboardHeightPx", keyboard.settings.optInt("keyboardHeightPx", 248));
        int width = preview.optInt("keyboardWidthPercent", width());
        int bottom = preview.optInt("keyboardBottomOffsetPx", bottom());
        String text = height + "px · " + width + "%" + (bottom > 0 ? " · ↑" + bottom + "px" : "");
        if (!text.contentEquals(badge.getText())) badge.setText(text);
        badge.setAlpha(drag == null ? .8f : 1);
    }

    private int width() { return clamp(keyboard.settings.optInt("keyboardWidthPercent", 100), 72, 100); }
    private int bottom() { return clamp(keyboard.settings.optInt("keyboardBottomOffsetPx"), 0, 84); }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

    private final class Drag {
        final View target;
        final int pointer, horizontal, vertical;
        final boolean move;
        final float x, y, container;
        final int height, maxHeight, width, offset, bottom;
        final JSONObject patch = json();

        Drag(View target, MotionEvent event, int horizontal, int vertical, boolean move) {
            this.target = target;
            pointer = event.getPointerId(0);
            this.horizontal = horizontal;
            this.vertical = vertical;
            this.move = move;
            x = event.getRawX();
            y = event.getRawY();
            container = Math.max(260, keyboard.getWidth() / density);
            height = keyboard.settings.optInt("keyboardHeightPx", 248);
            maxHeight = clamp(Math.round(keyboard.editor.getScreenHeightDp() * .5f), 380, 540);
            width = width();
            offset = clamp(keyboard.settings.optInt("keyboardHorizontalOffsetPx"), -60, 60);
            bottom = bottom();
        }
    }
}
