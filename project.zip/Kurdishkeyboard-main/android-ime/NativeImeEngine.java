package io.kurdikebord.app;

import android.content.Context;
import android.os.Looper;

import com.whl.quickjs.wrapper.QuickJSContext;
import com.whl.quickjs.android.QuickJSLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Runs the same data and text algorithms as the web keyboard without creating a WebView. */
final class NativeImeEngine implements AutoCloseable {
    private final QuickJSContext runtime;

    NativeImeEngine(Context context) throws IOException {
        String bundle = asset(context, "native-ime/engine.js");
        QuickJSLoader.init();
        runtime = QuickJSContext.create();
        try {
            runtime.evaluate(bundle, "native-ime/engine.js");
        } catch (RuntimeException | LinkageError e) {
            close();
            throw e;
        }
    }

    static String asset(Context context, String name) throws IOException {
        try (InputStream stream = context.getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192];
            int count;
            while ((count = stream.read(chunk)) != -1) buffer.write(chunk, 0, count);
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    Object call(String operation, Object value) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException("The keyboard engine runs on the IME main thread");
        }
        String input = value == null ? "null" : value instanceof String
                ? JSONObject.quote((String) value) : value.toString();
        Object result = runtime.evaluate("kurdiNativeCall(" + JSONObject.quote(operation) + ","
                + JSONObject.quote(input) + ")");
        try {
            return new JSONTokener((String) result).nextValue();
        } catch (JSONException e) {
            throw new IllegalStateException("Invalid response from keyboard engine", e);
        }
    }

    JSONObject object(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof JSONObject ? (JSONObject) result : new JSONObject();
    }

    JSONArray array(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof JSONArray ? (JSONArray) result : new JSONArray();
    }

    String text(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof String ? (String) result : "";
    }

    @Override public void close() {
        runtime.destroy();
    }
}
