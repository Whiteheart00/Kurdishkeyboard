package io.kurdikebord.app;

import android.app.backup.BackupManager;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Only fixed, non-text appearance and behavior preferences are eligible for OS backup. */
final class NativeAutoBackup {
    static final String PREF = "kurdi_auto_safe_v1";
    private static final String[] BOOLS = {"keyAnimation","dynamicBackgroundGlow","keyPopupPreview","showSecondaryHints","showTopToolbar","showBottomKeys","showGlobeKey","showEmojiKey","showCommaKey","swapGlobeAndEmoji","wordSuggestions","autoComplete","doubleSpacePeriod","autoCapitalization","autoSpacePunctuation","soundEnabled","vibrationEnabled","physicalKeyboardSync","emojiSuggestions","showLanguagePickerOnLongPress"};
    private static final String[] NUMBERS = {"fontSizePercent","iconSizePercent","keySpacingPercent","keySpacingHorizontal","keySpacingVertical","keyboardHeightPx","keyboardWidthPercent","keyboardBottomOffsetPx","keyboardHorizontalOffsetPx","longPressDelayMs","flyingLettersSizeMultiplier","emojiFontSizePx","zikrFontSizePx","emojiColumns","soundVolume","vibrationDurationMs","swipeDistanceThreshold","swipeVelocityThreshold","clipboardGridColumns"};
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static boolean enabled(Context c){try{return ImeStateStore.unlocked(c)&&prefs(c).getBoolean("enabled",false);}catch(RuntimeException e){return false;}}
    static JSONObject safe(JSONObject source){
        JSONObject out=new JSONObject();
        for(String k:BOOLS){Object v=source.opt(k);if(v instanceof Boolean)ImeStateStore.put(out,k,v);}
        for(String k:NUMBERS){Object v=source.opt(k);if(v instanceof Number){double n=((Number)v).doubleValue();if(!Double.isNaN(n)&&!Double.isInfinite(n)&&Math.abs(n)<=10000)ImeStateStore.put(out,k,v);}}
        enumValue(source,out,"appLanguage","ckb","kmr","en","ar","fa");
        enumValue(source,out,"appTheme","light","dark","amoled");
        enumValue(source,out,"keyboardThemeMode","light","dark","auto");
        enumValue(source,out,"emojiStyle","system","facebook","twemoji","rounded","classic","minimal");
        enumValue(source,out,"numberStyle","latin","kurdish","urdu_farsi","hindi");
        enumValue(source,out,"numberRowMode","always","per_language","never");
        return out;
    }
    private static void enumValue(JSONObject in,JSONObject out,String key,String... values){String v=in.optString(key);for(String allowed:values)if(allowed.equals(v)){ImeStateStore.put(out,key,v);return;}}
    static JSONObject read(Context c){try{if(enabled(c))return safe(ImeStateStore.parse(prefs(c).getString("settings","{}")));}catch(RuntimeException ignored){}return new JSONObject();}
    static boolean setEnabled(Context c,boolean on,JSONObject settings){
        if(!ImeStateStore.unlocked(c))return false;
        SharedPreferences.Editor e=prefs(c).edit().clear();
        if(on)e.putBoolean("enabled",true).putString("settings",safe(settings).toString());
        if(!e.commit())return false;notifyChanged(c);return true;
    }
    private static void notifyChanged(Context c){try{new BackupManager(c).dataChanged();}catch(RuntimeException ignored){}}
    static void update(Context c,JSONObject settings){
        try{if(!enabled(c))return;
        String next=safe(settings).toString(); SharedPreferences p=prefs(c);
        if(!next.equals(p.getString("settings",""))){p.edit().putString("settings",next).apply();notifyChanged(c);}}catch(RuntimeException ignored){}
    }
}
