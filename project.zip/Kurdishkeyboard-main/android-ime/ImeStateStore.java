package io.kurdikebord.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.UserManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Iterator;
import java.util.Set;

/** Credential-protected shared keyboard state. The editor's text is never stored here. */
final class ImeStateStore {
    static final String PREFS = "kurdi_native_ime_v1";
    static final String STATE = "state";
    private static final int VERSION = 1;
    private static final int MAX_BYTES = 16 * 1024 * 1024;
    private static final ExecutorService learnedWriter = Executors.newSingleThreadExecutor(
            task -> new Thread(task, "ime-learned-words"));

    static boolean enabled(Context context) {
        // Always use the native IME.
        return true;
    }
    static boolean unlocked(Context context) {
        if (android.os.Build.VERSION.SDK_INT < 24) return true;
        UserManager users = context.getSystemService(UserManager.class);
        return users == null || users.isUserUnlocked();
    }

    static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized JSONObject read(Context context) {
        return parseState(rawState(context));
    }

    private static final String SEALED = "clipboardEncryptedV1";
    private static String cachedEnvelope = "", cachedClipboard = "";
    private static String decryptClipboard(String envelope) throws Exception {
        if (!envelope.equals(cachedEnvelope) || cachedClipboard.isEmpty()) {
            String plain = NativeClipboardVault.open(envelope);
            new JSONArray(plain); // validate before caching
            cachedEnvelope = envelope; cachedClipboard = plain;
        }
        return cachedClipboard;
    }
    static synchronized String rawState(Context context) {
        if (!unlocked(context)) { cachedEnvelope = ""; cachedClipboard = ""; return ""; }
        String raw = preferences(context).getString(STATE, "");
        JSONObject state = parseState(raw);
        if (state.has(SEALED)) {
            try {
                String plain = decryptClipboard(state.getString(SEALED));
                state.remove(SEALED); state.put("clipboard", new JSONArray(plain));
                NativeSecurityStatus.note(context,"vault",1);
            } catch (Exception error) {
                // Keep ciphertext on disk and block writes until it can be read.
                state.remove(SEALED); state.remove("clipboard");
                NativeSecurityStatus.note(context,"vault",0);
                android.util.Log.w("ClipboardVault", "Clipboard unavailable; existing storage preserved");
            }
            return state.toString();
        }
        if (state.optJSONArray("clipboard") != null && !write(context, state, true)) {
            // No plaintext fallback for new writes. Preserve old data on failed migration.
            android.util.Log.w("ClipboardVault", "Clipboard migration not completed");
        }
        return raw;
    }

    static JSONObject parseState(String raw) {
        JSONObject state = parse(raw);
        return state.optInt("version") == VERSION ? state : new JSONObject();
    }

    static void saveLearnedWords(Context context, Map<String, Integer> increments) {
        Context application = context.getApplicationContext();
        learnedWriter.execute(() -> addLearnedWords(application, increments));
    }

    private static synchronized void addLearnedWords(Context context, Map<String, Integer> increments) {
        if (!unlocked(context) || incognito(context)) return;
        JSONObject state = read(context);
        JSONObject words = state.optJSONObject("learned");
        if (words == null) words = new JSONObject();
        mergeLearnedWords(words, increments);
        put(state, "version", VERSION);
        put(state, "learned", words);
        write(context, state);
    }

    static void mergeLearnedWords(JSONObject words, Map<String, Integer> increments) {
        for (Map.Entry<String, Integer> entry : increments.entrySet()) {
            String word = entry.getKey();
            put(words, word, Math.min(Integer.MAX_VALUE, (long) words.optInt(word) + entry.getValue()));
        }
        if (words.length() <= 400) return;
        List<String> ordered = new ArrayList<>();
        Iterator<String> keys = words.keys();
        while (keys.hasNext()) ordered.add(keys.next());
        java.util.Collections.sort(ordered, (a, b) -> Integer.compare(words.optInt(a), words.optInt(b)));
        for (int i = 0; i < ordered.size() - 400; i++) words.remove(ordered.get(i));
    }

    static synchronized JSONObject snapshot(Context context) {
        JSONObject state = read(context);
        if (!state.optBoolean("legacyImported")) {
            put(state, "settings", effectiveSettings(context, state));
        }
        return state;
    }

    static JSONObject effectiveSettings(Context context, JSONObject state) {
        JSONObject stored = state.optJSONObject("settings");
        if (state.optBoolean("legacyImported") || state.optBoolean("replaceSettings")) {
            return stored == null ? new JSONObject() : stored;
        }
        JSONObject recovered = NativeAutoBackup.read(context);
        copyEntries(parse(NativeSettingsBackup.read(context)), recovered);
        if (stored != null) copyEntries(stored, recovered);
        return recovered;
    }

    static synchronized boolean importLegacy(Context context, String raw) {
        if (!unlocked(context) || raw == null || raw.length() > MAX_BYTES) return false;
        JSONObject pending = read(context);
        if (pending.optBoolean("legacyImported")) return true;
        try {
            JSONObject old = new JSONObject(raw);
            JSONObject state = json("version", VERSION, "legacyImported", true);
            copy(old, state, "settings", JSONObject.class);
            copy(old, state, "sourceLanguage", String.class);
            copy(old, state, "targetLanguage", String.class);
            copy(pending, state, "sourceLanguage", String.class);
            copy(pending, state, "targetLanguage", String.class);
            JSONObject overrides = pending.optJSONObject("settings");
            if (overrides != null) mergeSettings(state, overrides, pending.optBoolean("replaceSettings"));

            JSONArray clipboard = pending.optJSONArray("clipboard");
            JSONArray oldClipboard = old.optJSONArray("clipboard");
            if (clipboard != null || oldClipboard != null) {
                put(state, "clipboard", pending.optBoolean("replaceClipboard") ? clipboard : mergeClipboard(clipboard, oldClipboard, pending));
            }
            JSONObject learned = old.optJSONObject("learned");
            JSONObject newer = pending.optJSONObject("learned");
            if (newer != null) {
                if (learned == null) learned = new JSONObject();
                Iterator<String> words = newer.keys();
                while (words.hasNext()) {
                    String word = words.next();
                    put(learned, word, Math.min(Integer.MAX_VALUE, (long) learned.optInt(word) + newer.optInt(word)));
                }
            }
            put(state, "learned", learned);
            return write(context, state);
        } catch (JSONException e) {
            return false;
        }
    }

    private static JSONArray mergeClipboard(JSONArray current, JSONArray old, JSONObject pending) {
        JSONArray result = new JSONArray();
        Set<String> seenText = new HashSet<>();
        Set<String> currentIds = new HashSet<>();
        for (int i = 0; current != null && i < current.length(); i++) {
            JSONObject item = current.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("id");
            if (!id.isEmpty()) currentIds.add(id);
            if (seenText.add(item.optString("text"))) result.put(item);
        }
        JSONObject removed = pending.optJSONObject("clipboardRemovedIds");
        for (int i = 0; old != null && i < old.length(); i++) {
            JSONObject item = old.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("id");
            if (currentIds.contains(id) || removed != null && removed.optBoolean(id)) continue;
            if (pending.optBoolean("clipboardClearedUnpinned") && !item.optBoolean("pinned")) continue;
            if (seenText.add(item.optString("text"))) result.put(item);
        }
        return result;
    }

    // Device-local consent; not included in settings exports or cloud backups.
    private static final String CAPTURE_HIDDEN = "capture_hidden_clipboard";
    private static final String INCOGNITO = "incognito_local_v9";
    static boolean incognito(Context context) { return !unlocked(context) || preferences(context).getBoolean(INCOGNITO,false); }
    static void setIncognito(Context context,boolean on) { if(unlocked(context)) preferences(context).edit().putBoolean(INCOGNITO,on).apply(); }
    static boolean incognitoKey(String key) { return INCOGNITO.equals(key); }
    static boolean captureHiddenClipboard(Context context) {
        return unlocked(context) && !incognito(context) && preferences(context).getBoolean(CAPTURE_HIDDEN, false);
    }
    static boolean setCaptureHiddenClipboard(Context context, boolean enabled) {
        return unlocked(context) && preferences(context).edit().putBoolean(CAPTURE_HIDDEN, enabled).commit();
    }
    static synchronized boolean clipboardCaptureEnabled(Context context) {
        if (!unlocked(context) || incognito(context)) return false;
        JSONObject settings = effectiveSettings(context, read(context));
        return settings.optBoolean("clipboardEnabled", true) && settings.optBoolean("clipboardHistoryEnabled", true);
    }
    static synchronized boolean captureClipboard(Context context, List<String> texts) {
        if (!unlocked(context) || incognito(context) || texts.isEmpty()) return false;
        JSONObject state = read(context);
        JSONObject settings = effectiveSettings(context, state);
        if (!settings.optBoolean("clipboardEnabled", true) || !settings.optBoolean("clipboardHistoryEnabled", true)) return false;
        JSONArray existing = state.optJSONArray("clipboard");
        int limit = Math.max(100, settings.optInt("clipboardMaxItems", 20));
        JSONArray result = new JSONArray();
        Set<String> seen = new HashSet<>();
        for (String value : texts) {
            String text = ImeClipboardCapture.safeText(value);
            if (text == null || !seen.add(text)) continue;
            JSONObject previous = null;
            for (int i = 0; existing != null && i < existing.length(); i++) {
                JSONObject item = existing.optJSONObject(i);
                if (item != null && text.equals(item.optString("text"))) { previous = item; break; }
            }
            JSONObject item = json("id", previous == null ? "clip_" + java.util.UUID.randomUUID() : previous.optString("id"),
                    "text", text, "timestamp", System.currentTimeMillis());
            if (previous != null && previous.has("pinned")) put(item, "pinned", previous.optBoolean("pinned"));
            result.put(item);
        }
        if (result.length() == 0) return false;
        for (int i = 0; existing != null && i < existing.length(); i++) {
            JSONObject item = existing.optJSONObject(i);
            if (item != null && !seen.contains(item.optString("text")) && (item.optBoolean("pinned") || result.length() < limit)) result.put(item);
        }
        put(state, "version", VERSION);
        put(state, "clipboard", result);
        return write(context, state);
    }

    static synchronized void updateClipboard(Context context, JSONArray clipboard, Set<String> removedIds, boolean clearUnpinned) {
        if (!unlocked(context)) return;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        put(state, "clipboard", clipboard);
        if (!state.optBoolean("legacyImported") && !state.optBoolean("replaceClipboard")) {
            if (!removedIds.isEmpty()) {
                JSONObject removed = state.optJSONObject("clipboardRemovedIds");
                if (removed == null) removed = new JSONObject();
                for (String id : removedIds) put(removed, id, true);
                put(state, "clipboardRemovedIds", removed);
            }
            if (clearUnpinned) put(state, "clipboardClearedUnpinned", true);
        }
        write(context, state);
    }

    static synchronized JSONObject updateSettings(Context context, JSONObject values, boolean replace) {
        if (!unlocked(context)) return null;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        if (replace && !state.optBoolean("legacyImported")) put(state, "replaceSettings", true);
        if (!replace) put(state, "settings", effectiveSettings(context, state));
        mergeSettings(state, values, replace);
        if (!write(context, state)) return null;
        JSONObject effective = effectiveSettings(context, state);
        NativeAutoBackup.update(context, effective);
        return effective;
    }

    static synchronized JSONObject resetSettingsSection(Context context,JSONObject core,String scope) {
        if(!unlocked(context))return null;
        JSONObject current=effectiveSettings(context,read(context));
        JSONObject next=NativeSettingsSections.reset(current,core,scope);
        return updateSettings(context,next,true);
    }

    private static JSONObject mergeSettings(JSONObject state, JSONObject values, boolean replace) {
        JSONObject settings = replace ? null : state.optJSONObject("settings");
        if (settings == null) settings = new JSONObject();
        copyEntries(values, settings);
        put(state, "settings", settings);
        return settings;
    }

    private static void copyEntries(JSONObject values, JSONObject target) {
        Iterator<String> keys = values.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            put(target, key, values.opt(key));
        }
    }

    static synchronized void set(Context context, String key, Object value) {
        set(context, key, value, false);
    }

    static synchronized void set(Context context, String key, Object value, boolean replaceClipboard) {
        if (!unlocked(context)) return;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        if (replaceClipboard && !state.optBoolean("legacyImported")) put(state, "replaceClipboard", true);
        put(state, key, value);
        write(context, state);
    }

    private static boolean write(Context context, JSONObject state) {
        return write(context, state, false);
    }
    private static boolean write(Context context, JSONObject state, boolean durable) {
        if (!unlocked(context)) return false;
        try {
            SharedPreferences prefs = preferences(context);
            String previous = prefs.getString(STATE, "");
            JSONObject old = parseState(previous);
            if (old.has(SEALED)) decryptClipboard(old.getString(SEALED)); // never overwrite unreadable data
            JSONObject disk = new JSONObject(state.toString());
            JSONArray clips = disk.optJSONArray("clipboard");
            disk.remove("clipboard"); disk.remove(SEALED);
            if (clips != null) {
                String plain = clips.toString();
                String envelope = !cachedEnvelope.isEmpty() && plain.equals(cachedClipboard)
                    ? cachedEnvelope : NativeClipboardVault.seal(plain);
                disk.put(SEALED, envelope);
            }
            String raw = disk.toString();
            if (raw.length() > MAX_BYTES * 2L || state.toString().length() > MAX_BYTES) return false;
            if (raw.equals(previous)) return true;
            SharedPreferences.Editor edit = prefs.edit().putString(STATE, raw);
            if (durable || (old.has("clipboard") && !old.has(SEALED))) {
                if (!edit.commit()) return false;
            } else edit.apply();
            if (clips != null) { cachedEnvelope = disk.getString(SEALED); cachedClipboard = clips.toString(); }
            else { cachedEnvelope = ""; cachedClipboard = ""; }
            return true;
        } catch (Exception error) {
            android.util.Log.w("ClipboardVault", "State write blocked; existing storage preserved");
            return false;
        }
    }

    private static void copy(JSONObject from, JSONObject to, String key, Class<?> type) throws JSONException {
        Object value = from.opt(key);
        if (type.isInstance(value)) to.put(key, value);
    }

    static JSONObject parse(String raw) {
        try { return new JSONObject(raw); } catch (JSONException | NullPointerException e) { return new JSONObject(); }
    }

    static JSONObject json(Object... pairs) {
        JSONObject json = new JSONObject();
        for (int i = 0; i < pairs.length; i += 2) put(json, (String) pairs[i], pairs[i + 1]);
        return json;
    }

    static void put(JSONObject json, String key, Object value) {
        try { json.put(key, value); } catch (JSONException e) { throw new IllegalArgumentException(key, e); }
    }

    /** Apply a flat settings patch from native settings screens (native only). */
    static synchronized void mergeSettingsPatch(Context context, JSONObject patch) {
        if (context == null || patch == null || patch.length() == 0 || !unlocked(context)) return;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        JSONObject settings = effectiveSettings(context, state);
        Iterator<String> keys = patch.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            put(settings, key, patch.opt(key));
        }
        put(state, "settings", settings);
        if (write(context, state)) NativeAutoBackup.update(context, settings);
    }

    static synchronized boolean configureAutoBackup(Context context, boolean enabled, JSONObject core) {
        if(!unlocked(context))return false;
        JSONObject current=new NativeImeSettings(core).hydrate(effectiveSettings(context,read(context)));
        if(updateSettings(context,current,false)==null)return false;
        return NativeAutoBackup.setEnabled(context,enabled,current);
    }

    /** Merge chosen sections into a single state update, without deleting unrelated data. */
    static synchronized boolean restoreCloud(Context context, JSONObject payload, JSONObject core, int selected) throws Exception {
        if (!unlocked(context)) return false;
        int mask = NativeCloudBackup.validate(payload) & selected;
        if (mask == 0) return false;
        JSONObject state = read(context);
        JSONObject existing = effectiveSettings(context,state);
        JSONObject patch = NativeCloudBackup.filterSettings(payload.getJSONObject("settings"),core,mask);
        copyEntries(patch, existing);
        JSONObject settings = new NativeImeSettings(core).hydrate(existing);
        put(state,"version",VERSION);
        put(state,"settings",settings);
        if ((mask & NativeCloudBackup.LANGUAGES) != 0) for (String key:new String[]{"sourceLanguage","targetLanguage"}) {
            String code=payload.optString(key);if(NativeCloudBackup.validLanguage(core,key,code))put(state,key,code);
        }
        if ((mask & NativeCloudBackup.WORDS) != 0) {
            JSONObject words = state.optJSONObject("learned"); if(words==null)words=new JSONObject();
            JSONObject incoming = payload.getJSONObject("learned");
            Iterator<String> keys=incoming.keys();
            while(keys.hasNext()) {String word=keys.next();int count=incoming.optInt(word,0);
                if(count>0 && word.length()<=128&&!NativeCloudBackup.obviousSecret(word))put(words,word,Math.max(count,words.optInt(word)));}
            mergeLearnedWords(words,java.util.Collections.emptyMap());put(state,"learned",words);
        }
        if ((mask & (NativeCloudBackup.PINNED|NativeCloudBackup.ALL_CLIPS)) != 0) {
            JSONArray clips=NativeCloudBackup.mergeClips(state.optJSONArray("clipboard"),payload.getJSONArray("clipboard"),(mask&NativeCloudBackup.ALL_CLIPS)!=0);
            put(state,"clipboard",clips);
        }
        String raw=state.toString();
        if(raw.length()>MAX_BYTES)return false;
        // Commit synchronously on the backup worker, so success means the state reached storage.
        if(!write(context,state,true))return false;
        NativeAutoBackup.update(context,settings);
        return true;
    }
}
