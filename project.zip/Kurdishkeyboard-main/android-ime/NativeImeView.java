package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;
import java.util.Set;

final class NativeImeView extends FrameLayout implements AutoCloseable {
    private static final String[] MODES = {"characters", "symbols", "symbols2", "numeric_advanced"};
    private static final java.util.List<String> FRAME_DECORATORS = java.util.Arrays.asList("royal_frame", "hearts_frame", "stars_frame", "kurdish_ornate");
    private static final Pattern WORD_END = Pattern.compile("([^\\s\\p{Z}.,!?؟،:;()\\[\\]{}\"'«»]+)$");
    private static final Pattern SENTENCE_END = Pattern.compile("[.!?]\\s+$");
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, JSONObject> deckModels = new LruCache<>(8);
    private final Map<String, Integer> pendingWords = new LinkedHashMap<>();
    private final Runnable saveWords = this::flushLearnedWords;
    private final Runnable showSuggestions = () -> {
        suggestionsScheduled = false;
        updateSuggestions();
    };
    private final int[] previewOrigin = new int[2];
    private final int[] previewAnchor = new int[2];
    final KurdiKeyboardImeService service;
    final KurdiKeyboardImeService.NativeEditorController editor;
    final NativeImeEngine engine;
    final NativeImeAppearance appearance;
    final JSONObject defaults;
    final NativeImePanels panels;
    JSONObject settings;
    JSONObject theme = new JSONObject();
    JSONArray clipboard;
    String mode = "characters";
    String panel = "keys";
    String decorator = "none";
    String voiceState = "idle";
    String voiceNotice = "";
    private String shift = "off";
    private String kana = "hira";
    private String tail = "";
    private String currentWord = "";
    private String lastRenderedTail;
    private String lastConfirmedTail;
    private boolean lastEditorSensitive;
    private boolean suggestionsScheduled;
    private boolean predictionContextDirty = true;
    private String predictionKana;
    private String predictionSettingsJson, predictionLearnedJson;
    private final java.util.concurrent.ExecutorService predictionWorker = java.util.concurrent.Executors.newSingleThreadExecutor(r -> new Thread(r, "ime-predictions"));
    private java.util.concurrent.Future<?> predictionTask;
    private long predictionGeneration;
    // These are accessed exclusively on the prediction worker.
    private NativeImePrediction workerPrediction;
    private String workerSettings, workerLearned, workerKana;
    private boolean redrawOnShow;
    private JSONObject lang = new JSONObject();
    private JSONObject learned;
    private String lastStoredLearned;
    private String lastStoredState;
    private String settingsKey = "";
    private boolean rtl;
    private boolean listening;
    private boolean closed;
    private final java.util.ArrayDeque<TextView> flyingLetters = new java.util.ArrayDeque<>();
    private NativeImeKeyGrid grid;
    private int additionalDeckHeightDp;
    private LinearLayout suggestions;
    private LinearLayout surface;
    private TextView previewBubble;
    private Boolean lowMemoryDevice;
    private View choice;
    private View choiceStem;
    private View choiceAnchor;
    private LinearLayout choiceItems;
    private final ArrayList<TextView> keyAlternateButtons = new ArrayList<>();
    private JSONArray choiceOptions;
    private int choiceIndex = -1;
    private boolean choiceFollowsPointer;
    private boolean emailAlternates;
    private boolean inlineResize;
    private NativeImeResizeFrame resizeFrame;
    private boolean renderAfterResize;
    private long lastSpace;
    private long lastShift;
    private SoundPool sounds;
    private final Map<String, Integer> samples = new HashMap<>();
    private final Set<Integer> loadedSamples = new HashSet<>();
    private SharedPreferences observed;
    private final SharedPreferences.OnSharedPreferenceChangeListener observer = (preferences, key) -> {
        if (ImeStateStore.STATE.equals(key)) post(this::refreshState);
    };
    private final Runnable clearVoiceNotice = () -> { voiceNotice = ""; render(); };

    NativeImeView(KurdiKeyboardImeService service, KurdiKeyboardImeService.NativeEditorController editor) throws IOException {
        super(service);
        this.service = service;
        this.editor = editor;
        engine = new NativeImeEngine(service);
        try {
            appearance = new NativeImeAppearance(service, engine);
            defaults = engine.object("defaults", null);
            panels = new NativeImePanels(this);
            refreshState();
        } catch (RuntimeException | LinkageError error) {
            predictionWorker.shutdownNow();
            engine.close();
            throw error;
        }
    }

    void startSession(String initialTail) {
        if (ImeStateStore.unlocked(service)) {
            if (observed == null) {
                observed = ImeStateStore.preferences(service);
                observed.registerOnSharedPreferenceChangeListener(observer);
            }
        }
        refreshState();
        lastConfirmedTail = initialTail;
        if (initialTail != null) setTail(initialTail);
        if (!"keys".equals(panel)) panels.panelChanged(panel);
        boolean shifted = initialTail != null && autoShift();
        if (shifted || redrawOnShow || !"keys".equals(panel)) render();
        else updateSuggestions();
        redrawOnShow = false;
    }

    void endSession() {
        endSession(false);
    }

    void endSession(boolean restartingEditor) {
        cancelSuggestionUpdate();
        invalidatePredictions();
        if (!restartingEditor && resizeFrame != null && resizeFrame.cancelDrag()) redrawOnShow = true;
        flushLearnedWords();
        if (grid != null) grid.cancel();
        dismissChoices();
        clearFlyingLetters();
        panels.endSession();
        lastSpace = 0;
        lastShift = 0;
        boolean clearShift = "caps".equals(shift) && !settings.optBoolean("rememberCapsLockState");
        if (clearShift) shift = "off";
        redrawOnShow |= clearShift || !"keys".equals(panel) || suggestions == null;
        setTail("");
        lastRenderedTail = null;
        lastConfirmedTail = null;
    }

    private void refreshState() {
        if (closed) return;
        String raw = ImeStateStore.rawState(service);
        if (raw.equals(lastStoredState)) return;
        lastStoredState = raw;
        JSONObject state = ImeStateStore.parseState(raw);
        JSONObject stored = ImeStateStore.effectiveSettings(service, state);
        JSONArray before = clipboard;
        clipboard = state.optJSONArray("clipboard");
        if (clipboard == null) clipboard = defaults.optJSONArray("clipboard");
        JSONObject storedLearned = state.optJSONObject("learned");
        String learnedKey = storedLearned == null ? "{}" : storedLearned.toString();
        if (!learnedKey.equals(lastStoredLearned)) {
            lastStoredLearned = learnedKey;
            learned = storedLearned == null ? new JSONObject() : storedLearned;
            ImeStateStore.mergeLearnedWords(learned, pendingWords);
            predictionContextDirty = true;
        }
        panels.readState(state);
        String key = stored.toString();
        if (settings == null || !settingsKey.equals(key)) {
            settingsKey = key;
            JSONObject previous = settings;
            settings = engine.object("hydrate", stored);
            if ("emoji".equals(panel) && mediaHistoryOnly(previous, settings) && panels.refreshMedia()) return;
            settingsChanged();
        } else if (before == null || !before.toString().equals(clipboard.toString())) {
            if ("clipboard".equals(panel) && !panels.clipboardPanel.editing()) panels.clipboardPanel.refresh(); else updateSuggestions();
        }
    }

    private static boolean mediaHistoryOnly(JSONObject before, JSONObject after) {
        if (before == null || after == null) return false;
        java.util.Set<String> keys = new java.util.HashSet<>();
        java.util.Iterator<String> it = before.keys(); while (it.hasNext()) keys.add(it.next());
        it = after.keys(); while (it.hasNext()) keys.add(it.next());
        boolean changed = false;
        for (String key : keys) {
            if (java.util.Objects.equals(String.valueOf(before.opt(key)), String.valueOf(after.opt(key)))) continue;
            switch (key) {
                case "emojiLastUsedCategory": case "emojiPinned": case "recentEmojis":
                case "kaomojiPinned": case "recentKaomoji": case "zikrHistories": case "recentZikr":
                    changed = true; break;
                default: return false;
            }
        }
        return changed;
    }

    void settingsPatch(JSONObject patch) {
        JSONObject saved = ImeStateStore.updateSettings(service, patch, false);
        if (saved != null) {
            refreshState();
        } else {
            java.util.Iterator<String> keys = patch.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                put(settings, key, patch.opt(key));
            }
            settingsChanged();
        }
    }

    private void settingsChanged() {
        deckModels.evictAll();
        predictionContextDirty = true;
        if (previewBubble != null) {
            getOverlay().remove(previewBubble);
            previewBubble = null;
        }
        render();
    }

    void clipboardUpdated(JSONArray values) {
        clipboardUpdated(values, java.util.Collections.emptySet(), false);
    }

    void clipboardUpdated(JSONArray values, Set<String> removed, boolean clearUnpinned) {
        clipboard = values;
        ImeStateStore.updateClipboard(service, values, removed, clearUnpinned);
        if ("clipboard".equals(panel)) panels.clipboardPanel.refresh(); else updateSuggestions();
    }

    void systemClipboard(String text) {
        if (!settings.optBoolean("clipboardHistoryEnabled")) return;
        String clean = text.trim();
        if (clean.isEmpty() || clean.length() > 524288) return;
        long now = System.currentTimeMillis();
        JSONArray next = new JSONArray();
        JSONObject previous = null;
        int limit = Math.max(100, settings.optInt("clipboardMaxItems", 20));
        for (int i = 0; i < clipboard.length(); i++) {
            JSONObject item = clipboard.optJSONObject(i);
            if (item == null) continue;
            if (clean.equals(item.optString("text"))) previous = item;
            else if (item.optBoolean("pinned") || next.length() < limit - 1) next.put(item);
        }
        JSONObject first = json("id", previous == null ? "clip_" + now : previous.optString("id"), "text", clean, "timestamp", now);
        if (previous != null && previous.has("pinned")) put(first, "pinned", previous.optBoolean("pinned"));
        JSONArray result = new JSONArray().put(first);
        for (int i = 0; i < next.length(); i++) result.put(next.opt(i));
        clipboardUpdated(result);
    }

    String clipboardCurrentText() { return service.nativeSensitiveEditor() ? "" : tail; }

    void editorChanged(String value) {
        if (closed) return;
        boolean availabilityChanged = tail.trim().isEmpty() != value.trim().isEmpty();
        boolean contextChanged = !value.equals(lastConfirmedTail);
        lastConfirmedTail = value;
        setTail(value);
        if (availabilityChanged && "clipboard".equals(panel) && !panels.clipboardPanel.editing()) { panels.clipboardPanel.refresh(); return; }
        if (contextChanged && "keys".equals(panel) && (grid == null || !grid.ownsTouch()) && autoShift()) { render(); return; }
        if (!tail.equals(lastRenderedTail) || lastEditorSensitive != service.nativeSensitiveEditor()) requestSuggestions();
    }

    private void setTail(String value) {
        if (value.equals(tail)) return;
        tail = value;
        java.util.regex.Matcher word = WORD_END.matcher(value.substring(Math.max(0, value.length() - 80)));
        currentWord = word.find() ? word.group(1) : "";
    }

    void characterDeleted() {
        if (tail.isEmpty() || service.nativeSensitiveEditor()) return;
        setTail(tail.substring(0, tail.offsetByCodePoints(tail.length(), -1)));
        requestSuggestions();
    }

    private void requestSuggestions() {
        if (suggestions == null || suggestionsScheduled) return;
        suggestionsScheduled = true;
        main.postDelayed(showSuggestions, 48);
    }

    private void cancelSuggestionUpdate() {
        if (!suggestionsScheduled) return;
        suggestionsScheduled = false;
        main.removeCallbacks(showSuggestions);
    }

    private boolean autoShift() {
        if (!"off".equals(shift) || !"characters".equals(mode) || !"ltr".equals(lang.optString("dir"))
                || !settings.optBoolean("autoCapitalization") || service.nativeSensitiveEditor()) return false;
        if (!tail.isEmpty() && !tail.endsWith("\n") && !SENTENCE_END.matcher(tail).find()) return false;
        shift = "once";
        return true;
    }

    String font() { return settings.optString("fontStyle", "system"); }
    boolean light() { return theme.optBoolean("isLight"); }
    int bg() { return appearance.color(theme, "bg", Color.BLACK); }
    int keyColor() { return appearance.color(theme, "keyBg", 0xff202124); }
    int textColor() { return appearance.color(theme, "keyText", Color.WHITE); }
    int secondaryColor() { return appearance.color(theme, "secondaryText", 0xffa1a1aa); }
    int accent() { return appearance.color(theme, "accent", 0xff2990ff); }
    int dp(double size) { return appearance.dp(size); }
    private int toolbarTint() { return light() ? 0xff1e293b : Color.WHITE; }

    void openPanel(String name) {
        openPanel(name, false);
    }

    void openEmojiSearch() {
        mode = "characters";
        openPanel("keys", true);
    }

    private void openPanel(String name, boolean searchEmoji) {
        if (resizeFrame != null) resizeFrame.cancelDrag();
        if (!panel.equals(name)) panels.panelChanged(name);
        panel = name;
        if (searchEmoji) panels.enableEmojiSearch();
        inlineResize = false;
        dismissChoices();
        render();
    }

    void render() {
        if (closed) return;
        if (resizeFrame != null && resizeFrame.isDragging()) {
            renderAfterResize = true;
            return;
        }
        renderAfterResize = false;
        resizeFrame = null;
        cancelSuggestionUpdate();
        invalidatePredictions();
        if (grid != null) grid.cancel();
        dismissChoices();
        clearFlyingLetters();
        grid = null;
        suggestions = null;
        removeAllViews();
        String deckKey = mode + ":" + shift + ":" + kana;
        JSONObject deck = deckModels.get(deckKey);
        if (deck == null) {
            deck = engine.object("deck", json("settings", settings, "mode", mode, "shift", shift, "kana", kana));
            deckModels.put(deckKey, deck);
        }
        theme = deck.optJSONObject("theme");
        lang = deck.optJSONObject("lang");
        rtl = "rtl".equals(deck.optString("direction"));
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        setClipChildren(false);
        setClipToPadding(false);
        int width = deck.optInt("width", 100);
        int verticalOffset = Math.max(0, Math.min(84, settings.optInt("keyboardBottomOffsetPx")));
        int offset = Math.max(-60, Math.min(60, settings.optInt("keyboardHorizontalOffsetPx")));
        setBackgroundColor(width < 100 || verticalOffset > 0 ? light() ? 0xffe2e8f0 : 0xff050608 : bg());
        surface = column();
        surface.setBackground(appearance.background(bg(), width < 100 || verticalOffset > 0 ? 16 : 0, 0, 0));
        applyBackgroundGlow();
        LayoutParams layout = new LayoutParams(surfaceWidth(width), -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        layout.bottomMargin = dp(verticalOffset);
        if (width < 100) surface.setTranslationX(dp(offset));
        addView(surface, layout);
        boolean editingClipboard = panels.clipboardPanel.editing();
        if (settings.optBoolean("showTopToolbar") && !"emoji".equals(panel) && !editingClipboard) addToolbar();
        if (!voiceNotice.isEmpty() && !editingClipboard) addVoiceBanner();
        if (editingClipboard) {
            surface.addView(panels.clipboardPanel.renderEditor(), new LinearLayout.LayoutParams(-1, -2));
        } else if (panels.showingLivePicker() || !"keys".equals(panel)) {
            View panelView = panels.showingLivePicker() ? panels.livePicker() : panels.render(panel);
            if (panelView.getLayoutParams() == null) surface.addView(panelView, new LinearLayout.LayoutParams(-1, -2));
            else surface.addView(panelView);
            return;
        } else if (!panels.renderTypingStrip(surface)) addSuggestions();
        LinearLayout deckRow = row();
        String handed = settings.optString("oneHandedMode");
        if ("right".equals(handed)) addHandedRail(deckRow, true);
        FrameLayout gridBody = new FrameLayout(getContext());
        gridBody.setClipChildren(false);
        int deckHeight = deck.optInt("height", 248);
        additionalDeckHeightDp = deckHeight - keyAreaHeight(settings.optInt("keyboardHeightPx", 248));
        deckRow.addView(gridBody, new LinearLayout.LayoutParams(0, dp(deckHeight), 1));
        grid = new NativeImeKeyGrid(this, deck);
        gridBody.addView(grid, new LayoutParams(-1, -1));
        if (inlineResize) {
            resizeFrame = new NativeImeResizeFrame(this, gridBody);
            gridBody.addView(resizeFrame, new LayoutParams(-1, -1));
        }
        if ("left".equals(handed)) addHandedRail(deckRow, false);
        surface.addView(deckRow);
    }

    private void addToolbar() {
        LinearLayout bar = row();
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), 0, dp(12), 0);
        bar.setBackgroundColor(appearance.color(theme, "toolbarBg", bg()));
        addToolbarIcon(bar, "ic_select_all", "دیاریکردنی هەموو", () -> editorAction(android.R.id.selectAll, editor::selectAll));
        addToolbarIcon(bar, "ic_copy", "کۆپیکردن", () -> editorAction(android.R.id.copy, editor::copy));
        addToolbarIcon(bar, "ic_left", "چەپ", () -> moveToolbarCursor(-1));
        addToolbarIcon(bar, "mic", "دەنگ بۆ نووسین", this::toggleVoice);
        addToolbarIcon(bar, "ic_right", "ڕاست", () -> moveToolbarCursor(1));
        addToolbarIcon(bar, "ic_cuts", "بڕین", () -> editorAction(android.R.id.cut, editor::cut));
        View paste = addToolbarIcon(bar, "ic_pastes", "کرتە بۆ پەیست، کرتەی درێژ بۆ کلیپ‌بۆرد", () -> editorAction(android.R.id.paste, editor::paste));
        paste.setOnLongClickListener(view -> { feedback("special"); openPanel("clipboard"); return true; });
        surface.addView(bar, new LinearLayout.LayoutParams(-1, dp(48)));
        View divider = new View(getContext());
        divider.setBackgroundColor(0x0dffffff);
        surface.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private View addToolbarIcon(LinearLayout bar, String icon, String label, Runnable action) {
        View view = iconButton(icon, label, 20, "mic".equals(icon) && listening ? 0xfffb7185 : toolbarTint(), action);
        int width = ((LayoutParams) surface.getLayoutParams()).width;
        if (width < 0) width = getResources().getDisplayMetrics().widthPixels;
        int iconWidth = Math.max(1, Math.min(dp(40), (width - dp(24)) / 7));
        if (bar.getChildCount() > 0) bar.addView(new android.widget.Space(getContext()), new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(view, new LinearLayout.LayoutParams(iconWidth, dp(36)));
        return view;
    }

    private void addVoiceBanner() {
        LinearLayout banner = row();
        banner.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        banner.setPadding(dp(12), dp(6), dp(12), dp(6));
        banner.setBackgroundColor(0x2620a5e9);
        TextView label = appearance.text(voiceNotice, 12, 0xff7dd3fc, font(), 500);
        label.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        banner.addView(label, new LinearLayout.LayoutParams(0, -1, 1));
        if ("permission".equals(voiceState)) banner.addView(button("مۆڵەت بدە", editor::requestVoicePermission));
        else if (listening) banner.addView(button("recording".equals(voiceState) ? "وەستان" : "هەڵوەشاندنەوە", this::toggleVoice));
        surface.addView(banner, new LinearLayout.LayoutParams(-1, dp(36)));
    }

    private void addSuggestions() {
        LinearLayout strip = row();
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(6), 0, dp(6), 0);
        if (settings.optBoolean("smartReplyEnabled")) {
            addUtilityIcon(strip, iconButton("ic_smart", "وەڵامدەرەوەی زیرەک (AI)", 19, toolbarTint(), () -> openPanel("ai_smart")));
        }
        addUtilityIcon(strip, iconButton("ic_translate", "وەرگێڕان و وەرگێڕانی ڕاستەوخۆ", 19, toolbarTint(), () -> openPanel("translate")));
        View calculator = iconButton("calculator", "کلێشە و بژمێری خێرا", 17, toolbarTint(), () -> openPanel("snippets_calc"));
        calculator.setOnLongClickListener(view -> { openPanel("tools"); return true; });
        addUtilityIcon(strip, calculator);
        View divider = new View(getContext());
        divider.setBackgroundColor(light() ? 0xcce2e8f0 : 0x1affffff);
        LinearLayout.LayoutParams dividerPosition = new LinearLayout.LayoutParams(dp(1), dp(28));
        dividerPosition.leftMargin = dp(6);
        strip.addView(divider, dividerPosition);
        HorizontalScrollView scroll = new HorizontalScrollView(getContext());
        scroll.setLayoutDirection(rtl ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        scroll.setHorizontalScrollBarEnabled(false);
        suggestions = row();
        suggestions.setPadding(dp(8), 0, dp(8), 0);
        suggestions.setLayoutDirection(scroll.getLayoutDirection());
        scroll.addView(suggestions, new LayoutParams(-2, -1));
        strip.addView(scroll, new LinearLayout.LayoutParams(0, dp(28), 1));
        surface.addView(strip, new LinearLayout.LayoutParams(-1, dp(44)));
        updateSuggestions();
    }

    private void addUtilityIcon(LinearLayout strip, View action) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(32), dp(32));
        if (strip.getChildCount() > 0) params.leftMargin = dp(2);
        strip.addView(action, params);
    }

    private void invalidatePredictions() {
        predictionGeneration++;
        if (predictionTask != null) predictionTask.cancel(false);
    }

    private void updateSuggestions() {
        cancelSuggestionUpdate();
        invalidatePredictions();
        if (closed || suggestions == null) return;
        lastRenderedTail = tail;
        lastEditorSensitive = service.nativeSensitiveEditor();
        if (lastEditorSensitive) { suggestions.removeAllViews(); return; }
        if (predictionContextDirty || predictionSettingsJson == null || !kana.equals(predictionKana)) {
            predictionSettingsJson = settings.toString();
            predictionLearnedJson = learned == null ? "{}" : learned.toString();
            predictionKana = kana;
            predictionContextDirty = false;
        }
        final String settingSnapshot = predictionSettingsJson, learnedSnapshot = predictionLearnedJson;
        final String kanaSnapshot = kana, suggestedTail = tail;
        final long generation = predictionGeneration;
        predictionTask = predictionWorker.submit(() -> {
            try {
                if (workerPrediction == null) {
                    NativeImeData predictionData = new NativeImeData(service);
                    workerPrediction = new NativeImePrediction(predictionData, new NativeImeMedia(predictionData));
                }
                if (!settingSnapshot.equals(workerSettings) || !learnedSnapshot.equals(workerLearned) || !kanaSnapshot.equals(workerKana)) {
                    workerPrediction.prepare(new JSONObject(settingSnapshot), kanaSnapshot, new JSONObject(learnedSnapshot));
                    workerSettings = settingSnapshot; workerLearned = learnedSnapshot; workerKana = kanaSnapshot;
                }
                JSONObject result = workerPrediction.predict(suggestedTail);
                main.post(() -> {
                    if (!closed && generation == predictionGeneration && suggestions != null && suggestedTail.equals(tail) && !service.nativeSensitiveEditor()) renderSuggestions(result, suggestedTail);
                });
            } catch (Exception e) {
                main.post(() -> { if (!closed && generation == predictionGeneration && suggestions != null) { suggestions.removeAllViews(); lastRenderedTail = null; } });
            }
        });
    }

    private void renderSuggestions(JSONObject prediction, String suggestedTail) {
        suggestions.removeAllViews();
        currentWord = prediction.optString("currentWord");
        JSONObject math = prediction.optJSONObject("math");
        if (math != null) {
            String result = math.optString("formatted");
            chip("= " + result, () -> {
                if (math.optBoolean("hasTrailingEquals")) insert(" " + result + " ");
                else replaceSuffix(math.optString("rawMatch"), result + " ");
            }, 0x3334d399, 0xff6ee7b7);
        }
        if (!"none".equals(decorator)) chip("جوانکاری ×", () -> { decorator = "none"; updateSuggestions(); }, 0x330ea5e9, 0xff38bdf8);
        JSONObject latest = clipboard.optJSONObject(0);
        if (latest != null && currentWord.isEmpty() && math == null && settings.optBoolean("clipboardEnabled") && settings.optBoolean("clipboardSuggestLatest")
                && (!settings.optBoolean("clipboardSuggestLimit60s") || System.currentTimeMillis() - latest.optLong("timestamp") <= 60000)) {
            TextView clip = chip(ImeClipboardText.preview(latest.optString("text")), () -> insert(latest.optString("text")), light() ? 0xffe2e8f0 : 0xff191b20, textColor());
            clip.setMaxWidth(dp(160));
            clip.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, appearance.px(11));
            clip.setBackground(appearance.background(light() ? 0xffe2e8f0 : 0xff191b20, 14, light() ? 0 : 1, 0x0dffffff));
            clip.setCompoundDrawablesRelativeWithIntrinsicBounds(appearance.icon("ic_clipboards", 0xff38bdf8, 14), null, null, null);
            clip.setCompoundDrawablePadding(dp(4));
        }
        JSONArray items = prediction.optJSONArray("items");
        for (int i = 0; items != null && i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            String value = item.optString("value");
            boolean selected = i == 0 && !currentWord.isEmpty() || item.optBoolean("isEmail") || item.optBoolean("isShortcut");
            Runnable action = () -> { if (suggestedTail.equals(tail)) suggestionTap(item); else updateSuggestions(); };
            int fill = selected ? 0x3320a5e9 : Color.TRANSPARENT;
            int color = selected ? light() ? 0xff075985 : 0xff7dd3fc : light() ? 0xff334155 : 0xffd4d4d8;
            if (item.optBoolean("isEmoji")) {
                LinearLayout emojiChip = row();
                emojiChip.setGravity(Gravity.CENTER_VERTICAL);
                emojiChip.setPadding(dp(10), 0, dp(10), 0);
                emojiChip.setBackground(appearance.background(fill, 8, 0, 0));
                emojiChip.addView(panels.emojiGlyph(value, 18), new LinearLayout.LayoutParams(dp(20), -1));
                String label = item.optString("displayLabel", value);
                if (settings.optBoolean("emojiSuggestionShowName") && label.startsWith(value + " ")) {
                    TextView name = appearance.text(label.substring(value.length()+1), 12, color, font(), 500);
                    name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END); name.setMaxWidth(dp(170));
                    LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-2, -1); nameParams.setMarginStart(dp(4)); emojiChip.addView(name, nameParams);
                }
                emojiChip.setContentDescription(label); clickable(emojiChip, action);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -1); params.setMarginEnd(dp(6)); suggestions.addView(emojiChip, params);
            } else chip(item.optString("displayLabel", value), action, fill, color);
        }
    }

    private TextView chip(String label, Runnable action, int fill, int color) {
        TextView chip = appearance.text(label, 12, color, font(), 500);
        chip.setMaxWidth(dp(210));
        chip.setSingleLine(true);
        chip.setEllipsize(TextUtils.TruncateAt.END);
        chip.setPadding(dp(10), 0, dp(10), 0);
        chip.setBackground(appearance.background(fill, 8, 0, 0));
        clickable(chip, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -1);
        params.setMarginEnd(dp(6));
        suggestions.addView(chip, params);
        return chip;
    }

    private void addHandedRail(LinearLayout target, boolean right) {
        LinearLayout rail = column();
        rail.setGravity(Gravity.CENTER);
        View swap = button(right ? "‹" : "›", () -> settingsPatch(json("oneHandedMode", right ? "left" : "right")));
        swap.setBackground(appearance.background(0x1affffff, 18, 0, 0));
        rail.addView(swap, new LinearLayout.LayoutParams(dp(36), dp(36)));
        View expand = button("⤢", () -> settingsPatch(json("oneHandedMode", "off")));
        expand.setBackground(appearance.background(0x1affffff, 18, 0, 0));
        LinearLayout.LayoutParams expandParams = new LinearLayout.LayoutParams(dp(36), dp(36)); expandParams.topMargin = dp(12);
        rail.addView(expand, expandParams);
        target.addView(rail, new LinearLayout.LayoutParams(dp(48), -1));
    }

    LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(LinearLayout.HORIZONTAL);
        return view;
    }

    LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(LinearLayout.VERTICAL);
        view.setClipChildren(false);
        return view;
    }

    TextView button(String label, Runnable runnable) {
        TextView button = appearance.text(label, 12, textColor(), font(), 600);
        button.setPadding(dp(8), dp(4), dp(8), dp(4));
        button.setMinHeight(dp(30));
        button.setBackground(appearance.background(light() ? 0xffe2e8f0 : 0xff191b20, 9, 0, 0));
        clickable(button, runnable);
        return button;
    }

    private void clickable(View view, Runnable runnable) {
        view.setSoundEffectsEnabled(false);
        view.setFocusable(true);
        view.setOnClickListener(v -> { feedback("special"); runnable.run(); });
    }

    View iconButton(String name, String label, double size, int color, Runnable runnable) {
        Drawable icon = appearance.icon(name, color, size);
        if (icon == null) return button(label, runnable);
        FrameLayout wrapper = new FrameLayout(getContext());
        wrapper.setContentDescription(label);
        ImageView image = new ImageView(getContext());
        image.setImageDrawable(icon);
        wrapper.addView(image, new LayoutParams(icon.getIntrinsicWidth(), icon.getIntrinsicHeight(), Gravity.CENTER));
        clickable(wrapper, runnable);
        return wrapper;
    }

    void keyTap(JSONObject key) {
        dismissChoices();
        String type = key.optString("type");
        switch (type) {
            case "shift":
                feedback("special");
                long now = SystemClock.uptimeMillis();
                if ("capslock_by_cycle".equals(settings.optString("capitalizationBehavior"))) cycleShift();
                else {
                    shift = lastShift > 0 && now - lastShift < 320 ? "caps".equals(shift) ? "off" : "caps" : "off".equals(shift) ? "once" : "off";
                    lastShift = now;
                    render();
                }
                break;
            case "backspace": feedback("backspace"); backspace(false); break;
            case "space": feedback("space"); space(); break;
            case "enter":
                feedback("enter");
                if (!panels.typingEnter()) { learn(currentWord); editor.sendEnter(); }
                break;
            case "characters": case "numeric_advanced": case "phone": case "phone2":
                feedback("special"); mode = type; autoShift(); render(); break;
            case "symbols": feedback("special"); mode = "symbols".equals(mode) ? "characters" : "symbols"; render(); break;
            case "symbols2": case "sym_toggle": feedback("special"); mode = "symbols2".equals(mode) ? "symbols" : "symbols2"; render(); break;
            case "emoji": feedback("special"); openPanel("emoji"); break;
            case "globe": cycleLanguage(1); break;
            case "kana_toggle": feedback("special"); kana = "hira".equals(kana) ? "kata" : "hira"; render(); break;
            case "settings": feedback("special"); editor.openSettings(); break;
            case "copy": feedback("special"); editorAction(android.R.id.copy, editor::copy); break;
            case "cut": feedback("special"); editorAction(android.R.id.cut, editor::cut); break;
            case "paste": feedback("special"); editorAction(android.R.id.paste, editor::paste); break;
            case "select_all": feedback("special"); editorAction(android.R.id.selectAll, editor::selectAll); break;
            case "compact_left": feedback("special"); settingsPatch(json("oneHandedMode", "left".equals(settings.optString("oneHandedMode")) ? "off" : "left")); break;
            case "zwnj": feedback("special"); insert("\u200c"); break;
            default: feedback("char"); character(key.optString("output", key.optString("label")));
        }
    }

    private void cycleShift() {
        shift = "off".equals(shift) ? "once" : "once".equals(shift) ? "caps" : "off";
        render();
    }

    private void cycleLanguage(int delta) {
        JSONArray languages = settings.optJSONArray("enabledLanguages");
        if (languages == null || languages.length() <= 1) return;
        String current = settings.optString("activeLanguage");
        int index = 0;
        while (index < languages.length() && !current.equals(languages.optJSONObject(index).optString("code"))) index++;
        selectLanguage(languages.optJSONObject((index + delta + languages.length()) % languages.length()).optString("code"));
        feedback("special");
    }

    private void selectLanguage(String code) {
        mode = "characters";
        shift = "off";
        settingsPatch(json("activeLanguage", code));
        if (autoShift()) render();
    }

    private void space() {
        if (panels.type(" ")) return;
        learn(currentWord);
        long now = SystemClock.uptimeMillis();
        if (settings.optBoolean("doubleSpacePeriod") && lastSpace > 0 && now - lastSpace < 320 && tail.endsWith(" ") && !tail.endsWith(". ")) {
            replaceSuffix(" ", ". ");
            lastSpace = 0;
            return;
        }
        lastSpace = now;
        insert(" ");
        if (settings.optBoolean("spaceBarSwitchesToCharacters", true) && ("symbols".equals(mode) || "symbols2".equals(mode))) {
            mode = "characters";
            render();
        }
    }

    private void character(String raw) {
        if (raw.isEmpty()) return;
        boolean typeInPanel = panels.type(raw);
        if (!typeInPanel) {
            boolean composed = false;
            if (lang.optString("composerId").contains("hangul-unicode") && "none".equals(decorator) && raw.length() == 1) {
                JSONObject hangul = engine.object("compose", json("tail", tail, "text", raw));
                int count = hangul.optInt("replaceLen");
                if (count > 0 && count <= tail.length()) {
                    replaceSuffix(tail.substring(tail.length() - count), hangul.optString("text"));
                    composed = true;
                }
            }
            if (!composed) {
                String value = raw;
                if (raw.startsWith("@") && raw.contains(".")) {
                    if (tail.endsWith("@")) value = raw.substring(1);
                } else if (!"none".equals(decorator) && !FRAME_DECORATORS.contains(decorator)) {
                    value = engine.text("decorate", json("id", decorator, "text", raw));
                } else if (settings.optBoolean("autoSpacePunctuation") && "none".equals(decorator)
                        && raw.matches("[.,،؟?!;:]") && !(".".equals(raw) && tail.matches("(?s).*(\\d|@[^\\s]*)$"))) {
                    value += " ";
                }
                insert(value);
            }
        }
        if ("once".equals(shift)) { shift = "off"; render(); }
    }

    void insert(String value) {
        if (value.isEmpty()) return;
        if (panels.clipboardPanel.editing()) { panels.clipboardPanel.insertInEdit(value); return; }
        if (panels.insertToolField(value)) return;
        editor.commitText(value);
        if (!service.nativeSensitiveEditor()) {
            setTail(ImeClipboardText.appendTail(tail, value, 240));
            requestSuggestions();
        }
    }

    private void replaceSuffix(String expected, String value) {
        if (expected.isEmpty() || !tail.endsWith(expected) || service.nativeSensitiveEditor()) return;
        editor.replaceVerifiedSuffix(expected, expected.length(), value);
        setTail(tail.substring(0, tail.length() - expected.length()) + value);
        requestSuggestions();
    }

    private void suggestionTap(JSONObject item) {
        feedback("char");
        String value = item.optString("value");
        if (item.optBoolean("isEmail")) {
            java.util.regex.Matcher match = java.util.regex.Pattern.compile("@[a-zA-Z0-9.-]*$").matcher(tail);
            if (match.find()) replaceSuffix(match.group(), value); else insert(value);
        } else if (item.optBoolean("isEmoji")) {
            int length = item.optInt("replaceLength");
            if (length > 0 && length <= tail.length()) replaceSuffix(tail.substring(tail.length() - length), value + " ");
            else insert(" " + value + " ");
            if (settings.optBoolean("emojiSuggestionUpdateHistory", true)) panels.recordRich("emoji", value);
        } else if (currentWord.isEmpty()) insert(value + " ");
        else { learn(value); replaceSuffix(currentWord, value + " "); }
    }

    private void learn(String word) {
        if (service.nativeSensitiveEditor() || !settings.optBoolean("personalDictionaryEnabled") || word.length() < 2 || word.length() > 28 || word.matches("[0-9٠-٩۰-۹]+")) return;
        if (pendingWords.isEmpty()) main.postDelayed(saveWords, 1500);
        Integer pending = pendingWords.get(word);
        pendingWords.put(word, pending == null ? 1 : pending + 1);
        ImeStateStore.mergeLearnedWords(learned, java.util.Collections.singletonMap(word, 1));
        predictionContextDirty = true;
    }

    private void flushLearnedWords() {
        if (pendingWords.isEmpty()) return;
        main.removeCallbacks(saveWords);
        Map<String, Integer> batch = new LinkedHashMap<>(pendingWords);
        pendingWords.clear();
        ImeStateStore.saveLearnedWords(service, batch);
    }

    void backspace(boolean word) {
        if (panels.clipboardPanel.editing()) { panels.clipboardPanel.deleteInEdit(word); return; }
        if (!panels.typingDelete(word)) {
            if (word) editor.deleteWord(); else editor.deleteBackward();
        }
    }

    private void moveToolbarCursor(int direction) {
        if (panels.clipboardPanel.editing()) panels.clipboardPanel.moveCursor(direction, 0, false);
        else if (!panels.moveToolField(direction, 0, false, false)) editor.moveCursor(direction);
    }

    void moveCursor(int x, int y, boolean select) {
        if (panels.clipboardPanel.editing()) panels.clipboardPanel.moveCursor(x, y, select);
        else if (!panels.moveToolField(x, y, select, false)) editor.moveCursorEx(x, y, select);
    }

    private void moveLineEdge(boolean end, boolean select) {
        if (panels.clipboardPanel.editing()) panels.clipboardPanel.moveLineEdge(end, select);
        else if (!panels.moveToolField(end ? 1 : -1, 0, select, true)) editor.moveLineEdge(end, select);
    }

    private void editorAction(int command, Runnable hostAction) {
        if (panels.clipboardPanel.editing()) panels.clipboardPanel.editAction(command);
        else if (!panels.editToolField(command)) hostAction.run();
    }

    boolean swipe(JSONObject key, float dx, float dy, long elapsed) {
        String type = key == null ? "" : key.optString("type");
        if ("backspace".equals(type)) {
            return dx < -28 && Math.abs(dx) > Math.abs(dy) && swipeAction(settings.optString("deleteKeySwipeLeftAction"), null);
        }
        double distance = Math.hypot(dx, dy);
        if ("space".equals(type)) {
            if (distance < 32) return false;
            String action = Math.abs(dx) > Math.abs(dy) ? dx < 0 ? "spaceBarSwipeLeftAction" : "spaceBarSwipeRightAction" : dy < 0 ? "spaceBarSwipeUpAction" : "swipeDownAction";
            return swipeAction(settings.optString(action), null);
        }
        double threshold = Math.max(40, settings.optInt("swipeDistanceThreshold", 48) * 1.15);
        double velocity = distance / Math.max(0.03, elapsed / 1000.0);
        if (distance < threshold || velocity < Math.max(70, settings.optInt("swipeVelocityThreshold", 200) * 0.4) && distance < threshold * 1.55) return false;
        double absX = Math.abs(dx);
        double absY = Math.abs(dy);
        String action;
        if (absX > absY * 1.25) action = dx < 0 ? "swipeLeftAction" : "swipeRightAction";
        else if (absY > absX * 1.25) action = dy < 0 ? "swipeUpAction" : "swipeDownAction";
        else return false;
        swipeAction(settings.optString(action), null);
        return true;
    }

    boolean swipeAction(String action, View anchor) {
        switch (action) {
            case "shift": cycleShift(); break;
            case "hide_keyboard": editor.hideKeyboard(); break;
            case "insert_space": insert(" "); break;
            case "delete_character": case "delete_characters_precisely": backspace(false); break;
            case "delete_word": case "delete_words_precisely": backspace(true); break;
            case "move_cursor_left": moveCursor(-1, 0, false); break;
            case "move_cursor_right": moveCursor(1, 0, false); break;
            case "move_cursor_up": moveCursor(0, -1, false); break;
            case "move_cursor_down": moveCursor(0, 1, false); break;
            case "move_cursor_start_of_line": case "move_cursor_start_of_page": moveLineEdge(false, false); break;
            case "move_cursor_end_of_line": case "move_cursor_end_of_page": moveLineEdge(true, false); break;
            case "select_characters_precisely": moveCursor(-1, 0, true); break;
            case "select_words_precisely": moveLineEdge(false, true); break;
            case "undo": editorAction(android.R.id.undo, editor::undo); break;
            case "redo": editorAction(android.R.id.redo, editor::redo); break;
            case "show_arabic_harakat": showGestureStrip(anchor, "حەرەکاتی عەرەبی", defaults.optJSONArray("harakat")); break;
            case "space_bar_custom_menu": showGestureStrip(anchor, "درێژکردنەوە و نیوبزوێن", defaults.optJSONArray("spaceMenu")); break;
            case "show_subtype_picker": case "show_input_method_picker": languages(anchor); break;
            case "switch_to_next_subtype": cycleLanguage(1); break;
            case "switch_to_prev_subtype": case "switch_to_prev_keyboard": cycleLanguage(-1); break;
            case "switch_to_clipboard_context": openPanel("clipboard"); break;
            case "switch_to_media_context": openPanel("emoji"); break;
            case "switch_to_symbols_keyboard": mode = "symbols".equals(mode) ? "characters" : "symbols"; render(); break;
            case "cycle_to_next_keyboard_mode": case "cycle_to_previous_keyboard_mode":
                int index = java.util.Arrays.asList(MODES).indexOf(mode);
                mode = MODES[(index + (action.contains("next") ? 1 : MODES.length - 1) + MODES.length) % MODES.length];
                render();
                break;
            case "toggle_compact_layout": settingsPatch(json("oneHandedMode", "off".equals(settings.optString("oneHandedMode")) ? "right" : "off")); break;
            case "toggle_smartbar_visibility": settingsPatch(json("showTopToolbar", !settings.optBoolean("showTopToolbar"))); break;
            default: return false;
        }
        feedback("special");
        return true;
    }

    private int surfaceWidth(int percent) {
        int available = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
        return percent == 100 ? -1 : Math.round(available * percent / 100f);
    }

    private static int keyAreaHeight(int configured) {
        return Math.max(110, Math.min(720, configured));
    }

    // Native approximation of the original theme-accent outer shadow. Applied once per render,
    // not on every key press. Older Android releases only support the default shadow color.
    private void applyBackgroundGlow() {
        boolean enabled=settings.optBoolean("dynamicBackgroundGlow");
        surface.setElevation(enabled?dp(8):0);
        if(Build.VERSION.SDK_INT>=28){
            int color=enabled?(accent() & 0x00ffffff)|0xff000000:Color.BLACK;
            surface.setOutlineAmbientShadowColor(color);
            surface.setOutlineSpotShadowColor(color);
        }
    }

    void previewResize(View deck, JSONObject patch) {
        int width = Math.max(72, Math.min(100, patch.optInt("keyboardWidthPercent", settings.optInt("keyboardWidthPercent", 100))));
        int bottom = Math.max(0, Math.min(84, patch.optInt("keyboardBottomOffsetPx", settings.optInt("keyboardBottomOffsetPx", 0))));
        int offset = patch.optInt("keyboardHorizontalOffsetPx", settings.optInt("keyboardHorizontalOffsetPx", 0));
        LayoutParams container = (LayoutParams) surface.getLayoutParams();
        boolean wasFloating = container.width != -1 || container.bottomMargin != 0;
        boolean floating = width < 100 || bottom > 0;
        int nextWidth = surfaceWidth(width), nextMargin = dp(bottom);
        if (container.width != nextWidth || container.bottomMargin != nextMargin) {
            container.width = nextWidth;
            container.bottomMargin = nextMargin;
            surface.setLayoutParams(container);
        }
        if (floating != wasFloating) {
            setBackgroundColor(floating ? light() ? 0xffe2e8f0 : 0xff050608 : bg());
            surface.setBackground(appearance.background(bg(), floating ? 16 : 0, 0, 0));
        }
        surface.setTranslationX(width == 100 ? 0 : dp(Math.max(-60, Math.min(60, offset))));
        int height = dp(additionalDeckHeightDp + keyAreaHeight(patch.optInt("keyboardHeightPx",
                settings.optInt("keyboardHeightPx", 248))));
        android.view.ViewGroup.LayoutParams params = deck.getLayoutParams();
        if (params.height != height) {
            params.height = height;
            deck.setLayoutParams(params);
        }
    }

    void beginResize() {
        if (!"keys".equals(panel)) panels.panelChanged("keys");
        panel = "keys";
        inlineResize = true;
        render();
    }

    void resetResize() {
        settingsPatch(json("keyboardHeightPx", 248, "keyboardWidthPercent", 100, "keyboardBottomOffsetPx", 0,
                "keyboardHorizontalOffsetPx", 0, "oneHandedMode", "off"));
    }

    void resizeDragFinished(NativeImeResizeFrame frame, JSONObject patch) {
        if (resizeFrame != frame) return;
        if (patch != null && patch.length() > 0) settingsPatch(patch);
        if (resizeFrame != frame) return;
        if (renderAfterResize) render();
        else frame.restorePreview();
    }

    void finishResize() { inlineResize = false; render(); }

    void keyPreview(View anchor, JSONObject key) {
        String type = key.optString("type");
        if (!"char".equals(type) && !"comma".equals(type) && !"period".equals(type)) return;
        String label = key.optString("label");
        if (label.isEmpty()) return;
        if (settings.optBoolean("flyingLettersEnabled")) {
            if (lowMemoryDevice == null) lowMemoryDevice = editor.isLowMemoryDevice();
            if (!lowMemoryDevice) flyLetter(anchor, label);
        }
        if (!settings.optBoolean("keyPopupPreview") || !isAttachedToWindow()) return;
        dismissPreview();
        int width = Math.max(dp(45), anchor.getWidth());
        int height = dp(44);
        getLocationOnScreen(previewOrigin);
        anchor.getLocationOnScreen(previewAnchor);
        if (previewBubble == null) {
            previewBubble = newPreviewBubble(label);
            previewBubble.setElevation(dp(5));
            getOverlay().add(previewBubble);
        }
        previewBubble.setText(label);
        previewBubble.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
        int left = Math.max(0, Math.min(getWidth() - width,
                previewAnchor[0] - previewOrigin[0] + (anchor.getWidth() - width) / 2));
        int top = Math.max(0, previewAnchor[1] - previewOrigin[1] - height - dp(3));
        previewBubble.layout(left, top, left + width, top + height);
        previewBubble.setVisibility(View.VISIBLE);
    }

    private TextView newPreviewBubble(String label) {
        TextView bubble = appearance.text(label, 24, textColor(), font(), 600);
        bubble.setBackground(appearance.background(appearance.color(theme, "popupBg", keyColor()), 12, 1,
                appearance.color(theme, "popupBorder", 0x662990ff)));
        return bubble;
    }

    private void flyLetter(View anchor, String label) {
        if (flyingLetters.size() >= 4) discardLetter(flyingLetters.removeFirst());
        TextView letter = appearance.text(label, Math.round(22 * settings.optInt("flyingLettersSizeMultiplier", 90) / 100f), accent(), font(), 800);
        int[] origin = new int[2];
        int[] key = new int[2];
        getLocationOnScreen(origin);
        anchor.getLocationOnScreen(key);
        LayoutParams position = new LayoutParams(dp(44), dp(32), Gravity.TOP | Gravity.LEFT);
        position.leftMargin = key[0] - origin[0] + (anchor.getWidth() - dp(44)) / 2;
        position.topMargin = key[1] - origin[1] - dp(8);
        if(surface!=null)letter.setTranslationZ(surface.getElevation());
        addView(letter, position);
        flyingLetters.addLast(letter);
        letter.setAlpha(0.96f);
        letter.setScaleX(0.88f);
        letter.setScaleY(0.88f);
        letter.animate().translationY(-dp(26)).alpha(1).scaleX(1.16f).scaleY(1.16f).setDuration(172).withEndAction(() ->
                letter.animate().translationY(-dp(56)).alpha(0).scaleX(0.95f).scaleY(0.95f).setDuration(258).withEndAction(() -> {
                    flyingLetters.remove(letter);
                    removeView(letter);
                }).start()).start();
    }

    private void clearFlyingLetters() {
        while (!flyingLetters.isEmpty()) discardLetter(flyingLetters.removeFirst());
    }

    private void discardLetter(TextView letter) {
        letter.animate().cancel();
        removeView(letter);
    }

    void dismissPreview() {
        if (previewBubble != null) previewBubble.setVisibility(View.INVISIBLE);
    }

    boolean keyHold(View anchor, JSONObject key) {
        switch (key.optString("type")) {
            case "space": return swipeAction(settings.optString("spaceBarLongPressAction"), anchor);
            case "globe":
                if (settings.optBoolean("showLanguagePickerOnLongPress")) { languages(anchor); feedback("special"); return true; }
                return false;
            case "emoji": beginResize(); feedback("special"); return true;
            case "backspace": return false;
            case "enter": {
                JSONArray editOpts = new JSONArray();
                editOpts.put(json("label", "هەمووی", "value", "__select_all__"));
                editOpts.put(json("label", "کۆپیکردن", "value", "__copy__"));
                editOpts.put(json("label", "بڕین", "value", "__cut__"));
                editOpts.put(json("label", "لکاندن", "value", "__paste__"));
                showKeyAlternates(anchor, editOpts);
                feedback("special");
                return true;
            }
            default: break;
        }
        JSONArray variants = key.optJSONArray("alts");
        if (variants == null || variants.length() == 0) {
            String secondary = key.optString("secondary");
            if (secondary.isEmpty()) return false;
            variants = new JSONArray().put(secondary);
        }
        JSONArray options = new JSONArray();
        Set<String> seen = new HashSet<>();
        boolean email = false;
        for (int i = 0; i < variants.length(); i++) {
            Object raw = variants.opt(i);
            JSONObject item = raw instanceof JSONObject ? (JSONObject) raw : json("label", raw, "value", raw);
            String value = item.optString("value");
            if (!value.isEmpty() && seen.add(item.optString("label") + '\n' + value)) {
                options.put(item);
                email |= value.startsWith("@") && value.contains(".");
            }
        }
        if (email) showChoices(anchor, options, true, true, this::character);
        else showKeyAlternates(anchor, options);
        return options.length() > 0;
    }

    private void languages(View anchor) {
        JSONArray options = new JSONArray();
        JSONArray entries = settings.optJSONArray("enabledLanguages");
        for (int i = 0; entries != null && i < entries.length(); i++) {
            JSONObject lang = entries.optJSONObject(i);
            options.put(json("label", lang.optString("nativeName"), "value", lang.optString("code")));
        }
        showChoices(anchor, options, false, true, this::selectLanguage);
    }

    interface StringAction { void accept(String value); }

    private static String alternateLabel(JSONObject option) {
        String value = NativeImeData.trim(option.optString("value"));
        int code = option.optInt("code");
        if ((code == -255 || code == -1001) && !value.isEmpty() && value.length() <= 28) return value;
        return NativeImeData.trim(option.optString("label"));
    }

    private void showKeyAlternates(View anchor, JSONArray options) {
        if (options.length() == 0 || !isAttachedToWindow()) return;
        dismissPreview();
        dismissChoices();
        choiceOptions = options;
        choiceAnchor = anchor;
        choiceFollowsPointer = true;
        choiceIndex = 0;
        int longestLabel = 0;
        boolean phrase = false;
        for (int i = 0; i < options.length(); i++) {
            JSONObject option = options.optJSONObject(i);
            int code = option.optInt("code");
            phrase |= code == -255 || code == -1001 || NativeImeData.trim(option.optString("label")).length() > 2
                    || NativeImeData.trim(option.optString("value")).length() > 2;
            longestLabel = Math.max(longestLabel, alternateLabel(option).length());
        }

        int padding = dp(6), gap = dp(phrase ? 6 : 4);
        int usable = Math.max(1, getWidth() - dp(12));
        int contentWidth = Math.max(1, usable - padding * 2);
        int itemWidth = phrase
                ? Math.min(contentWidth, dp(Math.max(196, Math.min(272, longestLabel * 9.5 + 48))) - padding * 2)
                : Math.min(contentWidth, dp(42));
        int columns = phrase ? 1 : Math.max(1, Math.min(6, (contentWidth + gap) / (itemWidth + gap)));
        columns = Math.min(columns, options.length());
        int rows = (options.length() + columns - 1) / columns;
        int itemHeight = dp(phrase ? 48 : 44);
        int width = itemWidth * columns + gap * (columns - 1) + padding * 2;
        int height = rows * itemHeight + gap * (rows - 1) + padding * 2;
        int popupHeight = Math.min(height, Math.min(getHeight(), dp(232)));
        int popupBg = appearance.color(theme, "popupBg", light() ? Color.WHITE : 0xff20222a);
        int popupBorder = appearance.color(theme, "popupBorder", light() ? 0x240f172a : 0x1fffffff);
        choiceItems = column();
        choiceItems.setPadding(padding, padding, padding, padding);
        for (int i = 0; i < options.length(); i++) {
            JSONObject option = options.optJSONObject(i);
            TextView item = appearance.text(alternateLabel(option), phrase ? 15 : 18, Color.WHITE, font(), 700);
            item.setSingleLine(true);
            item.setEllipsize(TextUtils.TruncateAt.END);
            item.setPadding(dp(phrase ? 12 : 4), 0, dp(phrase ? 12 : 4), 0);
            item.setFocusable(true);
            item.setSoundEffectsEnabled(false);
            item.setOnClickListener(view -> {
                dismissChoices();
                commitAlternateValue(option.optString("value"));
            });
            keyAlternateButtons.add(item);
        }
        for (int r = 0; r < rows; r++) {
            LinearLayout line = row();
            line.setGravity(Gravity.CENTER_HORIZONTAL);
            line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout.LayoutParams rowPosition = new LinearLayout.LayoutParams(-1, itemHeight);
            if (r != 0) rowPosition.topMargin = gap;
            choiceItems.addView(line, rowPosition);
            int first = phrase ? rows - r - 1 : r * columns;
            for (int i = first; i < Math.min(first + columns, options.length()); i++) {
                LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(itemWidth, -1);
                if (i != first) cell.setMarginStart(gap);
                line.addView(keyAlternateButtons.get(i), cell);
            }
        }

        choice = choiceItems;
        if (height > popupHeight) {
            android.widget.ScrollView scroll = new android.widget.ScrollView(getContext());
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(choiceItems);
            choice = scroll;
            if (phrase) scroll.post(() -> scroll.scrollTo(0, choiceItems == null ? 0 : height));
        }
        choice.setBackground(appearance.background(popupBg, 16, 1, popupBorder));
        choice.setElevation(dp(8));
        markAlternate();
        getLocationOnScreen(previewOrigin);
        anchor.getLocationOnScreen(previewAnchor);
        choiceStem = new View(getContext());
        choiceStem.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        choiceStem.setBackground(appearance.background(popupBg, 12, 1, popupBorder));
        LayoutParams stemPosition = new LayoutParams(anchor.getWidth(), anchor.getHeight(), Gravity.TOP | Gravity.LEFT);
        stemPosition.leftMargin = previewAnchor[0] - previewOrigin[0];
        stemPosition.topMargin = previewAnchor[1] - previewOrigin[1];
        if(surface!=null)choiceStem.setTranslationZ(surface.getElevation());
        addView(choiceStem, stemPosition);
        positionChoices(anchor, width, popupHeight, dp(6));
    }

    /** The original gesture menu is a scrollable RTL strip, not a row of equal-width keys. */
    private void showGestureStrip(View anchor, String title, JSONArray options) {
        if (options == null || options.length() == 0 || !isAttachedToWindow()) return;
        dismissPreview();
        dismissChoices();
        // Use the deck's width even when the keyboard is in one-handed mode.
        View deck = grid != null && grid.getWidth() > 0 ? grid : this;
        int inset = dp(6);
        int width = Math.max(1, deck.getWidth() - inset * 2);
        int padding = dp(6);
        int textTint = light() ? 0xff0f172a : Color.WHITE;
        int popupBg = appearance.color(theme, "popupBg", light() ? Color.WHITE : 0xff20222a);
        int popupBorder = appearance.color(theme, "popupBorder", light() ? 0x240f172a : 0x29ffffff);

        LinearLayout menu = column();
        menu.setPadding(padding, padding, padding, padding);
        menu.setBackground(appearance.background(popupBg, 16, 1, popupBorder));
        menu.setElevation(dp(8));
        menu.setClickable(true);
        menu.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout header = row();
        header.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView close = appearance.text("×", 21, textTint, "system", 700);
        close.setContentDescription("داخستن");
        close.setBackground(appearance.background(light() ? 0xffe2e8f0 : 0x1affffff, 16, 0, 0));
        clickable(close, this::dismissChoices);
        header.addView(close, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView heading = appearance.text(title, 13, light() ? 0xff075985 : 0xff7dd3fc, "system", 700);
        heading.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        heading.setSingleLine(true);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        heading.setPadding(dp(5), 0, dp(5), 0);
        header.addView(heading, new LinearLayout.LayoutParams(0, -1, 1));
        TextView scrollHint = appearance.text("↔", 16, textTint, "system", 600);
        scrollHint.setContentDescription("ڕاکێشان بۆ چەپ و ڕاست");
        header.addView(scrollHint, new LinearLayout.LayoutParams(dp(25), -1));
        menu.addView(header, new LinearLayout.LayoutParams(-1, dp(32)));

        HorizontalScrollView scroll = new HorizontalScrollView(getContext());
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.setFillViewport(false);
        scroll.setHorizontalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        LinearLayout strip = row();
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(0, dp(3), 0, dp(4));
        for (int i = 0; i < options.length(); i++) {
            JSONObject option = options.optJSONObject(i);
            if (option == null) continue;
            String label = option.optString("label");
            String value = option.optString("value");
            if (label.isEmpty() || value.isEmpty()) continue;
            // A fallback system font supports the Arabic combining marks. Font padding
            // leaves room above and below the baseline for shadda, fatha, kasra, etc.
            TextView item = appearance.text(label, 16, textTint, "system", 700);
            item.setIncludeFontPadding(true);
            item.setSingleLine(true);
            item.setPadding(dp(12), dp(5), dp(12), dp(5));
            item.setMinWidth(dp(44));
            item.setBackground(appearance.background(keyColor(), 10, 1, popupBorder));
            item.setFocusable(true);
            item.setSoundEffectsEnabled(false);
            item.setOnClickListener(v -> {
                dismissChoices();
                feedback("char");
                character(value);
            });
            LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(-2, dp(44));
            if (i > 0) cell.setMarginStart(dp(6));
            strip.addView(item, cell);
        }
        scroll.addView(strip, new FrameLayout.LayoutParams(-2, -1));
        menu.addView(scroll, new LinearLayout.LayoutParams(-1, dp(51)));
        choice = menu;
        // Stay open after the held space key is released; only a tap commits a value.
        choiceFollowsPointer = false;
        int height = dp(83) + padding * 2;
        getLocationOnScreen(previewOrigin);
        deck.getLocationOnScreen(previewAnchor);
        LayoutParams position = new LayoutParams(width, height, Gravity.TOP | Gravity.LEFT);
        position.leftMargin = Math.max(0, Math.min(getWidth() - width, previewAnchor[0] - previewOrigin[0] + inset));
        position.topMargin = Math.max(0, Math.min(getHeight() - height,
                previewAnchor[1] - previewOrigin[1] - height - dp(3)));
        if (surface != null) menu.setTranslationZ(surface.getElevation());
        addView(menu, position);
        // Start at the right edge so the first original option is visible in RTL.
        scroll.post(() -> {
            if (choice == menu) scroll.scrollTo(Math.max(0, strip.getWidth() - scroll.getWidth()), 0);
        });
    }

    private void showChoices(View anchor, JSONArray options, boolean slide, boolean vertical, StringAction action) {
        if (options == null || options.length() == 0 || !isAttachedToWindow()) return;
        dismissPreview();
        dismissChoices();
        choiceOptions = options;
        choiceFollowsPointer = slide;
        emailAlternates = slide && vertical;
        choiceIndex = emailAlternates ? -1 : 0;
        choiceItems = vertical ? column() : row();
        choiceItems.setPadding(dp(4), dp(4), dp(4), dp(4));
        choiceItems.setBackground(appearance.background(appearance.color(theme, "popupBg", 0xff15181f), 12, 1, appearance.color(theme, "popupBorder", 0x33ffffff)));
        int available = Math.max(1, getWidth() - dp(12));
        int each = Math.max(1, Math.min(dp(42), available / options.length()));
        int itemWidth = vertical ? Math.min(dp(162), available) : each;
        for (int i = 0; i < options.length(); i++) {
            JSONObject option = options.optJSONObject(i);
            TextView item = button(option.optString("label"), () -> { dismissChoices(); action.accept(option.optString("value")); });
            choiceItems.addView(item, new LinearLayout.LayoutParams(itemWidth, dp(38)));
        }
        View popupContent = choiceItems;
        if (vertical) {
            android.widget.ScrollView scroll = new android.widget.ScrollView(getContext());
            scroll.addView(choiceItems);
            popupContent = scroll;
        }
        markAlternate();
        choice = popupContent;
        choice.setElevation(dp(5));
        int width = (vertical ? itemWidth : each * options.length()) + dp(8);
        int height = Math.min(getHeight(), Math.min(dp(232), dp((vertical ? 38 * options.length() : 38) + 8)));
        positionChoices(anchor, width, height, 0);
    }

    private void positionChoices(View anchor, int width, int height, int inset) {
        LayoutParams position = new LayoutParams(width, height, Gravity.TOP | Gravity.LEFT);
        if (anchor == null || anchor == this) {
            position.leftMargin = Math.max(0, (getWidth() - width) / 2);
            position.topMargin = Math.max(0, (getHeight() - height) / 2);
        } else {
            // Measure both views in the same coordinates. Placement is local to the IME.
            getLocationOnScreen(previewOrigin);
            anchor.getLocationOnScreen(previewAnchor);
            position.leftMargin = Math.max(inset, Math.min(getWidth() - width - inset,
                    previewAnchor[0] - previewOrigin[0] + (anchor.getWidth() - width) / 2));
            position.topMargin = Math.max(0, previewAnchor[1] - previewOrigin[1] - height - dp(3));
        }
        if(surface!=null)choice.setTranslationZ(surface.getElevation());
        addView(choice, position);
    }

    boolean hasAlternates() { return choice != null && choiceFollowsPointer; }

    boolean slidePopup(View root, float x, float y) {
        if (!hasAlternates()) return false;
        int[] origin = new int[2];
        int[] menu = new int[2];
        root.getLocationOnScreen(origin);
        if (!keyAlternateButtons.isEmpty()) {
            selectKeyAlternate(x + origin[0], y + origin[1], menu);
            return true;
        }
        choiceItems.getLocationOnScreen(menu);
        x += origin[0] - menu[0];
        y += origin[1] - menu[1];
        for (int i = 0; i < choiceItems.getChildCount(); i++) {
            View view = choiceItems.getChildAt(i);
            if (x >= view.getLeft() && x < view.getRight() && (!emailAlternates || y >= view.getTop() && y < view.getBottom())) {
                choiceIndex = i;
                markAlternate();
                break;
            }
        }
        return true;
    }

    private void selectKeyAlternate(float x, float y, int[] position) {
        int selected = -1;
        double closest = dp(68) + 1;
        choice.getLocationOnScreen(position);
        int visibleTop = position[1], visibleBottom = visibleTop + choice.getHeight();
        for (int i = 0; i < keyAlternateButtons.size(); i++) {
            TextView item = keyAlternateButtons.get(i);
            if (item.getWidth() == 0) continue;
            item.getLocationOnScreen(position);
            int top = Math.max(visibleTop, position[1]), bottom = Math.min(visibleBottom, position[1] + item.getHeight());
            if (top >= bottom) continue;
            float dx = Math.max(0, Math.max(position[0] - x, x - position[0] - item.getWidth()));
            float dy = Math.max(0, Math.max(top - y, y - bottom));
            double distance = Math.hypot(dx, dy);
            if (distance < closest) { closest = distance; selected = i; }
        }
        if (selected < 0 && choiceAnchor != null) {
            choiceAnchor.getLocationOnScreen(position);
            float dx = Math.max(0, Math.max(position[0] - x, x - position[0] - choiceAnchor.getWidth()));
            float dy = Math.max(0, Math.max(position[1] - y, y - position[1] - choiceAnchor.getHeight()));
            if (Math.hypot(dx, dy) <= dp(44)) selected = 0;
        }
        if (choiceIndex != selected) {
            choiceIndex = selected;
            markAlternate();
        }
    }

    private void markAlternate() {
        if (!keyAlternateButtons.isEmpty()) {
            for (int i = 0; i < keyAlternateButtons.size(); i++) {
                TextView item = keyAlternateButtons.get(i);
                boolean selected = i == choiceIndex;
                item.setTextColor(selected ? 0xff111318 : light() ? 0xff0f172a : Color.WHITE);
                item.setBackground(selected ? appearance.background(0xffff6d00, 12, 0, 0) : null);
                item.setSelected(selected);
            }
            return;
        }
        for (int i = 0; i < choiceItems.getChildCount(); i++) {
            choiceItems.getChildAt(i).setBackground(appearance.background(i == choiceIndex ? accent() : keyColor(), 7, 0, 0));
        }
    }

    boolean releaseAlternates() {
        if (!hasAlternates()) return false;
        if (choiceIndex < 0 && emailAlternates) { choiceFollowsPointer = false; return true; }
        String value = choiceIndex >= 0 ? choiceOptions.optJSONObject(choiceIndex).optString("value") : "";
        dismissChoices();
        if (!value.isEmpty()) commitAlternateValue(value);
        return true;
    }

    private void commitAlternateValue(String value) {
        if (value == null || value.isEmpty()) return;
        if ("__select_all__".equals(value)) {
            feedback("special");
            editorAction(android.R.id.selectAll, editor::selectAll);
        } else if ("__copy__".equals(value)) {
            feedback("special");
            editorAction(android.R.id.copy, editor::copy);
        } else if ("__cut__".equals(value)) {
            feedback("special");
            editorAction(android.R.id.cut, editor::cut);
        } else if ("__paste__".equals(value)) {
            feedback("special");
            editorAction(android.R.id.paste, editor::paste);
        } else {
            feedback("char");
            character(value);
        }
    }

    private void dismissChoices() {
        if (choice != null) { removeView(choice); choice = null; }
        if (choiceStem != null) { removeView(choiceStem); choiceStem = null; }
        keyAlternateButtons.clear();
        choiceAnchor = null;
        choiceFollowsPointer = false;
        emailAlternates = false;
        choiceIndex = -1;
        choiceItems = null;
        choiceOptions = null;
    }

    void cancelAlternates() { if (choiceFollowsPointer) dismissChoices(); }

    void toggleVoice() {
        if ("recording".equals(voiceState)) { editor.stopOfflineVoice(); return; }
        if (listening) { editor.cancelOfflineVoice(); return; }
        String language = settings.optString("activeLanguage");
        if (!"keys".equals(panel)) openPanel("keys");
        if ("en".equals(language) || "ar".equals(language)) editor.startNativeVoice("ar".equals(language) ? "ar-IQ" : "en-US");
        else if ("ckb".equals(language) || "ku".equals(language)) editor.startOfflineVoice();
        else {
            voiceState = "unsupported";
            voiceNotice = "گەڕانی دەنگی لەم وێبگەڕەدا پشتگیری ناکرێت.";
            removeCallbacks(clearVoiceNotice);
            postDelayed(clearVoiceNotice, 3000);
            render();
        }
    }

    void voiceChanged(String state, String detail) {
        voiceState = state;
        removeCallbacks(clearVoiceNotice);
        listening = java.util.Arrays.asList("connecting", "starting", "recording", "transcribing").contains(state);
        switch (state) {
            case "connecting": voiceNotice = "پەیوەندی بە مۆدێلی دەنگەوە دەکرێت..."; break;
            case "starting": voiceNotice = "دەنگ تۆمار دەکرێت..."; break;
            case "recording": voiceNotice = "گوێ دەگرێت..."; break;
            case "transcribing": voiceNotice = "دەنگ دەگۆڕدرێت بۆ نووسین..."; break;
            case "permission": voiceNotice = "مۆڵەتی مایکرۆفۆن پێویستە"; break;
            case "model_missing": voiceNotice = "مۆدێلی دەنگ لە Manga دابگرە"; break;
            case "app_missing": voiceNotice = "Manga Translator دابمەزرێنە"; break;
            case "error": voiceNotice = "نووسینی دەنگی سەرکەوتوو نەبوو"; break;
            default: voiceNotice = "";
        }
        if (!listening && !"permission".equals(state) && !voiceNotice.isEmpty()) postDelayed(clearVoiceNotice, 4600);
        render();
    }

    void vibrate(int ms) {
        if (!settings.optBoolean("vibrationEnabled")) return;
        Vibrator vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        }
    }

    void feedback(String type) {
        int ms = Math.max(6, Math.min(60, settings.optInt("vibrationDurationMs", 16)));
        if ("enter".equals(type) || "backspace".equals(type)) ms = Math.min(65, Math.round(ms * 1.35f));
        vibrate(ms);
        if (!settings.optBoolean("soundEnabled")) return;
        String pack = settings.optString("soundPack");
        String category = "space".equals(type) ? "space" : "backspace".equals(type) ? "delete" : "standard";
        String file = "";
        JSONArray files = defaults.optJSONArray("sounds");
        for (int i = 0; files != null && i < files.length(); i++) {
            JSONObject sound = files.optJSONObject(i);
            if (pack.equals(sound.optString("id")) && sound.optJSONObject("files") != null) file = sound.optJSONObject("files").optString(category);
        }
        if (file.isEmpty()) file = "/native-ime/" + type + ".wav";
        else file = "/public" + file;
        float volume = (float) Math.max(0, Math.min(1, settings.optDouble("soundVolume", 0.75)));
        if (sounds == null) {
            sounds = new SoundPool.Builder().setMaxStreams(3).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build()).build();
            sounds.setOnLoadCompleteListener((pool, id, status) -> { if (status == 0) loadedSamples.add(id); });
        }
        Integer id = samples.get(file);
        if (id == null) {
            try (android.content.res.AssetFileDescriptor fd = getContext().getAssets().openFd(file.substring(1))) {
                samples.put(file, sounds.load(fd, 1));
            } catch (IOException ignored) { }
        } else if (loadedSamples.contains(id)) {
            sounds.play(id, volume, volume, 1, 0, 1);
        }
    }

    @Override public void close() {
        if (closed) return;
        endSession();
        closed = true;
        predictionWorker.shutdownNow();
        removeCallbacks(clearVoiceNotice);
        if (previewBubble != null) getOverlay().remove(previewBubble);
        if (observed != null) observed.unregisterOnSharedPreferenceChangeListener(observer);
        if (sounds != null) sounds.release();
        panels.close();
        engine.close();
    }
}
