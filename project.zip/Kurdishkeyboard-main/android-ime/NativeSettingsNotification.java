package io.kurdikebord.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class NativeSettingsNotification {
    private NativeSettingsNotification() {}

    static View create(Context context, NativeImeAppearance appearance, String font,
                       NativeClipboardSettingsView.Change change) {
        LinearLayout banner = new LinearLayout(context);
        banner.setOrientation(LinearLayout.VERTICAL);
        int padding = appearance.dp(20);
        banner.setPadding(padding, padding, padding, padding);
        banner.setBackground(appearance.background(0xffb71c1c, 24, 0, 0));
        TextView title = appearance.text("ئاگادارکردنەوە کوژاوەتەوە", 18, 0xffffffff, font, 800);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        banner.addView(title);
        TextView detail = appearance.text("ئاگادارکردنەوەکان کارا بکە بۆ وەرگرتنی زانیاری لەکاتی بڵاوکردنەوەی ڕووکار، فۆنت و وەشانی نوێی بەرنامەکە!",
                12, 0xffffebee, font, 400);
        detail.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams detailPosition = new LinearLayout.LayoutParams(-1, -2);
        detailPosition.topMargin = appearance.dp(10);
        banner.addView(detail, detailPosition);
        TextView enable = appearance.text("کاراکردن", 14, 0xffffffff, font, 700);
        enable.setMinHeight(appearance.dp(44));
        enable.setBackground(appearance.background(0x33ffffff, 12, 1, 0x40ffffff));
        enable.setOnClickListener(v -> {
            banner.setVisibility(View.GONE);
            change.accept("notificationsEnabled", true);
        });
        LinearLayout.LayoutParams buttonPosition = new LinearLayout.LayoutParams(-1, -2);
        buttonPosition.topMargin = appearance.dp(10);
        banner.addView(enable, buttonPosition);
        return banner;
    }
}
