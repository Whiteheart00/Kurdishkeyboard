package io.kurdikebord.app;

import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.Arrays;

/** OS-scheduled daily backups; no work on the keyboard/UI thread. */
public final class NativeFirebaseBackupJob extends JobService {
    private volatile JobParameters current;
    @Override public boolean onStartJob(JobParameters params){
        current=params;
        NativeFirebaseBackup.WORK.execute(()->{char[] pass=null;try{
            if(current!=params||!ImeStateStore.unlocked(this)||ImeStateStore.incognito(this)||!NativeFirebaseBackup.automatic(this))return;
            String uid=NativeFirebaseBackup.uid(this);pass=NativeFirebaseBackup.unwrap(this,uid);
            if(current==params)NativeFirebaseBackup.upload(this,uid,pass,NativeFirebaseBackup.prefs(this).getInt("mask",NativeFirebaseBackup.BASIC),true);
        }catch(Exception ignored){/* Next periodic job can retry; never log credentials or text. */}finally{if(pass!=null)Arrays.fill(pass,'\0');if(current==params){current=null;jobFinished(params,false);}}});return true;
    }
    @Override public boolean onStopJob(JobParameters params){if(current==params)current=null;return true;}
}
