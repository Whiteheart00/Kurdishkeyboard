package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;

import org.json.JSONObject;

final class NativeImeHangul {
    private static final String INITIAL = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";
    private static final String VOWEL = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ";
    private static final String TRAILING = "\0ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ";
    private static final String COMPOUND_VOWELS = "ㅗㅏㅘㅗㅐㅙㅗㅣㅚㅜㅓㅝㅜㅔㅞㅜㅣㅟㅡㅣㅢ";
    private static final String COMPOUND_TRAILING = "ㄱㅅㄳㄴㅈㄵㄴㅎㄶㄹㄱㄺㄹㅁㄻㄹㅂㄼㄹㅅㄽㄹㅌㄾㄹㅍㄿㄹㅎㅀㅂㅅㅄ";

    private NativeImeHangul() {}

    static JSONObject compose(String tail, String text) {
        if (tail.isEmpty() || text.length() != 1) return replacement(0, text);
        char last = tail.charAt(tail.length() - 1), added = text.charAt(0);
        int vowel = VOWEL.indexOf(added), initial = INITIAL.indexOf(last);
        if (vowel >= 0 && initial >= 0) return replacement(1, syllable(initial, vowel, 0));
        if (last < 0xac00 || last > 0xd7a3) return replacement(0, text);
        int index = last - 0xac00, c = index / 588, v = index % 588 / 28, t = index % 28;
        if (vowel >= 0) {
            if (t == 0) {
                int combined = VOWEL.indexOf(compound(COMPOUND_VOWELS, VOWEL.charAt(v), added));
                if (combined >= 0) return replacement(1, syllable(c, combined, 0));
            } else {
                int next = INITIAL.indexOf(TRAILING.charAt(t));
                if (next >= 0) return replacement(1, syllable(c, v, 0) + syllable(next, vowel, 0));
            }
        }
        if (INITIAL.indexOf(added) >= 0) {
            int trailing = t == 0 ? TRAILING.indexOf(added) : TRAILING.indexOf(compound(COMPOUND_TRAILING, TRAILING.charAt(t), added));
            if (trailing > 0) return replacement(1, syllable(c, v, trailing));
        }
        return replacement(0, text);
    }

    private static char compound(String table, char first, char second) {
        for (int i = 0; i < table.length(); i += 3) {
            if (first == table.charAt(i) && second == table.charAt(i + 1)) return table.charAt(i + 2);
        }
        return 0;
    }

    private static String syllable(int initial, int vowel, int trailing) {
        return String.valueOf((char) (0xac00 + initial * 588 + vowel * 28 + trailing));
    }

    private static JSONObject replacement(int length, String text) { return json("replaceLen", length, "text", text); }
}
