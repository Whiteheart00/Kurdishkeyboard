package io.kurdikebord.app;

/** Main-thread state for a single outstanding editor context read. */
final class ImeTailRequests {
    private long revision;
    private boolean reading;
    private boolean waiting;

    void invalidate() {
        revision++;
        waiting = false;
    }

    long revision() { return revision; }

    boolean begin() {
        if (reading) {
            waiting = true;
            return false;
        }
        reading = true;
        waiting = false;
        return true;
    }

    boolean finish(long startedRevision) {
        reading = false;
        return revision == startedRevision;
    }

    boolean hasWaitingRead() { return waiting; }
}
