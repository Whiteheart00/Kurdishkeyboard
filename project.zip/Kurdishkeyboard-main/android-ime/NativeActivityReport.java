package io.kurdikebord.app;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** Text report format shared with the original settings screen. */
final class NativeActivityReport {
    private static final String LINE = "----------------------------------------";
    private static final String RULE = "========================================";
    private static String readable(Date date) { return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(date); }
    private static String value(JSONObject e,String key) {return e.isNull(key)?"":e.optString(key,"");}
    private static void optional(StringBuilder b,JSONObject e,String label,String key) {String v=value(e,key);if(!v.isEmpty())b.append(label).append(v).append('\n');}
    static String format(List<JSONObject> events,String scope,boolean single,String version,String platform,String os,Date generated) {
        List<JSONObject> sorted=new ArrayList<>(events);
        java.util.Collections.sort(sorted,(left,right)->Long.compare(left.optLong("epochMs"),right.optLong("epochMs")));
        if(single && sorted.size()==1){JSONObject e=sorted.get(0);version=e.optString("appVersion",version);platform=e.optString("platform",platform);os=e.optString("osVersion",os);}
        StringBuilder b=new StringBuilder(RULE).append("\nAPPLICATION ACTIVITY REPORT\n").append(RULE)
                .append("\nApplication: تەختەکلیلی کوردی — KurdiKeyboard\nVersion: ").append(version)
                .append("\nPlatform: ").append(platform).append(" / ").append(os)
                .append("\nGenerated: ").append(readable(generated)).append("\nTotal Events: ").append(sorted.size()).append('\n');
        if(scope!=null&&!scope.isEmpty())b.append("Filter: ").append(scope).append('\n');
        b.append(LINE).append('\n');
        for(int i=0;i<sorted.size();i++){
            JSONObject e=sorted.get(i);
            b.append(String.format(Locale.US,"EVENT %03d\n",i+1));
            for(String[] f:new String[][]{{"Event ID: ","id"},{"Category: ","category"},{"Severity: ","severity"},{"Event: ","title"}})b.append(f[0]).append(value(e,f[1])).append('\n');
            String iso=value(e,"timestamp");long epoch=e.optLong("epochMs",0);
            b.append("Time: ").append(epoch>0?readable(new Date(epoch)):iso).append(" (").append(iso).append(")\n");
            for(String[] f:new String[][]{{"Component: ","component"},{"Operation: ","operation"},{"Status: ","status"}})b.append(f[0]).append(value(e,f[1])).append('\n');
            optional(b,e,"Operation ID: ","operationId");optional(b,e,"Related Event ID: ","relatedEventId");
            if(e.opt("httpStatus") instanceof Number)b.append("HTTP Status: ").append(e.opt("httpStatus")).append('\n');
            if(e.opt("durationMs") instanceof Number)b.append("Duration: ").append(e.opt("durationMs")).append("ms\n");
            optional(b,e,"Description: ","description");optional(b,e,"Error: ","errorMessage");
            JSONObject meta=e.optJSONObject("metadata");if(meta!=null&&meta.length()>0){b.append("Metadata:\n");java.util.Iterator<String> keys=meta.keys();while(keys.hasNext()){String key=keys.next();b.append("  - ").append(key).append(": ").append(meta.opt(key)).append('\n');}}
            String stack=value(e,"stackTrace");if(!stack.isEmpty())b.append("Stack Trace:\n").append(stack).append('\n');
            b.append(LINE).append('\n');
        }
        return b.append(RULE).append("\nEND OF REPORT\n").append(RULE).toString();
    }
}
