package io.kurdikebord.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

/** Generated assets share the original layout/theme/dictionary data, without loading Chromium. */
final class NativeKeyboardData {
    private final Context context;
    private JSONObject defaults, dictionary, rich;
    private JSONArray themes, languages, translation;
    private String layoutId="";
    private JSONObject layout;
    private java.util.Set<String> availableLayouts;
    NativeKeyboardData(Context context){this.context=context.getApplicationContext();}
    private String read(String name){
        try(InputStream in=context.getAssets().open("native-keyboard/"+name+".json"); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>1024*1024)return "";out.write(buf,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    private JSONObject object(String name){try{return new JSONObject(read(name));}catch(Exception e){return new JSONObject();}}
    private JSONArray array(String name){try{return new JSONArray(read(name));}catch(Exception e){return new JSONArray();}}
    JSONObject config(JSONObject stored){
        if(defaults==null)defaults=object("defaults");
        try{JSONObject out=new JSONObject(defaults.toString());Iterator<String> it=stored.keys();while(it.hasNext()){String key=it.next();out.put(key,stored.get(key));}return out;}catch(Exception e){return stored;}
    }
    JSONArray allThemes(){if(themes==null)themes=array("themes");return themes;}
    JSONArray translationLanguages(){if(translation==null)translation=array("translation");return translation;}
    JSONObject theme(JSONObject settings){
        String id=settings.optString("activeThemeId","amoled_cobalt");
        if("custom_user_theme".equals(id)&&settings.optJSONObject("customTheme")!=null)return settings.optJSONObject("customTheme");
        if(themes==null)themes=array("themes");
        for(int i=0;i<themes.length();i++){JSONObject t=themes.optJSONObject(i);if(t!=null&&id.equals(t.optString("id")))return t;}
        return themes.optJSONObject(0)==null?new JSONObject():themes.optJSONObject(0);
    }
    JSONObject language(JSONObject settings,String code){
        JSONArray enabled=settings.optJSONArray("enabledLanguages");
        if(enabled!=null)for(int i=0;i<enabled.length();i++){JSONObject l=enabled.optJSONObject(i);if(l!=null&&code.equals(l.optString("code")))return l;}
        if(languages==null)languages=array("languages");
        for(int i=0;i<languages.length();i++){JSONObject l=languages.optJSONObject(i);if(l!=null&&code.equals(l.optString("code")))return l;}
        return new JSONObject();
    }
    JSONObject layout(JSONObject lang){
        String id=lang.optString("characterLayoutId","");
        if(!id.matches("[a-zA-Z0-9_-]{1,64}"))return new JSONObject();
        if(!id.equals(layoutId)||layout==null){layout=object("layouts/"+id);layoutId=id;}
        return layout;
    }
    boolean supports(JSONObject lang){
        // Korean composition and hybrid kana switching require the original specialized engine.
        String code=lang.optString("code"), id=lang.optString("characterLayoutId");
        if(availableLayouts==null){availableLayouts=new java.util.HashSet<>();try{String[] files=context.getAssets().list("native-keyboard/layouts");if(files!=null)java.util.Collections.addAll(availableLayouts,files);}catch(Exception ignored){}}
        return !"ko".equals(code)&&!"kurdi_hybrid".equals(id)&&!lang.optString("composerId").contains("hangul")&&availableLayouts.contains(id+".json");
    }
    String apiBase(){return object("api-base").optString("url","");}
    JSONObject dictionary(){if(dictionary==null)dictionary=object("dictionary");return dictionary;}
    JSONObject rich(){if(rich==null)rich=object("rich");return rich;}
    void releaseRich(){rich=null;}
}
