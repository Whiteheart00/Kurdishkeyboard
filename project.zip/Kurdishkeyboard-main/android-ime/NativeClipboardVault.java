package io.kurdikebord.app;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Device-local clipboard encryption, with no exportable key or cloud backup. */
final class NativeClipboardVault {
    private static final String ALIAS = "kk_clipboard_aes_v1";
    private static SecretKey key(boolean create) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        java.security.Key existing = ks.getKey(ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        if (!create) throw new java.security.GeneralSecurityException("Clipboard key unavailable");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }
    static String seal(String plain) throws Exception { return Base64.encodeToString(ClipboardVaultCrypto.seal(key(true), plain), Base64.NO_WRAP); }
    static String open(String sealed) throws Exception { return ClipboardVaultCrypto.open(key(false), Base64.decode(sealed,Base64.NO_WRAP)); }
}
