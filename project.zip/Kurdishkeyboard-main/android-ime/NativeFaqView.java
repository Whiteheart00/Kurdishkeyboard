package io.kurdikebord.app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;

final class NativeFaqView extends LinearLayout {
    private final NativeImeAppearance appearance;
    private final String font;
    private final int foreground;
    private final boolean light;
    private TextView openAnswer;
    private TextView openChevron;

    NativeFaqView(Context context, String theme, String font, JSONObject data, Runnable back) {
        super(context);
        this.font = font;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        setOrientation(VERTICAL);
        setLayoutDirection("ltr".equals(data.optString("direction")) ? LAYOUT_DIRECTION_LTR : LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = row();
        header.setLayoutDirection(LAYOUT_DIRECTION_RTL);
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = text("→", 20, foreground, 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = text(data.optString("title"), 16, foreground, 700);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        View border = new View(context);
        border.setBackgroundColor(light ? 0xffe2e8f0 : 0x0dffffff);
        addView(border, new LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(16));
        scroll.addView(body);

        LinearLayout banner = row();
        banner.setPadding(dp(16), dp(16), dp(16), dp(16));
        banner.setBackground(appearance.background(light ? 0xfff0f9ff : 0xff0e243d, 24, 1, 0x3338bdf8));
        ImageView logo = new ImageView(context);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try (InputStream input = context.getAssets().open("public/app-icon.png")) {
            logo.setImageBitmap(BitmapFactory.decodeStream(input));
        } catch (IOException ignored) {
            logo.setImageResource(context.getApplicationInfo().icon);
        }
        banner.addView(logo, new LayoutParams(dp(48), dp(48)));
        LinearLayout bannerCopy = column();
        bannerCopy.setPaddingRelative(dp(14), 0, 0, 0);
        bannerCopy.addView(label(data.optString("banner"), 14, foreground, 800));
        bannerCopy.addView(label(data.optString("appName"), 12, 0xffa1a1aa, 400));
        banner.addView(bannerCopy, new LayoutParams(0, -2, 1));
        append(body, banner, 0);

        JSONArray items = data.optJSONArray("items");
        for (int i = 0; items != null && i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item != null) addQuestion(body, item, i);
        }

        append(body, link(data.optString("youtube"), "https://www.youtube.com", 0x26ff0000, 0xfff87171), 16);
        LinearLayout socials = row();
        socials.addView(link(data.optString("facebook"), "https://www.facebook.com", light ? Color.WHITE : 0xff12151c,
                light ? 0xff2563eb : 0xff60a5fa), new LayoutParams(0, dp(40), 1));
        LayoutParams telegramPosition = new LayoutParams(0, dp(40), 1);
        telegramPosition.setMarginStart(dp(8));
        socials.addView(link("تێلیگرام", "https://t.me", light ? Color.WHITE : 0xff12151c,
                light ? 0xff0284c7 : 0xff38bdf8), telegramPosition);
        append(body, socials, 8);
    }

    private void addQuestion(LinearLayout body, JSONObject item, int index) {
        LinearLayout card = column();
        card.setBackground(appearance.background(light ? Color.WHITE : 0xff12151c, 16, 1,
                light ? 0xffe2e8f0 : 0x14ffffff));
        LinearLayout question = row();
        question.setPadding(dp(16), dp(14), dp(16), dp(14));
        question.setFocusable(true);
        TextView number = text(String.valueOf(index + 1), 12, 0xff9ac5ff, 800);
        number.setBackground(appearance.background(0x400a5fa8, 8, 0, 0));
        question.addView(number, new LayoutParams(dp(24), dp(24)));
        TextView caption = label(item.optString("question"), 14, foreground, 700);
        caption.setPaddingRelative(dp(10), 0, dp(12), 0);
        question.addView(caption, new LayoutParams(0, -2, 1));
        TextView chevron = text("⌄", 16, 0xffa1a1aa, 500);
        question.addView(chevron, new LayoutParams(dp(16), dp(24)));
        card.addView(question);

        TextView answer = label(item.optString("answer"), 12, 0xffa1a1aa, 400);
        answer.setLineSpacing(dp(5), 1f);
        answer.setPadding(dp(16), dp(4), dp(16), dp(16));
        answer.setVisibility(GONE);
        card.addView(answer);
        if (openAnswer == null && index == 0) toggle(answer, chevron);
        question.setOnClickListener(v -> toggle(answer, chevron));
        append(body, card, index == 0 ? 16 : 10);
    }

    private void toggle(TextView answer, TextView chevron) {
        boolean expand = openAnswer != answer;
        if (openAnswer != null) {
            openAnswer.setVisibility(GONE);
            openChevron.setRotation(0);
        }
        openAnswer = expand ? answer : null;
        openChevron = expand ? chevron : null;
        if (expand) {
            answer.setVisibility(VISIBLE);
            chevron.setRotation(180);
        }
    }

    private TextView link(String title, String url, int background, int color) {
        TextView link = text(title, 12, color, 800);
        link.setMinHeight(dp(42));
        link.setBackground(appearance.background(background, 16, 1, light ? 0xffe2e8f0 : 0x1affffff));
        link.setOnClickListener(v -> {
            try {
                getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException ignored) { }
        });
        return link;
    }

    private void append(LinearLayout parent, View child, int gap) {
        LayoutParams position = new LayoutParams(-1, -2);
        position.topMargin = dp(gap);
        parent.addView(child, position);
    }

    private int dp(int size) { return appearance.dp(size); }
    private TextView text(String label, int size, int color, int weight) {
        return appearance.text(label, size, color, font, weight);
    }
    private TextView label(String label, int size, int color, int weight) {
        TextView view = text(label, size, color, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }
    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }
    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }
}
