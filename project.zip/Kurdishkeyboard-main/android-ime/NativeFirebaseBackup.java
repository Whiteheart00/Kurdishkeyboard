package io.kurdikebord.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Account-scoped encrypted snapshots; no data sent unless a user explicitly enables a backup. */
final class NativeFirebaseBackup {
    static final ExecutorService WORK=Executors.newSingleThreadExecutor();
    static final int JOB=29812, BASIC=NativeCloudBackup.SETTINGS|NativeCloudBackup.LANGUAGES|NativeCloudBackup.THEMES|NativeCloudBackup.EMOJI;
    static final int LIMIT=750000;
    private static final String PREF="kk_firebase_backup_v1", ALIAS="kk_firebase_backup_key_v1";
    private static FirebaseFirestore db;
    static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static FirebaseUser user(){return FirebaseAuth.getInstance().getCurrentUser();}
    static String uid(){FirebaseUser u=user();return u==null?"":u.getUid();}
    static synchronized FirebaseFirestore db(){if(db==null){db=FirebaseFirestore.getInstance();db.setFirestoreSettings(new FirebaseFirestoreSettings.Builder().setPersistenceEnabled(false).build());}return db;}
    static DocumentReference doc(String uid){if(uid.isEmpty())throw new IllegalStateException("No account");return db().collection("keyboardBackups").document(uid);}
    static boolean associated(Context c,String uid){return !uid.isEmpty()&&uid.equals(prefs(c).getString("uid",""));}
    static boolean automatic(Context c){return associated(c,uid())&&prefs(c).getBoolean("auto",false);}
    static String revision(Context c,String uid){return associated(c,uid)?prefs(c).getString("revision",""):"";}
    static void check(String expected){if(expected.isEmpty()||!expected.equals(uid()))throw new IllegalStateException("Account changed");}
    static <T>T await(com.google.android.gms.tasks.Task<T> t)throws Exception{return Tasks.await(t,40,TimeUnit.SECONDS);}
    private static javax.crypto.SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        java.security.Key k=ks.getKey(ALIAS,null);if(k instanceof javax.crypto.SecretKey)return (javax.crypto.SecretKey)k;
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());return gen.generateKey();
    }
    private static String wrap(char[] pass,String uid)throws Exception{
        byte[] bytes=new String(pass).getBytes(StandardCharsets.UTF_8);try{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));byte[] iv=cipher.getIV(),ct=cipher.doFinal(bytes);ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(iv);out.write(ct);return Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}finally{Arrays.fill(bytes,(byte)0);}
    }
    static char[] unwrap(Context c,String uid)throws Exception{
        if(!associated(c,uid))throw new IllegalStateException("No key");byte[] bytes=Base64.decode(prefs(c).getString("key",""),Base64.NO_WRAP);if(bytes.length<29)throw new IOException("No key");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,bytes,0,12));cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));byte[] plain=cipher.doFinal(bytes,12,bytes.length-12);try{return new String(plain,StandardCharsets.UTF_8).toCharArray();}finally{Arrays.fill(plain,(byte)0);}
    }
    static void stop(Context c){prefs(c).edit().putBoolean("auto",false).remove("key").commit();JobScheduler js=c.getSystemService(JobScheduler.class);if(js!=null)js.cancel(JOB);}
    static void clear(Context c){stop(c);prefs(c).edit().clear().commit();}
    static void enable(Context c,String uid,char[] pass,int mask)throws Exception{
        check(uid);if(revision(c,uid).isEmpty())throw new IllegalStateException("First backup required");
        String wrapped=wrap(pass,uid);if(!prefs(c).edit().putString("key",wrapped).putInt("mask",mask).putBoolean("auto",true).commit())throw new IOException("Local storage");
        JobScheduler js=c.getSystemService(JobScheduler.class);if(js==null||js.schedule(new JobInfo.Builder(JOB,new ComponentName(c,NativeFirebaseBackupJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(TimeUnit.HOURS.toMillis(24)).setRequiresBatteryNotLow(true).build())!=JobScheduler.RESULT_SUCCESS){stop(c);throw new IOException("Scheduler");}
    }
    static JSONObject capture(Context c,int mask)throws Exception{
        if(!ImeStateStore.unlocked(c))throw new IllegalStateException("Locked");
        // Full clipboard and learned/typed words are never included in background uploads.
        mask=mask&(BASIC|NativeCloudBackup.PINNED);if(mask==0)throw new IOException("No selection");
        JSONObject data=NativeCloudBackup.capture(c,new NativeImeData(c).load("core"),mask);
        data.remove("created");data.remove("skipped");return data;
    }
    static String hash(byte[] bytes)throws Exception{return Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(bytes),Base64.NO_WRAP);}
    static boolean upload(Context c,String uid,char[] pass,int mask,boolean background)throws Exception{
        check(uid);if(background&&!automatic(c))return false;
        JSONObject data=capture(c,mask);byte[] plain=data.toString().getBytes(StandardCharsets.UTF_8);
        try{
            if(plain.length>LIMIT-64)throw new IOException("Backup too large");
            String hash=hash(plain), previous=revision(c,uid), next=UUID.randomUUID().toString();
            if(background&&hash.equals(prefs(c).getString("hash","")))return true;
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();NativeBackupCrypto.encrypt(plain,pass,buffer);byte[] encrypted=buffer.toByteArray();
            if(encrypted.length>LIMIT)throw new IOException("Backup too large");
            Map<String,Object> fields=new HashMap<>();fields.put("version",1);fields.put("revision",next);fields.put("ciphertext",Blob.fromBytes(encrypted));fields.put("updatedAt",FieldValue.serverTimestamp());
            DocumentReference ref=doc(uid);
            Boolean saved=await(db().runTransaction(tx->{
                check(uid);if(background&&!automatic(c))return false;
                DocumentSnapshot old=tx.get(ref);String actual=old.exists()?old.getString("revision"):"";
                if(!previous.equals(actual))return false;
                tx.set(ref,fields);return true;
            }));
            if(!Boolean.TRUE.equals(saved)){stop(c);return false;}check(uid);
            if(!prefs(c).edit().putString("uid",uid).putString("revision",next).putString("hash",hash).putInt("mask",mask).putLong("last",System.currentTimeMillis()).commit())throw new IOException("Local storage");
            return true;
        }finally{Arrays.fill(plain,(byte)0);}
    }
    static final class Download{final JSONObject payload;final String revision;Download(JSONObject p,String r){payload=p;revision=r;}}
    static Download download(String uid,char[] pass)throws Exception{
        check(uid);DocumentSnapshot snapshot=await(doc(uid).get(Source.SERVER));if(!snapshot.exists())return null;
        Blob blob=snapshot.getBlob("ciphertext");String revision=snapshot.getString("revision");if(blob==null||revision==null||blob.toBytes().length>LIMIT)throw new IOException("Invalid cloud data");
        byte[] plain=NativeBackupCrypto.decrypt(new ByteArrayInputStream(blob.toBytes()),pass);try{JSONObject data=new JSONObject(new String(plain,StandardCharsets.UTF_8));int mask=NativeCloudBackup.validate(data);if((mask&~(BASIC|NativeCloudBackup.PINNED))!=0)throw new IOException("Invalid selection");return new Download(data,revision);}finally{Arrays.fill(plain,(byte)0);}
    }
    static boolean restore(Context c,String uid,Download data)throws Exception{
        check(uid);DocumentSnapshot latest=await(doc(uid).get(Source.SERVER));if(!data.revision.equals(latest.getString("revision")))return false;
        if(!ImeStateStore.restoreCloud(c,data.payload,new NativeImeData(c).load("core"),data.payload.optInt("mask")))return false;
        stop(c);return prefs(c).edit().putString("uid",uid).putString("revision",data.revision).remove("hash").putInt("mask",data.payload.optInt("mask")).putLong("last",System.currentTimeMillis()).commit();
    }
    static void delete(Context c,String uid)throws Exception{check(uid);stop(c);await(doc(uid).delete());clear(c);}
}
