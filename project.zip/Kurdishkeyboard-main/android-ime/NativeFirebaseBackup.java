package io.kurdikebord.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Account-scoped encrypted snapshots; no data sent unless a user explicitly enables a backup. */
final class NativeFirebaseBackup {
    static final ExecutorService WORK=Executors.newSingleThreadExecutor();
    static final int JOB=29812, BASIC=NativeCloudBackup.SETTINGS|NativeCloudBackup.LANGUAGES|NativeCloudBackup.THEMES|NativeCloudBackup.EMOJI;
    static final int LIMIT=750000;
    private static final String PREF="kk_firebase_backup_v1", ALIAS="kk_firebase_backup_key_v1";
    static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static NativeFirebaseRest.User user(Context c){return NativeFirebaseRest.user(c);}
    static String uid(Context c){NativeFirebaseRest.User u=user(c);return u==null?"":u.getUid();}
    static boolean associated(Context c,String uid){return !uid.isEmpty()&&uid.equals(prefs(c).getString("uid",""));}
    static boolean automatic(Context c){return associated(c,uid(c))&&prefs(c).getBoolean("auto",false);}
    static String revision(Context c,String uid){return associated(c,uid)?prefs(c).getString("revision",""):"";}
    static void check(Context c,String expected){if(expected.isEmpty()||!expected.equals(uid(c)))throw new IllegalStateException("Account changed");}
    private static javax.crypto.SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        java.security.Key k=ks.getKey(ALIAS,null);if(k instanceof javax.crypto.SecretKey)return (javax.crypto.SecretKey)k;
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());return gen.generateKey();
    }
    private static String wrap(char[] pass,String uid)throws Exception{
        byte[] bytes=new String(pass).getBytes(StandardCharsets.UTF_8);try{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));byte[] iv=cipher.getIV(),ct=cipher.doFinal(bytes);ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(iv);out.write(ct);return Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}finally{Arrays.fill(bytes,(byte)0);}
    }
    static char[] unwrap(Context c,String uid)throws Exception{
        if(!associated(c,uid))throw new IllegalStateException("No key");byte[] bytes=Base64.decode(prefs(c).getString("key",""),Base64.NO_WRAP);if(bytes.length<29)throw new IOException("No key");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,bytes,0,12));cipher.updateAAD(uid.getBytes(StandardCharsets.UTF_8));byte[] plain=cipher.doFinal(bytes,12,bytes.length-12);try{return new String(plain,StandardCharsets.UTF_8).toCharArray();}finally{Arrays.fill(plain,(byte)0);}
    }
    static void stop(Context c){prefs(c).edit().putBoolean("auto",false).remove("key").commit();JobScheduler js=c.getSystemService(JobScheduler.class);if(js!=null)js.cancel(JOB);}
    static void clear(Context c){stop(c);prefs(c).edit().clear().commit();}
    static void enable(Context c,String uid,char[] pass,int mask)throws Exception{
        check(c,uid);if(revision(c,uid).isEmpty())throw new IllegalStateException("First backup required");
        String wrapped=wrap(pass,uid);if(!prefs(c).edit().putString("key",wrapped).putInt("mask",mask).putBoolean("auto",true).commit())throw new IOException("Local storage");
        JobScheduler js=c.getSystemService(JobScheduler.class);if(js==null||js.schedule(new JobInfo.Builder(JOB,new ComponentName(c,NativeFirebaseBackupJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(TimeUnit.HOURS.toMillis(24)).setRequiresBatteryNotLow(true).build())!=JobScheduler.RESULT_SUCCESS){stop(c);throw new IOException("Scheduler");}
    }
    static JSONObject capture(Context c,int mask)throws Exception{
        if(!ImeStateStore.unlocked(c))throw new IllegalStateException("Locked");
        // Full clipboard and learned/typed words are never included in background uploads.
        mask=mask&(BASIC|NativeCloudBackup.PINNED);if(mask==0)throw new IOException("No selection");
        JSONObject data=NativeCloudBackup.capture(c,new NativeImeData(c).load("core"),mask);
        data.remove("created");data.remove("skipped");return data;
    }
    static String hash(byte[] bytes)throws Exception{return Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(bytes),Base64.NO_WRAP);}
    static boolean upload(Context c,String uid,char[] pass,int mask,boolean background)throws Exception{
        check(c,uid);if(background&&!automatic(c))return false;
        JSONObject data=capture(c,mask);byte[] plain=data.toString().getBytes(StandardCharsets.UTF_8);
        try{
            if(plain.length>LIMIT-64)throw new IOException("Backup too large");
            String hash=hash(plain), previous=revision(c,uid), next=UUID.randomUUID().toString();
            if(background&&hash.equals(prefs(c).getString("hash","")))return true;
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();NativeBackupCrypto.encrypt(plain,pass,buffer);byte[] encrypted=buffer.toByteArray();
            if(encrypted.length>LIMIT)throw new IOException("Backup too large");
            NativeFirebaseRest.Snapshot old=NativeFirebaseRest.get(c,uid);
            String actual=old==null?"":old.revision;
            if(!previous.equals(actual)){stop(c);return false;}
            check(c,uid);if(background&&!automatic(c))return false;
            boolean saved=NativeFirebaseRest.put(c,uid,old,next,encrypted);
            if(!saved){stop(c);return false;}check(c,uid);
            if(!prefs(c).edit().putString("uid",uid).putString("revision",next).putString("hash",hash).putInt("mask",mask).putLong("last",System.currentTimeMillis()).commit())throw new IOException("Local storage");
            return true;
        }finally{Arrays.fill(plain,(byte)0);}
    }
    static final class Download{final JSONObject payload;final String revision;Download(JSONObject p,String r){payload=p;revision=r;}}
    static Download download(Context c,String uid,char[] pass)throws Exception{
        check(c,uid);NativeFirebaseRest.Snapshot snapshot=NativeFirebaseRest.get(c,uid);if(snapshot==null)return null;
        byte[] plain=NativeBackupCrypto.decrypt(new ByteArrayInputStream(snapshot.ciphertext),pass);try{JSONObject data=new JSONObject(new String(plain,StandardCharsets.UTF_8));int mask=NativeCloudBackup.validate(data);if((mask&~(BASIC|NativeCloudBackup.PINNED))!=0)throw new IOException("Invalid selection");return new Download(data,snapshot.revision);}finally{Arrays.fill(plain,(byte)0);}
    }
    static boolean restore(Context c,String uid,Download data)throws Exception{
        check(c,uid);NativeFirebaseRest.Snapshot latest=NativeFirebaseRest.get(c,uid);if(latest==null||!data.revision.equals(latest.revision))return false;
        if(!ImeStateStore.restoreCloud(c,data.payload,new NativeImeData(c).load("core"),data.payload.optInt("mask")))return false;
        stop(c);return prefs(c).edit().putString("uid",uid).putString("revision",data.revision).remove("hash").putInt("mask",data.payload.optInt("mask")).putLong("last",System.currentTimeMillis()).commit();
    }
    static void delete(Context c,String uid)throws Exception{check(c,uid);stop(c);NativeFirebaseRest.delete(c,uid);clear(c);}
}
