package io.kurdikebord.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;

/** One user-initiated utterance at a time, all calls on the IME main looper. */
final class NativeKeyboardVoice {
    private final Context context;
    private final OfflineKeyboardStt.Events events;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private long generation;
    private final Runnable timeout = () -> finish("error", "timeout");
    NativeKeyboardVoice(Context context, OfflineKeyboardStt.Events events) { this.context=context; this.events=events; }
    boolean active() { return recognizer != null; }
    void start(String locale) {
        if (active()) return;
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { events.event("permission", ""); return; }
        try {
            if (!"en-US".equals(locale) && !"ar-IQ".equals(locale)) { events.event("error", "recognizer_unavailable"); return; }
            if (!SpeechRecognizer.isRecognitionAvailable(context)) { events.event("error", "recognizer_unavailable"); return; }
            final long token = ++generation;
            recognizer=SpeechRecognizer.createSpeechRecognizer(context);
            recognizer.setRecognitionListener(new RecognitionListener() {
                private boolean current() { return token==generation && active(); }
                public void onReadyForSpeech(Bundle b) { if(current()) events.event("recording", ""); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float rms) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { if(current()) { events.event("transcribing", ""); deadline(15000); } }
                public void onError(int code) { if(current()) finish(code==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS?"permission":"error", "recognizer_"+code); }
                public void onResults(Bundle b) { if(!current()) return; ArrayList<String> list=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); String text=list==null||list.isEmpty()?"":list.get(0); finish(text==null||text.trim().isEmpty()?"error":"result", text==null||text.trim().isEmpty()?"no_speech":text); }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int type, Bundle b) {}
            });
            Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            events.event("starting", ""); deadline(60000); recognizer.startListening(intent);
        } catch (RuntimeException e) { finish("error", "recognizer_unavailable"); }
    }
    private void deadline(long ms) { main.removeCallbacks(timeout); main.postDelayed(timeout, ms); }
    void stop() { if(active()) try { events.event("transcribing", ""); deadline(15000); recognizer.stopListening(); } catch(RuntimeException e) { finish("error", "recognizer_unavailable"); } }
    void cancel() { if(active()) finish("cancelled", ""); }
    private void finish(String state, String text) { generation++; main.removeCallbacks(timeout); SpeechRecognizer old=recognizer; recognizer=null; if(old!=null) { try { old.cancel(); } catch(RuntimeException ignored) {} try { old.destroy(); } catch(RuntimeException ignored) {} } events.event(state,text); }
}
