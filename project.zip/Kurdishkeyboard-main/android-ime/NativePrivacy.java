package io.kurdikebord.app;

import java.util.regex.Pattern;

/** Conservative local heuristic, not a guarantee that arbitrary secrets are recognized. */
final class NativePrivacy {
    private static final Pattern OTP = Pattern.compile("[0-9٠-٩۰-۹]{4,8}");
    private static final Pattern LABEL = Pattern.compile("password|passcode|api[ _-]?key|secret[ _-]?key|bearer\\s+|private key|verification code|one.time password|\\bOTP\\b|وشەی نهێنی|کۆدی دڵنیایی", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern TOKEN = Pattern.compile("sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|AIza[A-Za-z0-9_-]{30,}|eyJ[A-Za-z0-9_-]{5,}\\.[A-Za-z0-9_-]{5,}\\.[A-Za-z0-9_-]{8,}");
    private static final Pattern CARD = Pattern.compile("[0-9][0-9 -]{11,24}[0-9]");
    static boolean looksSensitive(String text) {
        if (text == null) return false;
        String t = text.trim();
        if (OTP.matcher(t).matches() || LABEL.matcher(t).find() || TOKEN.matcher(t).find()) return true;
        if (!CARD.matcher(t).matches()) return false;
        String digits=t.replace(" ", "").replace("-", "");
        if(digits.length()<13 || digits.length()>19) return false;
        int sum=0; boolean doubled=false;
        for(int i=digits.length()-1;i>=0;i--){int n=digits.charAt(i)-'0'; if(doubled){n*=2;if(n>9)n-=9;}sum+=n;doubled=!doubled;}
        return sum%10==0;
    }
    private NativePrivacy() {}
}
