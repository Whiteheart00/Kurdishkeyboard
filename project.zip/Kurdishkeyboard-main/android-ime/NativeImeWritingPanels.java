package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;
import static io.kurdikebord.app.NativeImePanelStyle.*;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

final class NativeImeWritingPanels implements AutoCloseable {
    private static final String[][] MODES = {
            {"fix", "ڕاستکردنەوە"}, {"badini", "سۆرانی ← بادینی"}, {"sorani", "بادینی ← سۆرانی"},
            {"expand", "درێژکردنەوە"}, {"poetic", "شاعیرانە"}, {"shorten", "کورتکردنەوە"},
            {"rephrase", "داڕشتنەوە"}, {"explain", "مانا"}, {"formal", "فەرمی"},
            {"friendly", "دۆستانە"}, {"reply", "وەڵامی نامە"}
    };
    private static final String[][] STYLES = {{"casual", "ئاسایی"}, {"professional", "فەرمی"}, {"academic", "ئەکادیمی"}};
    private static final String[][] INTENTS = {{"polite", "بەڕێزانە"}, {"work", "کار"}, {"email", "ئیمەیڵ"}, {"humor", "گاڵتەوگەپ"}, {"academic", "لێکۆڵینەوە"}};
    private static final String[][] LENGTHS = {{"very_short", "زۆر کورت"}, {"short", "کورت"}, {"medium", "مامناوەند"}, {"long", "درێژ"}, {"detailed", "بەوردی"}};
    private static final String LIVE_PLACEHOLDER = "بە کیبۆرد بنووسە بۆ وەرگێڕانی ڕاستەوخۆ (Enter بۆ ناردن)...";

    private final NativeImeView keyboard;
    private final NativeImePanels panels;
    private final NativeImePanelStyle ui;
    private final NativeImeNetwork network;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, String> translations = new LruCache<>(60);
    private final LruCache<String, String> rewrites = new LruCache<>(60);
    private final Runnable translateLive = () -> translate(true);
    private JSONArray languages;
    private String source = "ckb";
    private String target = "en";
    private String draft = "";
    private String output = "";
    private String error = "";
    private String picking = "";
    private String query = "";
    private String nextTranslation;
    private boolean edited;
    private boolean aiEditing;
    private boolean live;
    private String liveText = "";
    private boolean loading;
    private boolean offline;
    private String mode = "fix";
    private String drawer = "";
    private String custom = "";
    private JSONObject tone;
    private HorizontalScrollView modeStrip;
    private int modePosition;
    private TextView liveInput;
    private TextView liveOutput;
    private LinearLayout livePreview;
    private ProgressBar liveProgress;
    private View liveClear;
    private View liveSend;

    NativeImeWritingPanels(NativeImeView keyboard, NativeImePanels panels, NativeImePanelStyle ui) {
        this.keyboard = keyboard;
        network=new NativeImeNetwork(keyboard.getContext());
        this.panels = panels;
        this.ui = ui;
    }

    static boolean isWritingPanel(String panel) { return "translate".equals(panel) || "ai_smart".equals(panel); }
    boolean live() { return live; }
    boolean pickingLiveLanguage() { return live && !picking.isEmpty(); }

    void readState(JSONObject state) {
        source = state.optString("sourceLanguage", source);
        target = state.optString("targetLanguage", target);
    }

    void panelChanged(String panel, boolean editingField) {
        if (editingField) return;
        cancelRequests();
        live = false;
        draft = isWritingPanel(panel) ? hostText() : "";
        edited = false;
        output = error = picking = query = "";
        offline = aiEditing = false;
        mode = "fix";
        drawer = custom = "";
        modeStrip = null;
        modePosition = 0;
        tone = json("style", "professional", "intent", "polite", "length", "medium");
        if ("translate".equals(panel) && nextTranslation != null) {
            draft = nextTranslation;
            edited = true;
        }
        nextTranslation = null;
    }

    void translateClipboard(String text) {
        nextTranslation = text;
        keyboard.openPanel("translate");
    }

    View render(boolean ai) {
        if (!picking.isEmpty()) return picker(false);
        LinearLayout panel = ui.panel(height(ai ? 54 : 36, ai ? 336 : 315), 12, 10);
        addHeader(panel, ai);
        if (keyboard.service.nativeSensitiveEditor()) {
            ui.flex(panel, ui.text("دەق بەردەست نییە", 12, MUTED, 400), MATCH, 8);
            return panel;
        }
        if (ai) addAiControls(panel);
        else {
            ui.add(panel, languagesRow(false), MATCH, 36, 8);
            addTranslationInput(panel);
        }
        ui.flex(panel, resultCard(ai), MATCH, 8);
        return panel;
    }

    private int height(int extra, int minimum) {
        return Math.max(keyboard.settings.optInt("keyboardHeightPx", 248) + extra, minimum);
    }

    private void addHeader(LinearLayout panel, boolean ai) {
        LinearLayout header = ui.row();
        LinearLayout controls = ui.row();
        ui.add(controls, ui.icon(ai ? "ic_smart" : "ic_translate", SKY, 16), 16, 16, 0);
        TextView title = ui.text(ai ? "وەڵامدەرەوەی زیرەک (AI)" : "وەرگێڕان", ai ? 12 : 14, ui.foreground(), 700);
        ui.truncate(title);
        ui.add(controls, title, WRAP, WRAP, ai ? 6 : 8);
        if (!keyboard.service.nativeSensitiveEditor()) {
            if (ai) {
                TextView style = pill("شێواز", "tone".equals(drawer) || "tone".equals(mode), () -> toggleDrawer("tone"));
                ui.titleIcon(style, "sliders_horizontal", 12, 4);
                ui.add(controls, style, WRAP, 24, 6);
                ui.add(controls, pill("فەرمان", "custom".equals(drawer) || "custom".equals(mode), () -> toggleDrawer("custom")), WRAP, 24, 6);
            } else {
                boolean fluent = fluent();
                TextView engine = pill(fluent ? "Gemini زیرەک" : "گوگڵ خێرا", fluent, () -> {
                    cancelRequests();
                    keyboard.settingsPatch(json("translationEngine", fluent ? "google_fast" : "ai_fluent"));
                });
                engine.setContentDescription("گۆڕینی بزوێنەری وەرگێڕان " + engine.getText());
                ui.add(controls, engine, WRAP, 24, 8);
                ui.add(controls, ui.button("ڕاستەوخۆ", 10.5, 0xff34d399, 700, 0x3320c997, 12, 0x4d34d399, 10,
                        this::startLive), WRAP, 24, 8);
            }
        }
        ui.flex(header, controls, WRAP, 0);
        ui.add(header, ui.close(() -> keyboard.openPanel("keys"), 16), ai ? 28 : 32, ai ? 28 : 32, 6);
        ui.add(panel, header, MATCH, WRAP, 0);
    }

    private TextView pill(String label, boolean active, Runnable action) {
        return ui.button(label, 10.5, active ? SKY : ui.mutedText(), 700,
                active ? 0x330ea5e9 : ui.color(0xffe2e8f0, 0x1affffff), 12, active ? 0x5938bdf8 : 0, 9, action);
    }

    private void addTranslationInput(LinearLayout panel) {
        LinearLayout row = ui.row();
        String label = "دەقەکەت لێرە بنووسە...";
        ui.flex(row, panels.input(label, draft, () -> panels.beginTyping(label, draft, "translate", value -> {
            draft = value;
            edited = true;
            error = "";
            keyboard.render();
        }, this::translateFromKeyboard)), 40, 0);
        View translate = loading ? loadingButton() : ui.button("وەرگێڕە", 12, Color.WHITE, 700, BLUE, 12, 0, 16, () -> translate(false));
        ui.add(row, translate, loading ? 68 : WRAP, 40, 8);
        ui.add(panel, row, MATCH, 40, 8);
    }

    private void translateFromKeyboard(String value) {
        draft = value;
        edited = true;
        translate(false);
    }

    private View loadingButton() {
        FrameLayout button = new FrameLayout(keyboard.getContext());
        button.setBackground(ui.face(0x990b5fa8, 12, 0));
        button.setContentDescription("وەرگێڕان...");
        button.addView(spinner(Color.WHITE), new FrameLayout.LayoutParams(ui.dp(16), ui.dp(16), Gravity.CENTER));
        return button;
    }

    private void addAiControls(LinearLayout panel) {
        if (aiEditing || draft.trim().isEmpty()) {
            LinearLayout row = ui.row();
            String title = "دەقەکەت لێرە بنووسە یان بیلکێنە...";
            ui.flex(row, panels.input(title, draft, this::editAiDraft), 32, 0);
            if (!draft.trim().isEmpty()) {
                ui.add(row, ui.button("باشە", 11, Color.WHITE, 700, 0xff0284c7, 12, 0, 10, () -> {
                    aiEditing = false;
                    keyboard.render();
                }), WRAP, 32, 6);
            }
            ui.add(panel, row, MATCH, 32, 8);
        }
        if ("tone".equals(drawer)) addTone(panel);
        if ("custom".equals(drawer)) addCustom(panel);
        if (modeStrip != null) modePosition = modeStrip.getScrollX();
        LinearLayout modes = ui.row();
        for (String[] item : MODES) {
            boolean selected = item[0].equals(mode);
            TextView button = ui.button(item[1], 12, selected ? Color.WHITE : ui.mutedText(), 600,
                    selected ? BLUE : ui.color(0xffe2e8f0, 0xff181a20), 16, 0, 12, () -> rewrite(item[0], false, false));
            button.setSelected(selected);
            ui.add(modes, button, WRAP, 32, modes.getChildCount() == 0 ? 0 : 6);
        }
        modeStrip = ui.horizontal(modes);
        if (modePosition > 0) {
            HorizontalScrollView current = modeStrip;
            current.post(() -> current.scrollTo(modePosition, 0));
        }
        ui.add(panel, modeStrip, MATCH, 34, 8);
    }

    private void editAiDraft() {
        aiEditing = true;
        String title = "دەستکاریکردنی دەقی سەرچاوە";
        panels.beginTyping(title, draft, "ai_smart", value -> {
            draft = value;
            edited = true;
            error = "";
            keyboard.render();
        });
    }

    private void toggleDrawer(String section) {
        drawer = section.equals(drawer) ? "" : section;
        keyboard.render();
    }

    private void addTone(LinearLayout panel) {
        LinearLayout tonePanel = ui.column();
        ui.padding(tonePanel, 8, 8);
        tonePanel.setBackground(ui.face(ui.color(0xfff8fafc, 0xff14171f), 12, ui.border()));
        LinearLayout choices = ui.row();
        toneGroup(choices, "شێواز", "style", STYLES);
        toneGroup(choices, "مەبەست", "intent", INTENTS);
        ui.add(tonePanel, ui.horizontal(choices), MATCH, 24, 0);
        LinearLayout length = ui.row();
        LinearLayout options = ui.row();
        toneGroup(options, "درێژی", "length", LENGTHS);
        ui.flex(length, ui.horizontal(options), 24, 0);
        ui.add(length, ui.button("ئەنجامدان", 10.5, Color.WHITE, 700, 0xff0284c7, 8, 0, 10, () -> {
            drawer = "";
            rewrite("tone", false, false);
        }), WRAP, 24, 6);
        ui.add(tonePanel, length, MATCH, 24, 6);
        ui.add(panel, tonePanel, MATCH, WRAP, 8);
    }

    private void toneGroup(LinearLayout row, String title, String key, String[][] values) {
        ui.add(row, ui.text(title + ":", 10, 0xffa1a1aa, 700), WRAP, 24, row.getChildCount() == 0 ? 0 : 6);
        for (String[] item : values) {
            boolean selected = item[0].equals(tone.optString(key));
            TextView button = ui.button(item[1], 10.5, selected ? Color.WHITE : ui.mutedText(), 700,
                    selected ? BLUE : ui.color(Color.WHITE, 0x0fffffff), 8, !selected && keyboard.light() ? ui.border() : 0, 8, () -> {
                        put(tone, key, item[0]);
                        for (int i = 0; i < row.getChildCount(); i++) {
                            View sibling = row.getChildAt(i);
                            Object tag = sibling.getTag();
                            if (tag instanceof String && ((String) tag).startsWith(key + ":")) {
                                paintTone((TextView) sibling, (key + ":" + item[0]).equals(tag));
                            }
                        }
                    });
            button.setTag(key + ":" + item[0]);
            button.setSelected(selected);
            ui.add(row, button, WRAP, 24, 4);
        }
    }

    private void paintTone(TextView button, boolean selected) {
        button.setSelected(selected);
        button.setTextColor(selected ? Color.WHITE : ui.mutedText());
        button.setBackground(ui.face(selected ? BLUE : ui.color(Color.WHITE, 0x0fffffff), 8, !selected && keyboard.light() ? ui.border() : 0));
    }

    private void addCustom(LinearLayout panel) {
        LinearLayout row = ui.row();
        String title = "فەرمانەکەت بنووسە (وەک: بیکە بە ئیمەیڵی فەرمی)...";
        ui.flex(row, panels.input(title, custom, () -> panels.beginTyping(title, custom, "ai_smart", value -> {
            custom = value;
            keyboard.render();
        }, value -> {
            custom = value;
            rewrite("custom", false, false);
        })), 32, 0);
        ui.add(row, ui.button("جێبەجێکردن", 12, Color.WHITE, 700, BLUE, 12, 0, 12, () -> rewrite("custom", false, false)), WRAP, 32, 6);
        ui.add(panel, row, MATCH, 32, 8);
    }

    private View resultCard(boolean ai) {
        LinearLayout card = ui.column();
        ui.padding(card, 12, 12);
        card.setBackground(ui.face(ui.color(Color.WHITE, 0xff121418), 12, ui.color(0xffe2e8f0, 0x0dffffff)));
        if (ai && loading && output.isEmpty()) {
            LinearLayout progress = ui.row();
            progress.setGravity(Gravity.CENTER);
            ui.add(progress, spinner(SKY), 16, 16, 0);
            ui.add(progress, ui.text("ژیری دەسکرد خەریکی داڕشتنەوەیە...", 12, SKY, 400), WRAP, WRAP, 8);
            ui.flex(card, progress, MATCH, 0);
        } else if (!error.isEmpty()) {
            LinearLayout message = ui.column();
            message.setGravity(Gravity.CENTER);
            ui.add(message, ui.text(error, 12, 0xfffb7185, 400), MATCH, WRAP, 0);
            if (ai && !draft.trim().isEmpty()) {
                ui.add(message, ui.button("بەکارهێنانی دۆخی ئۆفڵاین", 11, ui.mutedText(), 700, ui.mutedFill(), 8, 0, 12,
                        () -> rewrite(mode, true, true)), WRAP, 28, 8);
            }
            ui.flex(card, message, MATCH, 0);
        } else if (!output.isEmpty()) {
            LinearLayout body = ui.column();
            if (offline) {
                TextView badge = ui.text("دۆخی ئۆفڵاین", 10, 0xfffbbf24, 700);
                ui.padding(badge, 8, 2);
                badge.setBackground(ui.face(0x26f59e0b, 6, 0));
                ui.add(body, badge, WRAP, WRAP, 0);
            }
            TextView result = ui.text(output, 14, ui.foreground(), 400);
            result.setTextIsSelectable(true);
            result.setGravity(Gravity.RIGHT | Gravity.TOP);
            ui.add(body, result, MATCH, WRAP, offline ? 6 : 0);
            ui.flex(card, ui.scroll(body), MATCH, 0);
            addResultActions(card, ai);
        } else {
            LinearLayout empty = ui.column();
            empty.setGravity(Gravity.CENTER);
            if (ai && !draft.trim().isEmpty()) {
                TextView preview = ui.button("«" + draft.trim() + "»", 11, ui.mutedText(), 400,
                        ui.color(0xfff1f5f9, 0x0affffff), 8, 0, 10, this::editAiDraft);
                ui.titleIcon(preview, "pencil", 12, 6);
                preview.setContentDescription("دەستکاریکردنی دەقی سەرچاوە " + draft.trim());
                ui.add(empty, preview, WRAP, 24, 0);
            }
            String instruction = ai ? "یەکێک لە شێوازەکانی سەرەوە هەڵبژێرە بۆ داڕشتنەوە و گۆڕینی دەقەکەت"
                    : "دەقەکەت بنووسە و لەسەر «وەرگێڕە» دابگرە بۆ وەرگێڕانی خێرا";
            ui.add(empty, ui.text(instruction, 12, MUTED, 400), MATCH, WRAP, ai ? 6 : 0);
            ui.flex(card, empty, MATCH, 0);
        }
        return card;
    }

    private void addResultActions(LinearLayout card, boolean ai) {
        View divider = new View(keyboard.getContext());
        divider.setBackgroundColor(ui.color(0xffe2e8f0, 0x0dffffff));
        ui.add(card, divider, MATCH, 1, 8);
        LinearLayout row = ui.row();
        ui.flex(row, ui.button("جێگرەوەی دەق", 12, Color.WHITE, 600, 0xff0284c7, 8, 0, 0, () -> insertResult(true)), 32, 0);
        ui.flex(row, ui.button("زیادکردن", 12, ui.foreground(), 600, ui.mutedFill(), 8, 0, 0, () -> insertResult(false)), 32, 6);
        if (ai) {
            ui.add(row, ui.iconButton("refresh_cw", "دووبارە دروستکردنەوە", ui.mutedText(), 14, ui.mutedFill(), 8,
                    () -> rewrite(mode, true, false)), 32, 32, 6);
        }
        ui.add(card, row, MATCH, 32, 8);
    }

    private ProgressBar spinner(int color) {
        ProgressBar progress = new ProgressBar(keyboard.getContext(), null, android.R.attr.progressBarStyleSmall);
        progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(color));
        return progress;
    }

    private void insertResult(boolean replace) {
        if (replace) keyboard.editor.replaceAllText(output, preferSelection());
        else keyboard.insert(output);
        keyboard.openPanel("keys");
    }

    private LinearLayout languagesRow(boolean liveRow) {
        LinearLayout row = ui.row();
        TextView from = languageButton(source, "source", liveRow);
        TextView to = languageButton(target, "target", liveRow);
        if (liveRow) {
            ui.add(row, from, WRAP, 28, 0);
        } else ui.flex(row, from, 36, 0);
        ui.add(row, ui.iconButton("arrow_left_right", "ئاڵوگۆڕی زمان", SKY, liveRow ? 14 : 16,
                liveRow ? ui.color(0xffe2e8f0, 0x1affffff) : 0x330284c7, liveRow ? 8 : 12, this::swapLanguages),
                liveRow ? 28 : 36, liveRow ? 28 : 36, liveRow ? 4 : 8);
        if (liveRow) ui.add(row, to, WRAP, 28, 4);
        else ui.flex(row, to, 36, 8);
        return row;
    }

    private TextView languageButton(String code, String kind, boolean liveRow) {
        TextView label = ui.button(language(code).optString(liveRow ? "shortLabel" : "label", code), liveRow ? 11 : 12,
                ui.foreground(), 700, ui.color(Color.WHITE, liveRow ? 0xff171920 : 0xff16181d),
                liveRow ? 8 : 12, ui.border(), liveRow ? 8 : 10, () -> {
                    picking = kind;
                    query = "";
                    keyboard.render();
                });
        label.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        if (liveRow) label.setMaxWidth(ui.dp(105));
        label.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null,
                keyboard.appearance.icon("chevron_down", 0xffa1a1aa, liveRow ? 12 : 14), null);
        label.setCompoundDrawablePadding(ui.dp(4));
        return label;
    }

    View picker(boolean livePicker) {
        LinearLayout panel = ui.panel(height(livePicker ? 64 : 36, 315), 10, 8);
        LinearLayout header = ui.row();
        String title = "source".equals(picking) ? "هەڵبژاردنی زمانی سەرچاوە" : "هەڵبژاردنی زمانی مەبەست";
        ui.add(header, ui.text(title, 12, ui.foreground(), 700), WRAP, 28, 0);
        TextView count = ui.text((languages().length() - 1) + " زمان", 10, ui.mutedText(), 600);
        count.setBackground(ui.face(ui.color(0xffe2e8f0, 0x1affffff), 6, 0));
        ui.padding(count, 6, 2);
        ui.add(header, count, WRAP, WRAP, 8);
        ui.flex(header, new View(keyboard.getContext()), 1, 0);
        ui.add(header, ui.close(this::closePicker, 14), 28, 28, 0);
        ui.add(panel, header, MATCH, 28, 0);
        LinearLayout search = ui.row();
        search.setBackground(ui.face(ui.color(Color.WHITE, 0xff16181d), 12, ui.border()));
        ui.padding(search, 10, 0);
        ui.add(search, ui.icon("search", 0xffa1a1aa, 14), 14, 14, 0);
        String placeholder = "گەڕان بۆ زمان (کوردی، English، Türkçe...)";
        TextView field = ui.button(query.isEmpty() ? placeholder : query, 11.5, query.isEmpty() ? MUTED : ui.foreground(), 400, 0, 0, 0, 0,
                () -> panels.beginTyping(placeholder, query, livePicker ? "keys" : "translate", value -> {
                    query = value;
                    keyboard.render();
                }));
        field.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        ui.flex(search, field, MATCH, 6);
        if (!query.isEmpty()) {
            ui.add(search, ui.iconButton("close", "پاککردنەوە", 0xffa1a1aa, 12, 0, 0, () -> {
                query = "";
                keyboard.render();
            }), 20, 32, 6);
        }
        ui.add(panel, search, MATCH, 32, 8);
        JSONArray choices = keyboard.engine.array("filterLanguages", new JSONArray().put(query).put("source".equals(picking)));
        if (choices.length() == 0) {
            ui.add(panel, ui.text("هیچ زمانێک نەدۆزرایەوە", 12, MUTED, 400), MATCH, 80, 8);
        } else {
            ListView list = new ListView(keyboard.getContext());
            list.setDivider(null);
            list.setDividerHeight(0);
            list.setVerticalScrollBarEnabled(false);
            list.setOverScrollMode(View.OVER_SCROLL_NEVER);
            list.setAdapter(new LanguageRows(choices, "source".equals(picking) ? source : target));
            ui.flex(panel, list, MATCH, 8);
        }
        return panel;
    }

    private final class LanguageRows extends BaseAdapter {
        private final JSONArray choices;
        private final String selection;

        LanguageRows(JSONArray choices, String selection) {
            this.choices = choices;
            this.selection = selection;
        }

        @Override public int getCount() { return (choices.length() + 1) / 2; }
        @Override public Object getItem(int position) { return choices.opt(position * 2); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View view, ViewGroup parent) {
            LinearLayout row = view == null ? ui.row() : (LinearLayout) view;
            row.removeAllViews();
            row.setPadding(ui.dp(2), 0, 0, ui.dp(6));
            ui.flex(row, languageCard(choices.optJSONObject(position * 2), selection), MATCH, 0);
            JSONObject second = choices.optJSONObject(position * 2 + 1);
            ui.flex(row, second == null ? new View(keyboard.getContext()) : languageCard(second, selection), MATCH, 6);
            row.setMinimumHeight(ui.dp(56));
            return row;
        }
    }

    private View languageCard(JSONObject language, String selection) {
        String code = language.optString("code");
        String label = language.optString("label");
        String ownName = language.optString("native");
        boolean active = code.equals(selection);
        LinearLayout card = ui.row();
        ui.padding(card, 10, 8);
        card.setBackground(ui.face(active ? 0x330b5fa8 : ui.color(Color.WHITE, 0xff171920), 12,
                active ? 0x9938bdf8 : ui.color(0xffe2e8f0, 0x0dffffff)));
        LinearLayout names = ui.column();
        TextView title = ui.text(label, 11.5, active ? SKY : ui.foreground(), 700);
        title.setGravity(Gravity.RIGHT);
        ui.truncate(title);
        ui.add(names, title, MATCH, WRAP, 0);
        if (!ownName.equals(label)) {
            TextView subtitle = ui.text(ownName, 10, active ? 0xcc7dd3fc : ui.color(0xff64748b, 0xffa1a1aa), 400);
            subtitle.setGravity(Gravity.RIGHT);
            ui.truncate(subtitle);
            ui.add(names, subtitle, MATCH, WRAP, 2);
        }
        ui.flex(card, names, WRAP, 0);
        if (active) ui.add(card, ui.icon("check", SKY, 14), 14, 14, 6);
        card.setSelected(active);
        ui.press(card, () -> {
            changeLanguage(picking, code);
            closePicker();
            if (live) scheduleLive();
        });
        return card;
    }

    private void closePicker() {
        picking = query = "";
        keyboard.render();
    }

    private void swapLanguages() {
        String previous = source;
        String nextSource = target;
        String nextTarget = "auto".equals(previous) ? "ckb".equals(target) ? "en" : "ckb" : previous;
        changeLanguage("source", nextSource);
        changeLanguage("target", nextTarget);
        if (live) scheduleLive();
        keyboard.render();
    }

    private void changeLanguage(String kind, String code) {
        boolean from = "source".equals(kind);
        if (from) source = code; else target = code;
        ImeStateStore.set(keyboard.service, from ? "sourceLanguage" : "targetLanguage", code);
    }

    private JSONArray languages() {
        if (languages == null) languages = keyboard.engine.array("languages", null);
        return languages;
    }

    private JSONObject language(String code) {
        JSONArray entries = languages();
        for (int i = 0; i < entries.length(); i++) {
            JSONObject language = entries.optJSONObject(i);
            if (code.equals(language.optString("code"))) return language;
        }
        return new JSONObject();
    }

    void startLive() {
        if (keyboard.service.nativeSensitiveEditor()) return;
        keyboard.openPanel("keys");
        cancelRequests();
        live = true;
        liveText = output = error = picking = query = "";
        keyboard.mode = "characters";
        keyboard.render();
    }

    void addLive(LinearLayout outer) {
        LinearLayout panel = ui.column();
        ui.padding(panel, 8, 6);
        LinearLayout bar = ui.row();
        ui.add(bar, ui.close(this::closeLive, 14), 28, 28, 0);
        ui.flex(bar, languagesRow(true), 28, 4);
        TextView send = ui.button("ناردن", 11, Color.WHITE, 700, BLUE, 8, 0, 10, this::commitLive);
        ui.titleIcon(send, "send", 12, 4);
        liveSend = send;
        ui.add(bar, send, WRAP, 28, 6);
        ui.add(panel, bar, MATCH, 28, 0);
        LinearLayout input = ui.row();
        ui.padding(input, 10, 0);
        input.setBackground(ui.face(ui.color(Color.WHITE, 0x14ffffff), 12, ui.color(SKY, 0x8038bdf8)));
        liveInput = ui.text("", 12, ui.foreground(), 500);
        liveInput.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        liveInput.setSingleLine(true);
        liveInput.setEllipsize(TextUtils.TruncateAt.START);
        ui.flex(input, liveInput, MATCH, 0);
        liveClear = ui.iconButton("close", "پاککردنەوە", 0xffa1a1aa, 14, 0, 0, () -> {
            liveText = "";
            scheduleLive();
        });
        ui.add(input, liveClear, 20, 32, 6);
        ui.add(panel, input, MATCH, 32, 6);
        livePreview = ui.row();
        livePreview.setBackground(ui.face(ui.color(0xfff0f9ff, 0x260ea5e9), 12, ui.color(0xffbae6fd, 0x4d38bdf8)));
        ui.padding(livePreview, 10, 0);
        ui.press(livePreview, this::commitLive);
        liveOutput = ui.text("", 12, ui.color(0xff0c4a6e, 0xffe0f2fe), 600);
        liveOutput.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        ui.truncate(liveOutput);
        ui.flex(livePreview, liveOutput, MATCH, 0);
        liveProgress = spinner(SKY);
        ui.add(livePreview, liveProgress, 14, 14, 8);
        ui.add(panel, livePreview, MATCH, 30, 4);
        ui.add(outer, panel, MATCH, WRAP, 0);
        View divider = new View(keyboard.getContext());
        divider.setBackgroundColor(ui.color(0xffe2e8f0, 0x1affffff));
        ui.add(outer, divider, MATCH, 1, 0);
        refreshLive();
    }

    void liveType(String value) {
        if (liveText.length() >= 12000) return;
        liveText += value;
        scheduleLive();
    }

    void liveDelete() {
        if (!liveText.isEmpty()) liveText = liveText.substring(0, liveText.offsetByCodePoints(liveText.length(), -1));
        scheduleLive();
    }

    void commitLive() {
        String value = (output.isEmpty() ? liveText : output).trim();
        if (value.isEmpty()) return;
        keyboard.insert(value + " ");
        liveText = "";
        scheduleLive();
    }

    void closeLive() {
        cancelRequests();
        live = false;
        liveText = output = picking = query = "";
        liveInput = liveOutput = null;
        livePreview = null;
        liveProgress = null;
        liveClear = liveSend = null;
        keyboard.render();
    }

    private void refreshLive() {
        if (liveInput == null) return;
        liveInput.setText(liveText.isEmpty() ? LIVE_PLACEHOLDER : liveText + "\u2009▏");
        liveInput.setTextColor(liveText.isEmpty() ? 0xffa1a1aa : ui.foreground());
        liveClear.setVisibility(liveText.isEmpty() ? View.GONE : View.VISIBLE);
        ui.enabled(liveSend, !liveText.trim().isEmpty());
        livePreview.setVisibility(output.isEmpty() && !loading ? View.GONE : View.VISIBLE);
        liveProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        liveOutput.setText(output.isEmpty() ? "وەرگێڕان..." : output);
    }

    private void scheduleLive() {
        cancelRequests();
        output = "";
        loading = !liveText.trim().isEmpty();
        if (loading) main.postDelayed(translateLive, 240);
        refreshLive();
    }

    private String hostText() {
        return keyboard.service.nativeSensitiveEditor() ? "" : keyboard.editor.getEditorText(preferSelection());
    }

    private boolean preferSelection() { return "selected_or_all".equals(keyboard.settings.optString("aiTextSource")); }

    private String apiBase() {
        return NativeImeNetwork.apiBase(keyboard.settings.optString("aiServerUrl"), keyboard.getResources().getString(R.string.native_ime_api_base));
    }

    private boolean fluent() { return "ai_fluent".equals(keyboard.settings.optString("translationEngine")); }

    private void translate(boolean liveRequest) {
        if (keyboard.service.nativeSensitiveEditor()) return;
        String input = (liveRequest ? liveText : draft).trim();
        if (!liveRequest && input.isEmpty()) input = hostText().trim();
        if (input.isEmpty()) {
            if (!liveRequest) {
                error = "تکایە دەقێک بنووسە بۆ وەرگێڕان.";
                keyboard.render();
            }
            return;
        }
        if (!liveRequest && draft.trim().isEmpty()) draft = input;
        boolean fluent = !liveRequest && fluent();
        String kind = fluent ? "ai_fluent" : "google_fast";
        String base = liveRequest ? "" : apiBase();
        String key = new JSONArray().put(base).put(kind).put(source).put(target).put(input).toString();
        String cached = translations.get(key);
        if (cached != null) {
            loading = false;
            output = cached;
            error = "";
            updateTranslation(liveRequest);
            return;
        }
        JSONObject payload = json("text", input, "sourceLang", source, "targetLang", target,
                "sourceLangName", language(source).optString("english", source), "targetLangName", language(target).optString("english", target),
                "engine", kind, "stream", true);
        long generation = keyboard.service.nativeEditorGeneration();
        error = output = "";
        loading = true;
        updateTranslation(liveRequest);
        network.request(partial -> network.translate(base, payload, fluent, partial), (value, done) -> {
            if (!keyboard.service.nativeEditorIsCurrent(generation)) return;
            output = value;
            loading = !done;
            if (done && !value.isEmpty()) translations.put(key, value);
            if (done && value.isEmpty() && !liveRequest) error = "هەڵە لە وەرگێڕاندا ڕوویدا.";
            updateTranslation(liveRequest);
        });
    }

    private void updateTranslation(boolean liveRequest) {
        if (liveRequest) refreshLive(); else if (!panels.editingToolField()) keyboard.render();
    }

    private void rewrite(String nextMode, boolean bypassCache, boolean offlineOnly) {
        if (keyboard.service.nativeSensitiveEditor()) return;
        cancelRequests();
        mode = nextMode;
        String current = (edited ? draft : hostText()).trim();
        if (current.isEmpty()) current = draft.trim();
        if (current.isEmpty()) {
            output = "";
            error = "سەرەتا دەقێک بنووسە یان لێرە بیلکێنە.";
            aiEditing = true;
            keyboard.render();
            return;
        }
        draft = current;
        String instruction = "custom".equals(nextMode) ? custom.trim() : "";
        if ("custom".equals(nextMode) && instruction.isEmpty()) {
            error = "تکایە فەرمانێک بنووسە (وەک: بیکە بە ئیمەیڵی فەرمی).";
            keyboard.render();
            return;
        }
        String input = current;
        JSONObject options = "tone".equals(nextMode) ? json("style", tone.optString("style"), "intent", tone.optString("intent"), "length", tone.optString("length")) : null;
        String base = apiBase();
        String key = new JSONArray().put(base).put(nextMode).put(instruction).put(options).put(input).toString();
        String cached = bypassCache ? null : rewrites.get(key);
        if (cached != null) {
            offline = false;
            output = cached;
            error = "";
            keyboard.render();
            return;
        }
        if (base.isEmpty() || offlineOnly) {
            offlineRewrite(input, nextMode, options, "ئەنجامی ئۆفلاین مەرجی داڕشتنەوەی پڕ نەکردەوە.");
            return;
        }
        JSONObject payload = json("text", input, "mode", nextMode, "customPrompt", instruction.isEmpty() ? null : instruction,
                "tone", options, "stream", false);
        long generation = keyboard.service.nativeEditorGeneration();
        loading = true;
        offline = false;
        error = output = "";
        keyboard.render();
        network.request(partial -> network.rewrite(base, payload), (value, done) -> {
            if (!done || !keyboard.service.nativeEditorIsCurrent(generation)) return;
            loading = false;
            if (validRewrite(input, value, nextMode)) {
                rewrites.put(key, value);
                output = value;
                if (!panels.editingToolField()) keyboard.render();
            } else offlineRewrite(input, nextMode, options, "ئەنجامی AI مەرجی داڕشتنەوەی پڕ نەکردەوە.");
        });
    }

    private void offlineRewrite(String input, String nextMode, JSONObject options, String message) {
        String value = keyboard.engine.text("offlineRewrite", new JSONArray().put(input).put(nextMode).put(options));
        offline = validRewrite(input, value, nextMode);
        output = offline ? value : "";
        error = offline ? "" : message;
        if (!panels.editingToolField()) keyboard.render();
    }

    private boolean validRewrite(String input, String value, String nextMode) {
        return !value.isEmpty() && Boolean.TRUE.equals(keyboard.engine.call("rewriteQuality", new JSONArray().put(input).put(value).put(nextMode)));
    }

    void endSession() {
        nextTranslation = null;
        panelChanged("keys", false);
        liveText = "";
        liveInput = liveOutput = null;
        livePreview = null;
        liveProgress = null;
        liveClear = liveSend = null;
    }

    private void cancelRequests() {
        network.cancel();
        main.removeCallbacks(translateLive);
        loading = false;
    }

    @Override public void close() { cancelRequests(); network.close(); }
}
