package io.kurdikebord.app;

import java.util.ArrayList;
import java.util.List;

/** A snapshot of literal, non-sensitive clipboard items. No clipboard data is logged. */
final class ImeClipboardCapture {
    private long timestamp = -1;
    private List<String> last = new ArrayList<>();

    static String safeText(CharSequence value) {
        if (value == null || value.length() > 524288) return null;
        String text = value.toString();
        return text.trim().isEmpty() || NativePrivacy.looksSensitive(text) ? null : text;
    }

    boolean isNew(long time, List<String> items) {
        return !items.isEmpty() && (time != timestamp || !last.equals(items));
    }

    void accepted(long time, List<String> items) {
        timestamp = time;
        last = new ArrayList<>(items);
    }

    void clear() { timestamp = -1; last.clear(); }
}
