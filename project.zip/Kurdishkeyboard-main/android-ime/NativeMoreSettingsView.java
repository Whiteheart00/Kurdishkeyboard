package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;

final class NativeMoreSettingsView extends LinearLayout {
    private static final int BLUE = 0xffa4c9ff;
    private static final int MUTED = 0xffa1a1aa;
    private static final String[] LANGUAGE_CODES = {"ckb", "kmr", "en", "ar", "fa"};
    private static final String[] LANGUAGE_LABELS = {"کوردی سۆرانی", "Kurmancî", "English", "العربية", "فارسی"};

    private final NativeImeAppearance appearance;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final boolean locked;
    private final boolean hasIcons;
    private final int foreground;
    private final int border;
    private final LinearLayout status;
    private final TextView statusText;
    private final TextView statusPath;
    private final ScrollView scroll;

    NativeMoreSettingsView(Context context, String theme, String font, JSONObject data, Runnable back,
                           NativeClipboardSettingsView.Change change, Runnable pickBackup) {
        super(context);
        this.change = change;
        this.font = font;
        light = "light".equals(theme);
        locked = !data.optBoolean("proUnlocked");
        foreground = light ? 0xff0f172a : Color.WHITE;
        border = light ? 0xffe2e8f0 : 0x1affffff;
        NativeImeEngine icons = null;
        try { icons = new NativeImeEngine(context); } catch (IOException ignored) {}
        hasIcons = icons != null;
        appearance = new NativeImeAppearance(context, icons);
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK);

        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        header.setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = label("ڕێکخستنی زیاتر", 16, foreground, 700);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        divider(this);

        scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(12), dp(16), dp(24));
        scroll.addView(body);

        if (!data.optBoolean("notificationsEnabled")) {
            append(body, NativeSettingsNotification.create(context, appearance, font, change), 0, -2);
        }
        status = column();
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout statusTop = row();
        statusText = label("", 12, foreground, 700);
        statusTop.addView(statusText, new LayoutParams(0, -2, 1));
        TextView close = appearance.text("×", 18, foreground, "system", 700);
        close.setContentDescription("داخستن");
        close.setOnClickListener(v -> status.setVisibility(GONE));
        statusTop.addView(close, new LayoutParams(dp(28), dp(32)));
        append(status, statusTop, 0, -2);
        statusPath = appearance.text("", 11, foreground, "system", 400);
        statusPath.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        statusPath.setTextDirection(TEXT_DIRECTION_LTR);
        statusPath.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        statusPath.setTypeface(Typeface.MONOSPACE);
        statusPath.setPadding(dp(10), dp(6), dp(10), dp(6));
        statusPath.setBackground(appearance.background(0x40000000, 12, 0, 0));
        append(status, statusPath, 6, -2);
        status.setVisibility(GONE);
        append(body, status, 12, -2);

        String currentLanguage = data.optString("appLanguage");
        LinearLayout languagePicker = column();
        append(languagePicker, setting("ic_language", "زمانی ڕووکاری بەرنامە", "کوردی سۆرانی · Kurmancî · English · العربية · فارسی", false), 0, -2);
        LinearLayout choices = row();
        for (int i = 0; i < LANGUAGE_CODES.length; i++) {
            if (i == 3) {
                append(languagePicker, choices, 8, -2);
                choices = row();
            }
            String language = LANGUAGE_CODES[i];
            TextView button = appearance.text(LANGUAGE_LABELS[i], 12, foreground, font, 700);
            boolean active = currentLanguage.equals(language);
            button.setSelected(active);
            button.setTextColor(active ? 0xff051b3a : foreground);
            button.setBackground(appearance.background(active ? BLUE : light ? Color.WHITE : 0xff14171d, 12, 1, active ? BLUE : border));
            button.setOnClickListener(v -> change.accept("appLanguage", language));
            equal(choices, button, i % 3 == 0 ? 0 : 8);
        }
        equal(choices, new View(context), 8);
        append(languagePicker, choices, 8, -2);
        append(body, languagePicker, 10, -2);
        divider(body);

        String themeName = "amoled".equals(theme) ? "تاریکی تەواو (AMOLED)" : light ? "ڕووناک" : "تاریک";
        String nextTheme = "amoled".equals(theme) ? "dark" : light ? "amoled" : "light";
        action(body, "ic_themes", "ڕووکاری ڕێکخستنەکان", themeName, false, () -> change.accept("appTheme", nextTheme));
        toggle(body, "", "بەشی سەرەوە (شریتی ئامرازەکان)", "پیشاندانی شریتی کۆپی، بڕین، لکاندن و لەبەرگیراوەکان", "showTopToolbar", data);
        action(body, "ic_backup", "Google Drive · پاشەکەوت و گەڕاندنەوە", "پاشەکەوتی شفرەکراو، Clipboard و پاشەکەوتی خۆکار", false, () -> change.accept("cloudBackup", true));
        action(body, "ic_download", "گێڕانەوەی پاشەکەوتی کۆن", "فایلی JSON ـی وەشانی پێشوو (بێ شفرە)", false, pickBackup);
        toggle(body, "ic_keyboards", "تەختەکلیلی دەرەکی", "هاوتاکردنی نووسین لەگەڵ تەختەکلیلی کۆمپیوتەر", "physicalKeyboardSync", data);

        LinearLayout activity = setting("ic_library", "en".equals(currentLanguage) ? "Activity Logs & Reports" : "تۆماری چالاکی و ڕاپۆرتەکان",
                "Activity Logs & Reports · بینین، کۆپیکردن و بەڕێوەبردنی ڕاپۆرتە تەکنیکییەکان", false);
        activity.addView(appearance.text("‹", 20, MUTED, "system", 700), new LayoutParams(dp(20), -2));
        activity.setOnClickListener(v -> change.accept("activityLogs", true));
        append(body, activity, 14, -2);
        divider(body);

        TextView reset = appearance.text("↻  گەڕاندنەوەی هەموو ڕێکخستنەکان بۆ بنەڕەتی", 12,
                light ? 0xffbe123c : 0xfffda4af, font, 700);
        reset.setBackground(appearance.background(0x26f43f5e, 16, 1, 0x40f43f5e));
        reset.setOnClickListener(v -> change.accept("resetAll", true));
        append(body, reset, 20, 44);
        if (icons != null) icons.close();

        JSONObject imported = data.optJSONObject("backupStatus");
        if (imported != null) showStatus(imported.optString("message"), imported.optString("path"), false);
    }

    void importBackup(String payload) {
        change.accept("importBackup", payload);
    }

    void showStatus(String message, String path, boolean failed) {
        int color = failed ? (light ? 0xff9f1239 : 0xfffda4af) : (light ? 0xff065f46 : 0xffa7f3d0);
        status.setBackground(appearance.background(failed ? 0x26f43f5e : 0x2610b981, 16, 1,
                failed ? 0x59f43f5e : 0x5910b981));
        statusText.setText(message);
        statusText.setTextColor(color);
        statusPath.setText(path);
        statusPath.setTextColor(color);
        statusPath.setVisibility(path == null || path.isEmpty() ? GONE : VISIBLE);
        status.setVisibility(VISIBLE);
        scroll.post(() -> scroll.smoothScrollTo(0, 0));
    }

    private void action(LinearLayout body, String icon, String title, String subtitle, boolean pro, Runnable action) {
        LinearLayout view = setting(icon, title, subtitle, pro);
        view.setOnClickListener(v -> action.run());
        append(body, view, 14, -2);
        divider(body);
    }

    private void toggle(LinearLayout body, String icon, String title, String subtitle, String key, JSONObject data) {
        LinearLayout view = setting(icon, title, subtitle, false);
        NativeSettingsToggle control = new NativeSettingsToggle(getContext(), appearance, title,
                data.optBoolean(key), checked -> change.accept(key, checked));
        LayoutParams params = new LayoutParams(dp(52), dp(30));
        params.setMarginStart(dp(12));
        view.addView(control, params);
        append(body, view, 14, -2);
        divider(body);
    }

    private LinearLayout setting(String icon, String title, String subtitle, boolean pro) {
        LinearLayout result = row();
        result.setPadding(0, dp(8), 0, dp(8));
        if (hasIcons && !icon.isEmpty()) {
            ImageView image = new ImageView(getContext());
            image.setImageDrawable(appearance.icon(icon, MUTED, 20));
            LayoutParams params = new LayoutParams(dp(20), dp(20));
            params.setMarginEnd(dp(12));
            result.addView(image, params);
        }
        LinearLayout copy = column();
        LinearLayout heading = row();
        heading.addView(label(title, 14, foreground, 700), new LayoutParams(0, -2, 1));
        if (pro && locked) {
            TextView badge = appearance.text("PRO", 10, Color.WHITE, "system", 800);
            badge.setPadding(dp(6), dp(2), dp(6), dp(2));
            badge.setBackground(appearance.background(0xff465bcb, 6, 0, 0));
            heading.addView(badge);
        }
        append(copy, heading, 0, -2);
        append(copy, label(subtitle, 12, MUTED, 400), 2, -2);
        result.addView(copy, new LayoutParams(0, -2, 1));
        return result;
    }

    private TextView label(String value, int size, int color, int weight) {
        TextView view = appearance.text(value, size, color, font, weight);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private void divider(LinearLayout parent) {
        View line = new View(getContext());
        line.setBackgroundColor(border);
        append(parent, line, 0, 1);
    }

    private LinearLayout row() {
        LinearLayout view = new LinearLayout(getContext());
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(getContext());
        view.setOrientation(VERTICAL);
        return view;
    }

    private void append(LinearLayout parent, View view, int gap, int height) {
        LayoutParams params = new LayoutParams(-1, height < 0 ? height : dp(height));
        params.topMargin = dp(gap);
        parent.addView(view, params);
    }

    private void equal(LinearLayout layout, View view, int gap) {
        LayoutParams params = new LayoutParams(0, dp(36), 1);
        params.setMarginStart(dp(gap));
        layout.addView(view, params);
    }

    private int dp(int value) { return appearance.dp(value); }
}
