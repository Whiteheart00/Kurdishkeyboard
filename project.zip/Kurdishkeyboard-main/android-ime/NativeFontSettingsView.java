package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class NativeFontSettingsView extends LinearLayout {
    private static final String[] NUMERALS = {"١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "١٠"};
    private final NativeImeAppearance appearance;
    private final boolean light;
    private final int foreground;
    private final FontChoice[] choices = new FontChoice[11];
    private final NativeClipboardSettingsView.Change change;
    private String selected;

    NativeFontSettingsView(Context context, String theme, String font, Runnable back,
                           NativeClipboardSettingsView.Change change) {
        super(context);
        this.change = change;
        selected = font;
        appearance = new NativeImeAppearance(context, null);
        light = "light".equals(theme);
        foreground = light ? 0xff0f172a : Color.WHITE;
        setOrientation(VERTICAL);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);
        setBackgroundColor(light ? 0xfff8fafc : Color.BLACK);

        LinearLayout header = row();
        header.setPadding(dp(16), 0, dp(16), 0);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        header.addView(arrow, new LayoutParams(dp(40), -1));
        TextView title = appearance.text("شێوەی فۆنت", 16, foreground, font, 700);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        title.setPaddingRelative(dp(12), 0, 0, 0);
        header.addView(title, new LayoutParams(0, -1, 1));
        addView(header, new LayoutParams(-1, dp(55)));
        View divider = new View(context);
        divider.setBackgroundColor(light ? 0xffe2e8f0 : 0x0dffffff);
        addView(divider, new LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        addView(scroll, new LayoutParams(-1, 0, 1));
        LinearLayout body = new LinearLayout(context);
        body.setOrientation(VERTICAL);
        body.setPadding(dp(16), dp(24), dp(16), dp(16));
        scroll.addView(body);
        choices[0] = new FontChoice("system", "A", true);
        LayoutParams systemPosition = new LayoutParams(-2, dp(54));
        systemPosition.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(choices[0], systemPosition);
        body.addOnLayoutChangeListener((view, l, t, r, b, oldL, oldT, oldR, oldB) -> {
            int width = Math.min(dp(272), Math.round((r - l - dp(32)) * .7f));
            if (width > 0 && systemPosition.width != width) {
                systemPosition.width = width;
                choices[0].setLayoutParams(systemPosition);
            }
        });

        for (int index = 0; index < NUMERALS.length; index += 2) {
            LinearLayout line = row();
            for (int offset = 0; offset < 2; offset++) {
                int slot = index + offset;
                choices[slot + 1] = new FontChoice("kurdifont" + (slot + 1), NUMERALS[slot], false);
                LayoutParams position = new LayoutParams(0, dp(52), 1);
                if (offset != 0) position.setMarginStart(dp(12));
                line.addView(choices[slot + 1], position);
            }
            LayoutParams position = new LayoutParams(-1, -2);
            position.topMargin = dp(index == 0 ? 20 : 12);
            body.addView(line, position);
        }
    }

    private void select(String id) {
        selected = id;
        for (FontChoice choice : choices) choice.paint();
        change.accept("fontStyle", id);
    }

    private final class FontChoice extends LinearLayout {
        final String id;
        final boolean system;
        final TextView badge;
        final TextView name;

        FontChoice(String id, String numeral, boolean system) {
            super(NativeFontSettingsView.this.getContext());
            this.id = id;
            this.system = system;
            setFocusable(true);
            setGravity(system ? Gravity.CENTER : Gravity.CENTER_VERTICAL);
            setPadding(dp(12), 0, dp(12), 0);
            badge = appearance.text(numeral, system ? 13 : 12, foreground, "system", 800);
            int side = dp(system ? 22 : 28);
            addView(badge, new LayoutParams(side, side));
            name = appearance.text(system ? "فۆنتی سیستەم" : "تەختەکلیلی کوردی", system ? 15.5 : 13.5,
                    foreground, id, system ? 700 : 400);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LayoutParams namePosition = system ? new LayoutParams(-2, -2) : new LayoutParams(0, -2, 1);
            namePosition.setMarginStart(dp(system ? 10 : 8));
            addView(name, namePosition);
            setContentDescription(system ? "فۆنتی سیستەم" : "فۆنتی کوردی " + numeral);
            setOnClickListener(v -> select(id));
            paint();
        }

        void paint() {
            boolean active = id.equals(selected);
            setSelected(active);
            setBackground(appearance.background(active ? light ? 0xffecfdf5 : 0xff061c09 : light ? Color.WHITE : 0xff212224,
                    system ? 18 : 16, active ? 1.5 : light ? 1 : 0, active ? light ? 0xff059669 : 0xff227a2b : 0xffe2e8f0));
            badge.setTextColor(active ? system ? 0xff051407 : Color.WHITE : light ? 0xff334155 : 0xffe4e4e7);
            badge.setBackground(appearance.background(active ? 0xff227a2b : light ? 0xffe2e8f0 : 0xff353639,
                    system ? 5 : 14, 0, 0));
            name.setTextColor(active && light ? 0xff022c22 : foreground);
        }
    }

    private int dp(int size) { return appearance.dp(size); }
    private LinearLayout row() {
        LinearLayout line = new LinearLayout(getContext());
        line.setGravity(Gravity.CENTER_VERTICAL);
        return line;
    }
}
