package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;
import static io.kurdikebord.app.NativeImeData.arr;
import static io.kurdikebord.app.NativeImeData.contains;
import static io.kurdikebord.app.NativeImeData.obj;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class NativeImeMediaPanel {
    private static final String[] ZIKR = {"duaa", "quran", "salawat"};
    private static final String[] ZIKR_NAMES = {"دوعا و زیکر", "قورئانی", "سەڵاوات"};
    private static final String[] ZIKR_ICONS = {"ic_zikr", "ic_ayat", "ic_tasbih1"};
    private static final String RECENT = "recent";
    private static final String EMOJI = "emoji";
    private static final String KAOMOJI = "kaomoji";
    private final NativeImeView keyboard;
    private final NativeImeEngine engine;
    private final NativeImePanelStyle ui;
    private final Runnable search;
    private final NativeImeEmojiGlyphs glyphs;
    private String tab = EMOJI;
    private String category = RECENT;
    private String zikrCategory = RECENT;
    private String kaomojiCategory = RECENT;
    private FrameLayout panel;
    private FrameLayout overlay;
    private ListView list;
    private String listKey;
    private HorizontalScrollView categoryScroll;
    private String categoryScrollTab;

    NativeImeMediaPanel(NativeImeView keyboard, NativeImePanelStyle ui, Runnable search) {
        this.keyboard = keyboard;
        this.engine = keyboard.engine;
        this.ui = ui;
        this.search = search;
        glyphs = new NativeImeEmojiGlyphs(keyboard);
    }

    void open() {
        tab = EMOJI;
        category = keyboard.settings.optString("emojiLastUsedCategory", RECENT);
        if (historyEnabled() && "recent".equals(keyboard.settings.optString("emojiInitialTab"))) category = RECENT;
        zikrCategory = RECENT;
        kaomojiCategory = RECENT;
        closePanel();
    }

    void closePanel() {
        dismissOverlay();
        list = null;
        categoryScroll = null;
        panel = null;
    }

    void close() {
        closePanel();
        glyphs.close();
    }

    private JSONObject media() { return engine.object("media", null); }
    private boolean historyEnabled() { return keyboard.settings.optBoolean("emojiHistoryEnabled"); }
    private int dp(int size) { return ui.dp(size); }
    private int muted() { return ui.color(0xff64748b, 0xffa1a1aa); }
    private int activeText() {
        return "facebook".equals(keyboard.settings.optString("emojiStyle"))
                ? ui.color(0xff0084ff, 0xff4aa8ff) : ui.color(0xff1d4ed8, 0xff74b3ff);
    }
    private int activeFill() {
        return "facebook".equals(keyboard.settings.optString("emojiStyle"))
                ? ui.color(0x260084ff, 0x400084ff) : ui.color(0xffdbeafe, 0xff17283d);
    }

    View render() {
        dismissOverlay();
        List<JSONObject> enabled = enabledCategories();
        if (EMOJI.equals(tab) && !(RECENT.equals(category) && historyEnabled())) {
            boolean found = false;
            for (JSONObject entry : enabled) found |= category.equals(entry.optString("id"));
            if (!found) category = enabled.isEmpty() ? "" : enabled.get(0).optString("id");
        }
        String key = tab + "/" + category + "/" + zikrCategory + "/" + kaomojiCategory;
        int position = 0, offset = 0;
        if (list != null && key.equals(listKey) && list.getChildCount() > 0) {
            position = list.getFirstVisiblePosition();
            offset = list.getChildAt(0).getTop() - list.getPaddingTop();
        }

        panel = new FrameLayout(keyboard.getContext());
        int height = Math.max(keyboard.settings.optInt("keyboardHeightPx") + 44, 332);
        panel.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(height)));
        panel.setBackgroundColor(keyboard.bg());
        LinearLayout content = keyboard.column();
        content.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        panel.addView(content, new FrameLayout.LayoutParams(-1, -1));
        addCategories(content, enabled);
        if (EMOJI.equals(tab)) addSearch(content);

        list = new ListView(keyboard.getContext());
        list.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(dp(8), dp(6), dp(8), dp(6));
        list.setClipToPadding(false);
        list.setVerticalScrollBarEnabled(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setItemsCanFocus(true);
        list.setAdapter(new Rows(rows(enabled)));
        content.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        listKey = key;
        if (position > 0 || offset != 0) list.setSelectionFromTop(position, offset);
        addBottomBar(content);
        return panel;
    }

    // The media panel owns its children. Keep the outer keyboard and input connection intact.
    boolean refreshAttached() {
        if (panel == null || !(panel.getParent() instanceof ViewGroup) || !panel.isAttachedToWindow()) return false;
        FrameLayout old = panel;
        ViewGroup parent = (ViewGroup) old.getParent();
        int index = parent.indexOfChild(old);
        if (index < 0) return false;
        View replacement = render();
        parent.removeViewAt(index);
        parent.addView(replacement, index);
        return true;
    }

    private void refreshOrRender() { if (!refreshAttached()) keyboard.render(); }

    private List<JSONObject> enabledCategories() {
        JSONArray items = arr(media(), "categories");
        JSONArray order = arr(keyboard.settings, "emojiCategoryOrder");
        JSONArray disabled = arr(keyboard.settings, "emojiDisabledCategories");
        Set<String> seen = new HashSet<>();
        List<JSONObject> result = new ArrayList<>();
        for (int i = 0; i < order.length() + items.length(); i++) {
            JSONObject entry = i < order.length() ? NativeImeData.find(items, "id", order.optString(i))
                    : items.optJSONObject(i - order.length());
            if (entry == null) continue;
            String id = entry.optString("id");
            if (!contains(disabled, id) && seen.add(id)) result.add(entry);
        }
        return result;
    }

    private void addCategories(LinearLayout content, List<JSONObject> enabled) {
        int scrollX = categoryScroll != null && tab.equals(categoryScrollTab) ? categoryScroll.getScrollX() : 0;
        LinearLayout header = keyboard.row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        ui.padding(header, 10, 6);
        LinearLayout chips = keyboard.row();
        chips.setGravity(Gravity.CENTER_VERTICAL);
        categoryScroll = new HorizontalScrollView(keyboard.getContext());
        categoryScrollTab = tab;
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        categoryScroll.addView(chips, new FrameLayout.LayoutParams(-2, -1));
        header.addView(categoryScroll, new LinearLayout.LayoutParams(0, dp(40), 1));
        if (EMOJI.equals(tab)) {
            if (historyEnabled()) categoryChip(chips, "دوایینەکان", "ic_history1", null,
                    RECENT.equals(category), () -> selectCategory(RECENT));
            for (JSONObject item : enabled) {
                String id = item.optString("id");
                categoryChip(chips, item.optString("label"), null, item.optString("icon"),
                        id.equals(category), () -> selectCategory(id));
            }
        } else if (KAOMOJI.equals(tab)) {
            categoryChip(chips, "دوایینەکان", "ic_history1", null, RECENT.equals(kaomojiCategory), () -> setSubTab(RECENT));
            categoryChip(chips, "کاومۆجی", "ic_kaomoji", null, "all".equals(kaomojiCategory), () -> setSubTab("all"));
        } else {
            categoryChip(chips, "دوایینەکان", "ic_history1", null, RECENT.equals(zikrCategory), () -> setSubTab(RECENT));
            for (int i = 0; i < ZIKR.length; i++) {
                String id = ZIKR[i];
                categoryChip(chips, ZIKR_NAMES[i], ZIKR_ICONS[i], null, id.equals(zikrCategory), () -> setSubTab(id));
            }
        }
        if (scrollX > 0) {
            HorizontalScrollView current = categoryScroll;
            current.post(() -> current.scrollTo(scrollX, 0));
        }
        ui.add(header, ui.iconButton("ic_settings", "ڕێکخستنی خەندەکان", ui.foreground(), 16,
                Color.TRANSPARENT, 18, keyboard.editor::openEmojiSettings), 36, 36, 4);
        content.addView(header);
        rule(content);
    }

    private void categoryChip(LinearLayout chips, String label, String icon, String emoji, boolean active, Runnable action) {
        LinearLayout chip = keyboard.row();
        chip.setGravity(Gravity.CENTER);
        chip.setContentDescription(label);
        chip.setSelected(active);
        chip.setBackground(pressFace(active ? activeFill() : Color.TRANSPARENT, 18));
        if (active) ui.padding(chip, 12, 0);
        if (emoji != null) { View glyph = glyphs.view(emoji, 18); glyph.setAlpha(active ? 1f : .75f); ui.add(chip, glyph, 18, 25, 0); }
        else ui.add(chip, ui.icon(icon, active ? activeText() : muted(), 16), 16, 16, 0);
        if (active) ui.add(chip, ui.text(label, 11, activeText(), 700), -2, -1, 6);
        ui.press(chip, action);
        ui.add(chips, chip, active ? -2 : 36, 36, chips.getChildCount() == 0 ? 0 : 4);
    }

    private void selectCategory(String selected) {
        if (selected.equals(category)) return;
        category = selected;
        if (selected.equals(keyboard.settings.optString("emojiLastUsedCategory"))) refreshOrRender();
        else keyboard.settingsPatch(json("emojiLastUsedCategory", selected));
    }

    private void setSubTab(String selected) {
        if (KAOMOJI.equals(tab)) kaomojiCategory = selected;
        else zikrCategory = selected;
        refreshOrRender();
    }

    private void addSearch(LinearLayout content) {
        LinearLayout row = keyboard.column();
        row.setPadding(dp(10), dp(8), dp(10), dp(4));
        TextView button = ui.button("گەڕان لە ١٦١٧ خەندە بە کوردی یان ئینگلیزی (دڵ، پێکەنین، heart)...",
                12, muted(), 500, ui.color(Color.WHITE, 0x0fffffff), 12, ui.border(), 12, search);
        button.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        ui.startIcon(button, "search", NativeImePanelStyle.SKY, 14, 8);
        ui.add(row, button, -1, 36, 0);
        content.addView(row);
    }

    private void addBottomBar(LinearLayout content) {
        rule(content);
        LinearLayout bottom = keyboard.row();
        ui.padding(bottom, 10, 8);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        ui.add(bottom, ui.iconButton("ic_keyboards", "گەڕانەوە بۆ تەختەکلیل",
                theme("specialKeyText", ui.foreground()), 20, theme("specialKeyBg", keyboard.keyColor()), 12,
                () -> keyboard.openPanel("keys")), 56, 44, 0);
        switcher(bottom, EMOJI, "خەندەکان", "ic_xanda");
        switcher(bottom, "zikr", "زیکر", "ic_tasbih1");
        switcher(bottom, KAOMOJI, "کاومۆجی", "ic_kaomoji");
        ui.add(bottom, ui.iconButton("ic_delete", "سڕینەوە",
                theme("backspaceText", theme("specialKeyText", ui.foreground())), 20,
                theme("backspaceBg", theme("specialKeyBg", keyboard.keyColor())), 12, () -> keyboard.backspace(false)), 56, 44, 0);
        content.addView(bottom);
    }

    private void switcher(LinearLayout bar, String id, String label, String icon) {
        boolean active = id.equals(tab);
        LinearLayout button = keyboard.column();
        button.setGravity(Gravity.CENTER);
        button.setSelected(active);
        button.setContentDescription(label);
        ui.add(button, ui.icon(icon, active ? 0xff5ba4ff : muted(), 16), 16, 16, 0);
        TextView tag = ui.text(label, 10.5, active ? activeText() : muted(), 600);
        ui.truncate(tag);
        ui.padding(tag, 5, 0);
        tag.setBackground(ui.face(active ? activeFill() : ui.color(0xcce2e8f0, 0xcc27272a), 8, 0));
        ui.add(button, tag, -2, 17, 2);
        ui.press(button, () -> { if (!id.equals(tab)) { tab = id; refreshOrRender(); } });
        ui.flex(bar, button, 44, 0);
    }

    private void rule(LinearLayout content) {
        View line = new View(keyboard.getContext());
        line.setBackgroundColor(ui.color(0xffe2e8f0, 0x0dffffff));
        ui.add(content, line, -1, 1, 0);
    }

    private int theme(String key, int fallback) { return keyboard.appearance.color(keyboard.theme, key, fallback); }
    private GradientDrawable face(int fill, int radius) { return keyboard.appearance.background(fill, radius, 0, 0); }
    private RippleDrawable pressFace(int fill, int radius) {
        return new RippleDrawable(ColorStateList.valueOf(ui.color(0x200f172a, 0x20ffffff)),
                face(fill, radius), face(Color.WHITE, radius));
    }

    private JSONObject history(String kind) {
        if (EMOJI.equals(kind)) return json("pinned", arr(keyboard.settings, "emojiPinned"), "recent", arr(keyboard.settings, "recentEmojis"));
        if (KAOMOJI.equals(kind)) return json("pinned", arr(keyboard.settings, "kaomojiPinned"), "recent", arr(keyboard.settings, "recentKaomoji"));
        return obj(obj(keyboard.settings, "zikrHistories"), kind);
    }

    void record(String kind, String value) {
        if (!historyEnabled()) return;
        JSONObject current = history(kind);
        JSONObject next = NativeImeMedia.recordHistory(new JSONArray().put(current).put(value)
                .put(keyboard.settings.optString("emojiHistoryUpdateStrategy")).put(keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40)));
        if (!next.toString().equals(current.toString())) saveHistory(kind, next);
    }

    private void pin(Cell cell) {
        dismissOverlay();
        saveHistory(cell.kind, NativeImeMedia.togglePin(new JSONArray().put(history(cell.kind)).put(cell.value)
                .put(keyboard.settings.optInt("emojiHistoryPinnedMaxSize", 24)).put(keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40))));
    }

    private void saveHistory(String kind, JSONObject next) {
        if (EMOJI.equals(kind)) keyboard.settingsPatch(json("emojiPinned", arr(next, "pinned"), "recentEmojis", arr(next, "recent")));
        else if (KAOMOJI.equals(kind)) keyboard.settingsPatch(json("kaomojiPinned", arr(next, "pinned"), "recentKaomoji", arr(next, "recent")));
        else {
            JSONObject histories = NativeImeData.copy(obj(keyboard.settings, "zikrHistories"));
            put(histories, kind, next);
            LinkedHashSet<String> combined = new LinkedHashSet<>();
            for (String bucket : new String[]{"pinned", RECENT}) {
                for (String section : ZIKR) {
                    JSONArray values = arr(obj(histories, section), bucket);
                    for (int i = 0; i < values.length(); i++) combined.add(values.optString(i));
                }
            }
            JSONArray recent = new JSONArray();
            for (String value : combined) {
                if (recent.length() >= keyboard.settings.optInt("emojiHistoryRecentMaxSize", 40)) break;
                recent.put(value);
            }
            keyboard.settingsPatch(json("zikrHistories", histories, "recentZikr", recent));
        }
    }

    private List<Row> rows(List<JSONObject> enabled) {
        List<Row> result = new ArrayList<>();
        if (EMOJI.equals(tab)) {
            int columns = Math.max(4, Math.min(12, keyboard.settings.optInt("emojiColumns", 7)));
            if (RECENT.equals(category)) {
                historyRows(result, EMOJI, columns, "ئیمۆجییە پینکراوەکان", "دوایین بەکارهاتووەکان");
                if (arr(history(EMOJI), "pinned").length() + arr(history(EMOJI), RECENT).length() == 0) result.add(new Row("هێشتا هیچ ئیمۆجییەکت بەکارنەهێناوە · دەستڕاگرتن لەسەر هەر ئیمۆجییەک پینی دەکات"));
            } else {
                for (JSONObject entry : enabled) if (category.equals(entry.optString("id"))) {
                    section(result, entry.optString("label"), EMOJI, arr(entry, "items"), columns, false);
                }
            }
        } else if (KAOMOJI.equals(tab)) {
            if (RECENT.equals(kaomojiCategory)) {
                historyRows(result, KAOMOJI, 3, "کاومۆجی پینکراوەکان", "دوایین کاومۆجییەکان");
                if (arr(history(KAOMOJI), "pinned").length() + arr(history(KAOMOJI), RECENT).length() == 0)
                    result.add(new Row("هێشتا هیچ کاومۆجییەکت بەکارنەهێناوە"));
            }
            else section(result, "کاومۆجی", KAOMOJI, arr(media(), "kaomoji"), 3, false);
        } else {
            for (int i = 0; i < ZIKR.length; i++) {
                String kind = ZIKR[i];
                if (RECENT.equals(zikrCategory)) {
                    JSONObject store = history(kind);
                    if (arr(store, "pinned").length() + arr(store, RECENT).length() > 0) {
                        historyRows(result, kind, 2, ZIKR_NAMES[i] + " · پینکراوەکان", ZIKR_NAMES[i]);
                    }
                } else if (kind.equals(zikrCategory)) {
                    JSONArray pinned = arr(history(kind), "pinned");
                    if (pinned.length() > 0) section(result, "پینکراوەکان", kind, pinned, 2, true);
                    section(result, ZIKR_NAMES[i], kind, arr(obj(media(), "zikr"), kind), 2, false);
                }
            }
            if (result.isEmpty()) result.add(new Row("هێشتا هیچ زیکرێکت بەکارنەهێناوە"));
        }
        return result;
    }

    private void historyRows(List<Row> rows, String kind, int columns, String pinnedTitle, String recentTitle) {
        JSONObject store = history(kind);
        JSONArray pinned = arr(store, "pinned");
        if (pinned.length() > 0) section(rows, pinnedTitle, kind, pinned, columns, true);
        section(rows, recentTitle, kind, arr(store, RECENT), columns, false);
    }

    private void section(List<Row> rows, String title, String kind, JSONArray entries, int columns, boolean pinned) {
        rows.add(new Row(title, entries.length(), pinned));
        for (int i = 0; i < entries.length(); i += columns) rows.add(new Row(kind, entries, i, columns));
    }

    private Cell cell(Row row, int i) {
        JSONObject entry = row.entries.optJSONObject(i);
        if (entry == null) {
            String value = row.entries.optString(i);
            return new Cell(row.kind, value, value, value, null);
        }
        if (EMOJI.equals(row.kind)) {
            String value = engine.text("emojiModifier", json("entry", entry,
                    "skin", keyboard.settings.optString("emojiSkinTone"), "hair", keyboard.settings.optString("emojiHairStyle")));
            return new Cell(row.kind, value, value, entry.optString("k", entry.optString("e", value)), entry);
        }
        return new Cell(row.kind, NativeImeData.trim(entry.optString("v")), entry.optString("d"),
                entry.optString("v"), null);
    }

    private void insert(Cell cell) {
        dismissOverlay();
        keyboard.feedback("char");
        keyboard.insert(EMOJI.equals(cell.kind) ? cell.value : cell.value + " ");
        record(cell.kind, cell.value);
    }

    private void showActions(Cell cell) {
        boolean pinned = contains(arr(history(cell.kind), "pinned"), cell.value);
        if (cell.entry != null) {
            LinearLayout popup = overlay(-2, 10);
            LinearLayout options = keyboard.row();
            options.setGravity(Gravity.CENTER);
            JSONArray variants = engine.array("emojiVariants", json("entry", cell.entry, "skin", keyboard.settings.optString("emojiSkinTone")));
            int columns = Math.max(1, Math.min(6, (panel.getWidth() - dp(44)) / dp(44)));
            List<String> values = new ArrayList<>();
            if (variants.length() <= 1) values.add(cell.value);
            else for (int i = 0; i < variants.length(); i++) values.add(variants.optString(i));
            for (int i = 0; i < values.size(); i++) {
                if (i % columns == 0) {
                    options = keyboard.row();
                    options.setGravity(Gravity.CENTER);
                    ui.add(popup, options, -1, 40, i == 0 ? 0 : 4);
                }
                String value = values.get(i);
                View glyph = glyphs.view(value, 26);
                glyph.setBackground(pressFace(Color.TRANSPARENT, 12));
                bindInsert(glyph, () -> insert(new Cell(EMOJI, value, value, value, null)));
                ui.add(options, glyph, 40, 40, i % columns == 0 ? 0 : 4);
            }
            actionBar(popup, cell, pinned, true);
        } else {
            int width = Math.min(320, Math.round(panel.getWidth() * .88f / keyboard.appearance.px(1)));
            LinearLayout popup = overlay(width, 12);
            LinearLayout header = ui.row();
            View label = EMOJI.equals(cell.kind) ? glyphs.view(cell.value, 24) : ui.text(cell.label, 14, ui.foreground(), 700);
            ui.flex(header, label, 28, 0);
            ui.add(header, ui.close(this::dismissOverlay, 14), 28, 28, 8);
            popup.addView(header);
            actionBar(popup, cell, pinned, false);
        }
    }

    private LinearLayout overlay(int width, int padding) {
        dismissOverlay();
        overlay = new FrameLayout(keyboard.getContext());
        overlay.setOnClickListener(v -> dismissOverlay());
        panel.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout popup = keyboard.column();
        popup.setClickable(true);
        ui.padding(popup, 12, padding);
        popup.setBackground(ui.face(theme("popupBg", ui.color(Color.WHITE, 0xff1b1e26)), 16, ui.border()));
        popup.setElevation(dp(12));
        overlay.addView(popup, new FrameLayout.LayoutParams(dp(width), -2, Gravity.CENTER));
        return popup;
    }

    private void dismissOverlay() {
        if (panel != null && overlay != null) panel.removeView(overlay);
        overlay = null;
    }

    private void actionBar(LinearLayout popup, Cell cell, boolean pinned, boolean variant) {
        LinearLayout row = ui.row();
        int color = ui.color(0xff075985, 0xff8ec2ff);
        ui.flex(row, action(pinned ? "pin_off" : "pin", pinned ? "لابردنی پین" : "پینکردن", color, 0x3338bdf8, () -> pin(cell)), 34, 0);
        if (variant) ui.add(row, ui.close(this::dismissOverlay, 14), 32, 32, 8);
        else ui.flex(row, action("trash_2", "سڕینەوە", ui.color(0xffbe123c, 0xfffda4af), 0x33f43f5e, () -> remove(cell)), 34, 6);
        ui.add(popup, row, -1, 34, 8);
        if (variant || (!pinned && !keyboard.settings.optString("emojiHistoryUpdateStrategy").startsWith("manual"))) return;
        LinearLayout moves = ui.row();
        ui.flex(moves, action("arrow_right", "جووڵاندن بۆ پێش", ui.mutedText(), ui.mutedFill(), () -> move(cell, pinned, -1)), 36, 0);
        ui.flex(moves, action("ic_arrow_left", "جووڵاندن بۆ دواوە", ui.mutedText(), ui.mutedFill(), () -> move(cell, pinned, 1)), 36, 6);
        ui.add(popup, moves, -1, 36, 6);
    }

    private TextView action(String icon, String label, int color, int background, Runnable command) {
        TextView view = ui.button(label, 11, color, 700, background, 12, 0, 5, command);
        ui.startIcon(view, icon, color, 14, 4);
        return view;
    }

    private void remove(Cell cell) {
        dismissOverlay();
        JSONObject store = history(cell.kind);
        JSONObject result = new JSONObject();
        for (String key : new String[]{"pinned", RECENT}) {
            JSONArray values = arr(store, key);
            JSONArray next = new JSONArray();
            for (int i = 0; i < values.length(); i++) if (!cell.value.equals(values.optString(i))) next.put(values.opt(i));
            put(result, key, next);
        }
        saveHistory(cell.kind, result);
    }

    private void move(Cell cell, boolean pinned, int delta) {
        String bucket = pinned ? "pinned" : RECENT;
        JSONObject store = NativeImeData.copy(history(cell.kind));
        JSONArray values = arr(store, bucket);
        for (int i = 0; i < values.length(); i++) if (cell.value.equals(values.optString(i))) {
            int to = i + delta;
            if (to < 0 || to >= values.length()) return;
            JSONArray reordered = new JSONArray();
            for (int j = 0; j < values.length(); j++) {
                reordered.put(values.opt(j == i ? to : j == to ? i : j));
            }
            put(store, bucket, reordered);
            dismissOverlay();
            saveHistory(cell.kind, store);
            FrameLayout current = panel;
            if (current != null) current.post(() -> { if (panel == current) showActions(cell); });
            return;
        }
    }

    void bindInsert(View view, Runnable insert) {
        view.setFocusable(true);
        view.setSoundEffectsEnabled(false);
        view.setOnClickListener(v -> insert.run());
    }

    View searchGlyph(String value, int size) { return glyphs.view(value, size); }

    private final class Rows extends BaseAdapter {
        private final List<Row> rows;
        Rows(List<Row> rows) { this.rows = rows; }
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 3; }
        @Override public int getItemViewType(int i) { return rows.get(i).entries != null ? 0 : rows.get(i).count >= 0 ? 1 : 2; }
        @Override public View getView(int index, View convertView, ViewGroup parent) {
            Row row = rows.get(index);
            if (row.entries == null) {
                LinearLayout box = convertView instanceof LinearLayout ? (LinearLayout) convertView : keyboard.column();
                box.removeAllViews();
                if (row.count < 0) {
                    TextView empty = ui.text(row.title, 12, muted(), 500);
                    ui.padding(empty, 10, 18);
                    ui.add(box, empty, -1, 76, 0);
                } else {
                    LinearLayout title = ui.row();
                    ui.padding(title, 10, 0);
                    title.setBackground(new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT,
                            new int[]{ui.color(0xe6e2e8f0, 0x14ffffff), ui.color(0x80e2e8f0, 0x0affffff), Color.TRANSPARENT}));
                    TextView label = ui.text(row.title, 11, ui.color(0xff334155, 0xffd4d4d8), 700);
                    label.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                    if (row.pinned) ui.startIcon(label, "pin", 0xff74b3ff, 12, 6);
                    ui.flex(title, label, 24, 0);
                    ui.add(title, ui.text(String.valueOf(row.count), 10, muted(), 500), -2, 24, 0);
                    ui.add(box, title, -1, 24, index == 0 ? 0 : 6);
                }
                return box;
            }
            LinearLayout line = convertView instanceof LinearLayout ? (LinearLayout) convertView : keyboard.row();
            line.removeAllViews();
            line.setPadding(0, dp(4), 0, 0);
            boolean emoji = EMOJI.equals(row.kind);
            boolean kaomoji = KAOMOJI.equals(row.kind);
            int emojiSize = Math.max(18, Math.min(36, keyboard.settings.optInt("emojiFontSizePx", 24)));
            int zikrSize = Math.max(10, Math.min(18, keyboard.settings.optInt("zikrFontSizePx", 12)));
            int height = emoji ? Math.max(38, Math.round(emojiSize * 1.75f)) : kaomoji ? 44 : 48;
            JSONArray pinnedValues = arr(history(row.kind), "pinned");
            for (int i = 0; i < row.columns; i++) {
                View view;
                if (row.start + i < row.entries.length()) {
                    Cell cell = cell(row, row.start + i);
                    boolean pinned = contains(pinnedValues, cell.value);
                    FrameLayout tile = new FrameLayout(keyboard.getContext());
                    View label = emoji ? glyphs.view(cell.value, emojiSize)
                            : ui.text(cell.label, kaomoji ? Math.max(11, zikrSize + 1) : zikrSize, ui.foreground(), kaomoji ? 600 : 500);
                    if (label instanceof TextView && !emoji) {
                        TextView text = (TextView) label;
                        text.setMaxLines(kaomoji ? 1 : 2);
                        text.setEllipsize(android.text.TextUtils.TruncateAt.END);
                        ui.padding(text, kaomoji ? 5 : 8, 0);
                    }
                    tile.addView(label, new FrameLayout.LayoutParams(-1, -1));
                    if (pinned && emoji) dot(tile, 6, 0xff74b3ff, Gravity.TOP | Gravity.RIGHT);
                    if (cell.entry != null && arr(cell.entry, "v").length() > 0) dot(tile, 4, 0xb371717a, Gravity.BOTTOM | Gravity.RIGHT);
                    tile.setContentDescription(cell.description);
                    tile.setBackground(pressFace(emoji ? Color.TRANSPARENT : pinned ? 0x2038bdf8
                            : ui.color(0x08000000, 0x0affffff), 12));
                    bindInsert(tile, () -> insert(cell));
                    tile.setOnLongClickListener(v -> { showActions(cell); return true; });
                    view = tile;
                } else view = new View(keyboard.getContext());
                ui.flex(line, view, height, i == 0 ? 0 : emoji ? 4 : 6);
            }
            line.setLayoutParams(new AbsListView.LayoutParams(-1, dp(height + 4)));
            return line;
        }
    }

    private void dot(FrameLayout tile, int size, int color, int gravity) {
        View marker = new View(keyboard.getContext());
        marker.setBackground(face(color, size));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(size), dp(size), gravity);
        params.setMargins(dp(4), dp(4), dp(4), dp(4));
        tile.addView(marker, params);
    }

    private static final class Row {
        final String title, kind;
        final int count, start, columns;
        final boolean pinned;
        final JSONArray entries;
        Row(String title) { this(title, -1, false); }
        Row(String title, int count, boolean pinned) {
            this.title = title; this.count = count; this.pinned = pinned;
            kind = null; entries = null; start = 0; columns = 0;
        }
        Row(String kind, JSONArray entries, int start, int columns) {
            this.kind = kind; this.entries = entries; this.start = start; this.columns = columns;
            title = null; count = -1; pinned = false;
        }
    }

    private static final class Cell {
        final String kind, value, label, description;
        final JSONObject entry;
        Cell(String kind, String value, String label, String description, JSONObject entry) {
            this.kind = kind; this.value = value; this.label = label; this.description = description; this.entry = entry;
        }
    }
}
