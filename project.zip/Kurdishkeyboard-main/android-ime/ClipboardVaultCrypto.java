package io.kurdikebord.app;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
final class ClipboardVaultCrypto {
    private static final byte[] AAD="io.kurdikebord.app/clipboard/v1".getBytes(StandardCharsets.UTF_8);
    static byte[] seal(SecretKey key,String text)throws Exception {
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key); c.updateAAD(AAD);
        byte[] plain=text.getBytes(StandardCharsets.UTF_8);
        try { byte[] enc=c.doFinal(plain),iv=c.getIV(); if(iv.length!=12)throw new java.security.GeneralSecurityException("Invalid IV");
            byte[] out=Arrays.copyOf(iv,12+enc.length);System.arraycopy(enc,0,out,12,enc.length);return out;
        } finally {Arrays.fill(plain,(byte)0);}
    }
    static String open(SecretKey key,byte[] blob)throws Exception {
        if(blob.length<28)throw new java.security.GeneralSecurityException("Invalid clipboard envelope");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,blob,0,12));c.updateAAD(AAD);
        byte[] plain=c.doFinal(blob,12,blob.length-12);try{return new String(plain,StandardCharsets.UTF_8);}finally{Arrays.fill(plain,(byte)0);}
    }
}
