package io.kurdikebord.app;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

final class NativeAboutView extends LinearLayout {
    NativeAboutView(Context context, String theme, String font, Runnable back) {
        super(context);
        NativeImeAppearance appearance = new NativeImeAppearance(context, null);
        boolean light = "light".equals(theme);
        int foreground = light ? 0xff0f172a : Color.WHITE;
        int surface = light ? 0xfff8fafc : "dark".equals(theme) ? 0xff0c0e12 : Color.BLACK;
        setOrientation(VERTICAL);
        setBackgroundColor(surface);
        setLayoutDirection(LAYOUT_DIRECTION_RTL);

        LinearLayout toolbar = new LinearLayout(context);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(appearance.dp(16), 0, appearance.dp(16), 0);
        toolbar.setBackgroundColor(light ? surface : Color.BLACK);
        TextView arrow = appearance.text("→", 20, foreground, "system", 500);
        arrow.setContentDescription("گەڕانەوە");
        arrow.setOnClickListener(v -> back.run());
        toolbar.addView(arrow, new LayoutParams(appearance.dp(40), -1));
        TextView heading = appearance.text("دەربارە", 16, foreground, font, 700);
        LayoutParams titlePosition = new LayoutParams(-2, -1);
        titlePosition.setMarginStart(appearance.dp(12));
        toolbar.addView(heading, titlePosition);
        addView(toolbar, new LayoutParams(-1, appearance.dp(55)));
        android.view.View divider = new android.view.View(context);
        divider.setBackgroundColor(light ? 0xffe2e8f0 : 0x0dffffff);
        addView(divider, new LayoutParams(-1, appearance.dp(1)));

        FrameLayout card = new FrameLayout(context);
        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x4d0a599c, 0x6605294a});
        face.setCornerRadius(appearance.px(24));
        face.setStroke(appearance.dp(1), 0x3338bdf8);
        card.setBackground(face);
        card.setElevation(appearance.dp(4));
        ImageView logo = new ImageView(context);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("تەختەکلیلی کوردی");
        try (InputStream input = context.getAssets().open("public/app-icon.png")) {
            logo.setImageBitmap(BitmapFactory.decodeStream(input));
        } catch (IOException ignored) {
            logo.setImageResource(context.getApplicationInfo().icon);
        }
        card.addView(logo, new FrameLayout.LayoutParams(appearance.dp(80), appearance.dp(80), Gravity.CENTER));
        LayoutParams cardPosition = new LayoutParams(appearance.dp(96), appearance.dp(96));
        cardPosition.gravity = Gravity.CENTER_HORIZONTAL;
        cardPosition.topMargin = appearance.dp(24);
        addView(card, cardPosition);

        addLabel(appearance, "تەختەکلیلی کوردی", 20, foreground, font, 800, 20);
        TextView website = addLabel(appearance, "www.kurdikebord.io", 12, 0xffa1a1aa, font, 400, 4);
        website.setTextDirection(TEXT_DIRECTION_LTR);
        TextView description = addLabel(appearance,
                "تەختەکلیلێکی پێشکەوتووی کوردی سۆرانی و فرەزمان کە پشتگیری تەواوی ڕووکارەکان، زیکر و دوعا قورئانییەکان، کاومۆجی، جوانکاری نووسین، لەبەرگیراوەکان، ڕیزبەندی تایبەت، وەرگێڕانی خێرا و وەڵامدەرەوەی زیرەکی (AI) دەکات.",
                12, 0xffa1a1aa, font, 400, 20);
        description.setLineSpacing(appearance.px(6), 1f);
    }

    private TextView addLabel(NativeImeAppearance appearance, String label, int size, int color, String font, int weight, int gap) {
        TextView text = appearance.text(label, size, color, font, weight);
        LayoutParams position = new LayoutParams(-2, -2);
        position.gravity = Gravity.CENTER_HORIZONTAL;
        position.topMargin = appearance.dp(gap);
        position.leftMargin = position.rightMargin = appearance.dp(16);
        text.setMaxWidth(appearance.dp(384));
        addView(text, position);
        return text;
    }
}
