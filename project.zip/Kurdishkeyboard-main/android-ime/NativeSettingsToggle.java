package io.kurdikebord.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.FrameLayout;

/** Native equivalent of the original AppToggle (52 x 30 dp, LTR in RTL pages). */
final class NativeSettingsToggle extends FrameLayout implements Checkable {
    interface Changed { void accept(boolean checked); }

    private final NativeImeAppearance appearance;
    private final View knob;
    private boolean checked;

    NativeSettingsToggle(Context context, NativeImeAppearance appearance, String label,
                         boolean initial, Changed changed) {
        super(context);
        this.appearance = appearance;
        setLayoutDirection(LAYOUT_DIRECTION_LTR);
        setContentDescription(label);
        setFocusable(true);
        knob = new View(context);
        knob.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        addView(knob);
        setChecked(initial);
        setOnClickListener(v -> {
            if (!isEnabled()) return;
            toggle();
            changed.accept(isChecked());
        });
    }

    @Override public boolean isChecked() { return checked; }

    @Override public void setChecked(boolean on) {
        checked = on;
        setSelected(on);
        setBackground(appearance.background(on ? 0xff9ac5ff : 0xff1d1f24,
                15, on ? 0 : 2, 0xff6c707a));
        int side = appearance.dp(on ? 22 : 16);
        LayoutParams params = new LayoutParams(side, side,
                Gravity.CENTER_VERTICAL | (on ? Gravity.RIGHT : Gravity.LEFT));
        // Original CSS: on: 3px + 22px translation; off: 2px border + 3px + 2px.
        params.leftMargin = appearance.dp(on ? 0 : 7);
        params.rightMargin = appearance.dp(on ? 5 : 0);
        knob.setLayoutParams(params);
        knob.setBackground(appearance.background(on ? 0xff0b3263 : 0xff8e939e,
                on ? 11 : 8, 0, 0));
    }

    @Override public void toggle() { setChecked(!checked); }

    @Override public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.4f);
    }

    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setClassName("android.widget.Switch");
        info.setCheckable(true);
        info.setChecked(isChecked());
    }
}
