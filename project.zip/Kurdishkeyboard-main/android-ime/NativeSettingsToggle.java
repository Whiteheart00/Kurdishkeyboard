package io.kurdikebord.app;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
final class NativeSettingsToggle extends FrameLayout {
    interface Changed { void accept(boolean checked); }
    private final NativeImeAppearance a;
    private final View knob;
    NativeSettingsToggle(Context context,NativeImeAppearance a,String label,boolean initial,Changed changed){super(context);this.a=a;setLayoutDirection(LAYOUT_DIRECTION_LTR);setContentDescription(label);setFocusable(true);knob=new View(context);addView(knob);paint(initial);setOnClickListener(v->{boolean next=!isSelected();paint(next);changed.accept(next);});}
    private void paint(boolean on){setSelected(on);setBackground(a.background(on?0xff9ac5ff:0xff1d1f24,15,on?0:2,0xff6c707a));int side=a.dp(on?22:16);LayoutParams lp=new LayoutParams(side,side,Gravity.CENTER_VERTICAL|(on?Gravity.RIGHT:Gravity.LEFT));lp.setMargins(a.dp(5),0,a.dp(5),0);knob.setLayoutParams(lp);knob.setBackground(a.background(on?0xff0b3263:0xff8e939e,12,0,0));}
    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(info);info.setClassName("android.widget.Switch");info.setCheckable(true);info.setChecked(isSelected());}
}
