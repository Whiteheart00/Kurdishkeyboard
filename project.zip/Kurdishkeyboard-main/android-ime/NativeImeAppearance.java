package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

final class NativeImeAppearance {
    private final Context context;
    private final float density;
    private final NativeImeEngine engine;
    private final Map<String, JSONObject> vectors = new HashMap<>();
    private static final Map<String, Typeface> fonts = new HashMap<>();
    private static final Map<String, Typeface> weightedFonts = new HashMap<>();
    private static JSONObject settingsIcons;
    // Geometry is independent of tint/size. Keep bounded, read-only paths; each Drawable owns its Paint.
    private static final android.util.LruCache<String, Path> PATH_CACHE = new android.util.LruCache<>(512);
    private static Path cachedPath(String data, boolean evenOdd) {
        String key = (evenOdd ? "E:" : "W:") + data;
        synchronized (PATH_CACHE) {
            Path existing = PATH_CACHE.get(key);
            if (existing != null) return existing;
            Path path = NativePathParser.createPathFromPathData(data);
            if (path != null) {
                if (evenOdd) path.setFillType(Path.FillType.EVEN_ODD);
                PATH_CACHE.put(key, path);
            }
            return path;
        }
    }

    NativeImeAppearance(Context context, NativeImeEngine engine) {
        this.context = context;
        this.engine = engine;
        density = context.getResources().getDisplayMetrics().density;
    }

    int dp(double number) { return (int) Math.round(number * density); }
    float px(double number) { return (float) (number * density); }

    static int color(String css, int fallback) {
        css = css.trim();
        if (css.isEmpty()) return fallback;
        if ("transparent".equals(css) || "none".equals(css)) return Color.TRANSPARENT;
        try {
            if (css.startsWith("#") && css.length() == 9) {
                return Color.parseColor("#" + css.substring(7, 9) + css.substring(1, 7));
            }
            if (css.startsWith("#") && (css.length() == 4 || css.length() == 5)) {
                StringBuilder hex = new StringBuilder("#");
                for (int index = 1; index < css.length(); index++) hex.append(css.charAt(index)).append(css.charAt(index));
                return color(hex.toString(), fallback);
            }
            if (css.startsWith("rgb")) {
                String[] values = css.substring(css.indexOf('(') + 1, css.indexOf(')')).split("[, ]+");
                return Color.argb(values.length == 4 ? (int) Math.round(255 * Double.parseDouble(values[3])) : 255,
                        Integer.parseInt(values[0]), Integer.parseInt(values[1]), Integer.parseInt(values[2]));
            }
            return Color.parseColor(css);
        } catch (IllegalArgumentException | IndexOutOfBoundsException ignored) {
            return fallback;
        }
    }

    int color(JSONObject json, String name, int fallback) { return color(json.optString(name), fallback); }

    Typeface font(String name, int weight) {
        synchronized (fonts) {
        if (!fonts.containsKey(name)) {
            Typeface result;
            if (name.matches("kurdifont(?:[1-9]|10)")) {
                try {
                    String extension = name.equals("kurdifont3") ? ".otf" : ".ttf";
                    result = Typeface.createFromAsset(context.getAssets(), "public/fonts/" + name + extension);
                } catch (RuntimeException e) { result = Typeface.DEFAULT; }
            } else {
                String family = "amiri".equals(name) || "naskh".equals(name) ? "serif" : "sans-serif";
                result = Typeface.create(family, Typeface.NORMAL);
            }
            fonts.put(name, result);
        }
        String key = name + ":" + weight;
        Typeface weighted = weightedFonts.get(key);
        if (weighted == null) {
            weighted = android.os.Build.VERSION.SDK_INT >= 28 ? Typeface.create(fonts.get(name), weight, false)
                : Typeface.create(fonts.get(name), weight >= 600 ? Typeface.BOLD : Typeface.NORMAL);
            weightedFonts.put(key, weighted);
        }
        return weighted;
        }
    }

    TextView text(String label, double size, int tint, String font, int weight) {
        TextView view = new TextView(context);
        view.setText(label);
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size));
        view.setTextColor(tint);
        view.setTypeface(font(font, weight));
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(false);
        view.setTextDirection(TextView.TEXT_DIRECTION_FIRST_STRONG);
        view.setPadding(0, 0, 0, 0);
        return view;
    }

    GradientDrawable background(int fill, double radius, double strokeWidth, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(px(radius));
        if (strokeWidth > 0) drawable.setStroke(Math.max(1, dp(strokeWidth)), stroke);
        return drawable;
    }

    /** CSS border-box geometry: the visible key occupies its entire assigned rectangle. */
    Drawable keyFace(JSONObject style, int fallback) {
        if (style == null) return background(fallback, 9, 0, 0);
        double radius = cssNumber(style.optString("borderRadius"), 9);
        String[] border = style.optString("border").split(" +", 3);
        int fill = color(style, "backgroundColor", fallback);
        double strokeW = border.length == 3 ? cssNumber(border[0], 0) : 0;
        int stroke = border.length == 3 ? color(border[2], 0) : 0;
        return new KeySurface(fill, px(radius), px(strokeW), stroke, style);
    }

    // Inset CSS highlights are drawn inside the face, not by shrinking its background.
    private static final class KeySurface extends Drawable {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final android.graphics.RectF rect = new android.graphics.RectF();
        final int fill, stroke, highlight;
        final float radius, border;
        KeySurface(int fill, float radius, float border, int stroke, JSONObject style) {
            this.fill = fill; this.radius = radius; this.border = border; this.stroke = stroke;
            String depth = style.optString("depth"); boolean light = style.optBoolean("light");
            if ("raised3d".equals(depth)) highlight = light ? 0xd9ffffff : 0x29ffffff;
            else if ("glass".equals(depth)) highlight = light ? 0xe6ffffff : 0x40ffffff;
            else if ("enter".equals(depth)) highlight = 0x3dffffff;
            else if ("default".equals(depth)) highlight = light ? 0xbfffffff : 0x0bffffff;
            else if ("pressed".equals(depth) || "neuIn".equals(depth)) highlight = light ? 0x2e0f172a : 0xa6000000;
            else highlight = Color.TRANSPARENT;
        }
        @Override public void draw(Canvas c) {
            rect.set(getBounds()); float r = Math.min(radius, Math.min(rect.width(), rect.height()) / 2f);
            paint.setStyle(Paint.Style.FILL); paint.setColor(fill); c.drawRoundRect(rect,r,r,paint);
            if (highlight != Color.TRANSPARENT) {
                c.save(); c.clipRect(rect.left,rect.top,rect.right,rect.top+Math.max(1, Math.min(2,rect.height()/2f)));
                paint.setColor(highlight); c.drawRoundRect(rect,r,r,paint); c.restore();
            }
            if (border > 0 && stroke != Color.TRANSPARENT) {
                rect.set(getBounds()); rect.inset(border/2,border/2);
                paint.setColor(stroke); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(border);
                c.drawRoundRect(rect,Math.max(0,r-border/2),Math.max(0,r-border/2),paint);
            }
        }
        @Override public void setAlpha(int alpha) {}
        @Override public void setColorFilter(android.graphics.ColorFilter filter) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    static double cssNumber(String raw, double fallback) {
        try { return Double.parseDouble(raw.replace("px", "")); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    Drawable premiumBadge(double size) { return new PremiumBadge(dp(size)); }

    /** Native drawing of the original PremiumBadgeIcon paths and gradients. */
    private static final class PremiumBadge extends Drawable {
        private final int size; private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path[] paths;
        private final android.graphics.LinearGradient outer=new android.graphics.LinearGradient(4,3,20,21,new int[]{0xffffe98a,0xfff5b82e,0xffc87e0a},new float[]{0,.5f,1},android.graphics.Shader.TileMode.CLAMP);
        private final android.graphics.LinearGradient inner=new android.graphics.LinearGradient(6,6,18,18,new int[]{0xfffff5be,0xfff7c948,0xffd69116},new float[]{0,.55f,1},android.graphics.Shader.TileMode.CLAMP);
        private final android.graphics.LinearGradient ring=new android.graphics.LinearGradient(2,2,22,22,0xe6fff3b0,0x66f59e0b,android.graphics.Shader.TileMode.CLAMP);
        PremiumBadge(int size){this.size=size;String[] defs={"M12,2L21,7V17L12,22L3,17V7L12,2Z","M12,3L20,7.5V16.5L12,21L4,16.5V7.5L12,3Z","M12,6L18,9.5V14.5L12,18L6,14.5V9.5L12,6Z","M12,3L20,7.5L12,6L4,7.5L12,3Z","M10,2L19,5.5L22,14L15,22L5,19L2,10L10,2Z","M8.5,10.5V13.5M8.5,10.5H10C10.6,10.5 11,10.9 11,11.5C11,12.1 10.6,12.5 10,12.5H8.5","M12,10.5V13.5M12,10.5H13.5C14.1,10.5 14.5,10.9 14.5,11.5C14.5,12.1 14.1,12.5 13.5,12.5H12M13.5,12.5L14.5,13.5","M15.5,11.2V12.8C15.5,13.2 15.9,13.5 16.3,13.5H17.2C17.6,13.5 18,13.2 18,12.8V11.2C18,10.8 17.6,10.5 17.2,10.5H16.3C15.9,10.5 15.5,10.8 15.5,11.2Z"};paths=new Path[defs.length];for(int i=0;i<defs.length;i++)paths[i]=NativePathParser.createPathFromPathData(defs[i]);}
        @Override public void draw(Canvas c){c.save();float scale=Math.min(getBounds().width(),getBounds().height())/24f;c.translate(getBounds().exactCenterX()-12*scale,getBounds().exactCenterY()-12*scale);c.scale(scale,scale);
            p.setStyle(Paint.Style.FILL);p.setShader(null);p.setColor(0x29000000);c.drawPath(paths[0],p);
            p.setColor(Color.WHITE);p.setShader(outer);c.drawPath(paths[1],p);p.setShader(inner);c.drawPath(paths[2],p);p.setShader(null);p.setColor(0xa6ffffff);c.drawPath(paths[3],p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.8f);p.setColor(Color.WHITE);p.setShader(ring);c.drawPath(paths[4],p);p.setShader(null);p.setColor(0xff1d2230);p.setStrokeWidth(.95f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);for(int i=5;i<paths.length;i++)c.drawPath(paths[i],p);c.restore();}
        @Override public int getIntrinsicWidth(){return size;}@Override public int getIntrinsicHeight(){return size;}
        @Override public void setAlpha(int alpha){}@Override public void setColorFilter(android.graphics.ColorFilter filter){}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }

    Drawable icon(String name, int tint, double size) {
        JSONObject vector = vectors.get(name);
        if (vector == null) {
            if (engine != null) vector = engine.object("icon", name);
            else {
                if (settingsIcons == null) {
                    try { settingsIcons = new NativeImeData(context).load("icons"); }
                    catch (RuntimeException e) { settingsIcons = new JSONObject(); }
                }
                vector = NativeImeData.obj(settingsIcons, name);
            }
            if (!vector.has("paths")) vector = supplementalIcon(name);
            vectors.put(name, vector);
        }
        return vector.has("paths") ? new Vector(vector, tint, dp(size)) : null;
    }

    private static JSONObject supplementalIcon(String name) {
        String path;
        double stroke = 2;
        switch (name) {
            case "settings_type": path = "M4 7V4h16v3 M12 4v16 M8 20h8"; break;
            case "settings_globe": path = "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z M2 12h20 M12 2a15 15 0 0 1 0 20 M12 2a15 15 0 0 0 0 20"; break;
            case "settings_sparkles": path = "M9 3l1.9 5.1L16 10l-5.1 1.9L9 17l-1.9-5.1L2 10l5.1-1.9L9 3Z M19 2v6 M16 5h6 M19 13v8 M15 17h8"; break;
            case "settings_hash": path = "M4 9h16 M4 15h16 M10 3 8 21 M16 3l-2 18"; break;
            case "settings_layers": path = "M12 3 2 8l10 5 10-5-10-5Z M2 12l10 5 10-5 M2 16l10 5 10-5"; break;
            case "settings_eye": path = "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"; break;
            case "settings_eye_off": path = "M3 3l18 18 M10.5 5.2 12 5c6.5 0 10 7 10 7a16 16 0 0 1-3 3.8 M6.4 6.4C3.6 8.4 2 12 2 12s3.5 7 10 7c1.7 0 3.2-.5 4.5-1.2"; break;
            case "settings_up": path = "M12 19V5 M5 12l7-7 7 7"; break;
            case "settings_down": path = "M12 5v14 M5 12l7 7 7-7"; break;
            case "settings_chevron_left": path = "M15 18l-6-6 6-6"; break;
            case "settings_smile": path = "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z M8 14s1 3 4 3 4-3 4-3 M9 9h.01 M15 9h.01"; break;
            case "prefs_grid": path = "M3 3h7v7H3Z M14 3h7v7h-7Z M3 14h7v7H3Z M14 14h7v7h-7Z"; break;
            case "prefs_spacing": path = "M12 3v18 M8 7l4-4 4 4 M8 17l4 4 4-4"; break;
            case "prefs_clock": path = "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z M12 6v6l4 2"; break;
            case "mic": path = "M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v3"; break;
            case "calculator": path = "M6 2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z M8 6h8 M8 10h2 M14 10h2 M8 14h2 M14 14h2 M8 18h2 M14 18h2"; break;
            case "corner_down_left": path = "M9 10l-5 5 5 5 M20 4v7a4 4 0 0 1-4 4H4"; break;
            case "number_space": path = "M4 4v4h16V4"; stroke = 2.4; break;
            case "close": path = "M18 6 6 18 M6 6l12 12"; break;
            case "resize_reset": path = "M3 12a9 9 0 1 1 9 9 9.75 9.75 0 0 1-6.74-2.74L3 16 M3 21v-5h5"; stroke = 2.5; break;
            case "resize_move": path = "M5 9l-3 3 3 3 M9 5l3-3 3 3 M15 19l-3 3-3-3 M19 9l3 3-3 3 M2 12h20 M12 2v20"; stroke = 2.4; break;
            case "resize_check": path = "M20 6 9 17l-5-5"; stroke = 2.8; break;
            case "arrow_right": path = "M5 12h14 M12 5l7 7-7 7"; break;
            case "plus": path = "M5 12h14 M12 5v14"; break;
            case "layout_list": path = "M4 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z M4 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1Z M14 4h7 M14 9h7 M14 15h7 M14 20h7"; break;
            case "pin": path = "M12 17v5 M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"; break;
            case "pin_off": path = "M12 17v5 M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89 M2 2l20 20 M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11"; break;
            case "pencil": path = "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z M15 5l4 4"; break;
            case "logs_close": path = "M6 6l12 12 M18 6L6 18"; break;
            case "logs_square": path = "M4 4h16v16H4Z"; break;
            case "logs_checked": path = "M4 4h16v16H4Z M7 12l3 3 7-7"; break;
            case "check": path = "M20 6L9 17l-5-5"; break;
            case "trash_2": path = "M10 11v6 M14 11v6 M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6 M3 6h18 M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"; break;
            case "arrow_left_right": path = "M8 3 4 7l4 4 M4 7h16 M16 21l4-4-4-4 M20 17H4"; break;
            case "chevron_down": path = "M6 9l6 6 6-6"; break;
            case "search": path = "M21 21l-4.34-4.34 M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z"; break;
            case "sliders_horizontal": path = "M10 5H3 M12 19H3 M14 3v4 M16 17v4 M21 12h-9 M21 19h-5 M21 5h-7 M8 10v4 M8 12H3"; break;
            case "refresh_cw": path = "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8 M21 3v5h-5 M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16 M8 16H3v5"; break;
            case "send": path = "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z M21.854 2.147l-10.94 10.939"; break;
            case "calendar_clock": path = "M16 14v2.2l1.6 1 M16 2v4 M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5 M3 10h5 M8 2v4 M22 16a6 6 0 1 1-12 0 6 6 0 0 1 12 0Z"; break;
            case "message_square_text": path = "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z M7 11h10 M7 15h6 M7 7h8"; break;
            default: return new JSONObject();
        }
        return ImeStateStore.json("viewBox", "number_space".equals(name) ? "0 0 24 12" : "0 0 24 24", "paths", new JSONArray().put(
                ImeStateStore.json("d", path, "stroke", "currentColor", "strokeWidth", stroke, "strokeLinecap", "round", "strokeLinejoin", "round")));
    }

    private static final class Vector extends Drawable {
        private final JSONObject definition;
        private final Path[] paths;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int tint;
        private final int size;
        private final float[] box = {0, 0, 24, 24};

        Vector(JSONObject source, int tint, int size) {
            definition = source;
            this.tint = tint;
            this.size = size;
            String[] viewport = source.optString("viewBox").trim().split("[ ,]+");
            if (viewport.length == 4) for (int i = 0; i < 4; i++) box[i] = (float) cssNumber(viewport[i], box[i]);
            JSONArray values = source.optJSONArray("paths");
            paths = new Path[values.length()];
            for (int i = 0; i < paths.length; i++) {
                JSONObject style = values.optJSONObject(i);
                if (style == null) continue;
                try {
                    paths[i] = cachedPath(style.optString("d"), "evenodd".equals(style.optString("fillRule")));
                } catch (RuntimeException ignored) { }
            }
        }

        @Override public void draw(Canvas canvas) {
            canvas.save();
            float scale = Math.min(getBounds().width() / box[2], getBounds().height() / box[3]);
            canvas.translate(getBounds().exactCenterX() - box[2] * scale / 2, getBounds().exactCenterY() - box[3] * scale / 2);
            canvas.scale(scale, scale);
            canvas.translate(-box[0], -box[1]);
            JSONArray styles = definition.optJSONArray("paths");
            boolean multicolor = definition.optBoolean("multicolor");
            for (int i = 0; i < paths.length; i++) {
                if (paths[i] == null) continue;
                JSONObject style = styles.optJSONObject(i);
                String fill = style.optString("fill");
                String stroke = style.optString("stroke");
                boolean hasStroke = !stroke.isEmpty() && !stroke.equals("none");
                if ((!fill.isEmpty() && !fill.equals("none")) || !hasStroke) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(multicolor ? color(fill, tint) : tint);
                    paint.setAlpha((int) (paint.getAlpha() * style.optDouble("fillOpacity", 1)));
                    canvas.drawPath(paths[i], paint);
                }
                if (hasStroke) {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(multicolor ? color(stroke, tint) : tint);
                    paint.setStrokeWidth((float) style.optDouble("strokeWidth", 1));
                    String cap = style.optString("strokeLinecap");
                    paint.setStrokeCap("round".equals(cap) ? Paint.Cap.ROUND : "square".equals(cap) ? Paint.Cap.SQUARE : Paint.Cap.BUTT);
                    String join = style.optString("strokeLinejoin");
                    paint.setStrokeJoin("round".equals(join) ? Paint.Join.ROUND : "bevel".equals(join) ? Paint.Join.BEVEL : Paint.Join.MITER);
                    canvas.drawPath(paths[i], paint);
                }
            }
            canvas.restore();
        }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return "0 0 24 12".equals(definition.optString("viewBox")) ? Math.max(1,Math.round(size/2f)) : size; }
        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
