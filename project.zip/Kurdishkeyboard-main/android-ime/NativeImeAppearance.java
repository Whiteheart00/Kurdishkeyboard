package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import androidx.core.graphics.PathParser;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

final class NativeImeAppearance {
    private final Context context;
    private final float density;
    private final NativeImeEngine engine;
    private final Map<String, JSONObject> vectors = new HashMap<>();
    private final Map<String, Typeface> fonts = new HashMap<>();

    NativeImeAppearance(Context context, NativeImeEngine engine) {
        this.context = context;
        this.engine = engine;
        density = context.getResources().getDisplayMetrics().density;
    }

    int dp(double number) { return (int) Math.round(number * density); }
    float px(double number) { return (float) (number * density); }

    static int color(String css, int fallback) {
        css = css.trim();
        if (css.isEmpty()) return fallback;
        if ("transparent".equals(css) || "none".equals(css)) return Color.TRANSPARENT;
        try {
            if (css.startsWith("#") && css.length() == 9) {
                return Color.parseColor("#" + css.substring(7, 9) + css.substring(1, 7));
            }
            if (css.startsWith("#") && (css.length() == 4 || css.length() == 5)) {
                StringBuilder hex = new StringBuilder("#");
                for (int index = 1; index < css.length(); index++) hex.append(css.charAt(index)).append(css.charAt(index));
                return color(hex.toString(), fallback);
            }
            if (css.startsWith("rgb")) {
                String[] values = css.substring(css.indexOf('(') + 1, css.indexOf(')')).split("[, ]+");
                return Color.argb(values.length == 4 ? (int) Math.round(255 * Double.parseDouble(values[3])) : 255,
                        Integer.parseInt(values[0]), Integer.parseInt(values[1]), Integer.parseInt(values[2]));
            }
            return Color.parseColor(css);
        } catch (IllegalArgumentException | IndexOutOfBoundsException ignored) {
            return fallback;
        }
    }

    int color(JSONObject json, String name, int fallback) { return color(json.optString(name), fallback); }

    Typeface font(String name, int weight) {
        if (!fonts.containsKey(name)) {
            Typeface result;
            if (name.matches("kurdifont(?:[1-9]|10)")) {
                try {
                    String extension = name.equals("kurdifont3") ? ".otf" : ".ttf";
                    result = Typeface.createFromAsset(context.getAssets(), "public/fonts/" + name + extension);
                } catch (RuntimeException e) { result = Typeface.DEFAULT; }
            } else {
                String family = "amiri".equals(name) || "naskh".equals(name) ? "serif" : "sans-serif";
                result = Typeface.create(family, Typeface.NORMAL);
            }
            fonts.put(name, result);
        }
        return android.os.Build.VERSION.SDK_INT >= 28 ? Typeface.create(fonts.get(name), weight, false)
                : Typeface.create(fonts.get(name), weight >= 600 ? Typeface.BOLD : Typeface.NORMAL);
    }

    TextView text(String label, double size, int tint, String font, int weight) {
        TextView view = new TextView(context);
        view.setText(label);
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size));
        view.setTextColor(tint);
        view.setTypeface(font(font, weight));
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(false);
        view.setTextDirection(TextView.TEXT_DIRECTION_FIRST_STRONG);
        view.setPadding(0, 0, 0, 0);
        return view;
    }

    GradientDrawable background(int fill, double radius, double strokeWidth, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(px(radius));
        if (strokeWidth > 0) drawable.setStroke(Math.max(1, dp(strokeWidth)), stroke);
        return drawable;
    }

    /** Builds a key face with tactile depth (shadow / glow / neumorphic) so pressed & idle states stay shiny. */
    Drawable keyFace(JSONObject style, int fallback) {
        if (style == null) return background(fallback, 9, 0, 0);
        double radius = cssNumber(style.optString("borderRadius"), 9);
        String[] border = style.optString("border").split(" +", 3);
        int fill = color(style, "backgroundColor", fallback);
        double strokeW = border.length == 3 ? cssNumber(border[0], 0) : 0;
        int stroke = border.length == 3 ? color(border[2], 0) : 0;
        boolean light = style.optBoolean("light");
        boolean pressed = style.optBoolean("pressed");
        String depth = style.optString("depth", "default");
        String glowCss = style.optString("glow");

        GradientDrawable face = background(fill, radius, strokeW, stroke);

        if ("none".equals(depth) || "flat".equals(style.optString("shape"))) {
            return face;
        }

        // Outer drop-shadow / glow layer under the face
        int shadowColor;
        int shadowDy;
        int shadowSpread;
        int insetBottom;
        int insetTop = 0;
        int insetX = 0;

        switch (depth) {
            case "raised3d":
                shadowColor = light ? 0x33101a2e : 0xCC000000;
                shadowDy = dp(2.4);
                shadowSpread = dp(0.5);
                insetBottom = dp(3);
                // subtle top highlight via second stroke already on face
                break;
            case "flat3d":
                shadowColor = light ? 0x22101a2e : 0x88000000;
                shadowDy = dp(0.6);
                shadowSpread = 0;
                insetBottom = dp(1);
                break;
            case "soft":
                shadowColor = light ? 0x28101a2e : 0x99000000;
                shadowDy = dp(1.5);
                shadowSpread = dp(0.5);
                insetBottom = dp(2);
                break;
            case "glass":
                shadowColor = 0x2E000000;
                shadowDy = dp(2);
                shadowSpread = dp(1);
                insetBottom = dp(3);
                break;
            case "glow": {
                int accent = color(glowCss, 0xffff6d00);
                shadowColor = (accent & 0x00FFFFFF) | 0x55000000;
                shadowDy = 0;
                shadowSpread = dp(4);
                insetBottom = dp(3);
                insetTop = dp(3);
                insetX = dp(2);
                break;
            }
            case "neuOut":
                // soft outer dual feel approximated with a darker bottom-right shadow
                shadowColor = light ? 0x22101a2e : 0xAA000000;
                shadowDy = dp(2);
                shadowSpread = dp(1);
                insetBottom = dp(3);
                insetX = dp(1);
                break;
            case "neuIn":
                // pressed neumorphic: no outer shadow, slightly inset face via darker fill already applied
                return face;
            case "enter":
                shadowColor = 0x99000000;
                shadowDy = dp(1.6);
                shadowSpread = 0;
                insetBottom = dp(2);
                break;
            case "pressed":
                shadowColor = light ? 0x18101a2e : 0x66000000;
                shadowDy = 0;
                shadowSpread = 0;
                insetBottom = dp(1);
                break;
            case "theme":
            case "default":
            default:
                shadowColor = light ? 0x2A101a2e : 0xB3000000;
                shadowDy = pressed ? dp(0.5) : dp(1.6);
                shadowSpread = pressed ? 0 : dp(0.4);
                insetBottom = pressed ? dp(1) : dp(2);
                break;
        }

        GradientDrawable shadow = new GradientDrawable();
        shadow.setShape(GradientDrawable.RECTANGLE);
        shadow.setColor(shadowColor);
        shadow.setCornerRadius(px(radius));

        LayerDrawable layer = new LayerDrawable(new Drawable[]{shadow, face});
        // shadow layer sits slightly lower/wider
        layer.setLayerInset(0,
                Math.max(0, insetX - shadowSpread),
                Math.max(0, insetTop + shadowDy - shadowSpread),
                Math.max(0, insetX - shadowSpread),
                Math.max(0, insetBottom - shadowDy));
        // face keeps top/left padding so the shadow peeks out bottom/right
        layer.setLayerInset(1,
                insetX + (depth.equals("glow") ? shadowSpread / 2 : 0),
                insetTop,
                insetX + (depth.equals("glow") ? shadowSpread / 2 : 0),
                insetBottom);
        return layer;
    }

    static double cssNumber(String raw, double fallback) {
        try { return Double.parseDouble(raw.replace("px", "")); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    Drawable icon(String name, int tint, double size) {
        JSONObject vector = vectors.get(name);
        if (vector == null) {
            vector = engine.object("icon", name);
            if (!vector.has("paths")) vector = supplementalIcon(name);
            vectors.put(name, vector);
        }
        return vector.has("paths") ? new Vector(vector, tint, dp(size)) : null;
    }

    private static JSONObject supplementalIcon(String name) {
        String path;
        double stroke = 2;
        switch (name) {
            case "mic": path = "M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v3"; break;
            case "calculator": path = "M6 2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z M8 6h8 M8 10h2 M14 10h2 M8 14h2 M14 14h2 M8 18h2 M14 18h2"; break;
            case "corner_down_left": path = "M9 10l-5 5 5 5 M20 4v7a4 4 0 0 1-4 4H4"; break;
            case "number_space": path = "M4 10v4h16v-4"; break;
            case "close": path = "M18 6 6 18 M6 6l12 12"; break;
            case "resize_reset": path = "M3 12a9 9 0 1 1 9 9 9.75 9.75 0 0 1-6.74-2.74L3 16 M3 21v-5h5"; stroke = 2.5; break;
            case "resize_move": path = "M5 9l-3 3 3 3 M9 5l3-3 3 3 M15 19l-3 3-3-3 M19 9l3 3-3 3 M2 12h20 M12 2v20"; stroke = 2.4; break;
            case "resize_check": path = "M20 6 9 17l-5-5"; stroke = 2.8; break;
            case "arrow_right": path = "M5 12h14 M12 5l7 7-7 7"; break;
            case "plus": path = "M5 12h14 M12 5v14"; break;
            case "layout_list": path = "M4 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z M4 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1Z M14 4h7 M14 9h7 M14 15h7 M14 20h7"; break;
            case "pin": path = "M12 17v5 M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"; break;
            case "pin_off": path = "M12 17v5 M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89 M2 2l20 20 M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11"; break;
            case "pencil": path = "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z M15 5l4 4"; break;
            case "check": path = "M20 6L9 17l-5-5"; break;
            case "trash_2": path = "M10 11v6 M14 11v6 M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6 M3 6h18 M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"; break;
            case "arrow_left_right": path = "M8 3 4 7l4 4 M4 7h16 M16 21l4-4-4-4 M20 17H4"; break;
            case "chevron_down": path = "M6 9l6 6 6-6"; break;
            case "search": path = "M21 21l-4.34-4.34 M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z"; break;
            case "sliders_horizontal": path = "M10 5H3 M12 19H3 M14 3v4 M16 17v4 M21 12h-9 M21 19h-5 M21 5h-7 M8 10v4 M8 12H3"; break;
            case "refresh_cw": path = "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8 M21 3v5h-5 M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16 M8 16H3v5"; break;
            case "send": path = "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z M21.854 2.147l-10.94 10.939"; break;
            case "calendar_clock": path = "M16 14v2.2l1.6 1 M16 2v4 M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5 M3 10h5 M8 2v4 M22 16a6 6 0 1 1-12 0 6 6 0 0 1 12 0Z"; break;
            case "message_square_text": path = "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z M7 11h10 M7 15h6 M7 7h8"; break;
            default: return new JSONObject();
        }
        return ImeStateStore.json("viewBox", "0 0 24 24", "paths", new JSONArray().put(
                ImeStateStore.json("d", path, "stroke", "currentColor", "strokeWidth", stroke, "strokeLinecap", "round", "strokeLinejoin", "round")));
    }

    private static final class Vector extends Drawable {
        private final JSONObject definition;
        private final Path[] paths;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int tint;
        private final int size;
        private final float[] box = {0, 0, 24, 24};

        Vector(JSONObject source, int tint, int size) {
            definition = source;
            this.tint = tint;
            this.size = size;
            String[] viewport = source.optString("viewBox").trim().split("[ ,]+");
            if (viewport.length == 4) for (int i = 0; i < 4; i++) box[i] = (float) cssNumber(viewport[i], box[i]);
            JSONArray values = source.optJSONArray("paths");
            paths = new Path[values.length()];
            for (int i = 0; i < paths.length; i++) {
                JSONObject style = values.optJSONObject(i);
                if (style == null) continue;
                try {
                    Path path = PathParser.createPathFromPathData(style.optString("d"));
                    if (path != null && "evenodd".equals(style.optString("fillRule"))) path.setFillType(Path.FillType.EVEN_ODD);
                    paths[i] = path;
                } catch (RuntimeException ignored) { }
            }
        }

        @Override public void draw(Canvas canvas) {
            canvas.save();
            float scale = Math.min(getBounds().width() / box[2], getBounds().height() / box[3]);
            canvas.translate(getBounds().exactCenterX() - box[2] * scale / 2, getBounds().exactCenterY() - box[3] * scale / 2);
            canvas.scale(scale, scale);
            canvas.translate(-box[0], -box[1]);
            JSONArray styles = definition.optJSONArray("paths");
            boolean multicolor = definition.optBoolean("multicolor");
            for (int i = 0; i < paths.length; i++) {
                if (paths[i] == null) continue;
                JSONObject style = styles.optJSONObject(i);
                String fill = style.optString("fill");
                String stroke = style.optString("stroke");
                boolean hasStroke = !stroke.isEmpty() && !stroke.equals("none");
                if ((!fill.isEmpty() && !fill.equals("none")) || !hasStroke) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(multicolor ? color(fill, tint) : tint);
                    paint.setAlpha((int) (paint.getAlpha() * style.optDouble("fillOpacity", 1)));
                    canvas.drawPath(paths[i], paint);
                }
                if (hasStroke) {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(multicolor ? color(stroke, tint) : tint);
                    paint.setStrokeWidth((float) style.optDouble("strokeWidth", 1));
                    String cap = style.optString("strokeLinecap");
                    paint.setStrokeCap("round".equals(cap) ? Paint.Cap.ROUND : "square".equals(cap) ? Paint.Cap.SQUARE : Paint.Cap.BUTT);
                    String join = style.optString("strokeLinejoin");
                    paint.setStrokeJoin("round".equals(join) ? Paint.Join.ROUND : "bevel".equals(join) ? Paint.Join.BEVEL : Paint.Join.MITER);
                    canvas.drawPath(paths[i], paint);
                }
            }
            canvas.restore();
        }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
