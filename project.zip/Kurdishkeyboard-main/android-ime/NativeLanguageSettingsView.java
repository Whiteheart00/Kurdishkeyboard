package io.kurdikebord.app;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.WindowManager;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Native language screen following the original cards and language picker. */
final class NativeLanguageSettingsView extends LinearLayout {
    private final NativeImeAppearance a;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int ink, muted, surface, border;
    private final JSONObject data;
    private final JSONArray enabled, presets, layouts;
    private final LinearLayout body;
    NativeLanguageSettingsView(Context context,String theme,String font,JSONObject data,Runnable back,NativeClipboardSettingsView.Change change) {
        super(context); this.font=font;this.data=data;this.change=change;a=new NativeImeAppearance(context,null);
        light="light".equals(theme);ink=light?0xff0f172a:Color.WHITE;muted=light?0xff64748b:0xffa1a1aa;surface=light?Color.WHITE:0xff17181b;border=light?0xffe2e8f0:0x0fffffff;
        enabled=NativeImeData.arr(data,"enabledLanguages");presets=NativeImeData.arr(data,"presets");layouts=NativeImeData.arr(data,"layoutOptions");
        setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_RTL);setBackgroundColor(light?0xfff8fafc:Color.BLACK);
        LinearLayout header=row();header.setPadding(dp(16),0,dp(16),0);TextView arrow=text("→",22,ink,600);arrow.setGravity(Gravity.CENTER);header.addView(arrow,new LayoutParams(dp(40),dp(56)));arrow.setOnClickListener(v->back.run());header.addView(text("زمان، فۆنت و ژیری دەسکرد",17,ink,800),new LayoutParams(0,dp(56),1));addView(header);
        ScrollView scroll=new ScrollView(context);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));body=column();body.setPadding(dp(16),dp(12),dp(16),dp(30));scroll.addView(body);
        if(!data.optBoolean("notificationsEnabled"))append(body,NativeSettingsNotification.create(context,a,font,change),0);
        two(tile("ic_font","شێوەی فۆنت",fontLabel(),()->change.accept("openPage","font_style")),tile("ic_global","زمانی بەرنامەکە",appLabel(),()->choose("زمانی بەرنامەکە",new String[]{"کوردی (سۆرانی)","Kurdî (Kurmancî)","English"},new String[]{"ckb","kmr","en"},"appLanguage")));
        two(tile("ic_smart","ژیری دەسکرد (AI)","ڕێکخستنی شێوازی کارکردن",()->change.accept("openPage","ai_settings")),tile("ic_translate","سەرچاوەی وەرگێڕان","ai_fluent".equals(data.optString("translationEngine"))?"ژیری دەسکرد (ڕەوان)":"وەرگێڕی گۆگڵ (خێرا)",()->choose("سەرچاوەی وەرگێڕان",new String[]{"وەرگێڕی گۆگڵ (خێرا)","ژیری دەسکرد (ڕەوان)"},new String[]{"google_fast","ai_fluent"},"translationEngine")));
        for(int i=0;i<enabled.length();i++){JSONObject l=enabled.optJSONObject(i);if(l!=null)languageCard(l);}
        TextView add=text("＋ زیادکردنی زمان ("+presets.length()+")",14,Color.WHITE,800);add.setGravity(Gravity.CENTER);add.setMinHeight(dp(48));add.setBackground(a.background(0xff0b5fa8,16,0,0));add.setOnClickListener(v->addLanguage());LinearLayout cta=row(); cta.setGravity(Gravity.START); cta.addView(add,new LayoutParams(-2,dp(48)));add.setPadding(dp(20),0,dp(20),0);append(body,cta,16);
    }
    private String fontLabel(){String id=data.optString("fontStyle","system");if(id.startsWith("kurdifont")){try{int n=Integer.parseInt(id.substring(9));String[] nums={"١","٢","٣","٤","٥","٦","٧","٨","٩","١٠"};if(n>=1&&n<=10)return "فۆنتی "+nums[n-1];}catch(NumberFormatException ignored){}}return "فۆنتی سیستەم";}
    private String appLabel(){String id=data.optString("appLanguage");return "en".equals(id)?"English":"kmr".equals(id)?"Kurdî (Kurmancî)":"کوردی (سۆرانی)";}
    private final class Sheet {
        final Dialog dialog; final LinearLayout list;
        Sheet(String title,String subtitle){dialog=new Dialog(getContext());dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout shell=column();shell.setLayoutDirection(LAYOUT_DIRECTION_RTL);shell.setPadding(dp(20),dp(10),dp(20),dp(20));shell.setBackground(a.background(light?Color.WHITE:0xff0c0d10,28,1,border));View handle=new View(getContext());handle.setBackground(a.background(0xff71717a,4,0,0));LayoutParams hp=new LayoutParams(dp(40),dp(4));hp.gravity=Gravity.CENTER_HORIZONTAL;shell.addView(handle,hp);LinearLayout heading=row();LinearLayout words=column();words.addView(text(title,18,ink,800));if(!subtitle.isEmpty())words.addView(text(subtitle,12,muted,400));heading.addView(words,new LayoutParams(0,-2,1));TextView close=text("×",24,muted,600);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());heading.addView(close,new LayoutParams(dp(40),dp(44)));append(shell,heading,12);ScrollView scroll=new ScrollView(getContext());scroll.setVerticalScrollBarEnabled(false);list=column();scroll.addView(list);append(shell,scroll,10);dialog.setContentView(shell);Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setDimAmount(.7f);w.setGravity(Gravity.BOTTOM);}}
        void show(){dialog.show();Window w=dialog.getWindow();if(w!=null){w.setLayout(-1,-2);View decor=w.getDecorView();int max=(int)(getResources().getDisplayMetrics().heightPixels*.82f);decor.measure(View.MeasureSpec.makeMeasureSpec(getResources().getDisplayMetrics().widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(max,View.MeasureSpec.AT_MOST));w.setLayout(-1,Math.min(max,decor.getMeasuredHeight()));}}
    }
    private View choice(String name,String sub,String mark,boolean active,Runnable action){LinearLayout line=row();line.setPadding(dp(12),dp(10),dp(12),dp(10));line.setMinimumHeight(dp(48));line.setBackground(a.background(active?(light?0xffe0f2fe:0xff17202d):Color.TRANSPARENT,14,1,active?0xff38bdf8:border));LinearLayout words=column();words.addView(text(name,13,active?0xff8ec2ff:ink,700));if(!sub.isEmpty())words.addView(text(sub,11,muted,400));line.addView(words,new LayoutParams(0,-2,1));if(!mark.isEmpty())line.addView(text(mark,12,active?0xff38bdf8:muted,700));line.setOnClickListener(v->action.run());return line;}
    private void choose(String title,String[] labels,String[] ids,String key){Sheet sheet=new Sheet(title,"");for(int i=0;i<ids.length;i++){final String id=ids[i];boolean active=id.equals(data.optString(key));append(sheet.list,choice(labels[i],"",active?"✓":"",active,()->{sheet.dialog.dismiss();change.accept(key,id);}),8);}sheet.show();}
    private void languageCard(JSONObject lang){String code=lang.optString("code"),layout=lang.optString("characterLayoutId");LinearLayout card=column();card.setPadding(dp(16),dp(16),dp(16),dp(16));card.setBackground(a.background(surface,24,1,border));LinearLayout top=row();LinearLayout copy=column();copy.addView(text(lang.optString("nativeName",code)+(code.equals(data.optString("activeLanguage"))?" · چالاک":""),16,ink,800));copy.addView(text(layoutLabel(layout),12,muted,400));copy.setOnClickListener(v->change.accept("activeLanguage",code));top.addView(copy,new LayoutParams(0,-2,1));ImageView trash=icon("ic_trash",0xfffb7185);trash.setBackground(a.background(0x26ef4444,24,0,0));top.addView(trash,new LayoutParams(dp(40),dp(40)));trash.setAlpha(enabled.length()>1?1f:.3f);trash.setOnClickListener(v->{if(enabled.length()>1)save(code,null,true);});card.addView(top);LinearLayout edit=row();edit.addView(icon("ic_keyboards",0xff8ec2ff),new LayoutParams(dp(20),dp(20)));TextView editLabel=text("شێوازی ڕیزبەندی",13,ink,600);editLabel.setPaddingRelative(dp(8),0,0,0);edit.addView(editLabel,new LayoutParams(0,dp(44),1));edit.addView(text(layoutLabel(layout)+"  ‹",12,0xff8ec2ff,700));edit.setOnClickListener(v->layoutPicker(lang));rule(card,12);append(card,edit,0);rule(card,0);LinearLayout line=row();line.addView(text("لیستی ژمارەکان",13,ink,600),new LayoutParams(0,-2,1));NativeSettingsToggle toggle=new NativeSettingsToggle(getContext(),a,"لیستی ژمارەکان",lang.optBoolean("numberRow"),on->{JSONObject changed=NativeImeData.copy(lang);ImeStateStore.put(changed,"numberRow",on);save(code,changed,false);});line.addView(toggle,new LayoutParams(dp(52),dp(30)));append(card,line,4);append(body,card,12);}
    private String layoutLabel(String id){JSONObject item=NativeImeData.find(layouts,"id",id);return item==null?id:item.optString("label",id);}
    private void layoutPicker(JSONObject lang){Sheet sheet=new Sheet("شێوازی ڕیزبەندی — "+lang.optString("nativeName"),"هەر یەکێک لە ٤١ ڕیزبەندییە فەرمییەکان هەڵبژێرە");String[] groups={"kurdish","fancy","arabic_persian","international"};String[] titles={"شێوازە کوردییەکان (١٣ شێواز)","شێوازە جوانکارەکان (Fancy Styles 1–10)","عەرەبی و فارسی","زمانە جیهانییەکان (QWERTY / AZERTY / ...)"};for(int g=0;g<groups.length;g++){append(sheet.list,text(titles[g],11,0xff8ec2ff,700),12);LinearLayout line=null;int count=0;for(int i=0;i<layouts.length();i++){JSONObject item=layouts.optJSONObject(i);if(item==null||!groups[g].equals(item.optString("group")))continue;if(count%2==0){line=row();append(sheet.list,line,6);}boolean active=item.optString("id").equals(lang.optString("characterLayoutId"));View button=choice(item.optString("label"),"",active?"✓":"",active,()->{JSONObject changed=NativeImeData.copy(lang);ImeStateStore.put(changed,"characterLayoutId",item.optString("id"));ImeStateStore.put(changed,"subtitle",item.optString("label"));ImeStateStore.put(changed,"dir",item.optString("direction",lang.optString("dir")));sheet.dialog.dismiss();save(lang.optString("code"),changed,false,true);});LayoutParams lp=new LayoutParams(0,-2,1);if(count%2==1)lp.setMarginStart(dp(6));line.addView(button,lp);count++;}if(count%2==1&&line!=null)line.addView(new View(getContext()),new LayoutParams(0,1,1));}sheet.show();}
    private void addLanguage(){Sheet sheet=new Sheet("زیادکردنی زمان ("+presets.length()+" زمان)","");for(int i=0;i<presets.length();i++){JSONObject l=presets.optJSONObject(i);if(l==null)continue;boolean already=NativeImeData.find(enabled,"code",l.optString("code"))!=null;View row=choice(l.optString("nativeName",l.optString("code")),l.optString("name")+" · "+l.optString("subtitle"),already?"زیادکراوە":"＋",false,()->{JSONArray next=new JSONArray();for(int j=0;j<enabled.length();j++)next.put(enabled.opt(j));next.put(l);sheet.dialog.dismiss();commit(next,l.optString("code"));});row.setEnabled(!already);row.setAlpha(already?.4f:1f);append(sheet.list,row,8);}sheet.show();}
    private void save(String code,JSONObject changed,boolean remove){save(code,changed,remove,false);}
    private void save(String code,JSONObject changed,boolean remove,boolean activate){JSONArray next=new JSONArray();for(int i=0;i<enabled.length();i++){JSONObject l=enabled.optJSONObject(i);if(l==null)continue;if(code.equals(l.optString("code"))){if(!remove)next.put(changed);}else next.put(l);}String active=activate?code:data.optString("activeLanguage");if(remove&&code.equals(active)&&next.length()>0)active=next.optJSONObject(0).optString("code");commit(next,active);}
    private void commit(JSONArray next,String active){JSONObject patch=new JSONObject();ImeStateStore.put(patch,"enabledLanguages",next);ImeStateStore.put(patch,"activeLanguage",active);change.accept("languageSelection",patch);}
    private View tile(String id,String title,String desc,Runnable run){LinearLayout c=column();c.setPadding(dp(14),dp(14),dp(14),dp(14));c.setBackground(a.background(surface,24,1,border));c.addView(icon(id,0xff8ec2ff),new LayoutParams(dp(26),dp(26)));append(c,text(title,14,ink,700),8);append(c,text(desc,11,muted,400),4);c.setOnClickListener(v->run.run());return c;}
    private void two(View v1,View v2){LinearLayout row=row();row.setGravity(Gravity.TOP);row.addView(v1,new LayoutParams(0,dp(112),1));LayoutParams lp=new LayoutParams(0,dp(112),1);lp.setMarginStart(dp(12));row.addView(v2,lp);append(body,row,12);}
    private ImageView icon(String id,int tint){ImageView v=new ImageView(getContext());v.setImageDrawable(a.icon(id,tint,22));v.setScaleType(ImageView.ScaleType.CENTER);return v;}
    private TextView text(String s,int size,int color,int w){TextView t=a.text(s,size,color,font,w);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(getContext());v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout column(){LinearLayout v=new LinearLayout(getContext());v.setOrientation(VERTICAL);return v;}
    private void append(LinearLayout parent,View child,int gap){LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(gap);parent.addView(child,lp);}
    private void rule(LinearLayout parent,int gap){View line=new View(getContext());line.setBackgroundColor(border);LayoutParams lp=new LayoutParams(-1,dp(1));lp.topMargin=dp(gap);parent.addView(line,lp);}
    private int dp(int n){return a.dp(n);}
}
