package io.kurdikebord.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Native language screen following the original cards and language picker. */
final class NativeLanguageSettingsView extends LinearLayout {
    private final NativeImeAppearance a;
    private final NativeClipboardSettingsView.Change change;
    private final String font;
    private final boolean light;
    private final int ink, muted, surface, border;
    private final JSONObject data;
    private final JSONArray enabled, presets, layouts;
    private final LinearLayout body;
    NativeLanguageSettingsView(Context context,String theme,String font,JSONObject data,Runnable back,NativeClipboardSettingsView.Change change) {
        super(context); this.font=font;this.data=data;this.change=change;a=new NativeImeAppearance(context,null);
        light="light".equals(theme);ink=light?0xff0f172a:Color.WHITE;muted=light?0xff64748b:0xffa1a1aa;surface=light?Color.WHITE:0xff121316;border=light?0xffe2e8f0:0x0fffffff;
        enabled=NativeImeData.arr(data,"enabledLanguages");presets=NativeImeData.arr(data,"presets");layouts=NativeImeData.arr(data,"layoutOptions");
        setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_RTL);setBackgroundColor(light?0xfff1f5f9:0xff07080b);
        LinearLayout header=row();header.setPadding(dp(16),0,dp(16),0);TextView arrow=text("→",22,ink,600);arrow.setGravity(Gravity.CENTER);header.addView(arrow,new LayoutParams(dp(40),dp(56)));arrow.setOnClickListener(v->back.run());header.addView(text("زمانەکان",17,ink,800),new LayoutParams(0,dp(56),1));addView(header);
        ScrollView scroll=new ScrollView(context);scroll.setVerticalScrollBarEnabled(false);addView(scroll,new LayoutParams(-1,0,1));body=column();body.setPadding(dp(16),dp(12),dp(16),dp(30));scroll.addView(body);
        if(!data.optBoolean("notificationsEnabled"))append(body,NativeSettingsNotification.create(context,a,font,change),0);
        two(tile("ic_font","شێوەی فۆنت",data.optString("fontStyle"),()->change.accept("openPage","font_style")),tile("ic_global","زمانی بەرنامەکە",data.optString("appLanguage"),()->choose("زمانی بەرنامەکە",new String[]{"کوردی (سۆرانی)","Kurdî (Kurmancî)","English","العربية","فارسی"},new String[]{"ckb","kmr","en","ar","fa"},"appLanguage")));
        two(tile("ic_smart","ژیری دەسکرد (AI)","ڕێکخستنی شێوازی کارکردن",()->change.accept("openPage","ai_settings")),tile("ic_translate","سەرچاوەی وەرگێڕان","ai_fluent".equals(data.optString("translationEngine"))?"ژیری دەسکرد (ڕەوان)":"وەرگێڕی گۆگڵ (خێرا)",()->choose("سەرچاوەی وەرگێڕان",new String[]{"وەرگێڕی گۆگڵ (خێرا)","ژیری دەسکرد (ڕەوان)"},new String[]{"google_fast","ai_fluent"},"translationEngine")));
        for(int i=0;i<enabled.length();i++){JSONObject l=enabled.optJSONObject(i);if(l!=null)languageCard(l);}
        TextView add=text("＋ زیادکردنی زمان ("+presets.length()+")",14,Color.WHITE,800);add.setGravity(Gravity.CENTER);add.setMinHeight(dp(48));add.setBackground(a.background(0xff0b5fa8,16,0,0));add.setOnClickListener(v->addLanguage());append(body,add,16);
    }
    private void choose(String title,String[] labels,String[] ids,String key){int selected=java.util.Arrays.asList(ids).indexOf(data.optString(key));new AlertDialog.Builder(getContext()).setTitle(title).setSingleChoiceItems(labels,selected,(d,i)->{d.dismiss();change.accept(key,ids[i]);}).setNegativeButton("داخستن",null).show();}
    private void languageCard(JSONObject lang){String code=lang.optString("code"),layout=lang.optString("characterLayoutId");LinearLayout card=column();card.setPadding(dp(16),dp(16),dp(16),dp(16));card.setBackground(a.background(surface,24,1,border));LinearLayout top=row();LinearLayout copy=column();copy.addView(text(lang.optString("nativeName",code)+(code.equals(data.optString("activeLanguage"))?" · چالاک":""),16,ink,800));copy.addView(text(layoutLabel(layout),12,muted,400));copy.setOnClickListener(v->change.accept("activeLanguage",code));top.addView(copy,new LayoutParams(0,-2,1));ImageView trash=icon("ic_trash",0xfffb7185);trash.setBackground(a.background(0x26ef4444,24,0,0));top.addView(trash,new LayoutParams(dp(40),dp(40)));trash.setAlpha(enabled.length()>1?1f:.3f);trash.setOnClickListener(v->{if(enabled.length()>1)save(code,null,true);});card.addView(top);TextView edit=text("شێوازی ڕیزبەندی     "+layoutLabel(layout)+"  ‹",13,ink,600);edit.setMinHeight(dp(44));edit.setOnClickListener(v->layoutPicker(lang));append(card,edit,8);LinearLayout line=row();line.addView(text("لیستی ژمارەکان",13,ink,600),new LayoutParams(0,-2,1));Switch toggle=new Switch(getContext());toggle.setChecked(lang.optBoolean("numberRow"));line.addView(toggle);toggle.setOnCheckedChangeListener((v,on)->{JSONObject changed=NativeImeData.copy(lang);ImeStateStore.put(changed,"numberRow",on);save(code,changed,false);});append(card,line,4);append(body,card,12);}
    private String layoutLabel(String id){JSONObject item=NativeImeData.find(layouts,"id",id);return item==null?id:item.optString("label",id);}
    private void layoutPicker(JSONObject lang){java.util.ArrayList<String> labels=new java.util.ArrayList<>(),ids=new java.util.ArrayList<>();for(int i=0;i<layouts.length();i++){JSONObject item=layouts.optJSONObject(i);if(item!=null){labels.add(item.optString("label"));ids.add(item.optString("id"));}}new AlertDialog.Builder(getContext()).setTitle("شێوازی ڕیزبەندی").setSingleChoiceItems(labels.toArray(new String[0]),ids.indexOf(lang.optString("characterLayoutId")),(d,i)->{JSONObject changed=NativeImeData.copy(lang);ImeStateStore.put(changed,"characterLayoutId",ids.get(i));d.dismiss();save(lang.optString("code"),changed,false);}).setNegativeButton("داخستن",null).show();}
    private void addLanguage(){java.util.ArrayList<JSONObject> choices=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();for(int i=0;i<presets.length();i++){JSONObject l=presets.optJSONObject(i);if(l!=null&&NativeImeData.find(enabled,"code",l.optString("code"))==null){choices.add(l);labels.add(l.optString("nativeName",l.optString("code")));}}new AlertDialog.Builder(getContext()).setTitle("زیادکردنی زمان").setItems(labels.toArray(new String[0]),(d,i)->{JSONArray next=new JSONArray();for(int j=0;j<enabled.length();j++)next.put(enabled.opt(j));next.put(choices.get(i));change.accept("enabledLanguages",next);}).setNegativeButton("داخستن",null).show();}
    private void save(String code,JSONObject changed,boolean remove){JSONArray next=new JSONArray();for(int i=0;i<enabled.length();i++){JSONObject l=enabled.optJSONObject(i);if(l==null)continue;if(code.equals(l.optString("code"))){if(!remove)next.put(changed);}else next.put(l);}change.accept("enabledLanguages",next);}
    private View tile(String id,String title,String desc,Runnable run){LinearLayout c=column();c.setPadding(dp(14),dp(14),dp(14),dp(14));c.setBackground(a.background(surface,24,1,border));c.addView(icon(id,0xff8ec2ff),new LayoutParams(dp(26),dp(26)));append(c,text(title,14,ink,700),8);append(c,text(desc,11,muted,400),4);c.setOnClickListener(v->run.run());return c;}
    private void two(View v1,View v2){LinearLayout row=row();row.setGravity(Gravity.TOP);row.addView(v1,new LayoutParams(0,dp(112),1));LayoutParams lp=new LayoutParams(0,dp(112),1);lp.setMarginStart(dp(12));row.addView(v2,lp);append(body,row,12);}
    private ImageView icon(String id,int tint){ImageView v=new ImageView(getContext());v.setImageDrawable(a.icon(id,tint,22));v.setScaleType(ImageView.ScaleType.CENTER);return v;}
    private TextView text(String s,int size,int color,int w){TextView t=a.text(s,size,color,font,w);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(getContext());v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout column(){LinearLayout v=new LinearLayout(getContext());v.setOrientation(VERTICAL);return v;}
    private void append(LinearLayout parent,View child,int gap){LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(gap);parent.addView(child,lp);}
    private int dp(int n){return a.dp(n);}
}
