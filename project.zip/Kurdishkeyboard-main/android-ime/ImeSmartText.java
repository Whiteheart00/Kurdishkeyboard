package io.kurdikebord.app;

import java.util.*;
/** Small offline, conservative spelling and phrase model. No text leaves the device. */
final class ImeSmartText {
    @SuppressWarnings("unchecked")
    private static <K,V> Map<K,V> map(Object... values) { Map<K,V> out=new LinkedHashMap<>(); for(int i=0;i<values.length;i+=2)out.put((K)values[i],(V)values[i+1]); return Collections.unmodifiableMap(out); }
    private static Map.Entry<String,String> pair(String a,String b){return new AbstractMap.SimpleImmutableEntry<>(a,b);}
    @SafeVarargs private static Map<String,String> pairs(Map.Entry<String,String>... values){Map<String,String> out=new LinkedHashMap<>();for(Map.Entry<String,String> v:values)out.put(v.getKey(),v.getValue());return Collections.unmodifiableMap(out);}
    private static final Map<String,String> KU = pairs(
        pair("سلاو","سڵاو"), pair("سوپاسس","سوپاس"), pair("كوردستان","کوردستان"),
        pair("كوردی","کوردی"), pair("دەستخوش","دەستخۆش"), pair("چونیت","چۆنیت"),
        pair("خۆشحالم","خۆشحاڵم"), pair("ته‌ختەکلیل","تەختەکلیل"));
    private static final Map<String,String> EN = map("teh","the","adn","and","thier","their","recieve","receive","becuase","because","freind","friend","woudl","would","shoudl","should");
    static final String[] EXTRA_KU = ("پاشەکەوتکردن گەڕاندنەوە هاوکاتکردن شفرەکردن تایبەتمەندی تایبەتمەندییەکان دەستپێک پێداچوونەوە پەیوەندیکردن هەڵگرتن هەڵسەنگاندن بەڕێوەبردن هەماهەنگی هەڵبژێردراو بەردەست بەردەوام بەردەوامی ڕێکخراو ڕێکخراوە پەسەندکردن دڵنیایی پشکنین پشکنەوە پشتڕاستکردنەوە سەرچاوە سەرچاوەکان زانیارییەکان ڕاپۆرت ڕاپۆرتەکان خەزنکردن ناوخۆیی دەرەکی خۆکار خۆکارانە نیشاندەر سڕاوە هەڵەکان چاککراوە نوێکراوە گۆڕانکاری گۆڕانکارییەکان هەڵسوکەوت چالاکی چالاککردن ناچالاککردن پاراستن پارێزراو پارێزگاری ئاسایش نهێنی هەژمار هەژمارەکان بەشداربوون گەڕۆک هەستیار هەستیارەکان ئاگاداری بەکارهێنەر بەکارهێنەران ڕێنمایی ڕێنماییەکان خوێندنەوە نووسینەوە بەڵگە بەڵگەنامە گەشەپێدان پەرەپێدان گەڕانەوە بەکارهێنان هەڵبژاردە ڕیزبەندی بەردەوامبوون").split(" ");
    private static final Map<String,List<String>> KU_PHRASES = map(
        "زۆر سوپاس",Arrays.asList("بۆ یارمەتیت","بۆ هەموو شتێک"), "بەیانی باش",Arrays.asList("چۆنیت","ڕۆژت خۆش"),
        "من دەمەوێت",Arrays.asList("فێر ببم","یارمەتیت بدەم"), "دەتوانیت",Arrays.asList("یارمەتیم بدەیت","پێم بڵێیت"),
        "بەخێر بێیت",Arrays.asList("بۆ کوردستان"), "هەموو شتێک",Arrays.asList("باشە","ئامادەیە"));
    private static final Map<String,List<String>> EN_PHRASES = map("thank you",Arrays.asList("very much","for your help"),"how are",Arrays.asList("you"),"i would",Arrays.asList("like to","love to"),"good morning",Arrays.asList("everyone","have a nice day"));
    private static final java.util.regex.Pattern LETTERS=java.util.regex.Pattern.compile("[\\p{L}\\p{M}\\u200c]+");
    private static final java.util.regex.Pattern LATIN=java.util.regex.Pattern.compile("[a-zA-Z][a-zA-Z'’-]*");
    private static final java.util.regex.Pattern LINK=java.util.regex.Pattern.compile("(?is)^https?://[^\\s]+$");
    static String correction(String word,String lang) {
        if (word==null || word.length()>32 || !LETTERS.matcher(word).matches()) return "";
        if ("ckb".equals(lang)||"ku".equals(lang)) return KU.getOrDefault(word, "");
        if (!"en".equals(lang)) return "";
        String low=word.toLowerCase(Locale.ROOT), value=EN.get(low);
        if(value==null)return "";
        if(word.equals(low))return value;
        if(word.equals(low.substring(0,1).toUpperCase(Locale.ROOT)+low.substring(1))) return value.substring(0,1).toUpperCase(Locale.ROOT)+value.substring(1);
        return "";
    }
    static List<String> phrases(String tail, boolean latin) {
        if(tail==null || tail.length()==0 || !Character.isWhitespace(tail.charAt(tail.length()-1)))return Collections.emptyList();
        String clean=tail.trim().toLowerCase(Locale.ROOT);
        if(clean.isEmpty()||!Character.isLetter(clean.codePointBefore(clean.length())))return Collections.emptyList();
        Map<String,List<String>> map=latin?EN_PHRASES:KU_PHRASES;
        String best="";for(String key:map.keySet())if((clean.equals(key)||clean.endsWith(" "+key))&&key.length()>best.length())best=key;
        return map.getOrDefault(best,Collections.emptyList());
    }
    static boolean latinWord(String word){return word!=null && LATIN.matcher(word).matches();}
    static final String SPACE_TRACKPAD = "space_cursor_trackpad";
    static String spaceHoldChoice(String stored, boolean chosen) {
        // Migrate the previous default, not unrelated custom gestures.
        return stored.isEmpty() || (!chosen && "space_bar_custom_menu".equals(stored))
                ? SPACE_TRACKPAD : stored;
    }
    static final class CursorDrag {
        private float anchor;
        CursorDrag(float start) { anchor = start; }
        int move(float x, float unit) {
            float delta = x - anchor;
            int count = steps(delta, unit);
            if (count == 0) return 0;
            int signed = delta < 0 ? -count : count;
            // Bound each dispatch and drop oversized backlog to avoid movement after reversal.
            anchor = Math.abs(delta) >= 5 * unit ? x : anchor + signed * unit;
            return signed;
        }
    }
    static int steps(float delta,float unit){return unit<=0?0:Math.min(4,(int)(Math.abs(delta)/unit));}
    static int deleteWordUnits(String text){
        int i=text.length();while(i>0&&Character.isWhitespace(text.codePointBefore(i)))i-=Character.charCount(text.codePointBefore(i));
        while(i>0&&!Character.isWhitespace(text.codePointBefore(i)))i-=Character.charCount(text.codePointBefore(i));
        return text.length()-i;
    }
    static boolean clipMatches(String text,boolean pinned,int filter){
        boolean link=text!=null&&LINK.matcher(text.trim()).matches();
        return filter==0 || filter==1&&pinned || filter==2&&link || filter==3&&!link;
    }
}
