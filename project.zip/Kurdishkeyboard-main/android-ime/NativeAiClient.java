package io.kurdikebord.app;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;

/** Native transport: the existing Vercel API retains the keys, failover and validation. */
final class NativeAiClient {
    private volatile HttpsURLConnection connection;
    private volatile boolean cancelled;
    void cancel(){cancelled=true; HttpsURLConnection c=connection;if(c!=null)c.disconnect();}
    String request(String base,JSONObject body,boolean translate)throws Exception{
        if(cancelled)throw new java.io.IOException("cancelled");
        base=base.trim();if(!base.contains("://"))base="https://"+base;
        URL url=new URL(base.replaceAll("/+$","").replaceAll("/api(/health)?$","")+(translate?"/api/ai/translate":"/api/ai/rewrite"));
        if(!"https".equalsIgnoreCase(url.getProtocol())||url.getUserInfo()!=null||url.getHost().isEmpty()||url.getQuery()!=null||url.getRef()!=null)throw new java.io.IOException("HTTPS server required");
        HttpsURLConnection c=(HttpsURLConnection)url.openConnection();connection=c;
        try{if(cancelled)throw new java.io.IOException("cancelled");c.setConnectTimeout(5000);c.setReadTimeout(20000);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setDoOutput(true);byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(java.io.OutputStream out=c.getOutputStream()){out.write(bytes);}
            int status=c.getResponseCode();if(status!=200)throw new java.io.IOException("HTTP "+status);
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){if(cancelled||out.size()+n>262144)throw new java.io.IOException("cancelled or response too large");out.write(buffer,0,n);}String result=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8)).optString(translate?"translated":"result","").trim();if(result.isEmpty())throw new java.io.IOException("empty result");return result;}
        }finally{connection=null;c.disconnect();}
    }
}
