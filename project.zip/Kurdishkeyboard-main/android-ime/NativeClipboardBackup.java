package io.kurdikebord.app;

import android.content.Context;
import android.os.UserManager;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Local credential-protected snapshot, excluded from Android automatic backups. */
final class NativeClipboardBackup {
    private static final int MAX_CHARS = 4 * 1024 * 1024;
    private static final int MAX_BYTES = 12 * 1024 * 1024;
    private static AtomicFile file(Context c) {
        // The normal application context uses credential-protected storage.
        // Never write private clipboard data into device-protected Direct Boot storage.
        Context safe = c.getApplicationContext();
        if (safe == null) return null;
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            UserManager u = (UserManager) safe.getSystemService(Context.USER_SERVICE);
            if (u == null || !u.isUserUnlocked() || safe.isDeviceProtectedStorage()) return null;
        }
        return new AtomicFile(new File(safe.getNoBackupFilesDir(), "kurdi_clipboard_v1.json"));
    }
    private static boolean valid(String raw) {
        if (raw == null || raw.length() > MAX_CHARS) return false;
        try {
            JSONArray items = new JSONArray(raw);
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                if (!(item.opt("id") instanceof String) || !(item.opt("text") instanceof String)
                    || !(item.opt("timestamp") instanceof Number)
                    || (item.has("pinned") && !(item.opt("pinned") instanceof Boolean))) return false;
            }
            return true;
        } catch (Exception e) { return false; }
    }
    static synchronized String read(Context c) {
        try {
            AtomicFile f = file(c);
            if (f == null) return "";
            byte[] bytes = f.readFully();
            if (bytes.length > MAX_BYTES) return "";
            String raw = new String(bytes, StandardCharsets.UTF_8);
            return valid(raw) ? raw : "";
        } catch (Exception e) { return ""; }
    }
    /** Merge a system clip with the latest durable snapshot; preserve pinned items. */
    static synchronized boolean appendText(Context c,String text,int limit) {
        if(text==null||text.isEmpty()||text.length()>65536)return false;
        try {
            String raw=read(c); if(raw.isEmpty())return false; // allow existing web history to migrate first
            JSONArray old=new JSONArray(raw);
            JSONObject found=null; int pins=0;
            for(int i=0;i<old.length();i++){JSONObject item=old.getJSONObject(i);if(text.equals(item.optString("text"))){if(found==null)found=item;}else if(item.optBoolean("pinned"))pins++;}
            if(old.length()>0&&text.equals(old.getJSONObject(0).optString("text")))return true;
            if(found==null)found=new JSONObject().put("id","native_"+java.util.UUID.randomUUID()).put("text",text);
            found.put("timestamp",System.currentTimeMillis());
            JSONArray next=new JSONArray();next.put(found); int unpinned=found.optBoolean("pinned")?0:1;
            int allowed=Math.max(0,limit-pins-(found.optBoolean("pinned")?1:0));
            for(int i=0;i<old.length();i++){JSONObject item=old.getJSONObject(i);if(text.equals(item.optString("text")))continue;if(item.optBoolean("pinned")||unpinned<allowed){next.put(item);if(!item.optBoolean("pinned"))unpinned++;}}
            return write(c,next.toString());
        }catch(Exception e){return false;}
    }
    static synchronized boolean edit(Context c,String id,boolean pin,boolean clear){
        try {String raw=read(c);if(raw.isEmpty())return false;JSONArray old=new JSONArray(raw),next=new JSONArray();for(int i=0;i<old.length();i++){JSONObject item=old.getJSONObject(i);if(clear){if(item.optBoolean("pinned"))next.put(item);}else if(id.equals(item.optString("id"))){if(pin){item.put("pinned",!item.optBoolean("pinned"));next.put(item);}}else next.put(item);}return write(c,next.toString());}catch(Exception e){return false;}
    }
    static synchronized boolean write(Context c, String raw) {
        if (!valid(raw)) return false;
        AtomicFile f = null;
        FileOutputStream out = null;
        try {
            f = file(c);
            if (f == null) return false;
            if (raw.equals(read(c))) return true;
            byte[] bytes = raw.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_BYTES) return false;
            out = f.startWrite();
            out.write(bytes);
            f.finishWrite(out);
            out = null;
            return true;
        } catch (Exception e) {
            if (f != null && out != null) f.failWrite(out);
            return false;
        }
    }
}
