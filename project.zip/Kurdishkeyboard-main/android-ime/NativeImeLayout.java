package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;
import static io.kurdikebord.app.NativeImeData.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class NativeImeLayout {
    private final JSONObject layouts;
    private final JSONArray characters;
    private final JSONArray currencies;
    private final JSONObject popups;
    private final JSONArray emails;
    private final JSONArray themes;

    NativeImeLayout(JSONObject bundle, JSONObject core) {
        layouts = obj(bundle, "layouts");
        characters = arr(obj(bundle, "manifest"), "characters");
        currencies = arr(bundle, "currencySets");
        popups = obj(bundle, "popupMappings");
        emails = arr(obj(core, "defaults"), "email");
        themes = arr(core, "themes");
    }

    JSONObject deck(JSONObject settings, String mode, String shift, String kana) {
        JSONArray languages = arr(settings, "enabledLanguages");
        JSONObject lang = find(languages, "code", settings.optString("activeLanguage"));
        if (lang == null) lang = languages.optJSONObject(0);
        String layout = lang.optString("characterLayoutId");
        JSONObject manifest = find(characters, "id", layout);
        String direction = "kurdi_hybrid".equals(layout) ? ("kata".equals(kana) ? "ltr" : "rtl")
                : manifest == null ? lang.optString("dir") : manifest.optString("direction", lang.optString("dir"));
        Resolver resolver = new Resolver(lang, mode, shift, kana, direction);
        boolean numberRow = "always".equals(settings.optString("numberRowMode"))
                || (!"never".equals(settings.optString("numberRowMode")) && lang.optBoolean("numberRow"));
        JSONArray digitRow = digits(settings, lang, "characters".equals(mode) && "kurdi_hybrid".equals(layout));
        JSONArray raw = rawRows(settings, lang, manifest, resolver, digitRow, numberRow);
        JSONArray rows = new JSONArray();
        for (int r = 0; r < raw.length(); r++) {
            JSONArray row = raw.optJSONArray(r);
            JSONArray keys = new JSONArray();
            if (row != null) for (int c = 0; c < row.length(); c++) {
                JSONObject key = resolver.key(row.optJSONObject(c), r, c);
                if (key != null) keys.put(key);
            }
            rows.put(keys);
        }
        normalizeRows(rows, settings, resolver, digitRow, numberRow);
        return NativeImeKeyFaces.deck(settings, theme(settings), lang, mode, shift, kana, direction, rows);
    }

    private JSONObject theme(JSONObject settings) {
        String id = settings.optString("activeThemeId");
        if ("custom_user_theme".equals(id)) return obj(settings, "customTheme");
        JSONObject theme = find(themes, "id", id);
        return theme == null ? themes.optJSONObject(0) : theme;
    }

    private JSONArray rawRows(JSONObject settings, JSONObject lang, JSONObject manifest, Resolver resolver, JSONArray digits, boolean numberRow) {
        switch (resolver.mode) {
            case "characters": {
                String id = lang.optString("characterLayoutId");
                JSONArray base = layout("characters", id, "kurdi_qvfgh");
                JSONArray custom = obj(settings, "customLayouts").optJSONArray(id);
                if (custom != null && custom.length() == base.length()) base = overrides(base, custom, resolver);
                String modifier = manifest == null ? "default" : manifest.optString("modifier", "default");
                modifier = modifier.substring(modifier.indexOf(':') + 1);
                String preset = settings.optString("bottomRowPreset");
                if ("auto".equals(preset)) preset = modifier;
                JSONArray modifiers = layout("charactersMod", preset, modifier);
                if (modifiers.length() == 0) modifiers = layout("charactersMod", "default", "default");
                return joinRows(base, modifiers, numberRow ? digits : null);
            }
            case "symbols":
            case "symbols2": {
                String id = lang.optString("symbols".equals(resolver.mode) ? "symbolsLayoutId" : "symbols2LayoutId");
                return joinRows(layout(resolver.mode, id, "sym_alt"),
                        layout(resolver.mode + "Mod", "cjk".equals(id) ? "cjk" : "default", "default"), digits);
            }
            case "numeric_advanced":
                String style = settings.optString("numberStyle");
                String id = "kurdish".equals(style) ? "kurdi_arabi" : "urdu_farsi".equals(style)
                        ? "urdu_farsi" : lang.optString("numericAdvancedId", "latin");
                return layout("numericAdvanced", id, "latin");
            case "phone":
            case "phone2":
                return layout(resolver.mode, "telpad", "telpad");
            default:
                return new JSONArray();
        }
    }

    private JSONArray layout(String family, String id, String fallback) {
        JSONObject group = obj(layouts, family);
        JSONArray rows = group.optJSONArray(id);
        return rows == null ? arr(group, fallback) : rows;
    }

    private JSONArray digits(JSONObject settings, JSONObject lang, boolean hybrid) {
        String id = settings.optString("numberStyle");
        if ("kurdish".equals(id)) id = "arabi_kurdi";
        else if (!"hindi".equals(id) && !"latin".equals(id) && !"urdu_farsi".equals(id)) id = lang.optString("numericRowId", "latin");
        if (hybrid) {
            JSONArray row = layout("numericRow", "kurdi_hybrid", "").optJSONArray(0);
            if (row != null) return row;
        }
        JSONArray row = layout("numericRow", id, "latin").optJSONArray(0);
        return row == null ? new JSONArray() : row;
    }

    private JSONArray overrides(JSONArray base, JSONArray custom, Resolver resolver) {
        JSONArray result = new JSONArray();
        for (int i = 0; i < base.length(); i++) {
            JSONArray row = base.optJSONArray(i);
            JSONArray replacements = custom.optJSONArray(i);
            if (replacements == null) { result.put(row); continue; }
            JSONArray revised = new JSONArray();
            int cursor = 0;
            for (int j = 0; j < row.length(); j++) {
                JSONObject key = row.optJSONObject(j);
                JSONObject leaf = resolver.leaf(key, "off");
                if (leaf != null && "char".equals(type(leaf.optInt("code"), leaf.optString("label")))
                        && cursor < replacements.length()) {
                    String label = replacements.optString(cursor++);
                    key = copy(key);
                    key.remove("$");
                    if (!label.isEmpty()) put(key, "code", label.codePointAt(0));
                    else key.remove("code");
                    put(key, "label", label);
                }
                revised.put(key);
            }
            result.put(revised);
        }
        return result;
    }

    private static boolean placeholder(JSONObject node) {
        return node != null && node.optInt("code") == 0 && "placeholder".equals(node.optString("type"));
    }

    private static JSONArray joinRows(JSONArray base, JSONArray modifier, JSONArray top) {
        JSONArray joined = new JSONArray();
        if (top != null) joined.put(top);
        JSONArray first = modifier.optJSONArray(0);
        boolean merge = false;
        if (first != null && base.length() > 0) {
            for (int i = 0; i < first.length(); i++) merge |= placeholder(first.optJSONObject(i));
        }
        int count = merge ? base.length() - 1 : base.length();
        for (int i = 0; i < count; i++) joined.put(base.opt(i));
        if (merge) {
            JSONArray row = new JSONArray();
            for (int i = 0; i < first.length(); i++) {
                Object key = first.opt(i);
                if (placeholder(first.optJSONObject(i))) {
                    JSONArray last = base.optJSONArray(base.length() - 1);
                    for (int j = 0; j < last.length(); j++) row.put(last.opt(j));
                } else row.put(key);
            }
            joined.put(row);
        }
        for (int i = merge ? 1 : 0; i < modifier.length(); i++) joined.put(modifier.opt(i));
        return joined;
    }

    private void normalizeRows(JSONArray rows, JSONObject settings, Resolver resolver, JSONArray digits, boolean numberRow) {
        if ("characters".equals(resolver.mode) && rows.length() > 0) {
            JSONArray top = rows.optJSONArray(0);
            if (!numberRow && top.length() == 10 && digits.length() == 10) {
                for (int i = 0; i < top.length(); i++) {
                    JSONObject key = top.optJSONObject(i);
                    JSONObject leaf = resolver.leaf(digits.optJSONObject(i), "off");
                    if (leaf == null) continue;
                    String digit = label(leaf);
                    if (digit.isEmpty()) continue;
                    put(key, "secondary", digit);
                    JSONArray alts = arr(key, "alts");
                    if (find(alts, "value", digit) != null) continue;
                    JSONArray combined = new JSONArray().put(json("label", digit, "value", digit));
                    for (int j = 0; j < alts.length(); j++) combined.put(alts.opt(j));
                    put(key, "alts", combined);
                }
            }
            JSONArray bottom = rows.optJSONArray(rows.length() - 1);
            JSONArray filtered = new JSONArray();
            int globe = -1, emoji = -1;
            for (int i = 0; i < bottom.length(); i++) {
                JSONObject key = bottom.optJSONObject(i);
                String type = key.optString("type");
                if (settings.optBoolean("showBottomKeys")) {
                    if ("globe".equals(type) && !settings.optBoolean("showGlobeKey")
                            || "emoji".equals(type) && !settings.optBoolean("showEmojiKey")
                            || "comma".equals(type) && !settings.optBoolean("showCommaKey")) continue;
                } else if (!"symbols".equals(type) && !"space".equals(type) && !"enter".equals(type)
                        && !"backspace".equals(type) && !"kana_toggle".equals(type)) continue;
                if ("emoji".equals(type)) emoji = filtered.length();
                if ("globe".equals(type)) globe = filtered.length();
                filtered.put(key);
            }
            if (globe >= 0 && emoji >= 0 && settings.optBoolean("swapGlobeAndEmoji")) {
                Object g = filtered.opt(globe);
                set(filtered, globe, filtered.opt(emoji));
                set(filtered, emoji, g);
            }
            set(rows, rows.length() - 1, filtered);
        } else if ("numeric_advanced".equals(resolver.mode) && rows.length() >= 4) {
            double[] top = {1, 1.38, 1.38, 1.38, 1};
            for (int r = 0; r < 3; r++) {
                JSONArray row = rows.optJSONArray(r);
                if (row.length() == 5) for (int c = 0; c < 5; c++) put(row.optJSONObject(c), "width", top[c]);
            }
            JSONArray bottom = rows.optJSONArray(rows.length() - 1);
            for (int i = 0; i < bottom.length(); i++) {
                JSONObject key = bottom.optJSONObject(i);
                double width = 1;
                String primary = key.optString("primary");
                switch (key.optString("type")) {
                    case "characters":
                        String code = resolver.lang.optString("code");
                        String nativeName = resolver.lang.optString("nativeName", resolver.lang.optString("name", "ABC"));
                        String shortName = "ckb".equals(code) ? "کوردی" : "en".equals(code) ? "English"
                                : nativeName.split("[\\s(]", -1)[0];
                        put(key, "primary", shortName); width = 1.32; break;
                    case "symbols": width = 1.16; break;
                    case "comma": width = .94; break;
                    case "space": width = 2.84; break;
                    case "enter": width = 1.36; break;
                    default:
                        int keyCode = key.optInt("code");
                        if ("0".equals(primary) || "٠".equals(primary) || "۰".equals(primary) || keyCode == 48 || keyCode == 1632) width = 1.08;
                        else if ("=".equals(primary) || keyCode == 61 || ",".equals(primary) || "،".equals(primary)) width = .94;
                }
                put(key, "width", width);
            }
        } else if ("phone".equals(resolver.mode) || "phone2".equals(resolver.mode)) {
            for (int r = 0; r < rows.length(); r++) {
                JSONArray row = rows.optJSONArray(r);
                for (int c = 0; c < row.length(); c++) put(row.optJSONObject(c), "width", 1);
            }
        }
    }

    private static void set(JSONArray array, int index, Object value) {
        try { array.put(index, value); } catch (org.json.JSONException error) { throw new IllegalArgumentException(error); }
    }

    private static String type(int code, String label) {
        switch (code) {
            case -7: return "backspace";
            case -11: return "shift";
            case 32: case 12288: return "space";
            case 10: return "enter";
            case -201: return "characters";
            case -202: return "symbols";
            case -203: return "symbols2";
            case -205: return "numeric_advanced";
            case -206: return "phone";
            case -207: return "phone2";
            case -212: return "emoji";
            case -227: return "globe";
            case -301: return "settings";
            case -31: return "copy";
            case -32: return "cut";
            case -33: return "paste";
            case -35: return "select_all";
            case -111: return "compact_left";
            case -9710: return "kana_toggle";
            case 8204: return "zwnj";
            default: return ",".equals(label) || "،".equals(label) ? "comma" : ".".equals(label) ? "period" : "char";
        }
    }

    private static double width(String type, int code) {
        switch (type) {
            case "space": return 5;
            case "shift": case "backspace": return 1.55;
            case "enter": return 1.5;
            case "symbols": case "symbols2": case "characters": return 1.4;
            case "numeric_advanced": case "phone": case "phone2": case "kana_toggle": return 1.2;
            case "globe": case "emoji": return 1.12;
            default: return code == 1600 ? 1.55 : 1;
        }
    }

    private static String codePoint(int code) { return new String(Character.toChars(code)); }

    private static String label(JSONObject key) {
        JSONArray points = key.optJSONArray("codePoints");
        if (points != null && points.length() > 0) return key.optString("label").isEmpty() ? points(points) : key.optString("label");
        int code = key.optInt("code");
        String raw = key.optString("label", code > 0 ? codePoint(code) : "");
        int pipe = raw.indexOf('|');
        if (pipe >= 0 && !"<|>".equals(raw)) {
            String display = trim(raw.substring(0, pipe));
            return display.isEmpty() ? raw : display;
        }
        if (code == 1600 && raw.isEmpty()) return "━";
        if (code == 8204 && raw.isEmpty()) return "<|>";
        return raw;
    }

    private static String output(JSONObject key, boolean kurdi) {
        JSONArray points = key.optJSONArray("codePoints");
        if (points != null && points.length() > 0) return points(points);
        int code = key.optInt("code");
        String raw = key.optString("label", code > 0 ? codePoint(code) : "");
        int pipe = raw.indexOf('|');
        if (pipe >= 0 && !"<|>".equals(raw)) return raw.substring(pipe + 1);
        if (code == 1600 || code == 8204 || kurdi && code > 32) return codePoint(code);
        return raw;
    }

    private static String points(JSONArray values) {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < values.length(); i++) output.appendCodePoint(values.optInt(i));
        return output.toString();
    }

    private final class Resolver {
        final JSONObject lang;
        final String mode, shift, kana, direction;
        final boolean kurdi;
        final JSONArray slots;
        final String mapping;

        Resolver(JSONObject lang, String mode, String shift, String kana, String direction) {
            this.lang = lang;
            this.mode = mode;
            this.shift = shift;
            this.kana = kana;
            this.direction = direction;
            kurdi = "qwerty_kurdi".equals(lang.optString("characterLayoutId"));
            JSONObject currency = find(currencies, "id", lang.optString("currencySetId"));
            slots = arr(currency == null ? currencies.optJSONObject(1) : currency, "slots");
            mapping = lang.optString("popupMappingId", "default");
        }

        JSONObject leaf(JSONObject key, String state) {
            for (int depth = 0; key != null && depth < 8; depth++) {
                switch (key.optString("$")) {
                    case "variation_selector": key = key.optJSONObject("default"); break;
                    case "layout_direction_selector": key = first(key, direction, "rtl".equals(direction) ? "ltr" : "rtl"); break;
                    case "case_selector": key = "off".equals(state) ? first(key, "lower", "upper") : first(key, "upper", "lower"); break;
                    case "shift_state_selector":
                        if ("caps".equals(state)) key = first(key, "capsLock", "default", "unshifted", "shiftedManual");
                        else if ("once".equals(state)) key = first(key, "shiftedManual", "shiftedAuto", "default", "unshifted");
                        else key = first(key, "unshifted", "default", "shiftedManual");
                        break;
                    case "kana_selector": key = "kata".equals(kana) ? first(key, "kata", "hira") : first(key, "hira", "kata"); break;
                    case "char_width_selector": key = first(key, "half", "full"); break;
                    default: return key;
                }
            }
            return key;
        }

        JSONObject key(JSONObject raw, int row, int col) {
            JSONObject key = leaf(raw, shift);
            if (key == null) return null;
            int code = key.optInt("code");
            double keyWidth = key.optDouble("width", 0);
            Popup inline = new Popup(key.optJSONObject("popup"));
            if (code <= -801 && code >= -806) {
                JSONObject slot = slots.optJSONObject(-code - 801);
                String label = slot == null ? "$" : slot.optString("label");
                int slotCode = slot == null ? 36 : slot.optInt("code");
                return json("id", "k_" + row + "_" + col + "_cur_" + slotCode, "code", slotCode, "primary", label, "output", label,
                        "secondary", inline.secondary, "alts", inline.options, "width", keyWidth != 0 ? keyWidth : 1,
                        "type", "char", "groupId", key.opt("groupId"));
            }

            String label = label(key), output = output(key, kurdi), type = type(code, label);
            if ("char".equals(type) && !"off".equals(shift) && !kurdi && label.length() == 1 && !lower(label).equals(label.toUpperCase(Locale.ROOT))) {
                label = label.toUpperCase(Locale.ROOT);
                output = output.toUpperCase(Locale.ROOT);
            }
            JSONObject ext = "period".equals(type) ? external("~right")
                    : "char".equals(type) || "comma".equals(type) ? external(kurdi ? output : label) : null;
            Popup external = new Popup(ext);
            JSONArray alts = new JSONArray();
            Set<String> seen = new HashSet<>();
            boolean at = code == 64 || "@".equals(label) || "@".equals(output);
            if (at) addAlts(alts, seen, emails);
            addAlts(alts, seen, inline.options);
            addAlts(alts, seen, external.options);
            String id = "k_" + mode + "_" + row + "_" + col + "_" + key.optString("code", label);
            return json("id", id, "code", key.opt("code"), "primary", friendly(type, code, label), "output", output,
                    "secondary", at ? ".com" : inline.secondary != null ? inline.secondary : external.secondary,
                    "alts", alts, "width", keyWidth > 0 ? keyWidth : width(type, code), "type", type, "groupId", key.opt("groupId"));
        }

        private JSONObject external(String query) {
            JSONObject def = obj(popups, "default");
            JSONObject map = popups.optJSONObject(mapping);
            if (map == null) map = def;
            String bucket = "off".equals(shift) ? "lower" : "upper";
            JSONObject popup = obj(map, bucket).optJSONObject(query);
            if (popup == null) popup = first(obj(map, "all"), query, lower(query));
            if (popup == null) popup = obj(def, bucket).optJSONObject(query);
            return popup == null ? obj(def, "all").optJSONObject(query) : popup;
        }

        private String friendly(String type, int code, String label) {
            switch (type) {
                case "symbols": return "!#1";
                case "symbols2": return "1/2";
                case "characters": return "rtl".equals(direction) ? "ئەب" : "ABC";
                case "numeric_advanced": return "rtl".equals(direction) ? "١٢٣" : "1234";
                case "phone2": return "*#";
                case "phone": return "123";
                default: return code == -9701 ? "全/半" : code == -9702 ? "全" : code == -9703 ? "半" : label;
            }
        }

        private final class Popup {
            final JSONArray options = new JSONArray();
            final Set<String> seen = new HashSet<>();
            String secondary;

            Popup(JSONObject raw) {
                if (raw == null) return;
                add(raw.optJSONObject("main"), true);
                JSONArray entries = arr(raw, "relevant");
                for (int i = 0; i < entries.length(); i++) add(entries.optJSONObject(i), false);
                if (secondary == null && options.length() > 0) secondary = options.optJSONObject(0).optString("label");
            }

            private void add(JSONObject raw, boolean main) {
                JSONObject key = leaf(raw, shift);
                if (key == null) return;
                int code = key.optInt("code");
                if (code <= -801 && code >= -806) {
                    JSONObject slot = slots.optJSONObject(-code - 801);
                    if (slot == null) return;
                    String label = slot.optString("label");
                    if (main && secondary == null) secondary = label;
                    if (seen.add(label)) options.put(json("label", label, "value", label, "code", slot.opt("code")));
                } else {
                    String label = label(key), value = output(key, false);
                    if (label.isEmpty() && value.isEmpty()) return;
                    if (main && secondary == null && !label.isEmpty()) secondary = label;
                    if (seen.add(label + "::" + value)) options.put(json("label", label.isEmpty() ? value : label, "value", value, "code", key.opt("code")));
                }
            }
        }
    }

    private static JSONObject first(JSONObject object, String... keys) {
        for (String key : keys) {
            JSONObject value = object.optJSONObject(key);
            if (value != null) return value;
        }
        return null;
    }

    private static void addAlts(JSONArray destination, Set<String> seen, JSONArray source) {
        for (int i = 0; i < source.length(); i++) {
            JSONObject item = source.optJSONObject(i);
            if (seen.add(item.optString("label") + "::" + item.optString("value"))) destination.put(item);
        }
    }
}
