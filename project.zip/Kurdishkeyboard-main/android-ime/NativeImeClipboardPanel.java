package io.kurdikebord.app;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.Selection;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.AbsListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Native rendering of the existing clipboard history and its card actions. */
final class NativeImeClipboardPanel {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int ORANGE = 0xffff7a00;
    private static final int MUTED = 0xff71717a;
    private final NativeImeView keyboard;
    private final NativeImeView.StringAction translate;
    private final Set<String> selected = new HashSet<>();
    private boolean selecting;
    private int filter;
    private int firstRow;
    private int firstRowTop;
    private String menuId;
    private String editId;
    private EditText editField;
    private ListView scroll;
    private FrameLayout root;
    private TextView toast;

    NativeImeClipboardPanel(NativeImeView keyboard, NativeImeView.StringAction translate) {
        this.keyboard = keyboard;
        this.translate = translate;
    }

    void reset() {
        selecting = false;
        filter=0;
        selected.clear();
        firstRow = 0;
        firstRowTop = 0;
        scroll = null;
        root = null;
        toast = null;
        menuId = null;
        editId = null;
        editField = null;
    }

    boolean editing() { return editId != null; }

    View render() {
        if (scroll != null && scroll.getChildCount() > 0) {
            firstRow = scroll.getFirstVisiblePosition();
            firstRowTop = scroll.getChildAt(0).getTop();
        }
        root = new FrameLayout(keyboard.getContext());
        root.setBackgroundColor(keyboard.bg());
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(Math.max(keyboard.settings.optInt("keyboardHeightPx", 248) + 36, 315))));
        toast = null;
        LinearLayout body = keyboard.column();
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(body, new FrameLayout.LayoutParams(MATCH, MATCH));

        List<JSONObject> items = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        for (int index = 0; index < keyboard.clipboard.length(); index++) {
            JSONObject item = keyboard.clipboard.optJSONObject(index);
            if (item == null) continue;
            ids.add(item.optString("id"));
            if(ImeSmartText.clipMatches(item.optString("text"),item.optBoolean("pinned"),filter))items.add(item);
        }
        selected.retainAll(ids);
        Collections.sort(items, (left,right)->{int pinned=Boolean.compare(right.optBoolean("pinned"),left.optBoolean("pinned"));return pinned!=0?pinned:Long.compare(right.optLong("timestamp"),left.optLong("timestamp"));});
        addHeader(body, items.size());
        if (!selecting) {
            android.content.Context context = keyboard.getContext();
            LinearLayout consent = keyboard.row();
            consent.setGravity(Gravity.CENTER_VERTICAL);
            TextView caption = text("تۆمارکردنی کۆپی و بڕین لە دەرەوەی کیبۆرد", 11, foreground(), 700);
            consent.addView(caption, new LinearLayout.LayoutParams(0, dp(38), 1));
            NativeSettingsToggle toggle = new NativeSettingsToggle(context, keyboard.appearance,
                    "تۆمارکردنی کۆپی و بڕین لە دەرەوەی کیبۆرد", ImeStateStore.captureHiddenClipboard(context), enabled -> {
                if (enabled) {
                    // This is device-local consent. It never enables cloud backup.
                    if (!ImeStateStore.incognito(context) && ImeStateStore.clipboardCaptureEnabled(context))
                        ImeStateStore.setCaptureHiddenClipboard(context, true);
                } else ImeStateStore.setCaptureHiddenClipboard(context, false);
                refresh();
            });
            toggle.setEnabled(!ImeStateStore.incognito(context) && ImeStateStore.clipboardCaptureEnabled(context));
            consent.addView(toggle, new LinearLayout.LayoutParams(dp(52), dp(30)));
            body.addView(consent, new LinearLayout.LayoutParams(MATCH, dp(38)));
        }
        if(!selecting){LinearLayout filters=keyboard.row();String[] names={"هەموو","پینکراو","لینک","دەق"};
            for(int i=0;i<names.length;i++){final int index=i; TextView chip=action(names[i],11,filter==i?0xff8ec2ff:foreground(),filter==i?0x3338bdf8:0x20222222,10,()->{filter=index;firstRow=firstRowTop=0;scroll=null;refresh();});
                filters.addView(chip,new LinearLayout.LayoutParams(0,dp(30),1));}
            body.addView(filters,new LinearLayout.LayoutParams(MATCH,dp(34)));
        }
        if (items.isEmpty()) {
            scroll = null;
            firstRow = firstRowTop = 0;
            LinearLayout empty = keyboard.column();
            empty.setGravity(Gravity.CENTER);
            ImageView image = icon("ic_clipboards", MUTED, 28);
            image.setAlpha(.4f);
            empty.addView(image, new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView message = text(filter==0?"هیچ دەقێکی لەبەرگیراو نییە":"هیچ دەقێک لەم پۆلەدا نییە", 12, MUTED, 400);
            LinearLayout.LayoutParams spacing = new LinearLayout.LayoutParams(WRAP, WRAP);
            spacing.topMargin = dp(8);
            empty.addView(message, spacing);
            body.addView(empty, new LinearLayout.LayoutParams(MATCH, 0, 1));
        } else {
            addCards(body, items);
            addFooter(body);
        }
        JSONObject currentMenu = menuId == null ? null : find(menuId);
        if (currentMenu != null) showMenu(currentMenu);
        else menuId = null;
        return root;
    }

    /** Rebuild just the clipboard surface, not the toolbar or keyboard deck. */
    void refresh() {
        if (editing() || root == null || !(root.getParent() instanceof ViewGroup) || !root.isAttachedToWindow()) {
            keyboard.render();
            return;
        }
        FrameLayout old = root;
        ViewGroup parent = (ViewGroup) old.getParent();
        int position = parent.indexOfChild(old);
        View replacement = render();
        parent.removeViewAt(position);
        parent.addView(replacement, position);
    }

    private void addHeader(LinearLayout body, int count) {
        LinearLayout header = keyboard.row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(circle("arrow_right", "گەڕانەوە", 20, foreground(), () -> keyboard.openPanel("keys")), new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout heading = keyboard.row();
        heading.setGravity(Gravity.CENTER);
        TextView title = text("لەبەرگیراوەکان", 15, foreground(), 800);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        heading.addView(title, new LinearLayout.LayoutParams(WRAP, WRAP));
        if (count > 0) {
            TextView counter = text("(" + count + ")", 11, 0xffa1a1aa, 700);
            LinearLayout.LayoutParams spacing = new LinearLayout.LayoutParams(WRAP, WRAP);
            spacing.setMarginStart(dp(6));
            heading.addView(counter, spacing);
        }
        header.addView(heading, new LinearLayout.LayoutParams(0, MATCH, 1));
        LinearLayout actions = keyboard.row();
        actions.setGravity(Gravity.CENTER_VERTICAL);
        if (selecting && !selected.isEmpty()) {
            TextView delete = action("سڕینەوە (" + selected.size() + ")", 12, 0xfffb7185, 0x33f43f5e, 16, this::deleteSelected);
            addHeaderAction(actions, delete, WRAP, dp(32));
        }
        if (selecting) {
            addHeaderAction(actions, circle("close", "پاشگەزبوونەوە", 16, foreground(), this::leaveSelection), dp(36), dp(36));
        } else {
            if (!keyboard.clipboardCurrentText().trim().isEmpty()) {
                View save = circle("plus", "پاشەکەوتکردنی دەقی ئێستا", 16,
                        keyboard.light() ? 0xff0369a1 : 0xff38bdf8, () -> keyboard.systemClipboard(keyboard.clipboardCurrentText()));
                if (keyboard.light()) save.setBackground(face(0xffe0f2fe, 18, 0, 0));
                addHeaderAction(actions, save, dp(36), dp(36));
            }
            addHeaderAction(actions, circle("layout_list", "هەڵبژاردن و بەڕێوەبردن", 16, foreground(), () -> {
                if (keyboard.clipboard.length() == 0) return;
                selecting = true;
                refresh();
            }), dp(36), dp(36));
        }
        header.addView(actions, new LinearLayout.LayoutParams(WRAP, MATCH));
        LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(MATCH, dp(36));
        position.bottomMargin = dp(10);
        body.addView(header, position);
    }

    private void addHeaderAction(LinearLayout actions, View view, int width, int height) {
        LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(width, height);
        if (actions.getChildCount() > 0) position.setMarginStart(dp(6));
        actions.addView(view, position);
    }

    private void addCards(LinearLayout body, List<JSONObject> items) {
        // ListView asks for visible rows only; the old ScrollView inflated every card.
        scroll = new ListView(keyboard.getContext());
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setDivider(null);
        scroll.setDividerHeight(0);
        scroll.setSelector(android.R.color.transparent);
        scroll.setCacheColorHint(Color.TRANSPARENT);
        scroll.setItemsCanFocus(true);
        scroll.setPadding(dp(2), 0, 0, dp(8));
        scroll.setClipToPadding(false);
        final int columns = keyboard.settings.optInt("clipboardGridColumns", 2) == 1 ? 1 : 2;
        scroll.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return (items.size() + columns - 1) / columns; }
            @Override public Object getItem(int position) { return items.get(position * columns); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int index, View convertView, ViewGroup parent) {
                // ListView can reuse a row measured for this same position. Different rows
                // have different gesture closures, so do not reuse them without rebinding.
                if (convertView != null && Integer.valueOf(index).equals(convertView.getTag())) return convertView;
                LinearLayout row = keyboard.row();
                row.setTag(index);
                row.setBaselineAligned(false);
                row.setGravity(Gravity.TOP);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                row.setPadding(0, index > 0 ? dp(8) : 0, 0, 0);
                row.setLayoutParams(new AbsListView.LayoutParams(MATCH, WRAP));
                for (int column = 0; column < columns; column++) {
                    LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(0, MATCH, 1);
                    if (column > 0) position.setMarginStart(dp(8));
                    int itemIndex = index * columns + column;
                    View card = itemIndex < items.size() ? card(items.get(itemIndex), columns == 1 ? 70 : 88) : new View(keyboard.getContext());
                    row.addView(card, position);
                }
                return row;
            }
        });
        body.addView(scroll, new LinearLayout.LayoutParams(MATCH, 0, 1));
        scroll.setSelectionFromTop(Math.min(firstRow, Math.max(0, scroll.getCount() - 1)), firstRowTop);
    }

    private View card(JSONObject item, int minHeight) {
        String id = item.optString("id");
        boolean pinned = item.optBoolean("pinned");
        boolean checked = selected.contains(id);
        FrameLayout frame = new FrameLayout(keyboard.getContext());
        frame.setBackground(face(keyboard.bg(), 16, 0, 0));
        frame.setClipToOutline(true);
        TextView underlay = text("", 12, Color.WHITE, 800);
        underlay.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        underlay.setVisibility(View.INVISIBLE);
        underlay.setPadding(dp(14), 0, dp(14), 0);
        frame.addView(underlay, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout card = keyboard.column();
        card.setMinimumHeight(dp(minHeight));
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(face(checked ? 0x26ff7a00 : keyboard.light() ? Color.WHITE : 0xff16171c,
                16, 1, checked ? ORANGE : keyboard.light() ? 0xffe2e8f0 : 0x0fffffff));
        LinearLayout top = keyboard.row();
        top.setGravity(Gravity.TOP);
        String preview = ImeClipboardText.preview(item.optString("text"));
        TextView clipText = text(preview, 12, foreground(), 400);
        clipText.setGravity(Gravity.RIGHT | Gravity.TOP);
        clipText.setMaxLines(3);
        clipText.setEllipsize(TextUtils.TruncateAt.END);
        relaxedLines(clipText);
        top.addView(clipText, new LinearLayout.LayoutParams(0, WRAP, 1));
        if (selecting) {
            FrameLayout marker = new FrameLayout(keyboard.getContext());
            marker.setBackground(face(checked ? ORANGE : Color.TRANSPARENT, 8, 1, checked ? ORANGE : MUTED));
            if (checked) marker.addView(icon("check", Color.WHITE, 10), new FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER));
            LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(dp(16), dp(16));
            position.setMarginStart(dp(6));
            position.topMargin = dp(2);
            top.addView(marker, position);
        }
        card.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP, 1));
        int statusColor = pinned ? keyboard.light() ? 0xff92400e : 0xffff9a3d : keyboard.light() ? 0xff64748b : 0xffa1a1aa;
        LinearLayout pill = keyboard.row();
        pill.setGravity(Gravity.CENTER);
        pill.setBackground(face(pinned ? keyboard.light() ? 0xfffef3c7 : 0x26ff7a00 : keyboard.light() ? 0xfff1f5f9 : 0xff22242c, 12, 0, 0));
        if (pinned) {
            LinearLayout.LayoutParams iconPosition = new LinearLayout.LayoutParams(dp(10), dp(10));
            iconPosition.setMarginEnd(dp(4));
            pill.addView(icon("pin", statusColor, 10), iconPosition);
        }
        pill.addView(text(pinned ? "جێگیرکراوە · پارێزراوە" : "هەمیشەیی پارێزراوە", 10, statusColor, 600));
        LinearLayout.LayoutParams pillPosition = new LinearLayout.LayoutParams(MATCH, dp(23));
        pillPosition.topMargin = dp(8);
        card.addView(pill, pillPosition);
        frame.setMinimumHeight(dp(minHeight));
        frame.addView(card, new FrameLayout.LayoutParams(MATCH, MATCH));
        frame.setContentDescription(preview);
        frame.setHapticFeedbackEnabled(false);
        frame.setSelected(checked);
        press(frame, () -> onCardPressed(id));
        if (!selecting) {
            frame.setOnLongClickListener(view -> { openMenu(id); return true; });
            frame.setOnTouchListener(new CardGesture(frame, card, underlay, id, pinned));
        }
        return frame;
    }

    private void addFooter(LinearLayout body) {
        LinearLayout footer = keyboard.row();
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(dp(2), dp(6), dp(2), 0);
        TextView help = text("ڕاکێشان بۆ چەپ: سڕینەوە · بۆ ڕاست: پینکردن · دەستڕاگرتن: بژاردەکان", 10, MUTED, 400);
        help.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        footer.addView(help, new LinearLayout.LayoutParams(0, WRAP, 1));
        if (selecting) {
            TextView clear = text("پاککردنەوەی ناجێگیرەکان", 10, 0xfffb7185, 700);
            press(clear, () -> removeItems(true));
            LinearLayout.LayoutParams position = new LinearLayout.LayoutParams(WRAP, WRAP);
            position.setMarginStart(dp(8));
            footer.addView(clear, position);
        }
        body.addView(footer, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private void onCardPressed(String id) {
        if (selecting) {
            if (!selected.add(id)) selected.remove(id);
            refresh();
            return;
        }
        JSONObject item = find(id);
        if (item == null) return;
        keyboard.insert(item.optString("text"));
        if (keyboard.settings.optBoolean("clipboardHideOnPaste", true)) keyboard.openPanel("keys");
    }

    private void leaveSelection() {
        selecting = false;
        selected.clear();
        refresh();
    }

    private void deleteSelected() { removeItems(false); }

    private void removeItems(boolean unpinned) {
        JSONArray remaining = new JSONArray();
        Set<String> removedIds = new HashSet<>();
        for (int index = 0; index < keyboard.clipboard.length(); index++) {
            JSONObject item = keyboard.clipboard.optJSONObject(index);
            if (item == null) continue;
            String id = item.optString("id");
            if (unpinned ? item.optBoolean("pinned") : !selected.contains(id)) remaining.put(item);
            else removedIds.add(id);
        }
        selecting = false;
        selected.clear();
        keyboard.clipboardUpdated(remaining, removedIds, unpinned);
    }

    private JSONObject find(String id) {
        for (int index = 0; index < keyboard.clipboard.length(); index++) {
            JSONObject item = keyboard.clipboard.optJSONObject(index);
            if (item != null && id.equals(item.optString("id"))) return item;
        }
        return null;
    }

    private void changeItem(String id, boolean delete) {
        if (delete) menuId = null;
        JSONArray updated = new JSONArray();
        for (int index = 0; index < keyboard.clipboard.length(); index++) {
            JSONObject item = keyboard.clipboard.optJSONObject(index);
            if (item == null) continue;
            if (id.equals(item.optString("id"))) {
                if (delete) continue;
                ImeStateStore.put(item, "pinned", !item.optBoolean("pinned"));
            }
            updated.put(item);
        }
        keyboard.clipboardUpdated(updated, delete ? Collections.singleton(id) : Collections.emptySet(), false);
    }

    private void openMenu(String id) {
        JSONObject item = find(id);
        if (item == null || root == null || !root.isAttachedToWindow()) return;
        menuId = id;
        showMenu(item);
    }

    private void showMenu(JSONObject item) {
        FrameLayout scrim = new FrameLayout(keyboard.getContext());
        scrim.setBackgroundColor(0xb3000000);
        scrim.setOnClickListener(view -> { menuId = null; root.removeView(scrim); });
        root.addView(scrim, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout menu = keyboard.row();
        menu.setClickable(true);
        menu.setGravity(Gravity.CENTER_VERTICAL);
        menu.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int deckWidth = root.getWidth();
        if (deckWidth <= 0) {
            deckWidth = keyboard.getResources().getDisplayMetrics().widthPixels * keyboard.settings.optInt("keyboardWidthPercent", 100) / 100;
        }
        int width = Math.min(dp(360), Math.max(dp(160), deckWidth - dp(24)));
        scrim.addView(menu, new FrameLayout.LayoutParams(width, WRAP, Gravity.CENTER));

        boolean pinned = item.optBoolean("pinned");
        String id = item.optString("id");
        int border = keyboard.light() ? 0xffe2e8f0 : 0x26ffffff;
        LinearLayout details = keyboard.column();
        details.setPadding(dp(12), dp(12), dp(12), dp(12));
        details.setBackground(face(keyboard.light() ? Color.WHITE : 0xff1a1b21, 16, 1, border));
        ScrollView scrollText = new ScrollView(keyboard.getContext()) {
            @Override protected void onMeasure(int widthSpec, int heightSpec) {
                super.onMeasure(widthSpec, MeasureSpec.makeMeasureSpec(dp(125), MeasureSpec.AT_MOST));
            }
        };
        TextView clip = text(item.optString("text"), 12, foreground(), 400);
        clip.setGravity(Gravity.RIGHT | Gravity.TOP);
        relaxedLines(clip);
        scrollText.addView(clip, new ScrollView.LayoutParams(MATCH, WRAP));
        details.addView(scrollText, new LinearLayout.LayoutParams(MATCH, WRAP));
        int pinColor = pinned ? 0xffff9a3d : keyboard.light() ? 0xff334155 : 0xffe4e4e7;
        TextView pin = action(pinned ? "جێگیرکراوە (لابردن)" : "هەمیشەیی پارێزراوە", 11, pinColor,
                pinned ? 0x33ff7a00 : keyboard.light() ? 0xfff1f5f9 : 0xff2c2e36, 12, () -> changeItem(id, false));
        pin.setCompoundDrawablesRelativeWithIntrinsicBounds(keyboard.appearance.icon("pin", pinColor, 14), null, null, null);
        pin.setCompoundDrawablePadding(dp(6));
        LinearLayout.LayoutParams pinPosition = new LinearLayout.LayoutParams(MATCH, dp(34));
        pinPosition.topMargin = dp(10);
        details.addView(pin, pinPosition);
        menu.addView(details, new LinearLayout.LayoutParams(0, WRAP, 1));

        LinearLayout actions = keyboard.column();
        actions.setPadding(0, dp(6), 0, dp(6));
        actions.setBackground(face(keyboard.light() ? Color.WHITE : 0xff1a1b21, 16, 1, border));
        menuAction(actions, "ic_translate", "وەرگێڕان", () -> { menuId = null; translate.accept(item.optString("text")); });
        menuAction(actions, "pencil", "دەستکاری", () -> startEdit(item));
        menuAction(actions, "ic_trash", "سڕینەوە", () -> { menuId = null; changeItem(id, true); });
        LinearLayout.LayoutParams actionsPosition = new LinearLayout.LayoutParams(Math.min(dp(152), width / 2), WRAP);
        actionsPosition.setMarginStart(dp(10));
        menu.addView(actions, actionsPosition);
    }

    private void menuAction(LinearLayout actions, String icon, String label, Runnable operation) {
        TextView button = text(label, 14, foreground(), 700);
        button.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        button.setPadding(dp(16), 0, dp(16), 0);
        button.setCompoundDrawablesRelativeWithIntrinsicBounds(keyboard.appearance.icon(icon, ORANGE, 18), null, null, null);
        button.setCompoundDrawablePadding(dp(12));
        press(button, operation);
        actions.addView(button, new LinearLayout.LayoutParams(MATCH, dp(48)));
    }

    private void startEdit(JSONObject item) {
        menuId = null;
        editId = item.optString("id");
        editField = new EditText(keyboard.getContext());
        editField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        editField.setShowSoftInputOnFocus(false);
        editField.setText(item.optString("text"));
        editField.setSelection(editField.length());
        editField.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        editField.setTextSize(TypedValue.COMPLEX_UNIT_PX, keyboard.appearance.px(12));
        editField.setTypeface(keyboard.appearance.font(keyboard.font(), 400));
        editField.setTextColor(foreground());
        editField.setGravity(Gravity.TOP | Gravity.START);
        editField.setIncludeFontPadding(false);
        editField.setPadding(dp(10), dp(10), dp(10), dp(10));
        editField.setBackground(face(keyboard.light() ? 0xfff8fafc : 0xff101115, 12, 1, ORANGE));
        keyboard.render();
    }

    View renderEditor() {
        LinearLayout editor = keyboard.column();
        editor.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        editor.setPadding(dp(12), dp(9), dp(12), dp(8));
        editor.setBackground(face(keyboard.light() ? Color.WHITE : 0xff181a20, 16, 1, keyboard.light() ? 0xffe2e8f0 : 0x26ffffff));
        LinearLayout header = keyboard.row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("دەستکاریکردنی لەبەرگیراو", 12, foreground(), 800);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        title.setCompoundDrawablesRelativeWithIntrinsicBounds(keyboard.appearance.icon("pencil", ORANGE, 14), null, null, null);
        title.setCompoundDrawablePadding(dp(8));
        header.addView(title, new LinearLayout.LayoutParams(0, dp(28), 1));
        header.addView(circle("close", "داخستن", 14, 0xffa1a1aa, this::cancelEdit), new LinearLayout.LayoutParams(dp(28), dp(28)));
        editor.addView(header);
        if (editField.getParent() instanceof ViewGroup) ((ViewGroup) editField.getParent()).removeView(editField);
        LinearLayout.LayoutParams editPosition = new LinearLayout.LayoutParams(MATCH, dp(96));
        editPosition.topMargin = dp(8);
        editor.addView(editField, editPosition);
        LinearLayout controls = keyboard.row();
        TextView save = action("پاشەکەوتکردن", 12, Color.WHITE, ORANGE, 12, this::saveEdit);
        controls.addView(save, new LinearLayout.LayoutParams(0, dp(36), 1));
        LinearLayout.LayoutParams cancelPosition = new LinearLayout.LayoutParams(WRAP, dp(36));
        cancelPosition.setMarginStart(dp(8));
        controls.addView(action("پاشگەزبوونەوە", 12, foreground(), keyboard.light() ? 0xffe2e8f0 : 0x1affffff, 12, this::cancelEdit), cancelPosition);
        LinearLayout.LayoutParams controlsPosition = new LinearLayout.LayoutParams(MATCH, WRAP);
        controlsPosition.topMargin = dp(8);
        editor.addView(controls, controlsPosition);
        return editor;
    }

    void insertInEdit(String value) {
        Editable text = editField.getText();
        int start = Math.max(0, Math.min(editField.getSelectionStart(), editField.getSelectionEnd()));
        int end = Math.max(start, Math.max(editField.getSelectionStart(), editField.getSelectionEnd()));
        text.replace(start, end, value);
        editField.setSelection(start + value.length());
    }

    void deleteInEdit(boolean word) {
        Editable text = editField.getText();
        int start = Math.max(0, Math.min(editField.getSelectionStart(), editField.getSelectionEnd()));
        int end = Math.max(start, Math.max(editField.getSelectionStart(), editField.getSelectionEnd()));
        if (start == end && start > 0) {
            if (word) {
                while (start > 0 && Character.isWhitespace(text.charAt(start - 1))) start--;
                while (start > 0 && !Character.isWhitespace(text.charAt(start - 1))) start--;
            } else start = Character.offsetByCodePoints(text, start, -1);
        }
        text.delete(start, end);
        editField.setSelection(start);
    }

    void editAction(int command) { editField.onTextContextMenuItem(command); }

    void moveCursor(int x, int y, boolean extend) {
        Editable text = editField.getText();
        Layout layout = editField.getLayout();
        if (layout == null) return;
        if (y < 0) {
            if (extend) Selection.extendUp(text, layout); else Selection.moveUp(text, layout);
        } else if (y > 0) {
            if (extend) Selection.extendDown(text, layout); else Selection.moveDown(text, layout);
        } else if (x < 0) {
            if (extend) Selection.extendLeft(text, layout); else Selection.moveLeft(text, layout);
        } else if (x > 0) {
            if (extend) Selection.extendRight(text, layout); else Selection.moveRight(text, layout);
        }
    }

    void moveLineEdge(boolean end, boolean extend) {
        Editable text = editField.getText();
        Layout layout = editField.getLayout();
        if (layout == null) return;
        if (end) {
            if (extend) Selection.extendToRightEdge(text, layout); else Selection.moveToRightEdge(text, layout);
        } else {
            if (extend) Selection.extendToLeftEdge(text, layout); else Selection.moveToLeftEdge(text, layout);
        }
    }

    private void cancelEdit() {
        editId = null;
        editField = null;
        keyboard.render();
    }

    private void saveEdit() {
        JSONObject item = find(editId);
        String value = editField.getText().toString().trim();
        editId = null;
        editField = null;
        if (item == null || value.isEmpty()) { keyboard.render(); return; }
        ImeStateStore.put(item, "text", value);
        ImeStateStore.put(item, "timestamp", System.currentTimeMillis());
        keyboard.clipboardUpdated(keyboard.clipboard);
    }

    private void showToast(String message) {
        if (root == null || !root.isAttachedToWindow()) return;
        if (toast != null) root.removeView(toast);
        TextView note = text(message, 11, Color.WHITE, 700);
        note.setBackground(face(0xeb111318, 14, 1, 0x26ffffff));
        note.setPadding(dp(12), dp(4), dp(12), dp(4));
        FrameLayout.LayoutParams position = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        position.topMargin = dp(52);
        root.addView(note, position);
        toast = note;
        FrameLayout panel = root;
        note.postDelayed(() -> panel.removeView(note), 1600);
    }

    private int dp(double value) { return keyboard.dp(value); }
    private int foreground() { return keyboard.light() ? 0xff0f172a : Color.WHITE; }
    private Drawable face(int fill, int radius, int strokeWidth, int stroke) { return keyboard.appearance.background(fill, radius, strokeWidth, stroke); }
    private TextView text(String label, int size, int color, int weight) { return keyboard.appearance.text(label, size, color, keyboard.font(), weight); }

    private void relaxedLines(TextView text) {
        android.graphics.Paint.FontMetricsInt metrics = text.getPaint().getFontMetricsInt();
        int extra = Math.max(0, dp(19.5) - (metrics.descent - metrics.ascent));
        text.setLineSpacing(extra, 1f);
        text.setPadding(0, extra / 2, 0, extra - extra / 2);
    }

    private ImageView icon(String name, int color, int size) {
        ImageView image = new ImageView(keyboard.getContext());
        image.setImageDrawable(keyboard.appearance.icon(name, color, size));
        return image;
    }

    private FrameLayout circle(String name, String label, int size, int color, Runnable operation) {
        FrameLayout button = new FrameLayout(keyboard.getContext());
        button.setContentDescription(label);
        button.setBackground(face(keyboard.light() ? 0xffe2e8f0 : 0xff1a1b20, 18, 0, 0));
        button.addView(icon(name, color, size), new FrameLayout.LayoutParams(dp(size), dp(size), Gravity.CENTER));
        press(button, operation);
        return button;
    }

    private TextView action(String label, int size, int color, int fill, int radius, Runnable operation) {
        TextView button = text(label, size, color, 700);
        button.setPadding(dp(10), 0, dp(10), 0);
        button.setBackground(face(fill, radius, 0, 0));
        press(button, operation);
        return button;
    }

    private void press(View view, Runnable operation) {
        view.setFocusable(true);
        view.setSoundEffectsEnabled(false);
        view.setOnClickListener(clicked -> operation.run());
    }

    private final class CardGesture implements View.OnTouchListener {
        private final View frame;
        private final View front;
        private final TextView underlay;
        private final String id;
        private final boolean pinned;
        private final Runnable hold;
        private float x;
        private float y;
        private float pull;
        private int pointer;
        private int threshold;
        private boolean horizontal;
        private boolean vertical;
        private boolean held;
        private boolean crossed;
        private boolean moved;
        private int underlayState;

        CardGesture(View frame, View front, TextView underlay, String id, boolean pinned) {
            this.frame = frame;
            this.front = front;
            this.underlay = underlay;
            this.id = id;
            this.pinned = pinned;
            hold = () -> {
                if (!frame.isAttachedToWindow()) return;
                held = frame.performLongClick();
                if (held) keyboard.vibrate(15);
            };
            frame.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override public void onViewAttachedToWindow(View v) { }
                @Override public void onViewDetachedFromWindow(View v) {
                    frame.removeCallbacks(hold);
                    restore();
                }
            });
        }

        @Override public boolean onTouch(View target, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x = event.getRawX();
                    y = event.getRawY();
                    pointer = event.getPointerId(0);
                    threshold = Math.max(dp(46), Math.min(dp(78), Math.round(frame.getWidth() * .34f)));
                    horizontal = vertical = held = crossed = moved = false;
                    pull = 0;
                    underlayState = 0;
                    frame.postDelayed(hold, 360);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (event.findPointerIndex(pointer) == 0 && !held) drag(event.getRawX() - x, event.getRawY() - y);
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    frame.removeCallbacks(hold);
                    moved = true;
                    return true;
                case MotionEvent.ACTION_UP:
                    frame.removeCallbacks(hold);
                    if (horizontal && crossed) {
                        boolean delete = pull < 0;
                        restore();
                        changeItem(id, delete);
                        showToast(delete ? "لەبەرگیراو سڕایەوە" : pinned ? "جێگیرکردن لابرا" : "جێگیرکرا (پین)");
                    } else {
                        restore();
                        if (!moved && !held) frame.performClick();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    frame.removeCallbacks(hold);
                    restore();
                    return true;
                default: return true;
            }
        }

        private void drag(float dx, float dy) {
            if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                moved = true;
                frame.removeCallbacks(hold);
            }
            if (vertical) return;
            if (!horizontal) {
                if (Math.abs(dy) > dp(10) && Math.abs(dy) > Math.abs(dx)) { vertical = true; return; }
                if (Math.abs(dx) <= dp(10) || Math.abs(dx) < Math.abs(dy) * 1.1) return;
                horizontal = true;
                frame.getParent().requestDisallowInterceptTouchEvent(true);
            }
            int maxPull = Math.max(dp(92), Math.min(dp(130), Math.round(frame.getWidth() * .58f)));
            pull = Math.max(-maxPull, Math.min(maxPull, dx));
            boolean ready = Math.abs(pull) >= threshold;
            if (ready && !crossed) keyboard.vibrate(14);
            crossed = ready;
            boolean left = pull < 0;
            int nextState = (left ? 1 : 3) + (ready ? 1 : 0);
            front.setTranslationX(pull);
            if (nextState == underlayState) return;
            underlayState = nextState;
            int color = left ? Color.WHITE : 0xff111318;
            underlay.setVisibility(View.VISIBLE);
            underlay.setBackgroundColor(left ? ready ? 0xffe11d48 : 0xbfe11d48 : ready ? ORANGE : 0xbfff7a00);
            underlay.setText(left ? "سڕینەوە" : pinned ? "لابردنی پین" : "پینکردن");
            underlay.setTextColor(color);
            underlay.setGravity(Gravity.CENTER_VERTICAL | (left ? Gravity.RIGHT : Gravity.LEFT));
            Drawable image = keyboard.appearance.icon(left ? "trash_2" : pinned ? "pin_off" : "pin", color, 16);
            underlay.setCompoundDrawablesWithIntrinsicBounds(left ? null : image, null, left ? image : null, null);
            underlay.setCompoundDrawablePadding(dp(6));
        }

        private void restore() {
            front.setTranslationX(0);
            underlayState = 0;
            underlay.setVisibility(View.INVISIBLE);
            if (frame.getParent() != null) frame.getParent().requestDisallowInterceptTouchEvent(false);
        }
    }
}
