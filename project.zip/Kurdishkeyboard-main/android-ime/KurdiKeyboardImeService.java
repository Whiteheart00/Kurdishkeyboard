package io.kurdikebord.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import android.widget.FrameLayout;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * KurdiKeyboard native Android InputMethodService (Direct Boot Aware).
 * Shares native preferences with the settings activity.
 */
public class KurdiKeyboardImeService extends InputMethodService {
    private FrameLayout rootContainer;
    private NativeImeView nativeView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile long lastLocalCommitAt = 0L;
    private OfflineKeyboardStt offlineKeyboardStt;
    private NativeKeyboardVoice nativeKeyboardVoice;
    private boolean nativeVoiceSelected;
    private long voiceStartedAt;
    private long lastCpuMs, lastSampleAt;
    private long lastTrimSampleRequest;
    private long nativeSessionGeneration = Long.MIN_VALUE;
    private EditorInfo seededEditorInfo;
    private long nativeSystemClipTimestamp;
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private final ImeTailRequests nativeTailRequests = new ImeTailRequests();
    private final ExecutorService nativeTailWorker = Executors.newSingleThreadExecutor(
            task -> new Thread(task, "ime-editor-context"));
    private final Runnable nativeClipboardSync = this::syncLatestSystemClipboard;
    private InputConnection voiceEditor;
    private volatile boolean inputVisible;
    private volatile long editorGeneration;
    private long voiceGeneration;
    private long nativeViewEpoch;
    private View fallback;
    private boolean fallbackLatin;
    private boolean fallbackShift;
    private android.widget.Button fallbackKey(String label, Runnable action) {
        android.widget.Button b = new android.widget.Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(17); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(0,0,0,0); b.setOnClickListener(v -> { try { action.run(); } catch(RuntimeException ignored) {} }); return b;
    }
    private void showFallback() {
        if (rootContainer == null) return;
        if (fallback != null) rootContainer.removeView(fallback);
        android.widget.LinearLayout panel = new android.widget.LinearLayout(this);
        panel.setOrientation(android.widget.LinearLayout.VERTICAL); panel.setBackgroundColor(0xff202124);
        String[] rows = fallbackLatin ? new String[]{"1234567890","qwertyuiop","asdfghjkl","zxcvbnm"} : new String[]{"١٢٣٤٥٦٧٨٩٠","قوەرتیئحۆپ","اسدفگەژکل","زخجڤبنمچشڕ","ڵێعغھ،؟."};
        for (String line : rows) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            for (int i=0;i<line.length();i++) { String raw=line.substring(i,i+1); final String key=fallbackLatin && fallbackShift?raw.toUpperCase(java.util.Locale.ROOT):raw;
                row.addView(fallbackKey(key, () -> { InputConnection ic=getCurrentInputConnection(); if (ic!=null && inputVisible) ic.commitText(key,1); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(48),1)); }
            panel.addView(row);
        }
        android.widget.LinearLayout controls = new android.widget.LinearLayout(this);
        controls.addView(fallbackKey("⇧", () -> { fallbackShift=!fallbackShift; showFallback(); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("🌐", () -> { fallbackLatin=!fallbackLatin; showFallback(); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("بۆشایی", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) ic.commitText(" ",1); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),2));
        controls.addView(fallbackKey("⌫", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) deleteOne(ic); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("↵", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) enter(ic); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        panel.addView(controls);
        panel.addView(fallbackKey("⌄", () -> requestHideSelf(0)));
        panel.addView(fallbackKey("دووبارە کردنەوە / Retry", this::retryKeyboard));
        fallback=panel; rootContainer.addView(panel,new FrameLayout.LayoutParams(-1,-2));
    }
    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        long now = SystemClock.elapsedRealtime();
        if (lastTrimSampleRequest == 0 || now - lastTrimSampleRequest >= 120_000) {
            lastTrimSampleRequest = now;
            sampleResources("trim_" + level);
        }
    }
    private void deleteOne(InputConnection ic) { deleteOne(ic, false); }

    private boolean deleteOne(InputConnection ic, boolean collapsedSelection) {
        if (!collapsedSelection && !TextUtils.isEmpty(ic.getSelectedText(0))) {
            ic.commitText("", 1);
            return false;
        }
        if (Build.VERSION.SDK_INT < 24 || !ic.deleteSurroundingTextInCodePoints(1, 0)) {
            CharSequence before=ic.getTextBeforeCursor(2,0);
            int n=before!=null && before.length()>=2 && Character.isSurrogatePair(before.charAt(before.length()-2),before.charAt(before.length()-1))?2:1;
            return ic.deleteSurroundingText(n, 0);
        }
        return true;
    }
    private void enter(InputConnection ic) {
        EditorInfo ei=getCurrentInputEditorInfo();
        if (ei!=null) {
            int action=ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (action!=EditorInfo.IME_ACTION_NONE && action!=EditorInfo.IME_ACTION_UNSPECIFIED && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION)==0 && ic.performEditorAction(action)) return;
            if ((ei.inputType & android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE)!=0 && ic.commitText("\n",1)) return;
        }
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER));
    }
    private final java.util.concurrent.ThreadPoolExecutor diagnostics = new java.util.concurrent.ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<>(8), r -> new Thread(r,"ime-diagnostics"), new java.util.concurrent.ThreadPoolExecutor.DiscardPolicy());
    private void logDiagnostic(String category,String severity,String title,String description,String operation,String status) {
        diagnostics.execute(() -> MainActivity.recordNativeEvent(getApplicationContext(),category,severity,title,description,"KurdiKeyboardImeService",operation,status,null));
    }
    private void sampleResources(String reason) {
        diagnostics.execute(() -> {
            android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
            if(am!=null) am.getMemoryInfo(mi);
            long cpu=android.os.Process.getElapsedCpuTime(), now=android.os.SystemClock.elapsedRealtime();
            Runtime rt=Runtime.getRuntime();
            String desc="reason="+reason+", javaHeapKB="+((rt.totalMemory()-rt.freeMemory())/1024)+", processPssKB="+android.os.Debug.getPss()+", systemAvailableKB="+(mi.availMem/1024)+", lowMemory="+mi.lowMemory+", cpuDeltaMs="+(lastSampleAt==0?0:cpu-lastCpuMs)+", intervalMs="+(lastSampleAt==0?0:now-lastSampleAt);
            lastCpuMs=cpu; lastSampleAt=now;
            MainActivity.recordNativeEvent(getApplicationContext(),"APPLICATION","INFO","IME resource sample",desc,"KurdiKeyboardImeService","resource_sample","COMPLETED",null);
        });
    }

    private void cancelVoice() {
        voiceEditor = null;
        if (nativeKeyboardVoice != null) nativeKeyboardVoice.cancel();
        if (offlineKeyboardStt != null) offlineKeyboardStt.cancel();
    }
    @Override public void onStartInput(EditorInfo info, boolean restarting) {
        editorGeneration++;
        cancelVoice();
        lastLocalCommitAt = 0;
        selectionStart = info == null ? -1 : info.initialSelStart;
        selectionEnd = info == null ? -1 : info.initialSelEnd;
        cancelNativeContext();
        if (nativeView != null) nativeView.endSession(restarting);
        super.onStartInput(info, restarting);
        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (manager != null) syncSubtypeLanguage(manager.getCurrentInputMethodSubtype());
    }

    @Override public void onCurrentInputMethodSubtypeChanged(InputMethodSubtype subtype) {
        super.onCurrentInputMethodSubtypeChanged(subtype);
        syncSubtypeLanguage(subtype);
    }

    /** Map system IME subtype locale -> app activeLanguage (ckb, en, ar, …). */
    private void syncSubtypeLanguage(InputMethodSubtype subtype) {
        if (subtype == null) return;
        String locale = subtype.getLocale();
        if (locale == null || locale.isEmpty()) {
            if (android.os.Build.VERSION.SDK_INT >= 24) locale = subtype.getLanguageTag();
        }
        if (locale == null || locale.isEmpty()) return;
        String lang = locale;
        int dash = locale.indexOf('_');
        if (dash < 0) dash = locale.indexOf('-');
        if (dash > 0) lang = locale.substring(0, dash);
        lang = lang.toLowerCase();
        // normalize common tags
        if ("en".equals(lang) || lang.startsWith("en")) lang = "en";
        else if ("ckb".equals(lang) || "ku".equals(lang) || "hac".equals(lang) || "sdh".equals(lang)) { /* keep */ }
        else if ("ar".equals(lang)) lang = "ar";
        else if ("fa".equals(lang)) lang = "fa";
        else if ("tr".equals(lang)) lang = "tr";
        else if ("de".equals(lang)) lang = "de";
        final String code = lang;
        mainHandler.post(() -> {
            try {
                if (nativeView != null) {
                    nativeView.settingsPatch(new JSONObject().put("activeLanguage", code));
                }
            } catch (Exception ignored) {}
        });
    }
    @Override public void onFinishInputView(boolean finishingInput) {
        inputVisible = false; editorGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        super.onFinishInputView(finishingInput);
    }
    @Override public void onFinishInput() {
        inputVisible = false; editorGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        super.onFinishInput();
    }
    @Override public void onWindowHidden() {
        inputVisible = false; editorGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        super.onWindowHidden();
    }
    @Override public void onDestroy() {
        inputVisible = false;
        if (nativeKeyboardVoice != null) nativeKeyboardVoice.cancel();
        if (offlineKeyboardStt != null) { offlineKeyboardStt.close(); offlineKeyboardStt = null; }
        mainHandler.removeCallbacksAndMessages(null);
        diagnostics.shutdown();
        nativeTailRequests.invalidate();
        nativeTailWorker.shutdownNow();
        closeNativeView();
        super.onDestroy();
    }
    private boolean sensitiveEditor() {
        EditorInfo info = getCurrentInputEditorInfo();
        if (info == null || !ImeStateStore.unlocked(this) ||
                (info.imeOptions & EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0) return true;
        int type = info.inputType;
        int cls = type & android.text.InputType.TYPE_MASK_CLASS;
        int variation = type & android.text.InputType.TYPE_MASK_VARIATION;
        return (cls == android.text.InputType.TYPE_CLASS_TEXT && (variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD || variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == android.text.InputType.TYPE_CLASS_NUMBER && variation == android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    }
    private final Runnable syncTailRunnable = this::requestNativeTail;

    private void cancelNativeContext() {
        nativeTailRequests.invalidate();
        mainHandler.removeCallbacks(syncTailRunnable);
        mainHandler.removeCallbacks(nativeClipboardSync);
    }

    private void scheduleSyncEditorTail(long delayMs) {
        if (nativeView != null) nativeTailRequests.invalidate();
        mainHandler.removeCallbacks(syncTailRunnable);
        mainHandler.postDelayed(syncTailRunnable, delayMs);
    }

    private void requestNativeTail() {
        NativeImeView view = nativeView;
        if (view == null || !inputVisible) return;
        if (sensitiveEditor()) {
            view.editorChanged("");
            return;
        }
        InputConnection connection = getCurrentInputConnection();
        if (connection == null || !nativeTailRequests.begin()) return;
        long generation = editorGeneration;
        long revision = nativeTailRequests.revision();
        // Context getters wait for another application's process. Keep the IME thread available
        // even when that editor is slow, and ignore snapshots overtaken by an edit or focus change.
        nativeTailWorker.execute(() -> {
            String tail = readFieldTail(connection);
            mainHandler.post(() -> {
                boolean current = nativeTailRequests.finish(revision);
                if (current && tail != null && nativeView == view && nativeEditorIsCurrent(generation)
                        && !sensitiveEditor()) view.editorChanged(tail);
                if (nativeTailRequests.hasWaitingRead()) requestNativeTail();
            });
        });
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public View onCreateInputView() {
        closeNativeView();
        rootContainer = new FrameLayout(this);
        rootContainer.setBackgroundColor(Color.BLACK);
        createNativeKeyboard();
        return rootContainer;
    }

    private void createNativeKeyboard() {
        try {
            nativeView = new NativeImeView(this, new NativeEditorController(++nativeViewEpoch));
            if (fallback != null) rootContainer.removeView(fallback);
            fallback = null;
            rootContainer.addView(nativeView, new FrameLayout.LayoutParams(-1, -2));
            android.util.Log.i("KurdiKeyboardIme", "Native keyboard view created");
            if (inputVisible) showNativeSession();
        } catch (IOException | RuntimeException | LinkageError error) {
            closeNativeView();
            android.util.Log.w("KurdiKeyboardIme", "Native keyboard startup failed: " + error.getClass().getSimpleName());
            logDiagnostic("ERRORS", "ERROR", "Native keyboard startup failed", error.getClass().getSimpleName(), "native_ime_start", "FAILED");
            showFallback();
        }
    }

    private void retryKeyboard() { if (nativeView == null && rootContainer != null) createNativeKeyboard(); }
    private void closeNativeView() {
        if (nativeView == null) return;
        nativeView.close();
        if (rootContainer != null) rootContainer.removeView(nativeView);
        nativeView = null;
        nativeSessionGeneration = Long.MIN_VALUE;
        cancelNativeContext();
    }

    boolean nativeSensitiveEditor() { return sensitiveEditor(); }
    long nativeEditorGeneration() { return editorGeneration; }
    boolean nativeEditorIsCurrent(long generation) { return inputVisible && generation == editorGeneration && nativeView != null; }

    private String readCurrentFieldText(boolean preferSelection) {
        if (sensitiveEditor()) return "";
        try {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return "";
            if (preferSelection) {
                CharSequence selected = ic.getSelectedText(0);
                if (!TextUtils.isEmpty(selected)) {
                    return selected.toString();
                }
            }
            ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
            if (et != null && !TextUtils.isEmpty(et.text)) {
                return et.text.toString();
            }
            CharSequence before = ic.getTextBeforeCursor(4000, 0);
            CharSequence after = ic.getTextAfterCursor(4000, 0);
            StringBuilder sb = new StringBuilder();
            if (before != null) sb.append(before);
            if (after != null) sb.append(after);
            return sb.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String readFieldTail(InputConnection connection) {
        if (connection == null) return null;
        try {
            CharSequence before = connection.getTextBeforeCursor(240, 0);
            return before == null ? null : before.toString();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private void showNativeSession() {
        if (nativeSessionGeneration == editorGeneration) return;
        nativeSessionGeneration = editorGeneration;
        boolean sensitive = sensitiveEditor();
        EditorInfo info = getCurrentInputEditorInfo();
        CharSequence initial = !sensitive && info != null && info != seededEditorInfo && Build.VERSION.SDK_INT >= 30
                ? info.getInitialTextBeforeCursor(240, 0) : null;
        seededEditorInfo = info;
        nativeView.startSession(sensitive ? "" : initial == null ? null : initial.toString());
        if (!sensitive) {
            scheduleSyncEditorTail(50);
            mainHandler.postDelayed(nativeClipboardSync, 220);
        }
    }

    @Override
    public void onWindowShown() {
        super.onWindowShown();
        inputVisible = true;
        if (nativeView != null) showNativeSession();
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        inputVisible = true;
        if (nativeView != null) showNativeSession();
    }

    @Override
    public void onUpdateSelection(
            int oldSelStart,
            int oldSelEnd,
            int newSelStart,
            int newSelEnd,
            int candidatesStart,
            int candidatesEnd
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (voiceEditor != null && (oldSelStart != newSelStart || oldSelEnd != newSelEnd)) cancelVoice();
        selectionStart = newSelStart;
        selectionEnd = newSelEnd;
        boolean local = SystemClock.uptimeMillis() - lastLocalCommitAt < 280L;
        if (nativeView == null || !inputVisible || sensitiveEditor()) return;
        scheduleSyncEditorTail(local ? 140 : 65);
    }

    private void syncLatestSystemClipboard() {
        if (nativeView == null || !inputVisible || sensitiveEditor()) return;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (nativeView != null && !nativeView.settings.optBoolean("clipboardHistoryEnabled")) return;
            if (cm != null) {
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    long timestamp = Build.VERSION.SDK_INT >= 26 ? clip.getDescription().getTimestamp() : 0;
                    if (nativeView != null && timestamp > 0 && timestamp == nativeSystemClipTimestamp) return;
                    // Never import clipboard items marked private by their originating app.
                    if (Build.VERSION.SDK_INT >= 24) {
                        android.os.PersistableBundle extras = clip.getDescription().getExtras();
                        if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) return;
                    }
                    // Read literal text only; do not dereference clipboard URIs or intents.
                    CharSequence text = clip.getItemAt(0).getText();
                    if (!TextUtils.isEmpty(text)) {
                        nativeSystemClipTimestamp = timestamp;
                        nativeView.systemClipboard(text.toString());
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private void emitKeyboardVoiceEvent(String state, String text) {
        boolean failed="error".equals(state)||"permission".equals(state)||"model_missing".equals(state)||"app_missing".equals(state);
        String detail=failed && text!=null && text.matches("[a-z_0-9]{1,60}")?text:"";
        logDiagnostic("USER_OPERATIONS",failed?"WARNING":"INFO","Voice "+state,"engine="+(nativeVoiceSelected?"native":"vekol")+", elapsedMs="+(android.os.SystemClock.elapsedRealtime()-voiceStartedAt)+", code="+detail,"voice_ipc",failed?"FAILED":"INFO");
        if ("result".equals(state)) {
            String clean = text == null ? "" : text.trim();
            InputConnection ic = getCurrentInputConnection();
            if (!inputVisible || voiceGeneration != editorGeneration || voiceEditor == null || voiceEditor != ic || sensitiveEditor()) {
                state = "cancelled"; text = "";
            } else if (!clean.isEmpty()) {
                try {
                    if (ic.commitText(clean + " ", 1)) { text = clean; lastLocalCommitAt = android.os.SystemClock.uptimeMillis(); scheduleSyncEditorTail(80); }
                    else { state = "error"; text = "editor_unavailable"; }
                } catch (RuntimeException e) { state = "error"; text = "editor_unavailable"; }
            }
        }
        if (!"connecting".equals(state) && !"starting".equals(state) && !"recording".equals(state) && !"transcribing".equals(state)) voiceEditor = null;
        if (nativeView != null) nativeView.voiceChanged(state, text);
    }
    public class NativeEditorController {
        private final long epoch;
        NativeEditorController(long epoch) { this.epoch=epoch; }
        private void postEditorOperation(Runnable action) {
            if (Looper.myLooper() != Looper.getMainLooper() || nativeView == null || !inputVisible || epoch != nativeViewEpoch) return;
            try { action.run(); } catch (RuntimeException ignored) { }
            if (!sensitiveEditor()) scheduleSyncEditorTail(110);
        }
         public boolean isLowMemoryDevice() {
            android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
            return am!=null && (am.isLowRamDevice() || am.getMemoryClass()<=128);
        }
         public void undo() { postEditorOperation(() -> { selectionStart = selectionEnd = -1; InputConnection ic=getCurrentInputConnection(); if(ic!=null && !sensitiveEditor()) ic.performContextMenuAction(android.R.id.undo); scheduleSyncEditorTail(80); }); }
         public void redo() { postEditorOperation(() -> { selectionStart = selectionEnd = -1; InputConnection ic=getCurrentInputConnection(); if(ic!=null && !sensitiveEditor()) ic.performContextMenuAction(android.R.id.redo); scheduleSyncEditorTail(80); }); }
         public void replaceVerifiedSuffix(String expected,int deleteBefore,String replacement) {
            if (expected==null || replacement==null || expected.length()>240 || deleteBefore<0 || deleteBefore>expected.length()) return;
            postEditorOperation(() -> {
                InputConnection ic=getCurrentInputConnection(); if(ic==null || sensitiveEditor()) return;
                CharSequence selected=ic.getSelectedText(0), before=ic.getTextBeforeCursor(Math.max(1,expected.length()),0);
                if (!TextUtils.isEmpty(selected) || before==null || !expected.contentEquals(before)) { scheduleSyncEditorTail(0); return; }
                ic.beginBatchEdit(); try { if(deleteBefore==0 || ic.deleteSurroundingText(deleteBefore,0)) ic.commitText(replacement,1); }
                finally { ic.endBatchEdit(); scheduleSyncEditorTail(80); }
            });
        }
         public void startOfflineVoice() {
            postEditorOperation(() -> {
                if (!inputVisible || sensitiveEditor() || getCurrentInputConnection() == null) { emitKeyboardVoiceEvent("error", "editor_unavailable"); return; }
                if (voiceEditor != null) return;
                voiceEditor = getCurrentInputConnection(); voiceGeneration = editorGeneration;
                nativeVoiceSelected=false; voiceStartedAt=android.os.SystemClock.elapsedRealtime();
                if (offlineKeyboardStt == null) offlineKeyboardStt = new OfflineKeyboardStt(KurdiKeyboardImeService.this, KurdiKeyboardImeService.this::emitKeyboardVoiceEvent);
                offlineKeyboardStt.start();
            });
        }
         public void startNativeVoice(String locale) {
            if (!"en-US".equals(locale) && !"ar-IQ".equals(locale)) return;
            postEditorOperation(() -> {
                if (!inputVisible || sensitiveEditor() || getCurrentInputConnection()==null) { emitKeyboardVoiceEvent("error","editor_unavailable"); return; }
                if (voiceEditor!=null) return;
                voiceEditor=getCurrentInputConnection(); voiceGeneration=editorGeneration;
                nativeVoiceSelected=true; voiceStartedAt=android.os.SystemClock.elapsedRealtime();
                if(nativeKeyboardVoice==null) nativeKeyboardVoice=new NativeKeyboardVoice(KurdiKeyboardImeService.this,KurdiKeyboardImeService.this::emitKeyboardVoiceEvent);
                nativeKeyboardVoice.start(locale);
            });
        }
         public String readNativeSettings() { return NativeSettingsBackup.read(KurdiKeyboardImeService.this); }
         public boolean writeNativeSettings(String json) { return NativeSettingsBackup.write(KurdiKeyboardImeService.this,json); }
         public void stopOfflineVoice() {
            postEditorOperation(() -> { if(nativeVoiceSelected) { if(nativeKeyboardVoice!=null)nativeKeyboardVoice.stop(); } else if (offlineKeyboardStt != null) offlineKeyboardStt.stop(); });
        }
         public void cancelOfflineVoice() { postEditorOperation(() -> cancelVoice()); }
         public void requestVoicePermission() {
            postEditorOperation(() -> {
                if (!inputVisible) return;
                try { startActivity(new Intent(KurdiKeyboardImeService.this, VoicePermissionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (RuntimeException e) { emitKeyboardVoiceEvent("permission", ""); }
            });
        }
        
        public void commitText(final String text) {
            if (text == null) return;
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(text, 1);
                }
            });
        }

        
        public void deleteBackward() {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    boolean collapsed = selectionStart >= 0 && selectionStart == selectionEnd;
                    if (deleteOne(ic, collapsed) && collapsed && nativeView != null) nativeView.characterDeleted();
                }
            });
        }

        
        public void deleteWord() {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                if (!TextUtils.isEmpty(ic.getSelectedText(0))) { ic.commitText("",1); return; }
                CharSequence before = ic.getTextBeforeCursor(64, 0);
                if (TextUtils.isEmpty(before)) return;
                String s = before.toString();
                int len = s.length();
                int i = len - 1;
                while (i >= 0 && Character.isWhitespace(s.charAt(i))) i--;
                while (i >= 0 && !Character.isWhitespace(s.charAt(i))) i--;
                int count = len - (i + 1);
                if (count > 0) {
                    ic.deleteSurroundingText(count, 0);
                }
            });
        }

        
        public void replaceSurroundingText(final int deleteBefore, final String insertText) {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                try {
                    ic.beginBatchEdit();
                    if (deleteBefore > 0) {
                        ic.deleteSurroundingText(deleteBefore, 0);
                    }
                    if (insertText != null && !insertText.isEmpty()) {
                        ic.commitText(insertText, 1);
                    }
                } catch (Exception ignored) {
                    // Never replay a partially completed edit.
                } finally { try { ic.endBatchEdit(); } catch (Exception ignored) {} }
                scheduleSyncEditorTail(120);
            });
        }

        
        public void sendEnter() {
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                enter(ic);
                scheduleSyncEditorTail(120);
            });
        }

        
        public void moveCursor(final int delta) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode = delta < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT;
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
                scheduleSyncEditorTail(120);
            });
        }

        
        public void moveCursorEx(final int dx, final int dy, final boolean select) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode;
                if (dy < 0) keyCode = KeyEvent.KEYCODE_DPAD_UP;
                else if (dy > 0) keyCode = KeyEvent.KEYCODE_DPAD_DOWN;
                else if (dx < 0) keyCode = KeyEvent.KEYCODE_DPAD_LEFT;
                else keyCode = KeyEvent.KEYCODE_DPAD_RIGHT;

                long now = android.os.SystemClock.uptimeMillis();
                int meta = select ? KeyEvent.META_SHIFT_ON : 0;
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta));
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0, meta));
            });
        }

        
        public void moveLineEdge(final boolean toEnd, final boolean select) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode = toEnd ? KeyEvent.KEYCODE_MOVE_END : KeyEvent.KEYCODE_MOVE_HOME;
                long now = android.os.SystemClock.uptimeMillis();
                int meta = select ? KeyEvent.META_SHIFT_ON : 0;
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta));
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0, meta));
            });
        }

        
        public void selectAll() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.performContextMenuAction(android.R.id.selectAll);
            });
        }

        
        public void copy() {
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.copy);
                    mainHandler.postDelayed(KurdiKeyboardImeService.this::syncLatestSystemClipboard, 120);
                }
            });
        }

        
        public void cut() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.cut);
                    mainHandler.postDelayed(KurdiKeyboardImeService.this::syncLatestSystemClipboard, 120);
                    scheduleSyncEditorTail(140);
                }
            });
        }

        
        public void paste() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.paste);
                    scheduleSyncEditorTail(140);
                }
            });
        }

        
        public void hideKeyboard() {
            postEditorOperation(() -> requestHideSelf(0));
        }

        
        public void openSettings() {
            openSettings(false);
        }

        void openEmojiSettings() { openSettings(true); }

        private void openSettings(boolean emoji) {
            postEditorOperation(() -> {
                try {
                    Intent intent = new Intent(KurdiKeyboardImeService.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    // Always open native settings shell (native settings).
                    intent.putExtra(MainActivity.EXTRA_NATIVE_SETTINGS, true);
                    if (emoji) intent.putExtra(MainActivity.EXTRA_EMOJI_SETTINGS, true);
                    startActivity(intent);
                } catch (Exception ignored) {
                }
            });
        }

        
        public String getEditorText(final boolean preferSelection) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                return readCurrentFieldText(preferSelection);
            }
            final AtomicReference<String> result = new AtomicReference<>("");
            final CountDownLatch latch = new CountDownLatch(1);
            final long generation=editorGeneration;
            mainHandler.post(() -> {
                try {
                    boolean current = nativeView != null && epoch == nativeViewEpoch;
                    if (current && generation == editorGeneration && inputVisible) result.set(readCurrentFieldText(preferSelection));
                } finally {
                    latch.countDown();
                }
            });
            try {
                latch.await(250, TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            return result.get();
        }

        
        public void replaceAllText(final String newText, final boolean preferSelection) {
            if (newText == null) return;
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null || sensitiveEditor()) return;
                boolean batch = false;
                try {
                    if (preferSelection) {
                        CharSequence selected = ic.getSelectedText(0);
                        if (!TextUtils.isEmpty(selected)) {
                            ic.commitText(newText, 1);
                            return;
                        }
                    }
                    ExtractedText et=ic.getExtractedText(new ExtractedTextRequest(),0);
                    if (et==null || et.text==null || et.startOffset!=0 || et.partialStartOffset>=0 || et.partialEndOffset>=0) return;
                    batch = ic.beginBatchEdit();
                    if (!ic.setSelection(0,et.text.length())) return;
                    CharSequence selectedAll=ic.getSelectedText(0);
                    if (et.text.length()>0 && (selectedAll==null || !et.text.toString().contentEquals(selectedAll))) {
                        ic.setSelection(et.selectionStart,et.selectionEnd); return;
                    }
                    ic.commitText(newText, 1);
                } catch (Exception ignored) {
                    // Avoid duplicate text on partial failure.
                } finally { if (batch) try { ic.endBatchEdit(); } catch (Exception ignored) {} }
            });
        }

        
        public int getScreenHeightDp() {
            try {
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                if (dm != null && dm.density > 0f) {
                    return Math.round(dm.heightPixels / dm.density);
                }
            } catch (Exception ignored) {
            }
            return 840;
        }

    }
}
