package io.kurdikebord.app;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * KurdiKeyboard native Android InputMethodService (Direct Boot Aware).
 * Uses the exact same https://localhost origin as Capacitor's MainActivity so
 * settings, themes, custom shortcuts, and permanent clipboard history are shared seamlessly.
 */
public class KurdiKeyboardImeService extends InputMethodService {
    private static final String VIRTUAL_HOST = "localhost";
    private FrameLayout rootContainer;
    private WebView webView;
    private NativeImeView nativeView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int keyboardHeightDp = 390;
    private String lastSyncedTail = null;
    private volatile long lastLocalCommitAt = 0L;
    private OfflineKeyboardStt offlineKeyboardStt;
    private NativeKeyboardVoice nativeKeyboardVoice;
    private boolean nativeVoiceSelected;
    private long voiceStartedAt;
    private long lastCpuMs, lastSampleAt;
    private long lastTrimSampleRequest;
    private long nativeSessionGeneration = Long.MIN_VALUE;
    private EditorInfo seededEditorInfo;
    private long nativeSystemClipTimestamp;
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private final ImeTailRequests nativeTailRequests = new ImeTailRequests();
    private final ExecutorService nativeTailWorker = Executors.newSingleThreadExecutor(
            task -> new Thread(task, "ime-editor-context"));
    private final Runnable nativeClipboardSync = this::syncLatestSystemClipboard;
    private InputConnection voiceEditor;
    private volatile boolean inputVisible;
    private final Runnable hiddenRelease = () -> { if (!inputVisible) destroyWebView(); };
    private volatile long editorGeneration;
    private long voiceGeneration;
    private long lastRendererRecovery;
    private int rendererFailures;
    private boolean webReady;
    private long watchdogGeneration;
    private volatile long webRendererEpoch;
    private long nativeViewEpoch;
    private final ImeOperationGate operationGate = new ImeOperationGate(256);
    private final java.util.concurrent.atomic.AtomicBoolean overflowNotice = new java.util.concurrent.atomic.AtomicBoolean();
    private View fallback;
    private boolean fallbackLatin;
    private boolean fallbackShift;
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (!inputVisible || webView == null) return;
            WebView target = webView;
            long generation = watchdogGeneration;
            Runnable expired = () -> { if (webView == target && inputVisible && generation==watchdogGeneration) recoverRenderer(); };
            mainHandler.postDelayed(expired, 5000);
            try { target.evaluateJavascript("Boolean(window.__onAndroidImeRefresh)", value -> {
                mainHandler.removeCallbacks(expired);
                if (target != webView || !inputVisible || generation!=watchdogGeneration) return;
                if ("true".equals(value)) markWebReady();
                else if (!webReady) { mainHandler.postDelayed(this, 1000); return; }
                mainHandler.postDelayed(this, 5000);
            }); } catch (RuntimeException e) { mainHandler.removeCallbacks(expired); recoverRenderer(); }
        }
    };
    private final Runnable loadDeadline = () -> { if (inputVisible && !webReady && webView != null) recoverRenderer(); };
    private void startWatchdog() {
        watchdogGeneration++;
        mainHandler.removeCallbacks(watchdog); mainHandler.removeCallbacks(loadDeadline);
        if (!webReady) mainHandler.postDelayed(loadDeadline, 15000);
        mainHandler.postDelayed(watchdog, 1000);
    }
    private void markWebReady() {
        if (webReady || webView == null) return;
        webReady = true; mainHandler.removeCallbacks(loadDeadline);
        if (fallback != null && rootContainer != null) rootContainer.removeView(fallback);
        fallback = null; webView.setVisibility(View.VISIBLE);
        if(android.os.Build.VERSION.SDK_INT>=26) try { webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT,true); } catch(RuntimeException ignored) {}
        logDiagnostic("APPLICATION","INFO","IME web ready","Renderer ready; native fallback removed.","web_ready","COMPLETED");
        sampleResources("web_ready");
        lastSyncedTail = null;
        try { webView.evaluateJavascript("window.__onAndroidImeRefresh?.("+JSONObject.quote(readFastFieldTail())+")",null); } catch(RuntimeException ignored) {}
        syncLatestSystemClipboard(); scheduleSyncEditorTail(0);
    }
    private void recoverRenderer() {
        destroyWebView(); cancelVoice();
        sampleResources("renderer_recovery");
        long now = android.os.SystemClock.elapsedRealtime();
        rendererFailures = now - lastRendererRecovery < 30000 ? rendererFailures + 1 : 1;
        lastRendererRecovery = now;
        // Prefer full native keyboard over emergency Latin/Arabic fallback grid.
        if (rootContainer != null && nativeView == null) createNativeKeyboard();
        else if (nativeView == null) showFallback();
        logDiagnostic("APPLICATION","WARNING","Native IME recovery","rendererFailures="+rendererFailures,"native_recovery","COMPLETED");
    }
    private android.widget.Button fallbackKey(String label, Runnable action) {
        android.widget.Button b = new android.widget.Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(17); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(0,0,0,0); b.setOnClickListener(v -> { try { action.run(); } catch(RuntimeException ignored) {} }); return b;
    }
    private void showFallback() {
        if (rootContainer == null) return;
        if (fallback != null) rootContainer.removeView(fallback);
        android.widget.LinearLayout panel = new android.widget.LinearLayout(this);
        panel.setOrientation(android.widget.LinearLayout.VERTICAL); panel.setBackgroundColor(0xff202124);
        String[] rows = fallbackLatin ? new String[]{"1234567890","qwertyuiop","asdfghjkl","zxcvbnm"} : new String[]{"١٢٣٤٥٦٧٨٩٠","قوەرتیئحۆپ","اسدفگەژکل","زخجڤبنمچشڕ","ڵێعغھ،؟."};
        for (String line : rows) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            for (int i=0;i<line.length();i++) { String raw=line.substring(i,i+1); final String key=fallbackLatin && fallbackShift?raw.toUpperCase(java.util.Locale.ROOT):raw;
                row.addView(fallbackKey(key, () -> { InputConnection ic=getCurrentInputConnection(); if (ic!=null && inputVisible) ic.commitText(key,1); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(48),1)); }
            panel.addView(row);
        }
        android.widget.LinearLayout controls = new android.widget.LinearLayout(this);
        controls.addView(fallbackKey("⇧", () -> { fallbackShift=!fallbackShift; showFallback(); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("🌐", () -> { fallbackLatin=!fallbackLatin; showFallback(); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("بۆشایی", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) ic.commitText(" ",1); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),2));
        controls.addView(fallbackKey("⌫", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) deleteOne(ic); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        controls.addView(fallbackKey("↵", () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null && inputVisible) enter(ic); }), new android.widget.LinearLayout.LayoutParams(0,dpToPx(50),1));
        panel.addView(controls);
        panel.addView(fallbackKey("⌄", () -> requestHideSelf(0)));
        panel.addView(fallbackKey("دووبارە کردنەوە / Retry", this::retryKeyboard));
        fallback=panel; rootContainer.addView(panel,new FrameLayout.LayoutParams(-1,-2));
    }
    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        long now = SystemClock.elapsedRealtime();
        if (lastTrimSampleRequest == 0 || now - lastTrimSampleRequest >= 120_000) {
            lastTrimSampleRequest = now;
            sampleResources("trim_" + level);
        }
        if (!inputVisible && webView != null && (level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND)) destroyWebView();
    }
    private void deleteOne(InputConnection ic) { deleteOne(ic, false); }

    private boolean deleteOne(InputConnection ic, boolean collapsedSelection) {
        if (!collapsedSelection && !TextUtils.isEmpty(ic.getSelectedText(0))) {
            ic.commitText("", 1);
            return false;
        }
        if (Build.VERSION.SDK_INT < 24 || !ic.deleteSurroundingTextInCodePoints(1, 0)) {
            CharSequence before=ic.getTextBeforeCursor(2,0);
            int n=before!=null && before.length()>=2 && Character.isSurrogatePair(before.charAt(before.length()-2),before.charAt(before.length()-1))?2:1;
            return ic.deleteSurroundingText(n, 0);
        }
        return true;
    }
    private void enter(InputConnection ic) {
        EditorInfo ei=getCurrentInputEditorInfo();
        if (ei!=null) {
            int action=ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (action!=EditorInfo.IME_ACTION_NONE && action!=EditorInfo.IME_ACTION_UNSPECIFIED && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION)==0 && ic.performEditorAction(action)) return;
            if ((ei.inputType & android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE)!=0 && ic.commitText("\n",1)) return;
        }
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER));
    }
    private final java.util.concurrent.ThreadPoolExecutor diagnostics = new java.util.concurrent.ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<>(8), r -> new Thread(r,"ime-diagnostics"), new java.util.concurrent.ThreadPoolExecutor.DiscardPolicy());
    private void logDiagnostic(String category,String severity,String title,String description,String operation,String status) {
        diagnostics.execute(() -> MainActivity.recordNativeEvent(getApplicationContext(),category,severity,title,description,"KurdiKeyboardImeService",operation,status,null));
    }
    private void logWebEvent(String category,String severity,String title,String description,String operation) { logDiagnostic(category,severity,title,description,operation,"FAILED"); }
    private void sampleResources(String reason) {
        diagnostics.execute(() -> {
            android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
            if(am!=null) am.getMemoryInfo(mi);
            long cpu=android.os.Process.getElapsedCpuTime(), now=android.os.SystemClock.elapsedRealtime();
            Runtime rt=Runtime.getRuntime();
            String desc="reason="+reason+", javaHeapKB="+((rt.totalMemory()-rt.freeMemory())/1024)+", processPssKB="+android.os.Debug.getPss()+", systemAvailableKB="+(mi.availMem/1024)+", lowMemory="+mi.lowMemory+", cpuDeltaMs="+(lastSampleAt==0?0:cpu-lastCpuMs)+", intervalMs="+(lastSampleAt==0?0:now-lastSampleAt);
            lastCpuMs=cpu; lastSampleAt=now;
            MainActivity.recordNativeEvent(getApplicationContext(),"APPLICATION","INFO","IME resource sample",desc,"KurdiKeyboardImeService","resource_sample","COMPLETED",null);
        });
    }

    private void cancelVoice() {
        voiceEditor = null;
        if (nativeKeyboardVoice != null) nativeKeyboardVoice.cancel();
        if (offlineKeyboardStt != null) offlineKeyboardStt.cancel();
    }
    @Override public void onStartInput(EditorInfo info, boolean restarting) {
        editorGeneration++;
        cancelVoice();
        lastSyncedTail = null;
        lastLocalCommitAt = 0;
        selectionStart = info == null ? -1 : info.initialSelStart;
        selectionEnd = info == null ? -1 : info.initialSelEnd;
        cancelNativeContext();
        if (nativeView != null) nativeView.endSession(restarting);
        if (webView!=null) try { webView.evaluateJavascript("window.__cancelKeyboardPointers?.()",null); } catch(RuntimeException ignored) {}
        super.onStartInput(info, restarting);
        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (manager != null) syncSubtypeLanguage(manager.getCurrentInputMethodSubtype());
    }

    @Override public void onCurrentInputMethodSubtypeChanged(InputMethodSubtype subtype) {
        super.onCurrentInputMethodSubtypeChanged(subtype);
        syncSubtypeLanguage(subtype);
    }

    /** Map system IME subtype locale -> app activeLanguage (ckb, en, ar, …). */
    private void syncSubtypeLanguage(InputMethodSubtype subtype) {
        if (subtype == null) return;
        String locale = subtype.getLocale();
        if (locale == null || locale.isEmpty()) {
            if (android.os.Build.VERSION.SDK_INT >= 24) locale = subtype.getLanguageTag();
        }
        if (locale == null || locale.isEmpty()) return;
        String lang = locale;
        int dash = locale.indexOf('_');
        if (dash < 0) dash = locale.indexOf('-');
        if (dash > 0) lang = locale.substring(0, dash);
        lang = lang.toLowerCase();
        // normalize common tags
        if ("en".equals(lang) || lang.startsWith("en")) lang = "en";
        else if ("ckb".equals(lang) || "ku".equals(lang) || "hac".equals(lang) || "sdh".equals(lang)) { /* keep */ }
        else if ("ar".equals(lang)) lang = "ar";
        else if ("fa".equals(lang)) lang = "fa";
        else if ("tr".equals(lang)) lang = "tr";
        else if ("de".equals(lang)) lang = "de";
        final String code = lang;
        mainHandler.post(() -> {
            try {
                if (nativeView != null) {
                    nativeView.settingsPatch(new JSONObject().put("activeLanguage", code));
                }
                if (webView != null) {
                    webView.evaluateJavascript(
                            "window.__onAndroidImeSubtype?.(" + JSONObject.quote(code) + ")", null);
                }
            } catch (Exception ignored) {}
        });
    }
    @Override public void onFinishInputView(boolean finishingInput) {
        inputVisible = false; editorGeneration++; watchdogGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        mainHandler.removeCallbacks(watchdog); mainHandler.removeCallbacks(loadDeadline);
        if (webView != null) try { webView.evaluateJavascript("window.__cancelKeyboardPointers?.()",null); } catch(RuntimeException ignored) {}
        super.onFinishInputView(finishingInput);
    }
    @Override public void onFinishInput() {
        inputVisible = false; editorGeneration++; watchdogGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        super.onFinishInput();
    }
    @Override public void onWindowHidden() {
        inputVisible = false; editorGeneration++; watchdogGeneration++; cancelVoice(); cancelNativeContext();
        if (nativeView != null) nativeView.endSession();
        mainHandler.removeCallbacks(watchdog); mainHandler.removeCallbacks(loadDeadline);
        if (webView != null) { try { webView.evaluateJavascript("window.__cancelKeyboardPointers?.()",null); webView.onPause(); } catch (RuntimeException ignored) {} }
        mainHandler.removeCallbacks(delayedRepaintRunnable);
        mainHandler.removeCallbacks(hiddenRelease);
        if (webView != null) mainHandler.postDelayed(hiddenRelease, 45000);
        super.onWindowHidden();
    }
    @Override public void onDestroy() {
        inputVisible = false;
        if (nativeKeyboardVoice != null) nativeKeyboardVoice.cancel();
        if (offlineKeyboardStt != null) { offlineKeyboardStt.close(); offlineKeyboardStt = null; }
        mainHandler.removeCallbacksAndMessages(null);
        diagnostics.shutdown();
        nativeTailRequests.invalidate();
        nativeTailWorker.shutdownNow();
        closeNativeView();
        destroyWebView();
        super.onDestroy();
    }
    private void destroyWebView() {
        WebView old = webView;
        if (old == null) return;
        webView = null;
        webReady = false;
        webRendererEpoch++;
        watchdogGeneration++;
        mainHandler.removeCallbacks(watchdog);
        mainHandler.removeCallbacks(loadDeadline);
        if (old.getParent() instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);
        try { old.removeJavascriptInterface("AndroidIME"); old.destroy(); } catch (RuntimeException ignored) {}
    }
    private boolean sensitiveEditor() {
        EditorInfo info = getCurrentInputEditorInfo();
        if (info == null) return true;
        int type = info.inputType;
        int cls = type & android.text.InputType.TYPE_MASK_CLASS;
        int variation = type & android.text.InputType.TYPE_MASK_VARIATION;
        return (cls == android.text.InputType.TYPE_CLASS_TEXT && (variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD || variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == android.text.InputType.TYPE_CLASS_NUMBER && variation == android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    }
    private final Runnable syncTailRunnable = () -> {
        if (nativeView != null) { requestNativeTail(); return; }
        if (webView == null || !inputVisible || !webReady) return;
        final String tail = readFastFieldTail();
        if (tail.equals(lastSyncedTail)) return;
        lastSyncedTail = tail;
        try { webView.evaluateJavascript(
                "window.__onAndroidEditorTail && window.__onAndroidEditorTail(" + JSONObject.quote(tail) + ");", null);
        } catch (RuntimeException ignored) {}
    };
    private final Runnable delayedRepaintRunnable = () -> {
        if (webView == null) return;
        try {
            webView.onResume();
            // Avoid global WebView timer changes.
            webView.invalidate();
            webView.postInvalidateOnAnimation();
            if (rootContainer != null) {
                rootContainer.invalidate();
            }
            webView.evaluateJavascript(
                    "window.__onAndroidImeForceRepaint && window.__onAndroidImeForceRepaint();",
                    null
            );
        } catch (Exception ignored) {
        }
    };

    private void cancelNativeContext() {
        nativeTailRequests.invalidate();
        mainHandler.removeCallbacks(syncTailRunnable);
        mainHandler.removeCallbacks(nativeClipboardSync);
    }

    private void scheduleSyncEditorTail(long delayMs) {
        if (nativeView != null) nativeTailRequests.invalidate();
        mainHandler.removeCallbacks(syncTailRunnable);
        mainHandler.postDelayed(syncTailRunnable, delayMs);
    }

    private void requestNativeTail() {
        NativeImeView view = nativeView;
        if (view == null || !inputVisible) return;
        if (sensitiveEditor()) {
            view.editorChanged("");
            return;
        }
        InputConnection connection = getCurrentInputConnection();
        if (connection == null || !nativeTailRequests.begin()) return;
        long generation = editorGeneration;
        long revision = nativeTailRequests.revision();
        // Context getters wait for another application's process. Keep the IME thread available
        // even when that editor is slow, and ignore snapshots overtaken by an edit or focus change.
        nativeTailWorker.execute(() -> {
            String tail = readFieldTail(connection);
            mainHandler.post(() -> {
                boolean current = nativeTailRequests.finish(revision);
                if (current && tail != null && nativeView == view && nativeEditorIsCurrent(generation)
                        && !sensitiveEditor()) view.editorChanged(tail);
                if (nativeTailRequests.hasWaitingRead()) requestNativeTail();
            });
        });
    }

    private void forceWebViewRepaint() {
        mainHandler.post(() -> {
            if (webView == null) return;
            try {
                webView.onResume();
                // Avoid global WebView timer changes.
                if (webReady) webView.setVisibility(View.VISIBLE);
                webView.invalidate();
                webView.postInvalidateOnAnimation();
                if (rootContainer != null) {
                    rootContainer.invalidate();
                }
                webView.evaluateJavascript(
                        "window.__onAndroidImeForceRepaint && window.__onAndroidImeForceRepaint();",
                        null
                );
            } catch (Exception ignored) {
            }
        });
        // Second compositor kick after IME slide-in window surface finishes attaching
        mainHandler.removeCallbacks(delayedRepaintRunnable);
        mainHandler.postDelayed(delayedRepaintRunnable, 70);
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView createConfiguredWebView() {
        WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.BLACK);
        wv.setVerticalScrollBarEnabled(false);
        wv.setHorizontalScrollBarEnabled(false);
        wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        wv.setLongClickable(false);
        wv.setHapticFeedbackEnabled(false);
        wv.setOnLongClickListener(v -> true);

        // Keep visible IME important, allow renderer priority to drop when hidden.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            try {
                wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
            } catch (Exception ignored) {
            }
        }

        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        wv.addJavascriptInterface(new AndroidImeBridge(webRendererEpoch), "AndroidIME");
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (view == webView && inputVisible) { lastSyncedTail=null; scheduleSyncEditorTail(200); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !request.isForMainFrame() || !"https".equals(uri.getScheme()) || !VIRTUAL_HOST.equalsIgnoreCase(uri.getHost());
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && "https".equals(uri.getScheme()) && VIRTUAL_HOST.equalsIgnoreCase(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || path.equals("/") || path.isEmpty()) {
                        path = "/index.html";
                    }
                    String assetPath = "public" + path;
                    try {
                        InputStream is = getAssets().open(assetPath);
                        return buildAssetResponse(guessMimeType(path), is);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                try {
                    String path = (request != null && request.getUrl() != null) ? request.getUrl().getPath() : "unknown";
                    if (path != null && path.contains("emoji-datasource-facebook")) {
                        return;
                    }
                    CharSequence desc = error != null ? error.getDescription() : "WebView resource error";
                    logWebEvent("ERRORS", "ERROR", "IME WebView Resource Error", "WebView error on " + path + ": " + desc, "onReceivedError");
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                try {
                    String path = (request != null && request.getUrl() != null) ? request.getUrl().getPath() : "unknown";
                    if (path != null && path.contains("emoji-datasource-facebook")) {
                        return;
                    }
                    int status = errorResponse != null ? errorResponse.getStatusCode() : 0;
                    logWebEvent("NETWORK", status >= 500 ? "ERROR" : "WARNING", "IME WebView HTTP " + status, "WebView HTTP error " + status + " for " + path, "onReceivedHttpError");
                } catch (Exception ignored) {
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                try {
                    boolean crashed = detail != null && detail.didCrash();
                    logWebEvent("CRASHES", "CRITICAL", "IME WebView Render Process Gone", crashed ? "IME WebView renderer crashed unexpectedly." : "IME WebView renderer killed by OS under memory pressure.", "onRenderProcessGone");
                } catch (Exception ignored) {
                }
                if (view != webView) { try { view.destroy(); } catch (RuntimeException ignored) {} return true; }
                recoverRenderer();
                return true;
            }
        });
        return wv;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public View onCreateInputView() {
        // 100% native keyboard — WebView IME path disabled by design.
        closeNativeView();
        destroyWebView();
        rootContainer = new FrameLayout(this);
        rootContainer.setBackgroundColor(Color.BLACK);
        createNativeKeyboard();
        return rootContainer;
    }

    private void createNativeKeyboard() {
        try {
            nativeView = new NativeImeView(this, new AndroidImeBridge(++nativeViewEpoch, true));
            if (fallback != null) rootContainer.removeView(fallback);
            fallback = null;
            rootContainer.addView(nativeView, new FrameLayout.LayoutParams(-1, -2));
            android.util.Log.i("KurdiKeyboardIme", "Native keyboard view created");
            if (inputVisible) showNativeSession();
        } catch (IOException | RuntimeException | LinkageError error) {
            closeNativeView();
            android.util.Log.w("KurdiKeyboardIme", "Native keyboard startup failed: " + error.getClass().getSimpleName());
            logDiagnostic("ERRORS", "ERROR", "Native keyboard startup failed", error.getClass().getSimpleName(), "native_ime_start", "FAILED");
            showFallback();
        }
    }

    private void retryKeyboard() {
        if (ImeStateStore.enabled(this)) createNativeKeyboard();
        else {
            rendererFailures = 0;
            destroyWebView();
            attachWebView();
        }
    }

    private void closeNativeView() {
        if (nativeView == null) return;
        nativeView.close();
        if (rootContainer != null) rootContainer.removeView(nativeView);
        nativeView = null;
        nativeSessionGeneration = Long.MIN_VALUE;
        cancelNativeContext();
    }

    boolean nativeSensitiveEditor() { return sensitiveEditor(); }
    long nativeEditorGeneration() { return editorGeneration; }
    boolean nativeEditorIsCurrent(long generation) { return inputVisible && generation == editorGeneration && nativeView != null; }

    private void attachWebView() {
        // WebView IME disabled — keep native only.
        if (rootContainer == null) return;
        if (nativeView == null) createNativeKeyboard();
    }

    private WebResourceResponse buildAssetResponse(String mimeType, InputStream stream) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        if ("text/html".equals(mimeType)) {
            headers.put("Cache-Control", "no-cache");
        } else {
            headers.put("Cache-Control", "public, max-age=31536000");
        }
        return new WebResourceResponse(mimeType, "UTF-8", 200, "OK", headers, stream);
    }

    private String readCurrentFieldText(boolean preferSelection) {
        if (sensitiveEditor()) return "";
        try {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return "";
            if (preferSelection) {
                CharSequence selected = ic.getSelectedText(0);
                if (!TextUtils.isEmpty(selected)) {
                    return selected.toString();
                }
            }
            ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
            if (et != null && !TextUtils.isEmpty(et.text)) {
                return et.text.toString();
            }
            CharSequence before = ic.getTextBeforeCursor(4000, 0);
            CharSequence after = ic.getTextAfterCursor(4000, 0);
            StringBuilder sb = new StringBuilder();
            if (before != null) sb.append(before);
            if (after != null) sb.append(after);
            return sb.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private String escapeForJsString(String raw) {
        if (raw == null) return "";
        return raw
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "")
                .replace("\u2028", "\\u2028")
                .replace("\u2029", "\\u2029");
    }

    private static String readFieldTail(InputConnection connection) {
        if (connection == null) return null;
        try {
            CharSequence before = connection.getTextBeforeCursor(240, 0);
            return before == null ? null : before.toString();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private String readFastFieldTail() {
        String tail = sensitiveEditor() ? null : readFieldTail(getCurrentInputConnection());
        return tail == null ? "" : tail;
    }

    private void showNativeSession() {
        if (nativeSessionGeneration == editorGeneration) return;
        nativeSessionGeneration = editorGeneration;
        boolean sensitive = sensitiveEditor();
        EditorInfo info = getCurrentInputEditorInfo();
        CharSequence initial = !sensitive && info != null && info != seededEditorInfo && Build.VERSION.SDK_INT >= 30
                ? info.getInitialTextBeforeCursor(240, 0) : null;
        seededEditorInfo = info;
        nativeView.startSession(sensitive ? "" : initial == null ? null : initial.toString());
        if (!sensitive) {
            scheduleSyncEditorTail(50);
            mainHandler.postDelayed(nativeClipboardSync, 220);
        }
    }

    @Override
    public void onWindowShown() {
        super.onWindowShown();
        inputVisible = true;
        mainHandler.removeCallbacks(hiddenRelease);
        if (nativeView != null) {
            showNativeSession();
            return;
        }
        if(android.os.SystemClock.elapsedRealtime()-lastRendererRecovery>30000) rendererFailures=0;
        if (webView == null && rendererFailures <= 2) attachWebView();
        if (webView != null) startWatchdog();
        forceWebViewRepaint();
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        inputVisible = true;
        mainHandler.removeCallbacks(hiddenRelease);
        if (nativeView != null) {
            showNativeSession();
            return;
        }
        if(android.os.SystemClock.elapsedRealtime()-lastRendererRecovery>30000) rendererFailures=0;
        if (webView == null && rendererFailures <= 2) attachWebView();
        if (webView != null) startWatchdog();
        forceWebViewRepaint();
        syncLatestSystemClipboard();
        final String rawTail = readFastFieldTail();
        lastSyncedTail = rawTail;
        final String currentFieldTail = escapeForJsString(rawTail);
        final long generation=editorGeneration;
        mainHandler.post(() -> {
            if (webView != null && generation==editorGeneration && inputVisible) {
                webView.evaluateJavascript(
                        "window.__onAndroidImeRefresh && window.__onAndroidImeRefresh('" + currentFieldTail + "');",
                        null
                );
            }
        });
    }

    @Override
    public void onUpdateSelection(
            int oldSelStart,
            int oldSelEnd,
            int newSelStart,
            int newSelEnd,
            int candidatesStart,
            int candidatesEnd
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (voiceEditor != null && (oldSelStart != newSelStart || oldSelEnd != newSelEnd)) cancelVoice();
        selectionStart = newSelStart;
        selectionEnd = newSelEnd;
        boolean local = SystemClock.uptimeMillis() - lastLocalCommitAt < 280L;
        if (nativeView != null && (!inputVisible || sensitiveEditor())) return;
        scheduleSyncEditorTail(nativeView == null ? (local ? 320 : 85) : (local ? 140 : 65));
    }

    private void syncLatestSystemClipboard() {
        if ((webView == null && nativeView == null) || !inputVisible || sensitiveEditor()) return;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (nativeView != null && !nativeView.settings.optBoolean("clipboardHistoryEnabled")) return;
            if (cm != null) {
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    long timestamp = Build.VERSION.SDK_INT >= 26 ? clip.getDescription().getTimestamp() : 0;
                    if (nativeView != null && timestamp > 0 && timestamp == nativeSystemClipTimestamp) return;
                    CharSequence text = clip.getItemAt(0).coerceToText(this);
                    if (!TextUtils.isEmpty(text)) {
                        if (nativeView != null) {
                            nativeSystemClipTimestamp = timestamp;
                            nativeView.systemClipboard(text.toString());
                            return;
                        }
                        String escaped = text.toString()
                                .replace("\\", "\\\\")
                                .replace("'", "\\'")
                                .replace("\n", "\\n")
                                .replace("\r", "");
                        mainHandler.post(() -> {
                            if (webView != null) {
                                webView.evaluateJavascript(
                                        "window.__onAndroidClipboardSync && window.__onAndroidClipboardSync('" + escaped + "');",
                                        null
                                );
                            }
                        });
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private String guessMimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".wav")) return "audio/wav";
        if (lower.endsWith(".mp3")) return "audio/mpeg";
        if (lower.endsWith(".ogg")) return "audio/ogg";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".ttf")) return "font/ttf";
        if (lower.endsWith(".otf")) return "font/otf";
        return "application/octet-stream";
    }

    private void emitKeyboardVoiceEvent(String state, String text) {
        boolean failed="error".equals(state)||"permission".equals(state)||"model_missing".equals(state)||"app_missing".equals(state);
        String detail=failed && text!=null && text.matches("[a-z_0-9]{1,60}")?text:"";
        logDiagnostic("USER_OPERATIONS",failed?"WARNING":"INFO","Voice "+state,"engine="+(nativeVoiceSelected?"native":"vekol")+", elapsedMs="+(android.os.SystemClock.elapsedRealtime()-voiceStartedAt)+", code="+detail,"voice_ipc",failed?"FAILED":"INFO");
        if ("result".equals(state)) {
            String clean = text == null ? "" : text.trim();
            InputConnection ic = getCurrentInputConnection();
            if (!inputVisible || voiceGeneration != editorGeneration || voiceEditor == null || voiceEditor != ic || sensitiveEditor()) {
                state = "cancelled"; text = "";
            } else if (!clean.isEmpty()) {
                try {
                    if (ic.commitText(clean + " ", 1)) { text = clean; lastLocalCommitAt = android.os.SystemClock.uptimeMillis(); scheduleSyncEditorTail(80); }
                    else { state = "error"; text = "editor_unavailable"; }
                } catch (RuntimeException e) { state = "error"; text = "editor_unavailable"; }
            }
        }
        if (!"connecting".equals(state) && !"starting".equals(state) && !"recording".equals(state) && !"transcribing".equals(state)) voiceEditor = null;
        if (nativeView != null) { nativeView.voiceChanged(state, text); return; }
        if (webView == null) return;
        try { webView.evaluateJavascript("window.__onKeyboardOfflineVoiceEvent && window.__onKeyboardOfflineVoiceEvent(" +
                JSONObject.quote(state) + "," + JSONObject.quote(text == null ? "" : text) + ");", null); }
        catch (RuntimeException ignored) {}
    }

    private void enqueueEditorOperation(long epoch, Runnable action) {
        final long generation = editorGeneration;
        if (!operationGate.tryAcquire()) {
            if (overflowNotice.compareAndSet(false,true)) mainHandler.post(() -> {
                overflowNotice.set(false); lastSyncedTail=null; scheduleSyncEditorTail(0);
                logWebEvent("ERRORS","WARNING","IME queue overloaded","Editor operation capacity exceeded; resynchronized editor tail.","input_queue_overflow");
            });
            return;
        }
        if (!mainHandler.post(() -> {
            try {
                if (!ImeOperationGate.isCurrent(epoch,webRendererEpoch,generation,editorGeneration,inputVisible && webReady)) return;
                action.run();
                lastSyncedTail = null; scheduleSyncEditorTail(100);
            } catch (RuntimeException ignored) { scheduleSyncEditorTail(100); }
            finally { operationGate.release(); }
        })) operationGate.release();
    }

    public class AndroidImeBridge {
        private final long epoch;
        private final boolean nativeTarget;
        AndroidImeBridge(long epoch) { this(epoch, false); }
        AndroidImeBridge(long epoch, boolean nativeTarget) { this.epoch=epoch; this.nativeTarget=nativeTarget; }
        private void postEditorOperation(Runnable action) {
            if (!nativeTarget) { enqueueEditorOperation(epoch, action); return; }
            if (Looper.myLooper() != Looper.getMainLooper() || nativeView == null || !inputVisible || epoch != nativeViewEpoch) return;
            try { action.run(); } catch (RuntimeException ignored) { }
            if (!sensitiveEditor()) scheduleSyncEditorTail(110);
        }
        @JavascriptInterface public boolean isLowMemoryDevice() {
            android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
            return am!=null && (am.isLowRamDevice() || am.getMemoryClass()<=128);
        }
        @JavascriptInterface public void undo() { postEditorOperation(() -> { selectionStart = selectionEnd = -1; InputConnection ic=getCurrentInputConnection(); if(ic!=null && !sensitiveEditor()) ic.performContextMenuAction(android.R.id.undo); scheduleSyncEditorTail(80); }); }
        @JavascriptInterface public void redo() { postEditorOperation(() -> { selectionStart = selectionEnd = -1; InputConnection ic=getCurrentInputConnection(); if(ic!=null && !sensitiveEditor()) ic.performContextMenuAction(android.R.id.redo); scheduleSyncEditorTail(80); }); }
        @JavascriptInterface public void replaceVerifiedSuffix(String expected,int deleteBefore,String replacement) {
            if (expected==null || replacement==null || expected.length()>240 || deleteBefore<0 || deleteBefore>expected.length()) return;
            postEditorOperation(() -> {
                InputConnection ic=getCurrentInputConnection(); if(ic==null || sensitiveEditor()) return;
                CharSequence selected=ic.getSelectedText(0), before=ic.getTextBeforeCursor(Math.max(1,expected.length()),0);
                if (!TextUtils.isEmpty(selected) || before==null || !expected.contentEquals(before)) { scheduleSyncEditorTail(0); return; }
                ic.beginBatchEdit(); try { if(deleteBefore==0 || ic.deleteSurroundingText(deleteBefore,0)) ic.commitText(replacement,1); }
                finally { ic.endBatchEdit(); scheduleSyncEditorTail(80); }
            });
        }
        @JavascriptInterface public void startOfflineVoice() {
            postEditorOperation(() -> {
                if (!inputVisible || sensitiveEditor() || getCurrentInputConnection() == null) { emitKeyboardVoiceEvent("error", "editor_unavailable"); return; }
                if (voiceEditor != null) return;
                voiceEditor = getCurrentInputConnection(); voiceGeneration = editorGeneration;
                nativeVoiceSelected=false; voiceStartedAt=android.os.SystemClock.elapsedRealtime();
                if (offlineKeyboardStt == null) offlineKeyboardStt = new OfflineKeyboardStt(KurdiKeyboardImeService.this, KurdiKeyboardImeService.this::emitKeyboardVoiceEvent);
                offlineKeyboardStt.start();
            });
        }
        @JavascriptInterface public void startNativeVoice(String locale) {
            if (!"en-US".equals(locale) && !"ar-IQ".equals(locale)) return;
            postEditorOperation(() -> {
                if (!inputVisible || sensitiveEditor() || getCurrentInputConnection()==null) { emitKeyboardVoiceEvent("error","editor_unavailable"); return; }
                if (voiceEditor!=null) return;
                voiceEditor=getCurrentInputConnection(); voiceGeneration=editorGeneration;
                nativeVoiceSelected=true; voiceStartedAt=android.os.SystemClock.elapsedRealtime();
                if(nativeKeyboardVoice==null) nativeKeyboardVoice=new NativeKeyboardVoice(KurdiKeyboardImeService.this,KurdiKeyboardImeService.this::emitKeyboardVoiceEvent);
                nativeKeyboardVoice.start(locale);
            });
        }
        @JavascriptInterface public String readNativeSettings() { return NativeSettingsBackup.read(KurdiKeyboardImeService.this); }
        @JavascriptInterface public boolean writeNativeSettings(String json) { return NativeSettingsBackup.write(KurdiKeyboardImeService.this,json); }
        @JavascriptInterface public void stopOfflineVoice() {
            postEditorOperation(() -> { if(nativeVoiceSelected) { if(nativeKeyboardVoice!=null)nativeKeyboardVoice.stop(); } else if (offlineKeyboardStt != null) offlineKeyboardStt.stop(); });
        }
        @JavascriptInterface public void cancelOfflineVoice() { postEditorOperation(() -> cancelVoice()); }
        @JavascriptInterface public void requestVoicePermission() {
            postEditorOperation(() -> {
                if (!inputVisible) return;
                try { startActivity(new Intent(KurdiKeyboardImeService.this, VoicePermissionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (RuntimeException e) { emitKeyboardVoiceEvent("permission", ""); }
            });
        }
        @JavascriptInterface
        public void commitText(final String text) {
            if (text == null) return;
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(text, 1);
                }
            });
        }

        @JavascriptInterface
        public void deleteBackward() {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    boolean collapsed = nativeTarget && selectionStart >= 0 && selectionStart == selectionEnd;
                    if (deleteOne(ic, collapsed) && collapsed && nativeView != null) nativeView.characterDeleted();
                }
            });
        }

        @JavascriptInterface
        public void deleteWord() {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                if (!TextUtils.isEmpty(ic.getSelectedText(0))) { ic.commitText("",1); return; }
                CharSequence before = ic.getTextBeforeCursor(64, 0);
                if (TextUtils.isEmpty(before)) return;
                String s = before.toString();
                int len = s.length();
                int i = len - 1;
                while (i >= 0 && Character.isWhitespace(s.charAt(i))) i--;
                while (i >= 0 && !Character.isWhitespace(s.charAt(i))) i--;
                int count = len - (i + 1);
                if (count > 0) {
                    ic.deleteSurroundingText(count, 0);
                }
            });
        }

        @JavascriptInterface
        public void replaceSurroundingText(final int deleteBefore, final String insertText) {
            lastLocalCommitAt = android.os.SystemClock.uptimeMillis();
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                try {
                    ic.beginBatchEdit();
                    if (deleteBefore > 0) {
                        ic.deleteSurroundingText(deleteBefore, 0);
                    }
                    if (insertText != null && !insertText.isEmpty()) {
                        ic.commitText(insertText, 1);
                    }
                } catch (Exception ignored) {
                    // Never replay a partially completed edit.
                } finally { try { ic.endBatchEdit(); } catch (Exception ignored) {} }
                scheduleSyncEditorTail(120);
            });
        }

        @JavascriptInterface
        public void sendEnter() {
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                enter(ic);
                scheduleSyncEditorTail(120);
            });
        }

        @JavascriptInterface
        public void moveCursor(final int delta) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode = delta < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT;
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
                scheduleSyncEditorTail(120);
            });
        }

        @JavascriptInterface
        public void moveCursorEx(final int dx, final int dy, final boolean select) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode;
                if (dy < 0) keyCode = KeyEvent.KEYCODE_DPAD_UP;
                else if (dy > 0) keyCode = KeyEvent.KEYCODE_DPAD_DOWN;
                else if (dx < 0) keyCode = KeyEvent.KEYCODE_DPAD_LEFT;
                else keyCode = KeyEvent.KEYCODE_DPAD_RIGHT;

                long now = android.os.SystemClock.uptimeMillis();
                int meta = select ? KeyEvent.META_SHIFT_ON : 0;
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta));
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0, meta));
            });
        }

        @JavascriptInterface
        public void moveLineEdge(final boolean toEnd, final boolean select) {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                int keyCode = toEnd ? KeyEvent.KEYCODE_MOVE_END : KeyEvent.KEYCODE_MOVE_HOME;
                long now = android.os.SystemClock.uptimeMillis();
                int meta = select ? KeyEvent.META_SHIFT_ON : 0;
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta));
                ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0, meta));
            });
        }

        @JavascriptInterface
        public void selectAll() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.performContextMenuAction(android.R.id.selectAll);
            });
        }

        @JavascriptInterface
        public void copy() {
            postEditorOperation(() -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.copy);
                    mainHandler.postDelayed(KurdiKeyboardImeService.this::syncLatestSystemClipboard, 120);
                }
            });
        }

        @JavascriptInterface
        public void cut() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.cut);
                    mainHandler.postDelayed(KurdiKeyboardImeService.this::syncLatestSystemClipboard, 120);
                    scheduleSyncEditorTail(140);
                }
            });
        }

        @JavascriptInterface
        public void paste() {
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.paste);
                    scheduleSyncEditorTail(140);
                }
            });
        }

        @JavascriptInterface
        public void hideKeyboard() {
            postEditorOperation(() -> requestHideSelf(0));
        }

        @JavascriptInterface
        public void openSettings() {
            openSettings(false);
        }

        void openEmojiSettings() { openSettings(true); }

        private void openSettings(boolean emoji) {
            postEditorOperation(() -> {
                try {
                    Intent intent = new Intent(KurdiKeyboardImeService.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    // Always open native settings shell (no WebView dependency for IME settings).
                    intent.putExtra(MainActivity.EXTRA_NATIVE_SETTINGS, true);
                    if (emoji) intent.putExtra(MainActivity.EXTRA_EMOJI_SETTINGS, true);
                    startActivity(intent);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public String getEditorText(final boolean preferSelection) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                return readCurrentFieldText(preferSelection);
            }
            final AtomicReference<String> result = new AtomicReference<>("");
            final CountDownLatch latch = new CountDownLatch(1);
            final long generation=editorGeneration;
            mainHandler.post(() -> {
                try {
                    boolean current = nativeTarget ? nativeView != null && epoch == nativeViewEpoch : epoch == webRendererEpoch;
                    if (current && generation == editorGeneration && inputVisible) result.set(readCurrentFieldText(preferSelection));
                } finally {
                    latch.countDown();
                }
            });
            try {
                latch.await(250, TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            return result.get();
        }

        @JavascriptInterface
        public void replaceAllText(final String newText, final boolean preferSelection) {
            if (newText == null) return;
            postEditorOperation(() -> {
                selectionStart = selectionEnd = -1;
                InputConnection ic = getCurrentInputConnection();
                if (ic == null || sensitiveEditor()) return;
                boolean batch = false;
                try {
                    if (preferSelection) {
                        CharSequence selected = ic.getSelectedText(0);
                        if (!TextUtils.isEmpty(selected)) {
                            ic.commitText(newText, 1);
                            return;
                        }
                    }
                    ExtractedText et=ic.getExtractedText(new ExtractedTextRequest(),0);
                    if (et==null || et.text==null || et.startOffset!=0 || et.partialStartOffset>=0 || et.partialEndOffset>=0) return;
                    batch = ic.beginBatchEdit();
                    if (!ic.setSelection(0,et.text.length())) return;
                    CharSequence selectedAll=ic.getSelectedText(0);
                    if (et.text.length()>0 && (selectedAll==null || !et.text.toString().contentEquals(selectedAll))) {
                        ic.setSelection(et.selectionStart,et.selectionEnd); return;
                    }
                    ic.commitText(newText, 1);
                } catch (Exception ignored) {
                    // Avoid duplicate text on partial failure.
                } finally { if (batch) try { ic.endBatchEdit(); } catch (Exception ignored) {} }
            });
        }

        @JavascriptInterface
        public int getScreenHeightDp() {
            try {
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                if (dm != null && dm.density > 0f) {
                    return Math.round(dm.heightPixels / dm.density);
                }
            } catch (Exception ignored) {
            }
            return 840;
        }

        @JavascriptInterface
        public void requestRepaint() {
            mainHandler.post(() -> {
                if (webView == null || epoch!=webRendererEpoch || !inputVisible) return;
                try {
                    webView.onResume();
                    // Avoid global WebView timer changes.
                    webView.invalidate();
                    webView.postInvalidateOnAnimation();
                    if (rootContainer != null) {
                        rootContainer.invalidate();
                    }
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void setKeyboardHeightDp(final int dp) {
            mainHandler.post(() -> {
                if (webView != null && epoch==webRendererEpoch && dp >= 210 && dp <= 720 && dp != keyboardHeightDp) {
                    keyboardHeightDp = dp;
                    ViewGroup.LayoutParams lp = webView.getLayoutParams();
                    if (lp != null) {
                        lp.height = dpToPx(dp);
                        webView.setLayoutParams(lp);
                        webView.postInvalidateOnAnimation();
                    }
                }
            });
        }
    }
}
