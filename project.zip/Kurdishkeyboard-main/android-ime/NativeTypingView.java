package io.kurdikebord.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

/** Lightweight native typing surface. Advanced panels remain in the original WebView. */
final class NativeTypingView extends LinearLayout {
    interface Actions {
        void type(String text); void delete(); void enter(); void cursor(int direction);
        void editorAction(int id); void voice(String language); void cancelVoice();
        void advanced(); void settings(); void hide(); void clipboard();
        String tail(); String sourceText(); void suggest(String expected,String value);
        void ai(String input,String mode,String target,String custom,java.util.function.Consumer<String> done);
        void cancelAi(); void setTheme(String id); void clipAction(String id,boolean pin); void rememberEmoji(String value,boolean pin); void clearClips();
    }
    private final Actions actions;
    private final NativeKeyboardData data;
    private JSONObject theme=new JSONObject(), lang=new JSONObject(), layout=new JSONObject();
    private Typeface keyFont=Typeface.DEFAULT;
    private final ArrayList<String> shiftedLabels=new ArrayList<>();
    private final ArrayList<TextView> suggestionKeys=new ArrayList<>();
    private final ArrayList<String> words=new ArrayList<>();
    private String panel="typing", lastPrefix="";
    private int clipboardPage;
    private int enterColor, enterText, specialText, borderColor, gapX=2,gapY=2,borderWidth;
    private long panelEpoch;
    private final Runnable suggestLater=this::updateSuggestions;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> languages = new ArrayList<>();
    private final ArrayList<TextView> characterKeys = new ArrayList<>();
    private final ArrayList<String> characterValues = new ArrayList<>();
    private JSONObject settings = new JSONObject();
    private String language = "ckb", voiceState = "idle";
    private int symbols = 0, generation = 0;
    private boolean shift, caps, numeric, privateField, repeatActive;
    private long lastShift;
    private int background, keyColor, specialColor, textColor, accent, rowHeight, keyRadius;
    private TextView voiceKey, shiftKey;
    NativeTypingView(Context c, Actions a, NativeKeyboardData d) {
        super(c); actions=a; data=d; setOrientation(VERTICAL); setLayoutDirection(LAYOUT_DIRECTION_LTR);
        setPadding(dp(2),dp(2),dp(2),dp(3)); setMotionEventSplittingEnabled(true);
    }
    private int dp(float x) { return Math.round(x*getResources().getDisplayMetrics().density); }
    String language() { return language; }
    void configure(JSONObject s, String preferred, boolean number, boolean sensitive) {
        settings=data.config(s); s=settings; numeric=number; privateField=sensitive;
        languages.clear(); JSONArray enabled=s.optJSONArray("enabledLanguages");
        if(enabled!=null) for(int i=0;i<enabled.length();i++) {
            JSONObject lang=enabled.optJSONObject(i); String code=lang==null?"":lang.optString("code");
            if(lang!=null&&data.supports(lang)&&!languages.contains(code)) languages.add(code);
        }
        if(languages.isEmpty()) { languages.add("ckb"); languages.add("en"); }
        language=languages.contains(preferred)?preferred:languages.get(0);
        loadLanguage();
        symbols=number?1:0; shift=false; caps=false; lastShift=0; voiceState="idle";
        rebuild();
    }
    void stopPointers() { generation++; repeatActive=false; handler.removeCallbacksAndMessages(null); }
    long startClipboardLoad(){clipboardPage=0;beginPanel("clipboard_loading");panelHeader("Clipboard…");return panelEpoch;}
    boolean isClipboardLoad(long token){return panelEpoch==token&&"clipboard_loading".equals(panel);}
    boolean clipboardOpen(){return "clipboard".equals(panel)||"clear_clipboard".equals(panel);}
    void editorMoved(){if(panel.startsWith("ai")){rebuild();}else selectionChanged();}
    void closePanel(){panelEpoch++;actions.cancelAi();data.releaseRich();stopPointers();}
    void selectionChanged(){if("typing".equals(panel)&&!privateField){handler.removeCallbacks(suggestLater);handler.postDelayed(suggestLater,75);}}
    @Override protected void onDetachedFromWindow() { closePanel(); super.onDetachedFromWindow(); }
    void voiceState(String state) {
        voiceState=state;
        if(voiceKey!=null) { voiceKey.setText(voiceLabel()); voiceKey.setContentDescription("Voice: "+state); }
    }
    private String voiceLabel() {
        if("recording".equals(voiceState))return "■";
        if("connecting".equals(voiceState)||"starting".equals(voiceState)||"transcribing".equals(voiceState))return "…";
        return "🎙";
    }
    private int color(String name,int fallback){try{return Color.parseColor(theme.optString(name));}catch(Exception e){return fallback;}}
    private void loadLanguage(){lang=data.language(settings,language);layout=data.layout(lang);words.clear();if(privateField||!settings.optBoolean("wordSuggestions",true))return;
        JSONObject dict=data.dictionary();JSONArray list=dict.optJSONArray(language);if(list==null)list=dict.optJSONArray("ltr".equals(lang.optString("dir"))?"en":"ckb");
        if(settings.optBoolean("personalDictionaryEnabled",true)){JSONArray p=settings.optJSONArray("personalDictionary");if(p!=null)for(int i=0;i<Math.min(p.length(),1000);i++)words.add(p.optString(i));}
        if(list!=null)for(int i=0;i<list.length();i++)words.add(list.optString(i));
    }
    private void setPalette() {
        theme=data.theme(settings); background=color("bg",0xff08090b);keyColor=color("keyBg",0xff1b1c20);specialColor=color("specialKeyBg",0xff25272f);textColor=color("keyText",Color.WHITE);accent=color("accent",0xff2990ff);enterColor=color("enterBg",accent);enterText=color("enterText",Color.BLACK);specialText=color("specialKeyText",textColor);borderColor=color("keyBorder",Color.TRANSPARENT);
        String style=settings.optString("keyShapeStyle","default");keyRadius=Math.max(0,Math.min(40,theme.optInt("borderRadius",10)));borderWidth=theme.optBoolean("hasKeyBorder")?Math.max(1,dp((float)theme.optDouble("keyBorderWidth",1))):0;
        if("flat".equals(style)){keyRadius=Math.min(keyRadius,6);borderWidth=0;}else if("pill_rounded".equals(style))keyRadius=40;else if("outline_only".equals(style)){borderWidth=dp(1);keyColor=Color.TRANSPARENT;}else if("borderless".equals(style))borderWidth=0;
        gapX=Math.max(0,Math.min(6,Math.round(2*settings.optInt("keySpacingHorizontal",100)/100f)));gapY=Math.max(0,Math.min(6,Math.round(2*settings.optInt("keySpacingVertical",100)/100f)));
        rowHeight=Math.max(34,Math.min(76,settings.optInt("keyboardHeightPx",248)/5));
        String font=settings.optString("fontStyle","system");keyFont=Typeface.DEFAULT;if(font.matches("kurdifont([1-9]|10)"))try{keyFont=Typeface.createFromAsset(getContext().getAssets(),"public/fonts/"+font+("kurdifont3".equals(font)?".otf":".ttf"));}catch(RuntimeException ignored){}
    }
    private GradientDrawable shape(int color) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(keyRadius));if(borderWidth>0)d.setStroke(borderWidth,borderColor);return d; }
    private TextView button(String label, int color, String description, Runnable action) {
        TextView v=new TextView(getContext()); v.setText(label); v.setTextColor(color==enterColor?enterText:color==specialColor?specialText:textColor);
        v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(13,Math.min(24,18*settings.optInt("fontSizePercent",130)/130f)));
        v.setGravity(Gravity.CENTER); v.setSingleLine(true); v.setTypeface(keyFont); v.setPadding(0,0,0,0);
        v.setContentDescription(description); v.setFocusable(false); v.setClickable(true);
        StateListDrawable bg=new StateListDrawable(); bg.addState(new int[]{android.R.attr.state_pressed},shape(color("keyHoverBg",accent))); bg.addState(new int[]{},shape(color)); v.setBackground(bg);
        v.setSoundEffectsEnabled(settings.optBoolean("soundEnabled",true)); v.setOnClickListener(w->{ if(!isShown())return; feedback(v); action.run(); });
        return v;
    }
    private void feedback(View v) { if(settings.optBoolean("vibrationEnabled",true))v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);  }
    private LinearLayout row() { LinearLayout r=new LinearLayout(getContext()); r.setOrientation(HORIZONTAL); r.setGravity(Gravity.CENTER); r.setLayoutDirection(LAYOUT_DIRECTION_LTR); r.setMotionEventSplittingEnabled(true); addView(r,new LayoutParams(-1,-2)); return r; }
    private void add(LinearLayout r, TextView v, float weight, int h) { LayoutParams lp=new LayoutParams(0,dp(h),weight); lp.setMargins(dp(gapX),dp(gapY),dp(gapX),dp(gapY)); r.addView(v,lp); }
    private void key(LinearLayout r,String label,String desc,float weight,int color,int h,Runnable action) { add(r,button(label,color,desc,action),weight,h); }
    private void insert(String text) { actions.type(text); if(shift&&!caps&&symbols==0){shift=false;refreshShift();} selectionChanged(); }
    private void refreshShift() {
        for(int i=0;i<characterKeys.size();i++) characterKeys.get(i).setText(shift?shiftedLabels.get(i):characterValues.get(i));
        if(shiftKey!=null) shiftKey.setText(caps?"⇪":shift?"⬆":"⇧");
    }
    private void changeLanguage() { actions.cancelVoice(); int idx=languages.indexOf(language); language=languages.get((idx+1)%languages.size()); loadLanguage(); symbols=0; shift=false;caps=false;rebuild(); }
    private void deleteButton(LinearLayout r) {
        TextView b=button("⌫",color("backspaceBg",specialColor),"Backspace",()->{actions.delete();selectionChanged();});
        b.setOnTouchListener(new OnTouchListener(){
            int pointer=-1; long token; boolean repeated;
            final Runnable repeat=new Runnable(){public void run(){if(pointer<0||token!=generation||!repeatActive||!isShown())return; repeated=true; actions.delete(); selectionChanged(); handler.postDelayed(this,65);}};
            public boolean onTouch(View v,MotionEvent e){
                int a=e.getActionMasked();
                if(a==MotionEvent.ACTION_DOWN){pointer=e.getPointerId(0); token=generation; repeated=false;repeatActive=true;v.setPressed(true);handler.postDelayed(repeat,Math.max(220,settings.optInt("longPressDelayMs",300)));return true;}
                if(a==MotionEvent.ACTION_MOVE){int p=e.findPointerIndex(pointer);if(p>=0&&(e.getX(p)<-dp(12)||e.getX(p)>v.getWidth()+dp(12)||e.getY(p)<-dp(12)||e.getY(p)>v.getHeight()+dp(12))){end(v);};return true;}
                if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP&&e.getPointerId(e.getActionIndex())==pointer){boolean click=pointer>=0&&!repeated&&token==generation;end(v);if(click)v.performClick();return true;}
                if(a==MotionEvent.ACTION_CANCEL){end(v);return true;} return true;
            }
            private void end(View v){pointer=-1;repeatActive=false;handler.removeCallbacks(repeat);v.setPressed(false);}
        }); add(r,b,1.15f,rowHeight);
    }
    void showClipboard(String raw) {
        if(privateField||!isShown())return;
        beginPanel("clipboard");
        LinearLayout header=row(); key(header,"‹","Back to typing",1,specialColor,36,this::rebuild); key(header,"Clipboard","Clipboard",3,accent,36,()->{});key(header,"پاککردنەوە","Clear unpinned clips",2,specialColor,36,()->{if("clear_clipboard".equals(panel)){actions.clearClips();}else{panel="clear_clipboard";android.widget.Toast.makeText(getContext(),"دووبارە فشار بدە بۆ سڕینەوەی نەپینکراوەکان",android.widget.Toast.LENGTH_SHORT).show();}});
        android.widget.ScrollView scroll=new android.widget.ScrollView(getContext()); LinearLayout list=new LinearLayout(getContext());list.setOrientation(VERTICAL);scroll.addView(list);addView(scroll,new LayoutParams(-1,dp(220)));
        try {
            JSONArray clips=new JSONArray(raw); int count=clips.length();int pages=Math.max(1,(count+29)/30);clipboardPage=Math.min(clipboardPage,pages-1);if(pages>1){LinearLayout bar=new LinearLayout(getContext());bar.setOrientation(HORIZONTAL);list.addView(bar,new LayoutParams(-1,-2));key(bar,"‹","Previous clipboard page",1,specialColor,32,()->{clipboardPage=Math.max(0,clipboardPage-1);showClipboard(raw);});key(bar,(clipboardPage+1)+"/"+pages,"Page",2,keyColor,32,()->{});key(bar,"›","Next clipboard page",1,specialColor,32,()->{clipboardPage=Math.min(pages-1,clipboardPage+1);showClipboard(raw);});}
            for(int i=clipboardPage*30;i<Math.min(count,(clipboardPage+1)*30);i++) { JSONObject item=clips.optJSONObject(i); if(item==null)continue; String text=item.optString("text", "");if(text.isEmpty())continue;
                String label=(item.optBoolean("pinned")?"★ ":"")+(text.length()>140?text.substring(0,140)+"…":text);
                TextView v=button(label,keyColor,"Paste clipboard item "+(i+1),()->{actions.type(text);if(settings.optBoolean("clipboardHideOnPaste",true))rebuild();});v.setSingleLine(false);v.setMaxLines(2);v.setPadding(dp(10),0,dp(10),0); LayoutParams lp=new LayoutParams(-1,dp(48));lp.setMargins(dp(3),dp(2),dp(3),dp(2));LinearLayout itemRow=new LinearLayout(getContext()); itemRow.setOrientation(HORIZONTAL);itemRow.addView(v,new LayoutParams(0,dp(48),4));String id=item.optString("id");key(itemRow,item.optBoolean("pinned")?"★":"☆","Pin clipboard",1,specialColor,48,()->actions.clipAction(id,true));key(itemRow,"×","Delete clipboard",1,specialColor,48,()->actions.clipAction(id,false));list.addView(itemRow,lp);
            }
        }catch(Exception ignored){}
        if(list.getChildCount()==0){TextView empty=new TextView(getContext());empty.setText("Clipboard — بەتاڵ");empty.setTextColor(textColor);empty.setGravity(Gravity.CENTER);list.addView(empty,new LayoutParams(-1,dp(60)));}
    }
    private void showAlternatives(String[] options) {
        if(!isShown())return;
        beginPanel("alternatives");
        LinearLayout h=row();key(h,"‹","Back to typing",1,specialColor,38,this::rebuild);key(h,"⋯","Tools",2,accent,38,this::showTools);
        LinearLayout choices=row();
        for(int i=0;i<options.length;i++){if(i>0&&i%6==0)choices=row();String raw=options[i];String value=shift?raw.toUpperCase(Locale.ROOT):raw;key(choices,value,value,1,keyColor,rowHeight,()->{insert(value);rebuild();});}
    }
    private void rebuild() {
        beginPanel("typing");setPalette();setBackgroundColor(background);
        LinearLayout top=row(); key(top,"⋯","Native tools",1,accent,36,this::showTools);
        if(!privateField&&settings.optBoolean("clipboardEnabled",true))key(top,"▣","Clipboard",1,specialColor,36,actions::clipboard);
        if(!privateField){voiceKey=button(voiceLabel(),specialColor,"Voice typing",()->actions.voice(language));add(top,voiceKey,1,36);voiceKey.setOnLongClickListener(v->{actions.cancelVoice();return true;});}
        if(!privateField&&settings.optBoolean("showEmojiKey",true))key(top,"☺","Emoji",1,specialColor,36,this::showEmoji);
        key(top,"⚙","Settings",1,specialColor,36,actions::settings);key(top,"⌄","Hide keyboard",1,specialColor,36,actions::hide);
        if(!privateField&&!numeric&&symbols==0&&settings.optBoolean("wordSuggestions",true)){LinearLayout r=row();for(int i=0;i<3;i++){final int idx=i;TextView v=button("",specialColor,"Suggestion",()->{String value=suggestionKeys.get(idx).getText().toString();if(!value.isEmpty())actions.suggest(lastPrefix,value);selectionChanged();});suggestionKeys.add(v);add(r,v,1,34);}}
        if(!numeric&&symbols==0&&("always".equals(settings.optString("numberRowMode"))||("per_language".equals(settings.optString("numberRowMode","per_language"))&&lang.optBoolean("numberRow", "en".equals(language))))) {
            LinearLayout n=row(); for(int i=1;i<=10;i++){final String s=digit(i%10);key(n,s,s,1,keyColor,Math.max(30,rowHeight-12),()->insert(s));}
        }
        if(!numeric&&symbols==0&&layout.optJSONArray("off")!=null)renderLayout();else{
        String[][] rows=numeric?new String[][]{{digit(1),digit(2),digit(3)},{digit(4),digit(5),digit(6)},{digit(7),digit(8),digit(9)},{"-",digit(0),"."}}:symbols>0?NativeTypingLayouts.symbols(symbols==2):NativeTypingLayouts.rows(language);
        for(String[] values:rows){LinearLayout r=row();for(String raw:values){final String value=raw.matches("[0-9]")?digit(Integer.parseInt(raw)):raw;key(r,value,value,1,keyColor,rowHeight,()->insert(value));}}}
        LinearLayout bottom=row();
        if(!numeric){key(bottom,symbols==0?"?123":symbols==1?"=\\<":"ABC","Symbols",1.2f,specialColor,rowHeight,()->{symbols=(symbols+1)%3;shift=false;caps=false;rebuild();});
        if(settings.optBoolean("showGlobeKey",true))key(bottom,"🌐","Language",1,specialColor,rowHeight,this::changeLanguage);
        if(symbols==0&&"ltr".equals(lang.optString("dir"))){shiftKey=button("⇧",specialColor,"Shift",()->{long n=android.os.SystemClock.uptimeMillis();if(shift&&n-lastShift<350)caps=true;else{shift=!shift;caps=false;}lastShift=n;refreshShift();});add(bottom,shiftKey,1,rowHeight);}
        if(settings.optBoolean("showCommaKey",true))key(bottom,language.equals("en")?",":"،","Comma",.8f,keyColor,rowHeight,()->insert(language.equals("en")?",":"،"));
        key(bottom,"none".equals(settings.optString("spacebarLabelMode"))?"␣":"custom".equals(settings.optString("spacebarLabelMode"))?settings.optString("customSpacebarText","␣"):lang.optString("nativeName",language),"Space",2.7f,color("spaceBg",keyColor),rowHeight,()->insert(" "));
        key(bottom,".","Period",.7f,keyColor,rowHeight,()->insert("."));}
        deleteButton(bottom); key(bottom,"↵","Enter",1.15f,enterColor,rowHeight,actions::enter);
        if(!numeric){LinearLayout edit=row();key(edit,"←","Cursor left",1,specialColor,32,()->actions.cursor(-1));key(edit,"→","Cursor right",1,specialColor,32,()->actions.cursor(1));if(!privateField){key(edit,"↶","Undo",1,specialColor,32,()->actions.editorAction(android.R.id.undo));key(edit,"↷","Redo",1,specialColor,32,()->actions.editorAction(android.R.id.redo));}key(edit,"Paste","Paste",1.5f,specialColor,32,()->actions.editorAction(android.R.id.paste));}
        selectionChanged();
    }

    private String digit(int i){String style=settings.optString("numberStyle","latin");return String.valueOf((char)(("kurdish".equals(style)?0x0660:"urdu_farsi".equals(style)?0x06f0:"hindi".equals(style)?0x0966:'0')+i));}
    private void beginPanel(String name){panelEpoch++;actions.cancelAi();if(!name.startsWith("emoji"))data.releaseRich();panel=name;stopPointers();removeAllViews();characterKeys.clear();characterValues.clear();shiftedLabels.clear();suggestionKeys.clear();voiceKey=null;shiftKey=null;}
    private void renderLayout(){JSONArray off=layout.optJSONArray("off"), upper=layout.optJSONArray("shift");JSONObject customs=settings.optJSONObject("customLayouts");JSONArray custom=customs==null?null:customs.optJSONArray(lang.optString("characterLayoutId"));
        for(int i=0;i<off.length();i++){JSONArray rr=off.optJSONArray(i),uu=upper==null?null:upper.optJSONArray(i),cc=custom==null?null:custom.optJSONArray(i);if(rr==null)continue;LinearLayout r=row();for(int j=0;j<rr.length();j++){JSONObject k=rr.optJSONObject(j),u=uu==null?null:uu.optJSONObject(j);if(k==null)continue;String override=cc==null?"":cc.optString(j,"");String base=override.isEmpty()?k.optString("value"):override;String label=override.isEmpty()?k.optString("label",base):override;String up=override.isEmpty()&&u!=null?u.optString("value",base):base.toUpperCase(Locale.ROOT);String upLabel=override.isEmpty()&&u!=null?u.optString("label",up):up;
        TextView b=button(shift?upLabel:label,keyColor,label,()->insert(shift?up:base));characterKeys.add(b);characterValues.add(label);shiftedLabels.add(upLabel);java.util.LinkedHashSet<String> alts=new java.util.LinkedHashSet<>();JSONArray aa=k.optJSONArray("alts");if(aa!=null)for(int z=0;z<aa.length();z++)alts.add(aa.optString(z));java.util.Collections.addAll(alts,NativeTypingLayouts.alternatives(base));if(!alts.isEmpty())b.setOnLongClickListener(v->{showAlternatives(alts.toArray(new String[0]));return true;});add(r,b,(float)Math.max(.5,Math.min(3,k.optDouble("width",1))),rowHeight);}}
    }
    private void updateSuggestions(){if(!"typing".equals(panel)||privateField||suggestionKeys.isEmpty()||!isShown())return;String before=actions.tail();String p=NativeWordEngine.prefix(before);lastPrefix=p;java.util.List<String> result=NativeWordEngine.suggest(words,p,3);if(p.isEmpty()){String prev=NativeWordEngine.prefix(before.trim());JSONObject next=data.dictionary().optJSONObject("next"), map=next==null?null:next.optJSONObject(language);JSONArray vals=map==null?null:map.optJSONArray(prev);if(vals!=null)for(int i=0;i<Math.min(vals.length(),3);i++)result.add(vals.optString(i));}for(int i=0;i<suggestionKeys.size();i++){TextView v=suggestionKeys.get(i);String value=i<result.size()?result.get(i):"";v.setText(value);v.setEnabled(!value.isEmpty());}}
    private LinearLayout panelHeader(String label){LinearLayout r=row();key(r,"‹","Back to typing",1,specialColor,36,this::rebuild);key(r,label,label,4,accent,36,()->{});return r;}
    private LinearLayout scrollList(int h){android.widget.ScrollView sc=new android.widget.ScrollView(getContext());LinearLayout list=new LinearLayout(getContext());list.setOrientation(VERTICAL);sc.addView(list);addView(sc,new LayoutParams(-1,dp(h)));return list;}
    private void item(LinearLayout parent,String label,Runnable action){TextView b=button(label,keyColor,label,action);b.setSingleLine(false);b.setMaxLines(3);LayoutParams lp=new LayoutParams(-1,dp(46));lp.setMargins(dp(3),dp(2),dp(3),dp(2));parent.addView(b,lp);}
    private void showTools(){beginPanel("tools");panelHeader("ئامرازەکان");LinearLayout list=scrollList(230);if(!privateField){if(settings.optBoolean("smartReplyEnabled",true))item(list,"✦ AI — داڕشتنەوە",()->showAi(false));item(list,"وەرگێڕان / Translate",()->showAi(true));item(list,"☺ ئیمۆجی، زیکر، Kaomoji",this::showEmoji);if(settings.optBoolean("clipboardEnabled",true))item(list,"Clipboard",actions::clipboard);item(list,"دەقە ئامادەکان",this::showSnippets);}
        item(list,"دەستکاری دەق",this::showEditorTools);item(list,"دیزاین و ڕەنگەکان",this::showThemes);item(list,"گۆڕینی زمان",this::changeLanguage);item(list,"ڕێکخستنەکان",actions::settings);item(list,"هەموو ئامرازەکانی پێشوو (WebView)",actions::advanced);}
    private void showEditorTools(){beginPanel("editor_tools");panelHeader("دەستکاری دەق");LinearLayout list=scrollList(230);item(list,"هەڵبژاردنی هەموو",()->actions.editorAction(android.R.id.selectAll));if(!privateField){item(list,"کۆپی",()->actions.editorAction(android.R.id.copy));item(list,"بڕین",()->actions.editorAction(android.R.id.cut));item(list,"Undo",()->actions.editorAction(android.R.id.undo));item(list,"Redo",()->actions.editorAction(android.R.id.redo));}item(list,"Paste",()->actions.editorAction(android.R.id.paste));}
    private void showThemes(){beginPanel("themes");panelHeader("دیزاینەکان");LinearLayout list=scrollList(235);JSONArray a=data.allThemes();for(int i=0;i<a.length();i++){JSONObject t=a.optJSONObject(i);if(t==null)continue;String id=t.optString("id");if(t.optBoolean("isStore")&&!hasTheme(id))continue;TextView b=button(t.optString("nameKu",t.optString("name")),keyColor,"Theme "+id,()->{try{settings.put("activeThemeId",id);}catch(Exception ignored){}actions.setTheme(id);rebuild();});try{b.setBackground(shape(Color.parseColor(t.optString("keyBg"))));b.setTextColor(Color.parseColor(t.optString("keyText")));}catch(Exception ignored){}list.addView(b,new LayoutParams(-1,dp(40)));}}
    private boolean hasTheme(String id){JSONArray a=settings.optJSONArray("downloadedThemeIds");if(a!=null)for(int i=0;i<a.length();i++)if(id.equals(a.optString(i)))return true;return false;}
    private void showSnippets(){beginPanel("snippets");panelHeader("دەقە ئامادەکان");LinearLayout list=scrollList(230);JSONArray a=settings.optJSONArray("quickSnippets");if(a!=null)for(int i=0;i<Math.min(a.length(),200);i++){JSONObject v=a.optJSONObject(i);if(v!=null)item(list,v.optString("label"),()->{insert(v.optString("text"));rebuild();});}}
    private void showEmoji(){if(privateField)return;beginPanel("emoji_categories");panelHeader("ئیمۆجی");LinearLayout list=scrollList(230);item(list,"★ پین و دوایین",()->showEmojiGroup("recent"));String query=NativeWordEngine.prefix(actions.tail());if(query.length()>=2)item(list,"گەڕان: "+query,()->showEmojiGroup("search:"+query));JSONArray cats=data.rich().optJSONArray("emojiCategories");JSONArray disabled=settings.optJSONArray("emojiDisabledCategories");if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c==null)continue;String id=c.optString("id");boolean hidden=false;if(disabled!=null)for(int j=0;j<disabled.length();j++)if(id.equals(disabled.optString(j)))hidden=true;if(!hidden)item(list,c.optString("icon")+"  "+c.optString("label"),()->showEmojiGroup(id));}item(list,"Kaomoji",()->showEmojiGroup("kaomoji"));item(list,"زیکر و دوعا",()->showEmojiGroup("duaa"));item(list,"قورئان",()->showEmojiGroup("quran"));item(list,"سەڵاوات",()->showEmojiGroup("salawat"));}
    private void remember(String value,boolean pin){if(settings.optBoolean("emojiHistoryEnabled",true)||pin){String key=pin?"emojiPinned":"recentEmojis";JSONArray a=settings.optJSONArray(key),next=new JSONArray();boolean exists=false;if(a!=null)for(int i=0;i<a.length();i++)if(value.equals(a.optString(i)))exists=true;if(!pin||!exists)next.put(value);int max=Math.max(1,Math.min(100,settings.optInt(pin?"emojiHistoryPinnedMaxSize":"emojiHistoryRecentMaxSize",pin?24:40)));if(a!=null)for(int i=0;i<a.length()&&next.length()<max;i++)if(!value.equals(a.optString(i)))next.put(a.optString(i));try{settings.put(key,next);}catch(Exception ignored){}actions.rememberEmoji(value,pin);}}
    private void showEmojiGroup(String id){showEmojiGroup(id,0);}
    private void showEmojiGroup(String id,int requestedPage){beginPanel("emoji_grid");LinearLayout h=panelHeader(id);key(h,"☷","Categories",1,specialColor,36,this::showEmoji);LinearLayout list=scrollList(235);JSONArray entries=new JSONArray();JSONObject rich=data.rich();if("recent".equals(id)){java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();for(String k:new String[]{"emojiPinned","recentEmojis"}){JSONArray a=settings.optJSONArray(k);if(a!=null)for(int i=0;i<a.length();i++)set.add(a.optString(i));}for(String v:set)entries.put(v);}else if(id.startsWith("search:")){String query=id.substring(7).toLowerCase(Locale.ROOT);JSONArray cats=rich.optJSONArray("emojiCategories");if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c==null)continue;JSONArray a=c.optJSONArray("items");if(a!=null)for(int j=0;j<a.length();j++){JSONObject v=a.optJSONObject(j);if(v!=null&&(v.optString("e").toLowerCase(Locale.ROOT).contains(query)||v.optString("k").contains(query)))entries.put(v);}}}else if("kaomoji".equals(id)){entries=rich.optJSONArray("kaomojiList");}else if(java.util.Arrays.asList("duaa","quran","salawat").contains(id)){JSONObject z=rich.optJSONObject("zikrData");entries=z==null?null:z.optJSONArray(id);}else{JSONArray cats=rich.optJSONArray("emojiCategories");if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c!=null&&id.equals(c.optString("id")))entries=c.optJSONArray("items");}}
        if(entries==null)return;boolean textMode=java.util.Arrays.asList("duaa","quran","salawat","kaomoji").contains(id);int cols=textMode?1:Math.max(4,Math.min(10,settings.optInt("emojiColumns",7)));LinearLayout r=null;
        final int pageSize=cols*(textMode?24:10), pageCount=Math.max(1,(entries.length()+pageSize-1)/pageSize), page=Math.max(0,Math.min(requestedPage,pageCount-1));
        if(pageCount>1){LinearLayout pages=new LinearLayout(getContext());pages.setOrientation(HORIZONTAL);list.addView(pages,new LayoutParams(-1,-2));key(pages,"‹","Previous page",1,specialColor,32,()->showEmojiGroup(id,page-1));key(pages,(page+1)+" / "+pageCount,"Page",2,keyColor,32,()->{});key(pages,"›","Next page",1,specialColor,32,()->showEmojiGroup(id,page+1));}
        for(int i=page*pageSize;i<Math.min(entries.length(),(page+1)*pageSize);i++){Object raw=entries.opt(i);JSONObject e=raw instanceof JSONObject?(JSONObject)raw:null;String value=e==null?entries.optString(i):e.optString("c",e.optString("v",""));if(value.isEmpty())continue;String label=e==null?value:e.optString("d",value);if(!textMode&&e!=null){String tone=settings.optString("emojiSkinTone"),hair=settings.optString("emojiHairStyle");JSONArray variants=e.optJSONArray("v");if(!tone.isEmpty()&&variants!=null)for(int j=0;j<variants.length();j++){String v=variants.optString(j);if(v.contains(tone)){value=v;break;}}if(!hair.isEmpty()&&java.util.Arrays.asList("👨","👩","🧑").contains(e.optString("c")))value=e.optString("c")+tone+"‍"+hair;label=value;}
            final String v=value;if(textMode){item(list,label,()->{actions.type(v);});continue;}if(i%cols==0||r==null){r=new LinearLayout(getContext());r.setOrientation(HORIZONTAL);list.addView(r,new LayoutParams(-1,-2));}TextView b=button(label,keyColor,e==null?label:e.optString("k",label),()->{actions.type(v);remember(v,false);});b.setTypeface(Typeface.DEFAULT);b.setTextSize(Math.max(18,Math.min(32,settings.optInt("emojiFontSizePx",24))));b.setOnLongClickListener(w->{showEmojiOptions(id,v,e);return true;});add(r,b,1,42);}}
    private void showEmojiOptions(String id,String value,JSONObject e){beginPanel("emoji_options");LinearLayout h=panelHeader("ئیمۆجی");key(h,"‹","Category",1,specialColor,36,()->showEmojiGroup(id));LinearLayout list=scrollList(225);item(list,"★ Pin / Unpin "+value,()->{remember(value,true);showEmojiGroup(id);});JSONArray a=e==null?null:e.optJSONArray("v");if(a!=null)for(int i=0;i<a.length();i++){String v=a.optString(i);item(list,v,()->{actions.type(v);remember(v,false);showEmojiGroup(id);});}}
    private void showAi(boolean translate){if(privateField)return;beginPanel("ai");panelHeader(translate?"وەرگێڕان":"AI — داڕشتنەوە");LinearLayout list=scrollList(245);String source=actions.sourceText();TextView preview=new TextView(getContext());preview.setText(source.isEmpty()?"دەقێک هەڵبژێرە":source);preview.setTextColor(textColor);preview.setTextSize(15);preview.setPadding(dp(8),dp(6),dp(8),dp(6));list.addView(preview,new LayoutParams(-1,-2));TextView status=new TextView(getContext());status.setTextColor(textColor);status.setText("دەقەکە تەنها بە فشاردانی فەرمان بۆ سێرڤەر دەنێردرێت");list.addView(status);
        if(source.isEmpty())return;String[] modes={"fix","formal","friendly","shorten","expand","rephrase","reply","poetic","explain","badini","sorani"};String[] labels={"ڕاستکردنەوە","فەرمی","دۆستانە","کورتکردنەوە","درێژکردنەوە","داڕشتنەوە","وەڵام","شیعری","ڕوونکردنەوە","بادینی","سۆرانی"};
        if(translate){JSONArray all=data.translationLanguages();modes=new String[all.length()];labels=new String[all.length()];for(int i=0;i<all.length();i++){JSONObject l=all.optJSONObject(i);modes[i]=l==null?"en":l.optString("code","en");labels[i]=l==null?"English":l.optString("label",modes[i])+" — "+l.optString("native",modes[i]);}}

        for(int i=0;i<modes.length;i++){String mode=modes[i];item(list,labels[i],()->{long token=++panelEpoch;status.setText("چاوەڕوانی ئەنجام…");actions.ai(source,translate?"translate":mode,translate?mode:"","",out->{if(token!=panelEpoch||!isShown())return;if(out==null){status.setText("هەڵەی سێرڤەر یان ئەنجامی نادروست");return;}beginPanel("ai_result");panelHeader("ئەنجام");LinearLayout result=scrollList(240);TextView t=new TextView(getContext());t.setTextColor(textColor);t.setText(out);t.setTextIsSelectable(false);result.addView(t);item(result,"دانانی ئەنجام لە شوێنی Cursor",()->{actions.type(out);rebuild();});item(result,"دووبارە",()->showAi(translate));});});}}
}
