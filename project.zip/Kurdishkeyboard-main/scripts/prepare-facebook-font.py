#!/usr/bin/env python3
"""Build-time conversion of a user-authorized color emoji font to offline PNGs.
No network access here. HarfBuzz rejects missing and uncomposed sequences.
"""
import argparse
import ctypes as C
import ctypes.util
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont, features

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'native-android/app/src/main/assets/native-ime'
MAX_FONT = 128 * 1024 * 1024


class GlyphInfo(C.Structure):
    _fields_ = [(x, C.c_uint32) for x in ('codepoint', 'mask', 'cluster', 'var1', 'var2')]


class Shaper:
    def __init__(self, path):
        library = ctypes.util.find_library('harfbuzz')
        if not library:
            raise RuntimeError('Install libharfbuzz0b (HarfBuzz shared library).')
        self.hb = C.CDLL(library)
        sig = {
            'hb_blob_create_from_file': ([C.c_char_p], C.c_void_p),
            'hb_blob_get_length': ([C.c_void_p], C.c_uint),
            'hb_face_create': ([C.c_void_p, C.c_uint], C.c_void_p),
            'hb_font_create': ([C.c_void_p], C.c_void_p),
            'hb_ot_font_set_funcs': ([C.c_void_p], None),
            'hb_buffer_create': ([], C.c_void_p),
            'hb_buffer_add_utf8': ([C.c_void_p, C.c_char_p, C.c_int, C.c_uint, C.c_int], None),
            'hb_buffer_guess_segment_properties': ([C.c_void_p], None),
            'hb_shape': ([C.c_void_p, C.c_void_p, C.c_void_p, C.c_uint], None),
            'hb_buffer_get_glyph_infos': ([C.c_void_p, C.POINTER(C.c_uint)], C.POINTER(GlyphInfo)),
            'hb_buffer_destroy': ([C.c_void_p], None),
            'hb_font_destroy': ([C.c_void_p], None),
            'hb_face_destroy': ([C.c_void_p], None),
            'hb_blob_destroy': ([C.c_void_p], None),
        }
        for name, (args, ret) in sig.items():
            fn = getattr(self.hb, name)
            fn.argtypes, fn.restype = args, ret
        self.blob = self.hb.hb_blob_create_from_file(str(path).encode())
        if not self.blob or not self.hb.hb_blob_get_length(self.blob):
            raise ValueError('Cannot read the supplied font')
        self.face = self.hb.hb_face_create(self.blob, 0)
        self.font = self.hb.hb_font_create(self.face)
        self.hb.hb_ot_font_set_funcs(self.font)

    def glyphs(self, value):
        raw = value.encode('utf-8')
        buf = self.hb.hb_buffer_create()
        try:
            self.hb.hb_buffer_add_utf8(buf, raw, len(raw), 0, len(raw))
            self.hb.hb_buffer_guess_segment_properties(buf)
            self.hb.hb_shape(self.font, buf, None, 0)
            n = C.c_uint()
            infos = self.hb.hb_buffer_get_glyph_infos(buf, C.byref(n))
            return [infos[i].codepoint for i in range(n.value)]
        finally:
            self.hb.hb_buffer_destroy(buf)

    def close(self):
        self.hb.hb_font_destroy(self.font)
        self.hb.hb_face_destroy(self.face)
        self.hb.hb_blob_destroy(self.blob)


def load_font(path):
    if not path.is_file() or not 0 < path.stat().st_size <= MAX_FONT:
        raise ValueError('Missing font or font exceeds 128 MiB')
    if not features.check('raqm'):
        raise RuntimeError('Pillow with RAQM is required for emoji shaping')
    with TTFont(path, lazy=True) as font:
        tables = set(font.keys())
        if not (('CBDT' in tables and 'CBLC' in tables) or 'sbix' in tables or ('COLR' in tables and 'CPAL' in tables)):
            raise ValueError('Unsupported color font format (need CBDT/CBLC, sbix or COLR/CPAL).')
        sizes = {128, 109, 96, 72, 64}
        if 'CBLC' in tables:
            sizes.update(int(s.bitmapSizeTable.ppemY) for s in font['CBLC'].strikes)
        if 'sbix' in tables:
            sizes.update(int(s) for s in font['sbix'].strikes)
    for size in sorted((s for s in sizes if 16 <= s <= 256), key=lambda s: abs(s-128)):
        try:
            return ImageFont.truetype(str(path), size, layout_engine=ImageFont.Layout.RAQM)
        except OSError:
            continue
    raise ValueError('FreeType cannot load any usable strike of this color font')


def render(font, value):
    left, top, right, bottom = font.getbbox(value)
    width, height = right-left, bottom-top
    if not (0 < width <= 2048 and 0 < height <= 2048):
        return None
    canvas = Image.new('RGBA', (width+8, height+8))
    ImageDraw.Draw(canvas).text((4-left, 4-top), value, font=font, embedded_color=True, fill=(0,0,0,255))
    bbox = canvas.getchannel('A').getbbox()
    if bbox is None:
        return None
    glyph = canvas.crop(bbox)
    glyph.thumbnail((60,60), Image.Resampling.LANCZOS)
    result = Image.new('RGBA', (64,64))
    result.paste(glyph, ((64-glyph.width)//2, (64-glyph.height)//2))
    return result


def build(path, target, expected):
    font = load_font(path)
    shaper = Shaper(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
            stage = Path(tmp)/'facebook-emoji'
            stage.mkdir()
            mapped, missing = {}, []
            for code, value in sorted(expected.items()):
                ids = shaper.glyphs(value)
                # A complete emoji cluster normally shapes to one non-.notdef glyph.
                # Do not mislabel disconnected ZWJ parts or a missing glyph as the requested style.
                if len(ids) != 1 or ids[0] == 0:
                    missing.append(code)
                    continue
                try:
                    image = render(font, value)
                except (OSError, ValueError):
                    image = None
                if image is None:
                    missing.append(code)
                    continue
                image.save(stage/(code+'.png'), optimize=True)
                mapped[code] = value
            # The user requested a working color pack, not an empty or monochrome substitute.
            required = {'1f600','1f60d','1f602','1f44b'}
            if not required.issubset(mapped):
                raise ValueError('Font could not render required common emoji: '+', '.join(sorted(required-set(mapped))))
            with Image.open(stage/'1f600.png') as sample:
                if not any(a > 128 and max(r,g,b)-min(r,g,b)>20 for r,g,b,a in sample.getdata()):
                    raise ValueError('Renderer did not produce a color emoji; check FreeType support.')
            (stage/'manifest.json').write_text(json.dumps(mapped, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
            # The font itself stays in the temporary build directory, not the source ZIP or APK.
            if target.exists():
                shutil.rmtree(target)
            stage.rename(target)
            print(f'Offline font conversion: {len(mapped)}/{len(expected)} matched; {len(missing)} use Noto offline.')
            print('Source font SHA-256:', hashlib.sha256(path.read_bytes()).hexdigest())
            if missing:
                print('First missing codes:', ', '.join(missing[:20]))
            return len(mapped), len(missing)
    finally:
        shaper.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('font', type=Path)
    parser.add_argument('--authorized', action='store_true', help='Confirm permission to package artwork from this font')
    parser.add_argument('--output', type=Path, default=ASSETS/'facebook-emoji')
    args = parser.parse_args()
    if not args.authorized:
        parser.error('Pass --authorized only if you have permission to package the artwork.')
    expected = json.loads((ASSETS/'emoji/manifest.json').read_text(encoding='utf-8'))
    build(args.font, args.output, expected)

if __name__ == '__main__':
    main()
