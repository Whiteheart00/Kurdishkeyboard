import { build } from 'esbuild';

export async function buildNativeImeData(directory) {
  const { writeFile } = await import('node:fs/promises');
  const { join } = await import('node:path');
  const bundle = await build({
    entryPoints: ['src/native-ime/data.ts'],
    bundle: true,
    format: 'cjs',
    platform: 'node',
    write: false,
  });
  const module = { exports: {} };
  const { createRequire } = await import('node:module');
  new Function('module', 'exports', 'require', bundle.outputFiles[0].text)(
    module, module.exports, createRequire(import.meta.url),
  );
  await Promise.all(Object.entries(module.exports.nativeData).map(([name, value]) =>
    writeFile(join(directory, `${name}.json`), JSON.stringify(value)),
  ));
}

// Generate the existing Web Audio fallback tones as short PCM assets for SoundPool.
export async function buildNativeImeSounds(directory) {
  const { writeFile } = await import('node:fs/promises');
  const { join } = await import('node:path');
  const rate = 22050;
  const count = Math.ceil(rate * 0.055);
  const tones = [
    ['char', 620, 260, 0.022, 0.026, 0.8, false],
    ['special', 520, 260, 0.022, 0.026, 0.8, false],
    ['space', 190, 85, 0.035, 0.04, 1, true],
    ['backspace', 340, 160, 0.03, 0.035, 0.9, false],
    ['enter', 420, 240, 0.045, 0.05, 0.95, true],
  ];
  await Promise.all(tones.map(async ([name, start, end, frequencyRamp, gainRamp, amplitude, triangle]) => {
    const buffer = Buffer.alloc(44 + count * 2);
    buffer.write('RIFF', 0);
    buffer.writeUInt32LE(buffer.length - 8, 4);
    buffer.write('WAVEfmt ', 8);
    buffer.writeUInt32LE(16, 16);
    buffer.writeUInt16LE(1, 20);
    buffer.writeUInt16LE(1, 22);
    buffer.writeUInt32LE(rate, 24);
    buffer.writeUInt32LE(rate * 2, 28);
    buffer.writeUInt16LE(2, 32);
    buffer.writeUInt16LE(16, 34);
    buffer.write('data', 36);
    buffer.writeUInt32LE(count * 2, 40);
    let phase = 0;
    for (let i = 0; i < count; i++) {
      const seconds = i / rate;
      const frequency = start * (end / start) ** Math.min(1, seconds / frequencyRamp);
      const gain = 0.11 * amplitude * (0.001 / (0.11 * amplitude)) ** Math.min(1, seconds / gainRamp);
      const sine = Math.sin(phase);
      const sample = (triangle ? 2 * Math.asin(sine) / Math.PI : sine) * gain;
      buffer.writeInt16LE(Math.round(sample * 32767), 44 + i * 2);
      phase += 2 * Math.PI * frequency / rate;
    }
    await writeFile(join(directory, `${name}.wav`), buffer);
  }));
}
