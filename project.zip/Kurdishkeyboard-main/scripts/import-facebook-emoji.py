#!/usr/bin/env python3
"""Import a locally supplied, authorized Facebook-style PNG pack. No network access."""
import argparse, io, json, re, shutil, tempfile, zipfile
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'native-android/app/src/main/assets/native-ime'
CODE = re.compile(r'[0-9a-f]{4,6}(?:-[0-9a-f]{4,6})*\.png')
MAX_SIZE = 256 * 1024

def normalize(name):
    base = Path(name).name.lower()
    if not CODE.fullmatch(base): return None
    return base[:-4]

def read_image(raw):
    if len(raw) > MAX_SIZE: raise ValueError('PNG exceeds 256 KiB')
    with Image.open(io.BytesIO(raw)) as image:
        if image.format != 'PNG' or image.size != (64, 64): raise ValueError('Expected a 64x64 PNG')
        image.load()
        if image.convert('RGBA').getchannel('A').getbbox() is None: raise ValueError('Transparent PNG')
    return raw

def load_pack(path, expected):
    wanted = {k.replace('-fe0f','') for k in expected}
    images = {}
    def add(name, raw):
        code = normalize(name)
        if code is None or code.replace('-fe0f','') not in wanted: return
        raw = read_image(raw)
        if code in images and images[code] != raw: raise ValueError('Conflicting image: '+code)
        images[code] = raw
    if path.is_dir():
        for file in path.rglob('*.png'):
            code = normalize(file.name)
            if code is not None and code.replace('-fe0f','') in wanted:
                if file.stat().st_size > MAX_SIZE: raise ValueError('Oversized image: '+file.name)
                add(file.name, file.read_bytes())
    else:
        with zipfile.ZipFile(path) as archive:
            for item in archive.infolist():
                code = normalize(item.filename)
                if code is not None and code.replace('-fe0f','') in wanted:
                    if item.file_size > MAX_SIZE: raise ValueError('Oversized image: '+item.filename)
                    add(item.filename, archive.read(item))
    by_normalized = {}
    for code in images: by_normalized.setdefault(code.replace('-fe0f',''), []).append(code)
    mapped = {}
    for code in expected:
        if code in images: mapped[code] = images[code]
        else:
            candidates = by_normalized.get(code.replace('-fe0f',''), [])
            if len(candidates) == 1: mapped[code] = images[candidates[0]]
    return mapped

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pack', type=Path, help='Folder or ZIP of licensed 64x64 PNGs named by Unicode code points')
    parser.add_argument('--authorized', action='store_true', help='Confirm that you have permission to package these images')
    args = parser.parse_args()
    if not args.authorized: parser.error('Permission to package the images is required; pass --authorized only if you have it.')
    expected = json.loads((ASSETS/'emoji/manifest.json').read_text())
    images = load_pack(args.pack, expected)
    if not images: raise SystemExit('No matching authorized artwork found; existing assets were not changed.')
    target = ASSETS/'facebook-emoji'
    with tempfile.TemporaryDirectory(dir=ASSETS) as tmp:
        staged = Path(tmp)/'facebook-emoji'; staged.mkdir()
        for code, raw in images.items(): (staged/(code+'.png')).write_bytes(raw)
        (staged/'manifest.json').write_text(json.dumps({code:expected[code] for code in sorted(images)},ensure_ascii=False,indent=2)+'\n')
        if target.exists(): shutil.rmtree(target)
        staged.rename(target)
    print(f'Imported {len(images)}/{len(expected)} emoji codes. Remaining codes use bundled Noto. No runtime Internet requests.')

if __name__ == '__main__': main()
