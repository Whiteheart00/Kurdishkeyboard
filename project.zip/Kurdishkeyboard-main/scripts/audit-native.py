#!/usr/bin/env python3
"""Fail CI if Android source/build or packaged DEX/assets reintroduce embedded web UI."""
from pathlib import Path
import json, re, sys, zipfile
root = Path(__file__).resolve().parent.parent
require_facebook = "--require-facebook" in sys.argv[1:]
args = [x for x in sys.argv[1:] if x != "--require-facebook"]
if len(args) > 1: raise SystemExit("Usage: audit-native.py [--require-facebook] [apk]")
patterns = re.compile(r'android\.webkit\.|androidx\.webkit\.|androidx\.core[:\.]|com\.getcapacitor\.|\bWebView\b|\bBridgeActivity\b|\bJavascriptInterface\b|\bevaluateJavascript\b|\baddJavascriptInterface\b|@capacitor/|\bnpx cap\b', re.I)
files = list((root/'android-ime').glob('*.java')) + list((root/'native-android').rglob('*.gradle')) + list((root/'native-android').rglob('*.xml')) + [root/'scripts/setup-android-ime.mjs', root/'.github/workflows/build.yml', root/'.github/workflows/build-apk.yml']
for p in files:
    for n,line in enumerate(p.read_text().splitlines(),1):
        if line.lstrip().startswith(('//','*')): continue
        if patterns.search(line): raise SystemExit(f'Forbidden Android code: {p.relative_to(root)}:{n}')
if (root/'android-ime/migrate.js').exists() or (root/'capacitor.config.json').exists(): raise SystemExit('Obsolete Android web files remain')
# Ensure every original emoji and its variants ship as offline artwork.
emoji_dir = root/'native-android/app/src/main/assets/native-ime/emoji'
emoji_manifest = json.loads((emoji_dir/'manifest.json').read_text())
rich = json.loads((root/'src/data/generated/richData.json').read_text())
values = {value for category in rich['emojiCategories'] for entry in category['items'] for value in [entry['c'], *entry.get('v', [])]}
values.update(category['icon'] for category in rich['emojiCategories'])
values.update(['😍','😂','❤️','🥹','🔥','👋','🧑','😁'])
for tone in ['', '🏻','🏼','🏽','🏾','🏿']:
    values.add('👋'+tone)
    for person in ['🧑','👨','👩']:
        for hair in ['', '🦰','🦱','🦳','🦲']:
            values.add(person+tone+('\u200d'+hair if hair else ''))
expected = {'-'.join(f'{ord(char):04x}' for char in value): value for value in values}
if expected != emoji_manifest: raise SystemExit('Offline emoji catalog differs from original data')
for code in expected:
    image = emoji_dir/(code+'.png')
    if not image.is_file(): raise SystemExit('Missing offline emoji: '+code)
    with image.open('rb') as f:
        if f.read(8) != b'\x89PNG\r\n\x1a\n': raise SystemExit('Invalid offline emoji: '+code)
print(f'Offline emoji catalog audit passed ({len(expected)} images).')
fb_dir = emoji_dir.parent/'facebook-emoji'
fb = json.loads((fb_dir/'manifest.json').read_text())
if not isinstance(fb, dict) or any(expected.get(code) != value for code, value in fb.items()):
    raise SystemExit('Invalid Facebook-style offline catalog')
if {p.stem for p in fb_dir.glob('*.png')} != set(fb):
    raise SystemExit('Facebook-style offline manifest does not match assets')
for code in fb:
    with (fb_dir/(code+'.png')).open('rb') as f:
        if f.read(8) != b'\x89PNG\r\n\x1a\n': raise SystemExit('Invalid Facebook-style PNG: '+code)
if require_facebook and not {'1f600','1f60d','1f602','1f44b'}.issubset(fb):
    raise SystemExit('Required offline Facebook emoji pack missing or incomplete; run font preparation before build.')
print(f'Facebook-style offline catalog: {len(fb)}/{len(expected)}; remaining codes use Noto.')
glyph_source = (root/'android-ime/NativeImeEmojiGlyphs.java').read_text()
if re.search(r'https?://|HttpURLConnection|java\.net\.', glyph_source):
    raise SystemExit('Native emoji renderer must not access the Internet')
if args:
    with zipfile.ZipFile(args[0]) as z:
        dex = [name for name in z.namelist() if re.fullmatch(r'classes\d*\.dex', name)]
        if not dex: raise SystemExit('APK DEX missing')
        for name in z.namelist():
            if name.startswith('assets/') and (re.search(r'\.(html?|js|mjs|css)$',name,re.I) or 'capacitor' in name.lower()):
                raise SystemExit('Embedded web asset: '+name)
        for name in dex:
            data=z.read(name)
            for descriptor in [b'Landroid/webkit/',b'Landroidx/webkit/',b'Lcom/getcapacitor/',b'android.webkit.WebView']:
                if descriptor in data: raise SystemExit(f'Forbidden DEX reference in {name}: {descriptor!r}')
        packaged = set(z.namelist())
        for code in expected:
            name = 'assets/native-ime/emoji/'+code+'.png'
            if name not in packaged: raise SystemExit('Missing packaged emoji: '+code)
        for code in fb:
            if 'assets/native-ime/facebook-emoji/'+code+'.png' not in packaged: raise SystemExit('Missing packaged Facebook-style emoji: '+code)
        if 'assets/native-ime/facebook-emoji/manifest.json' not in packaged: raise SystemExit('Missing Facebook-style manifest')
        if json.loads(z.read('assets/native-ime/facebook-emoji/manifest.json')) != fb: raise SystemExit('Packaged Facebook manifest differs from source')
        for name in ['assets/native-ime/core.json','assets/native-ime/settingsPages.json','assets/native-ime/layouts.json','assets/public/fonts/kurdifont1.ttf']:
            if name not in z.namelist(): raise SystemExit('Missing required asset: '+name)
    print('APK DEX and packaged asset audit passed.')
print(f'Native source audit passed ({len(files)} files).')
