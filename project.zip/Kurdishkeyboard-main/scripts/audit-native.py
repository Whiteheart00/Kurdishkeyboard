#!/usr/bin/env python3
"""Fail CI if Android source/build or packaged DEX/assets reintroduce embedded web UI."""
from pathlib import Path
import re, sys, zipfile
root = Path(__file__).resolve().parent.parent
patterns = re.compile(r'android\.webkit\.|com\.getcapacitor\.|\bWebView\b|\bBridgeActivity\b|\bJavascriptInterface\b|\bevaluateJavascript\b|\baddJavascriptInterface\b|@capacitor/|\bnpx cap\b', re.I)
files = list((root/'android-ime').glob('*.java')) + list((root/'native-android').rglob('*.gradle')) + list((root/'native-android').rglob('*.xml')) + [root/'scripts/setup-android-ime.mjs', root/'.github/workflows/build.yml', root/'.github/workflows/build-apk.yml']
for p in files:
    for n,line in enumerate(p.read_text().splitlines(),1):
        if line.lstrip().startswith(('//','*')): continue
        if patterns.search(line): raise SystemExit(f'Forbidden Android code: {p.relative_to(root)}:{n}')
if (root/'android-ime/migrate.js').exists() or (root/'capacitor.config.json').exists(): raise SystemExit('Obsolete Android web files remain')
if len(sys.argv)>1:
    with zipfile.ZipFile(sys.argv[1]) as z:
        dex = [name for name in z.namelist() if re.fullmatch(r'classes\d*\.dex', name)]
        if not dex: raise SystemExit('APK DEX missing')
        for name in z.namelist():
            if name.startswith('assets/') and (re.search(r'\.(html?|js|mjs|css)$',name,re.I) or 'capacitor' in name.lower()):
                raise SystemExit('Embedded web asset: '+name)
        for name in dex:
            data=z.read(name)
            for descriptor in [b'Landroid/webkit/WebView;',b'Landroid/webkit/WebViewClient;',b'Landroid/webkit/JavascriptInterface;',b'Lcom/getcapacitor/']:
                if descriptor in data: raise SystemExit(f'Forbidden DEX reference in {name}: {descriptor!r}')
        for name in ['assets/native-ime/core.json','assets/native-ime/settingsPages.json','assets/native-ime/layouts.json','assets/public/fonts/kurdifont1.ttf']:
            if name not in z.namelist(): raise SystemExit('Missing required asset: '+name)
    print('APK DEX and packaged asset audit passed.')
print(f'Native source audit passed ({len(files)} files).')
