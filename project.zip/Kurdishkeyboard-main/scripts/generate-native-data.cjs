// Regenerate the Native assets from the existing web data (node scripts/generate-native-data.cjs).
const fs = require('fs'), path = require('path'), Module = require('module');
const ts = require('typescript');
const root = path.resolve(__dirname,'..');
const original=Module._extensions['.ts'];
Module._extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,f);
const load=(name)=>require(path.join(root,'src/data',name+'.ts'));
const {ALL_THEMES,DEFAULT_CUSTOM_THEME}=load('themes');
const {ALL_SUBTYPE_PRESETS,CHARACTER_LAYOUT_OPTIONS,resolveLayoutRows}=load('layouts');
const {DEFAULT_SETTINGS}=load('defaultSettings');
const dict=load('dictionaries');
const out=path.join(root,'android-ime/native-data');
fs.mkdirSync(path.join(out,'layouts'),{recursive:true});
const put=(name,data)=>fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(data));
put('themes',[...ALL_THEMES,DEFAULT_CUSTOM_THEME]);
put('defaults',DEFAULT_SETTINGS);
put('languages',ALL_SUBTYPE_PRESETS);
put('translation',load('translationLanguages').TRANSLATION_LANGUAGES);
put('dictionary',{ckb:dict.KURDISH_SORANI_WORDS,en:dict.ENGLISH_COMMON_WORDS,ar:dict.ARABIC_COMMON_WORDS,fa:dict.PERSIAN_COMMON_WORDS,tr:dict.TURKISH_COMMON_WORDS,next:{ckb:dict.KURDISH_NEXT_WORDS,en:dict.ENGLISH_NEXT_WORDS}});
fs.copyFileSync(path.join(root,'src/data/generated/richData.json'),path.join(out,'rich.json'));
for(const opt of CHARACTER_LAYOUT_OPTIONS){
 const preset=ALL_SUBTYPE_PRESETS.find(x=>x.characterLayoutId===opt.id)||ALL_SUBTYPE_PRESETS.find(x=>x.dir===opt.direction)||ALL_SUBTYPE_PRESETS[0];
 const lang={...preset,characterLayoutId:opt.id,dir:opt.direction};
 const settings={...DEFAULT_SETTINGS,numberRowMode:'never',customLayouts:{},showBottomKeys:true,showGlobeKey:true,showEmojiKey:true,showCommaKey:true};
 // Extract character-only rows using the original resolver, preserving exact output and popups.
 const get=(shift)=>resolveLayoutRows(lang,'characters',shift,'hira',settings).rows.map(row=>row.filter(k=>k.type==='char'||k.type==='comma'||k.type==='period'||k.type==='zwnj').map(k=>({label:k.primary,value:k.output??k.primary,alts:(k.alts||[]).map(a=>typeof a==='string'?a:a.value),width:k.width||1}))).filter(row=>row.length && !(row.length<=2 && row.every(k=>[",","،","."].includes(k.value))));
 put('layouts/'+opt.id,{id:opt.id,off:get('off'),shift:get('caps'),dir:opt.direction});
}
if(original)Module._extensions['.ts']=original;else delete Module._extensions['.ts'];
console.log('Native assets generated:',ALL_THEMES.length,'themes,',CHARACTER_LAYOUT_OPTIONS.length,'layouts');
