#!/usr/bin/env python3
"""Check resolved Maven coordinates against OSV; fail closed on errors/advisories."""
import json, sys, urllib.request, time
from pathlib import Path

def check(path):
    packages = sorted(set(tuple(line.split('\t')) for line in Path(path).read_text().splitlines() if line.strip()))
    if not packages: raise ValueError('Empty dependency inventory')
    findings=[]
    for i in range(0,len(packages),100):
        batch=packages[i:i+100]
        queries=[{'package':{'ecosystem':'Maven','name':name},'version':version} for name,version in batch]
        req=urllib.request.Request('https://api.osv.dev/v1/querybatch',data=json.dumps({'queries':queries}).encode(),headers={'Content-Type':'application/json'})
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req,timeout=45) as response: result=json.load(response)['results']
                break
            except Exception:
                if attempt==2: raise
                time.sleep(2**attempt)
        if len(result)!=len(batch): raise ValueError('Incomplete OSV response')
        for (name,version), item in zip(batch,result):
            if item.get('next_page_token'): raise ValueError('Incomplete paginated OSV response')
            for vuln in item.get('vulns',[]): findings.append((name,version,vuln['id']))
    print(f'OSV checked {len(packages)} resolved Maven coordinates')
    for item in findings: print('Known advisory:',*item)
    return 1 if findings else 0
if __name__=='__main__': sys.exit(check(sys.argv[1]))
