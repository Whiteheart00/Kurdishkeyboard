#!/usr/bin/env python3
"""Report only forbidden type names, referencing classes and library candidates; no APK/keys/log dumps."""
import argparse
import io
import re
import subprocess
import tempfile
import zipfile
from pathlib import Path

TYPE = re.compile(rb'L(?:android/webkit|androidx/webkit|com/getcapacitor)/[A-Za-z0-9_$/]+;')
DOT = b'android.webkit.WebView'
CLASS = re.compile(r"Class descriptor\s*:\s*'([^']+)'")
SAFE_NAME = re.compile(r'[A-Za-z0-9_.$/;\-]+\Z')

def descriptors(data):
    out = set(TYPE.findall(data))
    if DOT in data:
        out.add(DOT)
    return out

def show(data):
    return ', '.join(v.decode('ascii') for v in sorted(data))

def library_candidates(cache, needles):
    # Only resolved/downloaded modules; candidates may have been removed by R8.
    for archive in sorted(cache.glob('*/*/*/*/*')):
        if archive.suffix not in ('.jar', '.aar') or not archive.is_file():
            continue
        parts = archive.relative_to(cache).parts
        module = ':'.join(parts[:3])
        if not SAFE_NAME.fullmatch('/'.join(parts[:3])):
            continue
        hits = set()
        def scan(jar):
            for item in jar.namelist():
                if item.endswith('.class') and SAFE_NAME.fullmatch(item):
                    data = jar.read(item)
                    found = {n for n in needles if n.rstrip(b';').removeprefix(b'L') in data}
                    if found:
                        hits.add((item, show(found)))
        try:
            with zipfile.ZipFile(archive) as z:
                if archive.suffix == '.jar':
                    scan(z)
                else:
                    for entry in z.namelist():
                        if entry == 'classes.jar' or (entry.startswith('libs/') and entry.endswith('.jar')):
                            with zipfile.ZipFile(io.BytesIO(z.read(entry))) as jar:
                                scan(jar)
        except (OSError, zipfile.BadZipFile, RuntimeError):
            continue
        for item, names in sorted(hits)[:80]:
            print(f'LIBRARY CANDIDATE {module} {item}: {names}')
        if len(hits)>80:
            print(f'Additional candidate classes in {module}: {len(hits)-80}')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('apk', type=Path)
    p.add_argument('--dexdump', type=Path, required=True)
    p.add_argument('--mapping', type=Path)
    p.add_argument('--cache', type=Path)
    a = p.parse_args()
    reverse = {}
    if a.mapping and a.mapping.is_file():
        for line in a.mapping.read_text(errors='replace').splitlines():
            m = re.fullmatch(r'([\w.$]+) -> ([\w.$]+):', line)
            if m:
                reverse['L'+m[2].replace('.','/')+';'] = m[1]
    all_types = set()
    with zipfile.ZipFile(a.apk) as z, tempfile.TemporaryDirectory() as tmp:
        for name in z.namelist():
            if not re.fullmatch(r'classes\d*\.dex',name):
                continue
            data = z.read(name)
            found = descriptors(data)
            if not found:
                continue
            all_types.update(found)
            print(f'DEX {name}: {show(found)}')
            path = Path(tmp)/name
            path.write_bytes(data)
            current = None
            hits = set()
            # Disassemble locally, but never print or upload raw disassembly.
            with subprocess.Popen([str(a.dexdump), '-d', str(path)], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
                for raw in proc.stdout:
                    line = raw.decode('utf-8', errors='replace')
                    m = CLASS.search(line)
                    if m:
                        current = m[1] if SAFE_NAME.fullmatch(m[1]) else None
                    if current:
                        matches = descriptors(raw)
                        # Also match the dotted notation emitted for some instructions.
                        for n in found:
                            dotted = n.decode('ascii').removeprefix('L').removesuffix(';').replace('/','.')
                            if dotted in line:
                                matches.add(n)
                        if matches:
                            hits.add((current,show(matches)))
                code = proc.wait()
            if code:
                print(f'dexdump exited {code} for {name}')
            for cls, types in sorted(hits):
                print(f'REFERENCING CLASS {cls} ({reverse.get(cls, cls)}): {types}')
            if not hits:
                print('No referencing class located by dexdump; DEX type evidence above still applies.')
    if all_types and a.cache and a.cache.is_dir():
        library_candidates(a.cache, all_types)
    if not all_types:
        print('No forbidden descriptors located by diagnostic scanner.')

if __name__ == '__main__':
    main()
