# Clipboard performance and original UI review

Base: compile_fix/project.zip (includes MainActivity ScrollView cast fix). Compared original project.zip's src/components/keyboard/KeyboardPanels.tsx (ClipboardPanel), KeyboardView.tsx and App.tsx with the current Java clipboard and editor paths.

## Findings and changes
- NativeImeClipboardPanel previously created every card in an eager ScrollView / LinearLayout, including up to 100 history entries by default. Changed to a native ListView with on-demand rows; one or two columns, RTL, stable pinned-first sorting, original card minimum heights (70/88dp), row/column gap, status pills, swipe and long-press actions are retained. Scroll position is restored on panel updates. Card padding matches the original 12px design scale. The ListView adapter does not reuse a different row's gesture closures.
- Select/deselect, pin, delete, history changes and save-button availability now refresh only the attached clipboard surface, instead of re-creating the entire keyboard. Fallback to full render for editor transitions or detached surfaces; keep the clipboard editing field alive when external history changes.
- Clipboard card and suggestion previews are capped at 512 UTF-16 code units plus ellipsis, without splitting surrogate pairs. The full item remains stored and is still passed to paste, long-press details, editing and translation; no change to the input commit operation itself.
- Editor tail update now takes only the necessary 240-character suffix without concatenating an entire pasted document. Unicode surrogate pairs are protected at the truncation boundary.
- Swipe animation updates translation on every move, but rebuilds the label/icon and colors only when direction or threshold state changes. Cancel pending long-press callbacks when a card detaches.
- Preserve already-pinned items when adding new clipboard entries even beyond the existing history cap. Do not change the original effective cap (`max(100, configured limit)`) for ordinary items or enable any automatic expiry. This is intentional to avoid unexpectedly losing history; the original settings screen offers 10/20/40 even though the original React save path uses a minimum of 100.
- Preserve the original context-menu behavior: pin/unpin keeps the menu open, delete closes it. Native source only; no new external dependency. No web, workflow, package ID or signing changes.

## Checks actually executed
- Java compiler syntax parse: 51 Android Java source files (not Android type checking).
- Three pure Java test programs compiled and executed: ImeClipboardTextTest, ImeLargeTextTest, ImeOperationGateTest.
- Seven JavaScript regression tests passed (keyboard-stability.test.mjs).
- All 469 bundled vector path inputs passed parser checks.
- Native source audit passed (58 files).
- ZIP file integrity checked; only intended Java files, new Java regression test, and this report differ from the base.

## Remaining verification
No Android SDK, emulator or actual APK/runtime available in this environment. Full Gradle build, APK DEX audit, scrolling/touch dispatch, actual UI parity, long-text paste into third-party apps, and latency measurements need the existing CI and device. JSON history serialization and shared-preference updates still run synchronously (disk write uses apply); they could contribute to lag with very large histories. No risky asynchronous persistence change was made. Context-menu full text still uses a TextView and may be expensive for very large items; it preserves original full-text behavior. Exact pixel parity and a specific speed improvement cannot be claimed.
