# Stability V3 — native voice and resilience

Based on cold-start-fix/project.zip (paired with Manga Translator 1.3.34).
Upload this archive as project.zip to the existing ZIP-based GitHub workflow. No workflow, signing configuration, Vercel credentials, model names, or Manga source changes are required for this update.

- English and Arabic in the Android IME use the OS SpeechRecognizer (en-US/ar-IQ). Runtime microphone permission, package visibility query, one session at a time, main-thread calls, cancellation, and timeout are included. The OS speech provider may use network services. Browser speech remains available outside the native IME. Kurdish retains the separate Manga Vekol IPC service.
- Vekol uses randomized positive request IDs and one automatic rebind if disconnected before recording, never resending recorded audio. State transitions and elapsed times appear in native activity logs. Existing model-ready handshake remains. A device test is required to establish cold-start operation without Manga overlay Start.
- Hidden WebView is released after 45 seconds; renderer startup priority is retained until ready, recovery retries reset after cooldown, native fallback supports Sorani and Latin, capitals, hide and retry. Recovery cannot prevent Android killing the whole app process or renderer.
- Resource samples report current Java heap, app-process PSS, system available memory, OS low-memory flag, and process CPU-time deltas at ready/recovery/trim. These are not separate renderer or system-wide CPU measurements. Logs omit dictated text.
- AI pool respects active cooldowns, quarantines invalid keys for an hour per warm instance, uses up to five attempts, 6.5-second per-attempt abort and 15-second total attempt budget. Provider SDK/network may exceed these best-effort bounds. Model IDs unchanged. Rewrite checks reject empty and structurally unsuitable responses including non-shortening or non-expanding text (for nontrivial inputs); native keyboard requests complete validated JSON rather than partial rewrite text. Translation streaming remains. Structural checks do not certify semantic accuracy. Offline fallback remains and is checked on the main rewrite flow.
- Settings-only versioned native SharedPreferences mirror (credential-protected, not clipboard or editor text), alongside existing localStorage/IndexedDB. Local primary remains first, native recovery second, local recovery third. Native writes use apply, not a synchronous durability guarantee. Existing backups/import remain.

## Verification
- Existing and added Node tests: 7 passed (pointer sessions, Unicode, storage, AI structural output checks).
- Existing pure Java ImeOperationGate test: 80,000 concurrent admission attempts passed.
- Java parser (7 sources) and TypeScript transpile syntax checks (7 files) passed, setup script node --check passed.
- No Android SDK, physical device, dependency install, full TS typecheck, Vercel deploy, or actual AI API testing in this environment. This is a source update, not a verified APK. Check Android permission, native speech provider, Kurdish cold start, renderer recovery, settings restore, and all AI modes on device.
