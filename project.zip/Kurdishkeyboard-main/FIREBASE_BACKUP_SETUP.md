# Firebase encrypted cloud backup (integration preview)

Base: the supplied Google Drive backup project, retaining manual encrypted backups, Android Auto Backup, keyboard UI, signing configuration, and offline emoji preparation.

## Setup
1. Confirm Google Authentication is enabled. The supplied `google-services.json` has matching package name, APK SHA-1 and Android/web OAuth clients. It is staged under `native-android/app/` and copied by the existing setup script. The configuration is app-side identification, not a service account credential.
2. In Firebase Console, create the default Cloud Firestore database in Standard/production mode if it does not yet exist. Open Rules, review `firestore.rules`, and publish its owner-only `keyboardBackups/{uid}` match. If the project has other applications/rules, merge the specific match carefully instead of replacing them wholesale. No public/test rules. Consider quotas and billing controls before wider distribution.
3. Replace repository project.zip. Existing Facebook font build workflow is unchanged; keep existing signing secrets and existing font authorization configuration. R8 shrinking is enabled for the Android debug variant to remove unused dependencies. The original strict APK DEX audit is unchanged; if a Firebase/Credential Manager transitive dependency still contains forbidden web references, CI must fail rather than publish it.
4. Run CI, inspect Build and APK audit. Install only a successful audited APK. Test with synthetic data first. Settings > More settings > Cloud / Google Drive > Firebase.
5. Connect Google, choose whether pinned clipboard is included (off by default), choose whether daily backup is enabled (off by default), select Backup now, and enter a unique 12+ character backup passphrase. Do not use the Google account password. Store it safely; it is necessary to decrypt data on a replacement device. Never share it with the developer. On another device, sign in with the same Google account and Restore first.

## Behavior
- Account-owned encrypted snapshot in `/keyboardBackups/{uid}`; one current backup, no file history. AES-256-GCM and PBKDF2-HMAC-SHA256 (600,000 rounds), same versioned crypto container as prior manual backup. Passphrase for scheduled backup encrypted with a device-bound Android Keystore key. Firebase Auth manages tokens. Firestore disk persistence disabled. Rules require an authenticated matching UID, versioned encrypted blob, revision and server timestamp; no listing of all users. This does not replace Firebase security rules testing, and project administrators can see metadata and encrypted blobs.
- Native Android JobScheduler periodic 24h network/battery constrained backup after explicit first backup and opt-in. Android determines actual timing; offline devices retain local data. No upload of unchanged payload (hash comparison), no uploading on key presses. Firebase account is not required to use the keyboard.
- Pinned clipboard opt-in is explicit, and includes later pinned entries until disabled. Obvious secret filtering is not reliable for arbitrary passwords; keep sensitive data unpinned. Entire clipboard history, learned words and shortcuts are not included in the automatic cloud feature. Prior encrypted manual backup remains available. No diagnostics, auth tokens, or AI server settings are included by the existing backup filter. Size limited to 750,000 encrypted bytes; oversized data remains local and is not uploaded.
- Optimistic revision transaction prevents a fresh device from silently replacing an existing backup. Restore requires confirmation, merges clipboard without deleting existing entries, and disables scheduled backup until explicitly enabled again. Sign-out stops scheduling and clears device association; cloud data remains until user deletes it. Cloud delete removes the cloud snapshot only.
- Auto Backup rules from previous version remain restricted to a safe preference file. Firebase is not Google Drive storage. Device-local passphrase encryption is not automatically transferable to other devices.

## Validation / remaining blockers
- APK V1 certificate SHA-1 and SHA-256 extracted with keytool; SHA-1 matches OAuth configuration.
- Java compiler parser (syntax only): 69 Java source/test files passed. No Android type checking performed.
- Existing Java crypto test: 10 checks passed, including wrong passphrase, tampering, Unicode and size limit.
- Keyboard-stability JS: 7 passed using Node's TypeScript stripping option.
- Native source and backup allowlist audit passed, 72 files; 3,058 Noto emoji assets checked. Facebook assets are generated during existing CI, not present in source ZIP.
- No Android SDK/Gradle in this environment; full dependency resolution, R8/DEX audit, actual APK, Google sign-in, live Firestore rules and cross-device restore are untested. No live Firebase writes were made. Firestore database creation is not confirmed. Full engine tests not run.
