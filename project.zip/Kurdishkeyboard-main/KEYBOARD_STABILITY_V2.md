# KurdiKeyboard — stability update (based on IPC-Stable)

Apply the ZIP to the **root of the IPC-Stable keyboard project**, preserving paths, including hidden `.github/`. This is a source patch, not an APK. If starting from the original Kurdishkeyboard-main archive, apply the earlier KurdiKeyboard-Changed-Files.zip first. No deletion is required. Manga Translator 1.3.33 IPC-Stable is still required for offline Kurdish voice. Vekol and ONNX remain exclusively in Manga; this update does not change the Manga app, model or signing configuration.

## Implemented

1. **Input:** main-looper FIFO with a bounded 256-operation admission gate; editor and renderer generations reject stale queued commands. On overflow, new operations are refused, diagnostics record a generic event, and the tail is resynchronized. Native typing updates React's tail at most once per animation frame, while key rows retain their existing memoization. No text is included in the new queue diagnostic.
2. **Memory:** load tool panels on demand; suppress optional flying-letter animations on low-RAM / <=128MB heap devices, leaving the setting intact. Release the hidden WebView under relevant memory trim signals, not on every ordinary hide. Avoid global WebView timer resume calls. These are mitigations, not measured memory savings.
3. **Recovery:** Native Kurdish/English basic typing, digits, space, delete, Enter and Retry while the WebView starts, crashes or fails its responsiveness check. 5s watchdog response deadline and 15s startup deadline; bounded automatic retries, then manual retry. Fallback is intentionally minimal and does not support all normal UI features. Recovery cannot handle a fully frozen Android main looper or a killed app process until Android restarts it.
6. **Touch:** one gesture owner and independent secondary tap sessions; reset on lost capture, cancellation, hide, blur and language/layout/panel change. Secondary taps do not start shared long-press/swipe timers. Backspace repeats use current handlers; final release does not add an extra delete. This is not independent simultaneous multi-finger long presses.
7. **Compatibility:** route Undo/Redo to the Android editor's own context actions; support depends on the host app. Enter attempts advertised editor action then multiline newline/key fallback. Selected-text deletion, code-point-aware backspace, verified suffix edits, and guarded whole-field replacement. Whole-field edits are rejected if a complete extract or selection cannot be verified; no attempt to silently overwrite only a partial field. No guarantee of universal host-editor support. Unicode code-point handling is not full grapheme cluster handling.
8. **Storage:** retain existing localStorage keys as primary, add versioned last-known-good backups, keep IndexedDB fallback, prevent startup default writes before hydration, retry DB open failures, guard delayed mirror writes and listen for same-origin storage events. Export settings with version 1 envelope, import both new and old settings JSON, and reject >16MB backup files / unknown versions. Automatic backup covers settings and clipboard; manual export is settings-only, as before. This does not guarantee transactional synchronization across processes or recovery from clearing all app data. Versioned exports should be imported using this or a newer compatible build.
9. **Voice:** require matching IPC request ID from the existing Manga 1.3.33 IPC-Stable service. Improve readiness/error messages, distinguish invalid readiness responses, handle cancellation while starting, guard against duplicate transcribing notice, handle capture allocation failure, and cancel when editor selection moves. Existing timeout/PCM limits remain. Older services not echoing IDs will time out rather than accepting ambiguous responses. Actual recording and inference are not tested here.
10. **Tests:** GitHub Actions uses Node 22 and runs JS and Java unit checks before APK build. No signing or release logic changed.

## Local verification (no Android SDK / project npm dependencies / device available)

- Node test: 5 passing; 20,000 pointer sessions, 10,000 Unicode suffix cases, cancellation, local recovery and versioned import/export.
- Java test: 80,000 concurrent queue admission attempts; capacity and stale editor/renderer checks.
- Java syntax parse, TypeScript/TSX syntax transpile, setup script syntax, workflow YAML parse passed. These are not full Android/TypeScript builds.
- Run JS: `node --experimental-strip-types --test tests/keyboard-stability.test.mjs` (Node 22.13+).
- Run Java: `mkdir -p /tmp/ime-test && javac -d /tmp/ime-test android-ime/ImeOperationGate.java tests/ImeOperationGateTest.java && java -cp /tmp/ime-test io.kurdikebord.app.ImeOperationGateTest`.

## Required device validation before release

- Install both IPC-Stable Manga and the rebuilt keyboard; download the model in Manga; grant microphone permission. Test start, stop, cancel, model missing, service disconnection, cursor switch, and app switch during inference.
- Compare launch latency, dropped keys, peak RAM, CPU and responsiveness on a low-RAM and standard phone. Android Studio / adb performance profiling and instrumentation are still needed. No measured improvement claimed.
- Test Telegram, WhatsApp, Chrome, native EditText, password fields, numeric fields, RTL selection, editor action buttons, undo/redo and very long fields. Verify clipboard, themes, custom layouts, gestures, AI, live translation, emoji, resize and settings backup.
- Force renderer kill/low-memory conditions on a test device and verify Native fallback and Retry. Verify that input is not sent to the previous editor. Unit tests do not replace end-to-end or load tests on Android.
