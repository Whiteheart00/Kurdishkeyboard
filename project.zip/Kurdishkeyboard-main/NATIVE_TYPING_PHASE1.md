# Native typing — phase 1 (hybrid)

Based on Clipboard V3. No change to package ID, signing configuration, Vercel API, backup format or Manga/Vekol protocol. The existing web keyboard, tools and React settings app remain in the archive. This is not a full native port or a measured performance release.

## How it works
- Default typing for the standard Sorani (`kurdi_qvfgh`), English (`qwerty`) and Arabic (`arabic1`) layouts uses Android Views and InputConnection directly. A supported language must be enabled in the app settings to be available on the native globe key. Unsupported/custom active layouts open the original keyboard automatically (except numeric fields). The full keyboard remains available with the `⋯` button. The native bar above the full keyboard returns to native typing and releases the IME WebView. Closing the IME also releases it. MainActivity still uses WebView.
- Native mode includes number/symbol rows, English shift/caps, a limited set of alternate characters, cursor movement, backspace repeat, enter/action handling, paste, undo/redo (where supported by the editor), settings, clipboard viewer and existing voice engines. Native clipboard views the first 40 durable entries; edits, pinning, clearing, complete history and other tools are available in the original UI. Clipboard capture uses a bounded worker, respects disabled history/sensitive clips/password fields, and will not create a new native snapshot before legacy history migration. Existing native backup is used; it is not replaced with an independent database.
- Native typing reads the settings mirror for basic light/dark mode, height, font size, sound/haptic enablement, enabled languages and number row. The original custom themes, font packs, all layouts and gestures, suggestions, emoji, AI, translation and other advanced functionality are retained in the original web mode. They are NOT all replicated natively. Language switching in native mode is session-local; advanced mode uses the saved web settings.
- Existing Vekol IPC and native speech recognizer are reused. No model has moved to the keyboard. Long press on microphone cancels. No new background microphone behavior.
- Resource samples distinguish `native_shown`, `advanced_shown`, `native_typing` and `web_ready`; no typed text is included in these diagnostic samples. A WebView crash in advanced mode returns to native typing, without automatic renderer restart loops.

## Verification
Local checks: Java syntax parse, Node syntax check of Android setup script, 9 existing JS unit tests, existing Java admission gate test, and new pure Java native layout test (10,000 independent layout loads). These are not Android UI, compile, benchmark or instrumentation tests. Run the new test with:

```sh
mkdir -p /tmp/ime-layout-test
javac -d /tmp/ime-layout-test android-ime/NativeTypingLayouts.java tests/NativeTypingLayoutsTest.java
java -cp /tmp/ime-layout-test io.kurdikebord.app.NativeTypingLayoutsTest
```

APK build / Android 16 test pending. Verify native mode cold open, ordinary typing and numeric/password fields, two-finger typing, deletion hold, language switching, clipboard migration and switching repeatedly between native and original UI. Verify both voice engines with consented mic permission, compare native/advanced `resource_sample` events under the same editor and workload. Do not assume RAM savings until measured. Existing clipboard app/WebView concurrency limitation remains.
