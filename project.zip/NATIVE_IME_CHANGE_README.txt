NATIVE ANDROID IME - DEFAULT ENABLED

Change: ImeStateStore.enabled(Context) now returns true, selecting the existing NativeImeView from KurdiKeyboardImeService.onCreateInputView().

Native keyboard components already present: NativeImeView.java, NativeImeEngine.java, NativeImeLayout.java, NativeImeKeyGrid.java, NativeImePanels.java, NativeImeSettings.java.

Scope: Native Android keyboard input view is selected by default. The React/TypeScript web application and WebView implementation remain in this project for non-IME screens and legacy code. This is NOT a complete removal of WebView/React from the application.

The app has not been built or tested on an Android device. Validate typing, spacebar cursor drag, symbol insertion, custom layouts, settings, emoji, clipboard and accessibility.
