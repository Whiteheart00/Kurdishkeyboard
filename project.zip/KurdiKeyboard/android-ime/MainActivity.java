package io.kurdikebord.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Native Android-only settings, theme picker, keyboard setup, and custom layout editor.
 *  Does not create a WebView, bridge, React screen, or JavaScript runtime.
 */
public final class MainActivity extends Activity {
    static final String EXTRA_EMOJI_SETTINGS = "io.kurdikebord.app.OPEN_EMOJI_SETTINGS";
    static final String DIAG_PREFS_NAME = "kurdikebord_diag_prefs";
    static final String DIAG_LOGS_KEY = "native_events_json";
    private static final int BG = 0xff0e1726, CARD = 0xff1c2b42, KEY = 0xff263852;
    private static final int TEXT = 0xfff4f7fb, MUTED = 0xffb4c3d6, ACCENT = 0xff38bdf8;
    private LinearLayout content;
    private NativeImeEngine engine;
    private JSONObject defaults = new JSONObject();
    private JSONObject prefs = new JSONObject();
    private JSONArray subtypes = new JSONArray();
    private JSONArray themes = new JSONArray();
    private String section = "home";

    static synchronized void recordNativeEvent(Context ctx, String category, String severity,
            String title, String description, String component, String operation, String status, Throwable error) {
        if (ctx == null) return;
        try {
            android.content.SharedPreferences p = ctx.getApplicationContext().getSharedPreferences(DIAG_PREFS_NAME, MODE_PRIVATE);
            JSONArray old = new JSONArray(p.getString(DIAG_LOGS_KEY, "[]"));
            JSONArray updated = new JSONArray();
            JSONObject item = new JSONObject();
            item.put("timestamp", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(new Date()));
            item.put("category", category); item.put("severity", severity); item.put("title", title);
            item.put("description", description); item.put("component", component);
            item.put("operation", operation); item.put("status", status);
            if (error != null) item.put("errorMessage", String.valueOf(error));
            updated.put(item);
            for (int i=0; i<Math.min(79, old.length()); ++i) updated.put(old.opt(i));
            p.edit().putString(DIAG_LOGS_KEY, updated.toString()).apply();
        } catch(Exception ignored) { }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        try {
            engine = new NativeImeEngine(this);
            JSONObject core = engine.object("core", null);
            defaults = NativeImeData.obj(NativeImeData.obj(core, "defaults"), "settings");
            subtypes = NativeImeData.arr(core, "subtypes");
            themes = NativeImeData.arr(core, "themes");
        } catch(IOException | RuntimeException ex) {
            new AlertDialog.Builder(this).setTitle("Keyboard data unavailable")
                    .setMessage("Native resources are missing. Rebuild native assets. " + ex.getMessage())
                    .setPositiveButton("OK", (a,b) -> finish()).show();
            return;
        }
        reload();
        String target = getIntent().getBooleanExtra(EXTRA_EMOJI_SETTINGS, false) ? "emoji" : "home";
        showSection(target);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (intent != null && intent.getBooleanExtra(EXTRA_EMOJI_SETTINGS, false)) showSection("emoji");
    }
    @Override public void onBackPressed() {
        if ("home".equals(section)) super.onBackPressed(); else showSection("home");
    }
    @Override protected void onDestroy() {
        if (engine != null) engine.close();
        super.onDestroy();
    }
    private int dp(float value) { return (int)(getResources().getDisplayMetrics().density * value + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable draw = new GradientDrawable(); draw.setColor(color); draw.setCornerRadius(dp(radius)); return draw;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL); if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams margin(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin=dp(bottom); return p;
    }
    private LinearLayout card() {
        LinearLayout l=column(); l.setBackground(bg(CARD,14)); l.setPadding(dp(14), dp(12), dp(14), dp(12));
        return l;
    }
    private Button button(String label, Runnable click) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(label); b.setTextSize(14);
        b.setTextColor(TEXT); b.setBackground(bg(KEY,10));
        b.setPadding(dp(9),0,dp(9),0); b.setMinHeight(dp(46));
        b.setOnClickListener(v -> click.run()); return b;
    }
    private void banner(String heading, String subtitle) {
        TextView title = text(heading, 23, TEXT, true);
        content.addView(title, margin(5));
        if(subtitle != null) content.addView(text(subtitle, 13, MUTED, false), margin(16));
    }
    private void reload() {
        JSONObject stored=ImeStateStore.effectiveSettings(this, ImeStateStore.read(this));
        prefs = engine.object("hydrate", stored);
    }
    private void apply(String name, Object value) {
        JSONObject patch = new JSONObject(); ImeStateStore.put(patch, name, value);
        JSONObject updated = ImeStateStore.updateSettings(this, patch, false);
        if (updated == null) { Toast.makeText(this,"Could not save",Toast.LENGTH_SHORT).show(); return; }
        NativeSettingsBackup.write(this, updated.toString());
        reload();
    }
    private void showSection(String target) {
        section=target; reload();
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        content=column(); content.setPadding(dp(16),dp(20),dp(16),dp(35));
        scroll.addView(content); setContentView(scroll);
        if(!"home".equals(target)) content.addView(button("‹  Back to settings",()->showSection("home")),margin(15));
        switch(target) {
            case "home": home(); break;
            case "layout": layoutEditor(); break;
            case "languages": languages(); break;
            case "themes": themes(); break;
            case "test": testKeyboard(); break;
            case "all": settingsList(null); break;
            default: settingsList(target); break;
        }
    }
    private void home() {
        banner("تەختەکلیلی کوردی", "Native Android keyboard • Java / Android Views");
        LinearLayout setup=card();
        setup.addView(text("Keyboard setup",18,TEXT,true),margin(7));
        setup.addView(button("1. Enable keyboard in Android settings", () -> {
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        }),margin(7));
        setup.addView(button("2. Select default keyboard", () -> {
            InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null) imm.showInputMethodPicker();
        }),margin(7));
        setup.addView(button("3. Test keyboard",()->showSection("test")));
        content.addView(setup, margin(16));
        String[][] groups={
            {"keyboard","Keyboard","Height, key size, bottom row and number row"},
            {"typing","Typing","Autocorrect, suggestions and dictionary"},
            {"smartbar","Smartbar","Toolbar, suggestions and utility shortcuts"},
            {"feedback","Sound & vibration","Haptics and keypress sounds"},
            {"gestures","Gestures","Swipe, long press and Spacebar cursor movement"},
            {"layout","Custom layout editor","Letters and symbols inside Characters, Symbols 1 and 2"},
            {"languages","Languages","Active language and keyboard layouts"},
            {"emoji","Emoji & media","Emoji categories, history and font size"},
            {"clipboard","Clipboard","Clipboard history and suggestions"},
            {"themes","Themes","Built-in native theme selection"},
            {"appearance","Appearance","Key shape, text and keyboard measurements"},
            {"other","Other settings","Backup-compatible settings and advanced options"},
            {"all","All settings","Every key from the native settings defaults"}
        };
        for(String[] item: groups) {
            LinearLayout l=card(); l.addView(text(item[1]+"    ›",17,TEXT,true));
            l.addView(text(item[2],12,MUTED,false)); l.setOnClickListener(v->showSection(item[0]));
            content.addView(l,margin(8));
        }
    }
    private String[] keys(String group) {
        switch(group) {
            case "keyboard": return new String[]{"keyboardHeightPx","keyboardWidthPercent","keyboardBottomOffsetPx","keyboardHorizontalOffsetPx","numberRowMode","numberStyle","showBottomKeys","bottomRowPreset","spacebarText","oneHandedMode","activeLanguage"};
            case "typing": return new String[]{"autoCapitalization","autoCorrectEnabled","wordSuggestionsEnabled","autoSpacePunctuation","doubleSpacePeriod","personalDictionaryEnabled","nextWordSuggestionsEnabled","smartReplyEnabled","capitalizationBehavior","longPressDelayMs"};
            case "smartbar": return new String[]{"showTopToolbar","showQuickSettings","toolsOrder","smartReplyEnabled","clipboardSuggestLatest","showPredictionBar"};
            case "feedback": return new String[]{"soundEnabled","vibrationEnabled","vibrationDurationMs","soundVolume","keyPressPopupEnabled","flyingLettersEnabled","flyingLettersSizeMultiplier"};
            case "gestures": return new String[]{"swipeUpAction","swipeDownAction","swipeLeftAction","swipeRightAction","swipeDistanceThreshold","swipeVelocityThreshold","spaceBarSwipeLeftAction","spaceBarSwipeRightAction","spaceBarSwipeUpAction","spaceBarLongPressAction","deleteKeySwipeLeftAction","deleteKeyLongPressAction"};
            case "emoji": return new String[]{"emojiHistoryEnabled","emojiFontSizePx","emojiInitialTab","emojiCategoryOrder","emojiStyle","emojiSuggestionUpdateHistory","emojiLastUsedCategory"};
            case "clipboard": return new String[]{"clipboardEnabled","clipboardHistoryEnabled","clipboardSuggestLatest","clipboardGridColumns","clipboardSuggestLimit60s"};
            case "appearance": return new String[]{"keyShapeStyle","activeThemeId","keyboardHeightPx","keyboardWidthPercent","keyboardBottomOffsetPx","keyboardHorizontalOffsetPx","keyFontSize","showNumberRow"};
            default: return new String[]{};
        }
    }
    private String label(String key) {
        return key.replaceAll("([a-z])([A-Z])", "$1 $2").replace('_',' ');
    }
    private void settingsList(String filter) {
        boolean all = filter==null;
        banner(all?"All native settings":label(filter)+" settings", "Saved in Android SharedPreferences; changes update the native IME.");
        EditText search=new EditText(this); search.setSingleLine(); search.setTextColor(TEXT);
        search.setHintTextColor(MUTED); search.setHint("Search setting name");
        search.setBackground(bg(CARD,12)); search.setPadding(dp(12),dp(8),dp(12),dp(8));
        content.addView(search,margin(12));
        LinearLayout results=column(); content.addView(results);
        Runnable render=()->{
            results.removeAllViews();
            ArrayList<String> names=new ArrayList<>();
            if(all || "other".equals(filter)) {
                Iterator<String> iter=defaults.keys(); while(iter.hasNext()) names.add(iter.next());
                java.util.Collections.sort(names);
            } else {
                names.addAll(Arrays.asList(keys(filter)));
                // Unlike a hardcoded list, native options remain searchable under All settings.
            }
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            for(String key:names) {
                if(!defaults.has(key) || !label(key).toLowerCase(Locale.ROOT).contains(q)) continue;
                Object value=prefs.opt(key); settingEntry(results,key,value);
            }
        };
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){render.run();}
            public void afterTextChanged(Editable e){} });
        render.run();
    }
    private void settingEntry(LinearLayout out, String key, Object value) {
        LinearLayout wrap=card();
        LinearLayout head=row();
        LinearLayout left=column(); left.addView(text(label(key),15,TEXT,true));
        left.addView(text(summary(value),12,MUTED,false));
        head.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        if(value instanceof Boolean) {
            Switch toggle = new Switch(this); toggle.setChecked((Boolean)value);
            toggle.setOnCheckedChangeListener((btn,on)->apply(key,on)); head.addView(toggle);
        } else {
            TextView edit=text("Edit ›",12,ACCENT,true); head.addView(edit);
            wrap.setOnClickListener(v->editSetting(key,value));
        }
        wrap.addView(head); out.addView(wrap,margin(8));
    }
    private String summary(Object value) {
        if(value==null || value==JSONObject.NULL) return "Not set";
        if(value instanceof JSONArray) return "Array ("+((JSONArray)value).length()+" entries)";
        if(value instanceof JSONObject) return "Object ("+((JSONObject)value).length()+" entries)";
        String s=String.valueOf(value); return s.length()>90?s.substring(0,87)+"...":s;
    }
    private void editSetting(String key,Object previous) {
        if("activeLanguage".equals(key)) { showSection("languages"); return; }
        if("activeThemeId".equals(key)) { showSection("themes"); return; }
        if("customLayouts".equals(key)) { showSection("layout"); return; }
        if(previous==null) previous=defaults.opt(key);
        final Object old=previous;
        final EditText input=new EditText(this); input.setTextColor(Color.BLACK); input.setText(String.valueOf(old));
        if(old instanceof Number) input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
        if(old instanceof JSONArray || old instanceof JSONObject) { input.setMinLines(4); input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); }
        new AlertDialog.Builder(this).setTitle(label(key)).setView(input)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(dialog,which)->{
                String raw=input.getText().toString();
                try {
                    Object typed;
                    if(old instanceof JSONArray || old instanceof JSONObject) {
                        typed=new JSONTokener(raw).nextValue();
                        if(old instanceof JSONArray && !(typed instanceof JSONArray) || old instanceof JSONObject && !(typed instanceof JSONObject)) throw new IllegalArgumentException("Wrong JSON type");
                    } else if(old instanceof Number) {
                        typed=old instanceof Integer || old instanceof Long ? Integer.parseInt(raw.trim()) : Double.parseDouble(raw.trim());
                    } else typed=raw;
                    apply(key,typed); showSection(section);
                } catch(Exception error) { Toast.makeText(this,"Invalid value: "+error.getMessage(), Toast.LENGTH_LONG).show(); }
            }).show();
    }
    private void languages() {
        banner("Languages", "Choose a language; native keyboard layout and suggestions update immediately.");
        JSONArray enabled=NativeImeData.arr(prefs,"enabledLanguages");
        for(int i=0;i<enabled.length();i++) {
            JSONObject lang=enabled.optJSONObject(i); if(lang==null)continue;
            String code=lang.optString("code");
            LinearLayout c=card();
            c.addView(text(lang.optString("nativeName",lang.optString("name",code))+(code.equals(prefs.optString("activeLanguage"))?" ✓":""),17,TEXT,true));
            c.addView(text(lang.optString("characterLayoutId"),12,MUTED,false));
            c.setOnClickListener(v->{apply("activeLanguage",code);showSection("languages");});
            content.addView(c,margin(8));
        }
        content.addView(button("Edit active language layout",()->showSection("layout")),margin(10));
    }
    private void themes() {
        banner("Native themes", "Themes are rendered by NativeImeAppearance (Android Views).");
        for(int i=0;i<themes.length();i++) {
            JSONObject theme=themes.optJSONObject(i); if(theme==null)continue;
            String id=theme.optString("id");
            if(id.isEmpty())continue;
            LinearLayout c=card(); c.addView(text(theme.optString("nameKu",theme.optString("name",id)) + (id.equals(prefs.optString("activeThemeId"))?" ✓":""),17,TEXT,true));
            c.addView(text(id,12,MUTED,false));
            c.setOnClickListener(v->{apply("activeThemeId",id);showSection("themes");});
            content.addView(c,margin(8));
        }
    }
    private void testKeyboard() {
        banner("Native keyboard test", "Tap the box and select KurdiKeyboard to test actual Android IME input.");
        EditText field=new EditText(this); field.setMinLines(5);field.setGravity(Gravity.TOP);
        field.setTextColor(TEXT);field.setHintTextColor(MUTED);field.setTextSize(18);
        field.setHint("لێرە بنووسە...  Type here...");
        field.setBackground(bg(CARD,12));field.setPadding(dp(16),dp(16),dp(16),dp(16));
        content.addView(field,new LinearLayout.LayoutParams(-1,dp(195)));
    }
    private final String[] palette = {
        "@","#","$","%","&","*","!","?","+","=","-","/","(",")","[","]","{","}",
        "،","؛","؟","£","€","¥","_","|","~","^","<",">","٪","×","÷","«","»","ـ", "ڕ","ڵ","ێ","ۆ","ژ","ڤ","چ","گ","ئ","ە"
    };
    private String currentLanguage;
    private String currentMode="characters";
    private int selectedRow=-1, selectedCol=-1;
    private String selectedSymbol;
    private JSONArray draft;
    private LinearLayout editorArea;

    private JSONObject activeLang() {
        JSONArray enabled=NativeImeData.arr(prefs,"enabledLanguages");
        JSONObject lang=NativeImeData.find(enabled,"code",currentLanguage);
        return lang==null?enabled.optJSONObject(0):lang;
    }
    private String layoutId() {
        JSONObject lang=activeLang();if(lang==null)return "kurdi_qvfgh";
        String name="characters".equals(currentMode)?"characterLayoutId": "symbols".equals(currentMode)?"symbolsLayoutId":"symbols2LayoutId";
        return lang.optString(name, "characters".equals(currentMode)?"kurdi_qvfgh":"sym_alt");
    }
    private String storageKey() {
        return "characters".equals(currentMode)?layoutId():currentMode+":"+layoutId();
    }
    private JSONArray cloned(JSONArray array) { try { return new JSONArray(array.toString()); }catch(Exception error){return new JSONArray();} }
    private void loadDraft() {
        selectedRow=selectedCol=-1; selectedSymbol=null;
        JSONArray saved=NativeImeData.obj(prefs,"customLayouts").optJSONArray(storageKey());
        if(saved!=null) { draft=cloned(saved); return; }
        JSONObject core=engine.object("core",null);
        JSONObject source=NativeImeData.obj(core,"editableRows");
        if(!"characters".equals(currentMode)) source=NativeImeData.obj(NativeImeData.obj(core,"editableSymbols"),currentMode);
        draft=cloned(NativeImeData.arr(source,layoutId()));
    }
    private void layoutEditor() {
        if(currentLanguage==null) currentLanguage=prefs.optString("activeLanguage","ckb");
        if(draft==null) loadDraft();
        banner("Custom layout editor", "100% Native • Tap two keys to swap, or choose a symbol then tap a key to replace.");
        LinearLayout l=card();
        l.addView(text("Language: "+currentLanguage+"     •     Layout: "+layoutId(),13,MUTED,true),margin(7));
        l.addView(button("Change language",()->chooseEditorLanguage()),margin(8));
        content.addView(l,margin(12));
        LinearLayout modes=row();
        for(String[] mode:new String[][]{{"characters","Characters"},{"symbols","Symbols 1"},{"symbols2","Symbols 2"}}) {
            Button b=button(mode[1],()->{currentMode=mode[0];loadDraft();showSection("layout");});
            if(currentMode.equals(mode[0]))b.setBackground(bg(0xff086c93,9));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(47),1);p.setMargins(dp(2),0,dp(2),0);modes.addView(b,p);
        }
        content.addView(modes,margin(12));
        editorArea=column();content.addView(editorArea,margin(10));
        drawEditorKeys();
        content.addView(text("Symbols and letters palette",15,TEXT,true),margin(8));
        for(int start=0;start<palette.length;start+=7) {
            LinearLayout line=row();
            for(int i=start;i<Math.min(start+7,palette.length);i++) {
                String value=palette[i];
                Button b=button(value,()->{selectedSymbol=value;selectedRow=selectedCol=-1;drawEditorKeys();});
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);p.setMargins(dp(1),dp(1),dp(1),dp(1));line.addView(b,p);
            }
            for(int i=Math.min(7,palette.length-start);i<7;i++)line.addView(new TextView(this),new LinearLayout.LayoutParams(0,dp(44),1));
            content.addView(line,margin(3));
        }
        content.addView(button("Enter custom key text",()->customSymbol()),margin(10));
        LinearLayout controls=row();
        Button save=button("✓  Save layout",()->saveLayout());
        Button reset=button("↺  Reset layout",()->resetLayout());
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(50),1);half.setMargins(0,0,dp(5),0);
        controls.addView(save,half);controls.addView(reset,new LinearLayout.LayoutParams(0,dp(50),1));
        content.addView(controls,margin(10));
        content.addView(text("Changes are stored in customLayouts and used directly by NativeImeLayout.",12,MUTED,false));
    }
    private void chooseEditorLanguage() {
        JSONArray enabled=NativeImeData.arr(prefs,"enabledLanguages");
        List<String> labels=new ArrayList<>(),codes=new ArrayList<>();
        for(int i=0;i<enabled.length();i++) {JSONObject item=enabled.optJSONObject(i); if(item!=null) {
            codes.add(item.optString("code")); labels.add(item.optString("nativeName", item.optString("code")));
        }}
        new AlertDialog.Builder(this).setTitle("Edit language")
            .setItems(labels.toArray(new String[0]),(dialog,index)->{currentLanguage=codes.get(index);loadDraft();showSection("layout");}).show();
    }
    private void drawEditorKeys() {
        editorArea.removeAllViews();
        editorArea.addView(text(selectedSymbol==null?"Select a key to move it":"Selected: "+selectedSymbol+" → tap a key",13,MUTED,false),margin(8));
        for(int r=0;r<draft.length();r++){
            JSONArray values=draft.optJSONArray(r);if(values==null)continue;
            LinearLayout line=row();
            for(int c=0;c<values.length();c++) {
                final int rr=r,cc=c;String name=values.optString(c,"·");
                Button key=button(name,()->tapKey(rr,cc));
                if(r==selectedRow && c==selectedCol)key.setBackground(bg(0xff087da4,8));
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(47),1);
                p.setMargins(dp(1),dp(2),dp(1),dp(2)); line.addView(key,p);
            }
            editorArea.addView(line,margin(5));
        }
    }
    private void tapKey(int row,int col) {
        JSONArray target=draft.optJSONArray(row); if(target==null)return;
        if(selectedSymbol!=null) {
            replace(target,col,selectedSymbol);selectedSymbol=null;selectedRow=selectedCol=-1;
        } else if(selectedRow<0) {selectedRow=row;selectedCol=col;}
        else if(selectedRow==row && selectedCol==col) {selectedRow=selectedCol=-1;}
        else {
            JSONArray other=draft.optJSONArray(selectedRow);
            if(other!=null) {String before=target.optString(col),swap=other.optString(selectedCol);
                replace(target,col,swap);replace(other,selectedCol,before);}
            selectedRow=selectedCol=-1;
        }
        drawEditorKeys();
    }
    private void replace(JSONArray array,int index,String value) {
        try {array.put(index,value);}catch(Exception ignored) { }
    }
    private void customSymbol() {
        EditText input=new EditText(this);input.setSingleLine();input.setHint("Example: @ or ڕ");
        new AlertDialog.Builder(this).setTitle("Insert character or symbol").setView(input)
            .setNegativeButton("Cancel",null).setPositiveButton("Select",(d,n)->{
                String value=input.getText().toString();
                if(!value.isEmpty() && value.codePointCount(0,value.length())<=6) {selectedSymbol=value;drawEditorKeys();}
                else Toast.makeText(this,"Enter 1–6 characters",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void saveLayout() {
        JSONObject custom=NativeImeData.copy(NativeImeData.obj(prefs,"customLayouts"));
        ImeStateStore.put(custom,storageKey(),cloned(draft));
        JSONObject patch=ImeStateStore.json("customLayouts",custom,"activeLanguage",currentLanguage);
        JSONObject result=ImeStateStore.updateSettings(this,patch,false);
        if(result!=null) {NativeSettingsBackup.write(this,result.toString());Toast.makeText(this,"Layout saved",Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this,"Could not save",Toast.LENGTH_SHORT).show();
    }
    private void resetLayout() {
        new AlertDialog.Builder(this).setTitle("Reset this layout?").setMessage("Only "+storageKey()+" will be reset.")
            .setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,n)->{
                JSONObject custom=NativeImeData.copy(NativeImeData.obj(prefs,"customLayouts"));custom.remove(storageKey());
                apply("customLayouts",custom);loadDraft();showSection("layout");
            }).show();
    }
}
