package io.kurdikebord.app;

import static io.kurdikebord.app.NativeImeData.*;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Java implementation of the keyboard algorithms, backed by build-time JSON assets. */
final class NativeImeEngine implements AutoCloseable {
    private final NativeImeData data;
    private final JSONObject core;
    private final NativeImeSettings settings;
    private final NativeImeMedia media;
    private final NativeImePrediction predictions;
    private final NativeImeRewrite rewrite;
    private NativeImeLayout layouts;

    NativeImeEngine(Context context) throws IOException {
        data = new NativeImeData(context);
        core = data.load("core");
        settings = new NativeImeSettings(core);
        media = new NativeImeMedia(data);
        predictions = new NativeImePrediction(data, media);
        rewrite = new NativeImeRewrite(data);
    }

    static String asset(Context context, String name) throws IOException {
        try (InputStream stream = context.getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192];
            int count;
            while ((count = stream.read(chunk)) != -1) buffer.write(chunk, 0, count);
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    Object call(String operation, Object value) {
        switch (operation) {
            case "core": return core;
            case "defaults": return obj(core, "defaults");
            case "hydrate": return settings.hydrate((JSONObject) value);
            case "deck": {
                JSONObject request = (JSONObject) value;
                if (layouts == null) layouts = new NativeImeLayout(data.load("layouts"), core);
                return layouts.deck(settings.hydrate(obj(request, "settings")), request.optString("mode"),
                        request.optString("shift"), request.optString("kana"));
            }
            case "preparePredictions": {
                JSONObject request = (JSONObject) value;
                predictions.prepare(settings.hydrate(obj(request, "settings")), request.optString("kana"), obj(request, "learned"));
                return null;
            }
            case "predictTail": return predictions.predict((String) value);
            case "compose": {
                JSONObject request = (JSONObject) value;
                return NativeImeHangul.compose(request.optString("tail"), request.optString("text"));
            }
            case "icon": return obj(data.load("icons"), (String) value);
            case "media": return data.load("media");
            case "emojiSearch": return media.search((String) value, 70);
            case "emojiModifier": {
                JSONObject request = (JSONObject) value;
                return media.emojiModifier(obj(request, "entry"), request.optString("skin"), request.optString("hair"));
            }
            case "emojiVariants": {
                JSONObject request = (JSONObject) value;
                return media.emojiVariants(obj(request, "entry"), request.optString("skin"));
            }
            case "recordHistory": return NativeImeMedia.recordHistory((JSONArray) value);
            case "togglePin": return NativeImeMedia.togglePin((JSONArray) value);
            case "themes": return arr(core, "themes");
            case "decorators": return arr(data.load("media"), "decorators");
            case "decorate": {
                JSONObject request = (JSONObject) value;
                return media.decorate(request.optString("id"), request.optString("text"));
            }
            case "math": return NativeImeMath.format((String) value);
            case "dateTime": return NativeImeMath.dateTime();
            case "languages": return arr(core, "languages");
            case "filterLanguages": {
                JSONArray request = (JSONArray) value;
                return filterLanguages(request.optString(0), request.optBoolean(1));
            }
            case "offlineRewrite": return rewrite.run((JSONArray) value);
            case "rewriteQuality": return NativeImeRewrite.quality((JSONArray) value);
            default: throw new IllegalArgumentException("Unknown keyboard operation " + operation);
        }
    }

    private JSONArray filterLanguages(String query, boolean includeAuto) {
        JSONArray languages = arr(core, "languages");
        JSONArray result = new JSONArray();
        String needle = lower(trim(query));
        for (int i = includeAuto ? 0 : 1; i < languages.length(); i++) {
            JSONObject language = languages.optJSONObject(i);
            if (needle.isEmpty() || lower(language.optString("label")).contains(needle)
                    || lower(language.optString("shortLabel")).contains(needle)
                    || lower(language.optString("native")).contains(needle)
                    || lower(language.optString("english")).contains(needle)
                    || lower(language.optString("code")).contains(needle)) result.put(language);
        }
        return result;
    }

    JSONObject object(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof JSONObject ? (JSONObject) result : new JSONObject();
    }

    JSONArray array(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof JSONArray ? (JSONArray) result : new JSONArray();
    }

    String text(String operation, Object value) {
        Object result = call(operation, value);
        return result instanceof String ? (String) result : "";
    }

    void releaseCaches(boolean lowMemory) {
        data.release("dialects");
        if (lowMemory) data.release("words", "media");
    }

    @Override public void close() { data.clear(); }
}
