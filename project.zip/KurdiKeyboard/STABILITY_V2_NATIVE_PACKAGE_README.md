# Stability V2 ZIP + native Android migration

## Compatibility
This ZIP contains exactly one root application folder, `KurdiKeyboard/`, with
all six files required by the existing GitHub-ZIP-Workflow Stability V2 validator.
The original React/Capacitor sources are preserved only for compatibility and
as historical source material. The latest native-only Android project is at
`KurdiKeyboard/native-android/` and is the build target when using the
companion `KurdiKeyboard_Native_build.yml` workflow.

## Important: the build workflow matters
The original `.github/workflows/build.yml` from the GitHub-ZIP-Workflow repo
validates this ZIP but then builds `npx cap add android` (WebView/Capacitor).
To produce a **native Android UI APK**, replace the repository-root
`.github/workflows/build.yml` with the companion native workflow supplied
alongside this ZIP. Upload this archive as `project.zip` at the GitHub repo
root. Do not upload `KurdiKeyboard_GitHub_Ready_Native.zip` *as* project.zip.

## Verification
The ZIP structure has been checked against the six-file Stability V2 check
and latest native static integrity script. This DOES NOT imply an APK was
compiled or that pixel-perfect UI, behavior, audio, AI, translations,
settings migration, or gesture equivalence have been device-tested.

## Native sources
`native-android/app/src/main/java/io/kurdikebord/app/`
`native-android/app/src/main/assets/native-ime/`
`native-android/validate_native_sources.py`
