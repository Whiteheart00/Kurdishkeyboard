package io.kurdikebord.app;

import static io.kurdikebord.app.ImeStateStore.json;
import static io.kurdikebord.app.ImeStateStore.put;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.regex.Pattern;

final class NativeImeKeyFaces {
    private static final Pattern DIGITS = Pattern.compile("[0-9٠-٩۰-۹]");
    private static final Pattern MARKS = Pattern.compile("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]");

    private NativeImeKeyFaces() {}

    static JSONObject deck(JSONObject settings, JSONObject theme, JSONObject language, String mode, String shift,
                           String kana, String direction, JSONArray rows) {
        double height = Math.max(110, Math.min(720, settings.optDouble("keyboardHeightPx")));
        double width = Math.max(72, Math.min(100, settings.optDouble("keyboardWidthPercent")));
        double scale = Math.max(.82, Math.min(1.48, (1 + (height / 248 - 1) * .65) * Math.max(.84, width / 100)));
        int font = (int) Math.round(16 * settings.optDouble("fontSizePercent") / 100 * scale);
        int icon = (int) Math.round(17 * settings.optDouble("iconSizePercent") / 100 * scale);
        boolean numbers = "characters".equals(mode) && rows.length() >= 6
                && ("always".equals(settings.optString("numberRowMode"))
                || "per_language".equals(settings.optString("numberRowMode")) && language.optBoolean("numberRow"));
        double hGap = Math.max(2, Math.round(settings.optDouble("keySpacingHorizontal", settings.optDouble("keySpacingPercent")) * 3.6 / 50) / 2d);
        double vGap = Math.max(3, Math.round(settings.optDouble("keySpacingVertical", settings.optDouble("keySpacingPercent")) * 6 / 100));
        boolean numeric = "numeric_advanced".equals(mode);
        String space = spaceLabel(settings, language, kana);
        JSONArray result = new JSONArray();
        for (int r = 0; r < rows.length(); r++) {
            JSONArray row = rows.optJSONArray(r);
            JSONArray keys = new JSONArray();
            boolean inset = "characters".equals(mode) && "ltr".equals(direction) && r < rows.length() - 1 && row.length() == 9;
            for (int c = 0; c < row.length(); c++) {
                JSONObject key = row.optJSONObject(c);
                inset &= "char".equals(key.optString("type", "char"));
                face(key, theme, settings, mode, shift, space, font, icon, scale, numbers && r == 0, r == rows.length() - 1);
                keys.put(key);
            }
            result.put(json("weight", numbers && r == 0 ? .76 : 1, "inset", inset ? 14 : 0, "keys", keys));
        }
        return json("theme", theme, "direction", direction, "lang", language, "width", width,
                "height", height + (numbers ? 30 : 0), "hGap", numeric ? Math.max(hGap, 6) : hGap,
                "vGap", numeric ? Math.max(vGap, 7) : vGap, "rows", result);
    }

    private static String spaceLabel(JSONObject settings, JSONObject language, String kana) {
        switch (settings.optString("spacebarLabelMode")) {
            case "none": return "";
            case "custom": return settings.optString("customSpacebarText");
            default:
                if ("kurdi_hybrid".equals(language.optString("characterLayoutId"))) {
                    return "kata".equals(kana) ? "Kurdî (Latînî)" : "کوردی";
                }
                String nativeName = language.optString("nativeName");
                return nativeName.isEmpty() ? "کوردی" : nativeName;
        }
    }

    private static void face(JSONObject key, JSONObject theme, JSONObject settings, String mode, String shift,
                             String space, int font, int iconSize, double scale, boolean topNumber, boolean last) {
        String type = key.optString("type", "char");
        boolean numeric = "numeric_advanced".equals(mode);
        boolean tatweel = key.optInt("code") == 1600;
        boolean punctuation = "comma".equals(type) || "period".equals(type);
        boolean digit = DIGITS.matcher(key.optString("primary").trim()).matches();
        String label = key.optString("primary");
        if ("space".equals(type)) label = space;
        else if (!"off".equals(shift) && !key.optString("shiftPrimary").isEmpty()) label = key.optString("shiftPrimary");
        String bg = theme.optString("keyBg");
        String color = theme.optString("keyText");
        String specialBg = theme.optString("specialKeyBg");
        String specialColor = theme.optString("specialKeyText");
        double borderWidth = theme.optDouble("keyBorderWidth", theme.optBoolean("hasKeyBorder") ? 1 : 0);
        String border = borderWidth > 0 ? borderWidth + "px solid " + theme.optString("keyBorder") : "none";
        if ("enter".equals(type)) {
            bg = theme.optString("enterBg");
            color = theme.optString("enterText");
            border = theme.optString("enterBorder").isEmpty() ? "none" : "1px solid " + theme.optString("enterBorder");
        } else if ("space".equals(type)) {
            bg = numeric ? specialBg : theme.optString("spaceBg");
            color = numeric ? theme.optString("accent") : fallback(theme, "spaceText", theme.optString("secondaryText"));
        } else if ("shift".equals(type)) {
            bg = "off".equals(shift) ? fallback(theme, "shiftBg", specialBg) : theme.optString("accent");
            color = "off".equals(shift) ? fallback(theme, "shiftText", specialColor) : theme.optString("enterText");
        } else if ("backspace".equals(type) || tatweel) {
            bg = fallback(theme, "backspaceBg", specialBg);
            color = fallback(theme, "backspaceText", specialColor);
        } else if (isMode(type)) {
            bg = fallback(theme, "symbolsBg", specialBg);
            color = numeric && "characters".equals(type) ? theme.optString("accent") : fallback(theme, "symbolsText", specialColor);
        } else if ("kana_toggle".equals(type)) {
            bg = theme.optString("accent");
            color = theme.optString("enterText");
        } else if (!"char".equals(type) && !punctuation) {
            bg = specialBg;
            color = specialColor;
        } else if (numeric && !digit) bg = specialBg;

        String trimmed = label.trim();
        boolean hint = settings.optBoolean("showSecondaryHints") && !numeric && !"phone".equals(mode) && !"phone2".equals(mode)
                && !tatweel && !punctuation && hintKey(type)
                && !(trimmed.length() == 1 && "؟،:,.".contains(trimmed));
        String secondary = hint ? NativeImeData.trim(key.optString("secondary")) : "";
        int length = hintLength(secondary);
        double hintSize = length <= 2 ? 10.5 : length <= 4 ? 10.3 : length <= 7 ? 9.4 : length <= 10 ? 8.6 : length <= 12 ? 8 : 7.2;
        double size;
        if ("space".equals(type)) size = Math.round(13 * Math.min(1.28, scale));
        else if (numeric && "characters".equals(type)) size = label.length() > 6 ? 11 : 12.5;
        else if (numeric && digit) size = Math.round(font * 1.18);
        else if (numeric && !last) size = Math.round(font * 1.14);
        else if (numeric && "symbols".equals(type)) size = Math.max(13, font - 3);
        else if ((isMode(type) && !"phone".equals(type) && !"phone2".equals(type))
                || "kana_toggle".equals(type)) size = Math.max(12, font - 4);
        else if ("period".equals(type)) size = Math.max(22, font + 2);
        else if (topNumber) size = Math.max(15, font - 3);
        else size = label.length() > 2 ? Math.max(12, font - 4) : font;

        String icon = null;
        int extra = 0;
        if (tatweel) { icon = "ic_drezh"; extra = 6; }
        else switch (type) {
            case "shift": icon = "caps".equals(shift) ? "ic_shift_lock" : "ic_shift"; extra = 2; break;
            case "backspace": icon = "ic_delete"; extra = 3; break;
            case "enter": icon = numeric ? "corner_down_left" : "ic_enter"; extra = numeric ? 2 : 3; break;
            case "emoji": icon = "ic_smile"; extra = 2; break;
            case "globe": icon = "ic_global"; extra = 2; break;
            case "settings": icon = "ic_settings"; extra = 1; break;
            case "copy": icon = "ic_copy"; break;
            case "cut": icon = "ic_cuts"; break;
            case "paste": icon = "ic_pastes"; break;
            case "select_all": icon = "ic_select_all"; break;
            case "zwnj": icon = "ic_zwnj"; extra = 1; break;
            case "space": if (numeric) icon = "number_space"; break;
            default: break;
        }
        put(key, "label", label);
        put(key, "color", color);
        put(key, "hint", secondary);
        put(key, "hintSize", hintSize);
        put(key, "size", size);
        put(key, "icon", icon);
        put(key, "iconSize", numeric && "space".equals(type) ? 22 : iconSize + extra);
        put(key, "labelOffset", !secondary.isEmpty() ? Math.round((length > 2 ? 8 : 6) * scale)
                : "period".equals(type) && !numeric ? -2 : 0);
        String shape = settings.optString("keyShapeStyle");
        put(key, "face", shape(shape, theme, bg, border, "enter".equals(type), false));
        put(key, "pressed", shape(shape, theme, bg, border, "enter".equals(type), true));
    }

    static int hintLength(String text) {
        return MARKS.matcher(text).replaceAll("").length();
    }

    private static boolean isMode(String type) {
        switch (type) {
            case "symbols": case "symbols2": case "characters": case "numeric_advanced": case "phone": case "phone2": return true;
            default: return false;
        }
    }

    private static boolean hintKey(String type) {
        switch (type) {
            case "space": case "enter": case "backspace": case "shift": case "emoji": case "globe": return false;
            default: return true;
        }
    }

    private static JSONObject shape(String shape, JSONObject theme, String bg, String border, boolean enter, boolean pressed) {
        boolean light = theme.optBoolean("isLight");
        String hover = theme.optString("keyHoverBg");
        String accent = theme.optString("accent");
        if (pressed) bg = hover;
        double radius = theme.optDouble("borderRadius", 8);
        switch (shape) {
            case "flat": radius = Math.min(radius, 6); border = "none"; break;
            case "three_dimensional":
                radius = Math.max(radius, 8);
                if ("none".equals(border)) border = "1px solid " + (light ? "rgba(15,23,42,0.14)" : "rgba(255,255,255,0.12)");
                break;
            case "pill_rounded": radius = 9999; break;
            case "glass_crystal":
                radius = Math.max(radius, 10);
                if (!enter) bg = light ? "rgba(255,255,255,0.58)" : "rgba(255,255,255,0.09)";
                border = "1px solid " + (light ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.22)");
                break;
            case "outline_only":
                if (!enter) {
                    bg = pressed ? accent + "22" : "transparent";
                    border = "1.5px solid " + (theme.optBoolean("hasKeyBorder") ? theme.optString("keyBorder") : accent + "88");
                }
                break;
            case "borderless": if (!enter) bg = pressed ? hover : "transparent"; border = "none"; break;
            case "soft_neumorphic": radius = Math.max(radius, 11); border = "none"; break;
            case "animated_glow": radius = Math.max(radius, 9); border = "1px solid " + accent + "99"; break;
            default: radius = Math.max(radius, 9);
        }
        return json("backgroundColor", bg, "borderRadius", radius + "px", "border", border);
    }

    private static String fallback(JSONObject theme, String key, String other) {
        String value = theme.optString(key);
        return value.isEmpty() ? other : value;
    }
}
