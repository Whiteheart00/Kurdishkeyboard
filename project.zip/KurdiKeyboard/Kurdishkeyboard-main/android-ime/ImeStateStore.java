package io.kurdikebord.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.UserManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Iterator;
import java.util.Set;

/** Credential-protected shared keyboard state. The editor's text is never stored here. */
final class ImeStateStore {
    static final String PREFS = "kurdi_native_ime_v1";
    static final String STATE = "state";
    private static final int VERSION = 1;
    private static final int MAX_BYTES = 16 * 1024 * 1024;
    private static final ExecutorService learnedWriter = Executors.newSingleThreadExecutor(
            task -> new Thread(task, "ime-learned-words"));

    static boolean enabled(Context context) { return context.getResources().getBoolean(R.bool.native_ime_preview); }
    static boolean unlocked(Context context) {
        if (android.os.Build.VERSION.SDK_INT < 24) return true;
        UserManager users = context.getSystemService(UserManager.class);
        return users == null || users.isUserUnlocked();
    }

    static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized JSONObject read(Context context) {
        return parseState(rawState(context));
    }

    static String rawState(Context context) {
        return unlocked(context) ? preferences(context).getString(STATE, "") : "";
    }

    static JSONObject parseState(String raw) {
        JSONObject state = parse(raw);
        return state.optInt("version") == VERSION ? state : new JSONObject();
    }

    static void saveLearnedWords(Context context, Map<String, Integer> increments) {
        Context application = context.getApplicationContext();
        learnedWriter.execute(() -> addLearnedWords(application, increments));
    }

    private static synchronized void addLearnedWords(Context context, Map<String, Integer> increments) {
        if (!unlocked(context)) return;
        JSONObject state = read(context);
        JSONObject words = state.optJSONObject("learned");
        if (words == null) words = new JSONObject();
        mergeLearnedWords(words, increments);
        put(state, "version", VERSION);
        put(state, "learned", words);
        write(context, state);
    }

    static void mergeLearnedWords(JSONObject words, Map<String, Integer> increments) {
        for (Map.Entry<String, Integer> entry : increments.entrySet()) {
            String word = entry.getKey();
            put(words, word, Math.min(Integer.MAX_VALUE, (long) words.optInt(word) + entry.getValue()));
        }
        if (words.length() <= 400) return;
        List<String> ordered = new ArrayList<>();
        Iterator<String> keys = words.keys();
        while (keys.hasNext()) ordered.add(keys.next());
        java.util.Collections.sort(ordered, (a, b) -> Integer.compare(words.optInt(a), words.optInt(b)));
        for (int i = 0; i < ordered.size() - 400; i++) words.remove(ordered.get(i));
    }

    static synchronized JSONObject snapshot(Context context) {
        JSONObject state = read(context);
        if (state.has("version") && !state.optBoolean("legacyImported")) {
            put(state, "settings", effectiveSettings(context, state));
        }
        return state;
    }

    static JSONObject effectiveSettings(Context context, JSONObject state) {
        JSONObject stored = state.optJSONObject("settings");
        if (state.optBoolean("legacyImported") || state.optBoolean("replaceSettings")) {
            return stored == null ? new JSONObject() : stored;
        }
        JSONObject recovered = parse(NativeSettingsBackup.read(context));
        if (stored != null) copyEntries(stored, recovered);
        return recovered;
    }

    static synchronized boolean importLegacy(Context context, String raw) {
        if (!unlocked(context) || raw == null || raw.length() > MAX_BYTES) return false;
        JSONObject pending = read(context);
        if (pending.optBoolean("legacyImported")) return true;
        try {
            JSONObject old = new JSONObject(raw);
            JSONObject state = json("version", VERSION, "legacyImported", true);
            copy(old, state, "settings", JSONObject.class);
            copy(old, state, "sourceLanguage", String.class);
            copy(old, state, "targetLanguage", String.class);
            copy(pending, state, "sourceLanguage", String.class);
            copy(pending, state, "targetLanguage", String.class);
            JSONObject overrides = pending.optJSONObject("settings");
            if (overrides != null) mergeSettings(state, overrides, pending.optBoolean("replaceSettings"));

            JSONArray clipboard = pending.optJSONArray("clipboard");
            JSONArray oldClipboard = old.optJSONArray("clipboard");
            if (clipboard != null || oldClipboard != null) {
                put(state, "clipboard", pending.optBoolean("replaceClipboard") ? clipboard : mergeClipboard(clipboard, oldClipboard, pending));
            }
            JSONObject learned = old.optJSONObject("learned");
            JSONObject newer = pending.optJSONObject("learned");
            if (newer != null) {
                if (learned == null) learned = new JSONObject();
                Iterator<String> words = newer.keys();
                while (words.hasNext()) {
                    String word = words.next();
                    put(learned, word, Math.min(Integer.MAX_VALUE, (long) learned.optInt(word) + newer.optInt(word)));
                }
            }
            put(state, "learned", learned);
            return write(context, state);
        } catch (JSONException e) {
            return false;
        }
    }

    private static JSONArray mergeClipboard(JSONArray current, JSONArray old, JSONObject pending) {
        JSONArray result = new JSONArray();
        Set<String> seenText = new HashSet<>();
        Set<String> currentIds = new HashSet<>();
        for (int i = 0; current != null && i < current.length(); i++) {
            JSONObject item = current.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("id");
            if (!id.isEmpty()) currentIds.add(id);
            if (seenText.add(item.optString("text"))) result.put(item);
        }
        JSONObject removed = pending.optJSONObject("clipboardRemovedIds");
        for (int i = 0; old != null && i < old.length(); i++) {
            JSONObject item = old.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("id");
            if (currentIds.contains(id) || removed != null && removed.optBoolean(id)) continue;
            if (pending.optBoolean("clipboardClearedUnpinned") && !item.optBoolean("pinned")) continue;
            if (seenText.add(item.optString("text"))) result.put(item);
        }
        return result;
    }

    static synchronized void updateClipboard(Context context, JSONArray clipboard, Set<String> removedIds, boolean clearUnpinned) {
        if (!unlocked(context)) return;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        put(state, "clipboard", clipboard);
        if (!state.optBoolean("legacyImported") && !state.optBoolean("replaceClipboard")) {
            if (!removedIds.isEmpty()) {
                JSONObject removed = state.optJSONObject("clipboardRemovedIds");
                if (removed == null) removed = new JSONObject();
                for (String id : removedIds) put(removed, id, true);
                put(state, "clipboardRemovedIds", removed);
            }
            if (clearUnpinned) put(state, "clipboardClearedUnpinned", true);
        }
        write(context, state);
    }

    static synchronized JSONObject updateSettings(Context context, JSONObject values, boolean replace) {
        if (!unlocked(context)) return null;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        if (replace && !state.optBoolean("legacyImported")) put(state, "replaceSettings", true);
        mergeSettings(state, values, replace);
        return write(context, state) ? effectiveSettings(context, state) : null;
    }

    private static JSONObject mergeSettings(JSONObject state, JSONObject values, boolean replace) {
        JSONObject settings = replace ? null : state.optJSONObject("settings");
        if (settings == null) settings = new JSONObject();
        copyEntries(values, settings);
        put(state, "settings", settings);
        return settings;
    }

    private static void copyEntries(JSONObject values, JSONObject target) {
        Iterator<String> keys = values.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            put(target, key, values.opt(key));
        }
    }

    static synchronized void set(Context context, String key, Object value) {
        set(context, key, value, false);
    }

    static synchronized void set(Context context, String key, Object value, boolean replaceClipboard) {
        if (!unlocked(context)) return;
        JSONObject state = read(context);
        put(state, "version", VERSION);
        if (replaceClipboard && !state.optBoolean("legacyImported")) put(state, "replaceClipboard", true);
        put(state, key, value);
        write(context, state);
    }

    private static boolean write(Context context, JSONObject state) {
        String raw = state.toString();
        if (raw.length() > MAX_BYTES) return false;
        SharedPreferences prefs = preferences(context);
        if (!raw.equals(prefs.getString(STATE, ""))) prefs.edit().putString(STATE, raw).apply();
        return true;
    }

    private static void copy(JSONObject from, JSONObject to, String key, Class<?> type) throws JSONException {
        Object value = from.opt(key);
        if (type.isInstance(value)) to.put(key, value);
    }

    static JSONObject parse(String raw) {
        try { return new JSONObject(raw); } catch (JSONException | NullPointerException e) { return new JSONObject(); }
    }

    static JSONObject json(Object... pairs) {
        JSONObject json = new JSONObject();
        for (int i = 0; i < pairs.length; i += 2) put(json, (String) pairs[i], pairs[i + 1]);
        return json;
    }

    static void put(JSONObject json, String key, Object value) {
        try { json.put(key, value); } catch (JSONException e) { throw new IllegalArgumentException(key, e); }
    }
}
