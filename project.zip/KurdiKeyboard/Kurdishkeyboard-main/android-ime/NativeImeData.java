package io.kurdikebord.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/** Reads shared keyboard assets generated at build time. Each asset is decoded on first use. */
final class NativeImeData {
    private final Context context;
    private final Map<String, JSONObject> assets = new HashMap<>();

    NativeImeData(Context context) { this.context = context.getApplicationContext(); }

    JSONObject load(String name) {
        JSONObject existing = assets.get(name);
        if (existing != null) return existing;
        try {
            JSONObject result = new JSONObject(NativeImeEngine.asset(context, "native-ime/" + name + ".json"));
            assets.put(name, result);
            return result;
        } catch (IOException | JSONException error) {
            throw new IllegalStateException("Cannot read keyboard asset " + name, error);
        }
    }

    void clear() { assets.clear(); }

    /** Drops parsed assets; load() reads them again when next needed. */
    void release(String... names) { for (String name : names) assets.remove(name); }

    static JSONObject obj(JSONObject source, String key) {
        JSONObject child = source == null ? null : source.optJSONObject(key);
        return child == null ? new JSONObject() : child;
    }

    static JSONArray arr(JSONObject source, String key) {
        JSONArray array = source == null ? null : source.optJSONArray(key);
        return array == null ? new JSONArray() : array;
    }

    static JSONObject copy(JSONObject source) {
        JSONObject result = new JSONObject();
        merge(result, source);
        return result;
    }

    static void merge(JSONObject target, JSONObject source) {
        if (source == null) return;
        Iterator<String> keys = source.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            ImeStateStore.put(target, key, source.opt(key));
        }
    }

    static boolean contains(JSONArray values, String value) {
        for (int i = 0; i < values.length(); i++) if (value.equals(values.optString(i))) return true;
        return false;
    }

    static JSONObject find(JSONArray values, String key, String value) {
        for (int i = 0; i < values.length(); i++) {
            JSONObject row = values.optJSONObject(i);
            if (row != null && value.equals(row.optString(key))) return row;
        }
        return null;
    }

    static String lower(String value) { return value.toLowerCase(Locale.ROOT); }

    static String trim(String value) {
        // A plain loop: this runs for every dictionary word on each language switch.
        int start = 0, end = value.length();
        while (start < end && blank(value.charAt(start))) start++;
        while (end > start && blank(value.charAt(end - 1))) end--;
        return value.substring(start, end);
    }

    private static boolean blank(char c) {
        return c == ' ' || c >= 9 && c <= 13 || c == 0xFEFF || Character.isSpaceChar(c);
    }
}
