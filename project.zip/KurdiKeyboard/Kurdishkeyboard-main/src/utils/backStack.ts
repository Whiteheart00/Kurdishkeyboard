import { useEffect, useRef } from 'react';

// Open sheets and dialogs register here so the Android back button closes the newest one first.
const handlers: Array<{ current: () => void }> = [];

export function useBackHandler(active: boolean, close: () => void) {
  const latest = useRef(close);
  latest.current = close;
  useEffect(() => {
    if (!active) return;
    handlers.push(latest);
    return () => {
      const index = handlers.indexOf(latest);
      if (index >= 0) handlers.splice(index, 1);
    };
  }, [active]);
}

export function runBackHandler(): boolean {
  const top = handlers[handlers.length - 1];
  if (!top) return false;
  top.current();
  return true;
}
