// Compiled to JSON by the Android build. The phone loads data, not JavaScript.
import { DEFAULT_SETTINGS, INITIAL_CLIPBOARD } from '../data/defaultSettings';
import { ALL_SUBTYPE_PRESETS, CHARACTER_LAYOUT_OPTIONS, EMAIL_DOMAIN_POPUP_OPTIONS, getEditableAlphaRows } from '../data/layouts';
import { ALL_SWIPE_ACTIONS, ARABIC_HARAKAT_OPTIONS, SPACEBAR_CUSTOM_MENU_OPTIONS } from '../data/gestures';
import { ALL_THEMES } from '../data/themes';
import { ARABIC_COMMON_WORDS, ENGLISH_COMMON_WORDS, ENGLISH_NEXT_WORDS, KURDISH_NEXT_WORDS,
  KURDISH_SORANI_WORDS, PERSIAN_COMMON_WORDS, TURKISH_COMMON_WORDS } from '../data/dictionaries';
import { EMOJI_CATEGORIES, EMOJI_KEYWORD_MAP, EMOJI_NAME_LOOKUP, EMOJI_SKIN_TONES, EMOJI_HAIR_STYLES,
  KAOMOJI_LIST, TEXT_DECORATORS, ZIKR_CATEGORIES } from '../data/richContent';
import { AUTO_DETECT_LANG, TRANSLATION_LANGUAGES } from '../data/translationLanguages';
import { MISSING_FACEBOOK_BASE_CODES } from '../data/emojiVisuals';
import { SOUND_PACKS } from '../utils/sound';
import { OFFLINE_DIALECTS } from '../utils/kurdishSmartHelper';
import layouts from '../data/generated/layoutsBundle.json';
import icons from '../data/generated/vectorIcons.json';
import strings from '../data/generated/officialStrings.json';

const ascii = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'];
export const nativeData = {
  core: {
    defaults: { settings: DEFAULT_SETTINGS, clipboard: INITIAL_CLIPBOARD, sounds: SOUND_PACKS,
      email: EMAIL_DOMAIN_POPUP_OPTIONS, harakat: ARABIC_HARAKAT_OPTIONS, spaceMenu: SPACEBAR_CUSTOM_MENU_OPTIONS },
    themes: ALL_THEMES,
    subtypes: ALL_SUBTYPE_PRESETS,
    swipeActions: ALL_SWIPE_ACTIONS,
    languages: [AUTO_DETECT_LANG, ...TRANSLATION_LANGUAGES],
    characterLayouts: CHARACTER_LAYOUT_OPTIONS,
    editableRows: Object.fromEntries(CHARACTER_LAYOUT_OPTIONS.map(({ id }) => [id, getEditableAlphaRows(id)])),
  },
  layouts,
  dialects: OFFLINE_DIALECTS,
  icons,
  strings,
  media: {
    categories: EMOJI_CATEGORIES, kaomoji: KAOMOJI_LIST, zikr: ZIKR_CATEGORIES,
    skinTones: EMOJI_SKIN_TONES, hairStyles: EMOJI_HAIR_STYLES, missingFacebook: MISSING_FACEBOOK_BASE_CODES,
    keywords: EMOJI_KEYWORD_MAP,
    names: EMOJI_NAME_LOOKUP,
    decorators: TEXT_DECORATORS.map(({ id, nameKu, preview }) => ({ id, label: nameKu, sample: preview })),
    decorationMaps: Object.fromEntries(TEXT_DECORATORS.filter(({ id }) => id.endsWith('_en')).map(({ id, transform }) =>
      [id, Object.fromEntries(ascii.map(char => [char, transform(char)]))])),
  },
  words: {
    ar: ARABIC_COMMON_WORDS, fa: PERSIAN_COMMON_WORDS, tr: TURKISH_COMMON_WORDS,
    en: ENGLISH_COMMON_WORDS, ckb: KURDISH_SORANI_WORDS,
    nextEnglish: ENGLISH_NEXT_WORDS, nextKurdish: KURDISH_NEXT_WORDS,
  },
};
