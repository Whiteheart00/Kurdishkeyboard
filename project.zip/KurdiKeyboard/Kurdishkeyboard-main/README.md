# تەختەکلیلی کوردی — KurdiKeyboard (Android APK & Web)

پرۆژەی تەواوی **تەختەکلیلی کوردی (KurdiKeyboard)** ئامادەکراوە بۆ دروستکردنی خۆکاری **APK** لە ڕێگەی **GitHub Actions**.

## چۆنیەتی دروستکردنی APK لە GitHub (تەنها ٣ هەنگاو)

1. لە هەژماری GitHubـی خۆتدا **Repository**ـیەکی نوێ دروست بکە و هەموو فایلەکانی ئەم پرۆژەیە (یان فایلی `.zip` پاش کردنەوەی) بەرز بکەرەوە (Push / Upload) بۆ برانچی `main`.
2. بچۆ سەر بەشی **Actions** لە GitHub — وۆرکفلۆی **Build KurdiKeyboard Android APK** خۆکارانە دەستپێدەکات (دەشتوانیت دەستی کلیک لە **Run workflow** بکەیت).
3. پاش ٢ تا ٣ خولەک، بچۆ سەر کارە تەواوبووەکە و لە خوارەوە لە بەشی **Artifacts** کلیک لە **`KurdiKeyboard-APK`** بکە بۆ داگرتنی فایلی **`KurdiKeyboard-debug.apk`**.

## چالاککردنی کیبۆردەکە لەسەر مۆبایلی ئەندرۆید
پاش دامەزراندنی APK لەسەر مۆبایلەکەت:
- بچۆ **Settings → System → Languages & input → On-screen keyboard → Manage on-screen keyboards**
- **تەختەکلیلی کوردی** چالاک بکە و وەک کیبۆردی سەرەکی هەڵیبژێرە.
- خزمەتگوزاری کیبۆردەکە پشتگیری `directBootAware="true"` دەکات بۆ کارکردن پاش ڕیستارتی مۆبایل.
## Native Android IME

Android builds use the Java IME and Android Views for the system keyboard, including suggestions and tools. The build generates JSON data for layouts, themes, and dictionaries. The companion settings still use Capacitor. The keyboard test box uses a native Android editor.

Run **Build KurdiKeyboard and deploy Vercel from ZIP** manually with `native_ime_preview` checked to build the `KurdiKeyboard-Native-Preview-APK` artifact without publishing it. For a local build, sync the web bundle and run `node scripts/setup-android-ime.mjs`. Both build paths use the existing application ID and signing configuration.
