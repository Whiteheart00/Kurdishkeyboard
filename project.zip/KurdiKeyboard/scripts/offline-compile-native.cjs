// Pure build-time Node.js+TypeScript transpilation, no React runtime.
// Falls back to TypeScript installed with npm; use scripts/generate-native-android.mjs in CI.
const fs = require('fs');
const path = require('path');
const Module = require('module');
const ts = require('typescript');
Module._extensions['.ts'] = function(mod,filename) {
  const source=fs.readFileSync(filename,'utf8');
  const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true,resolveJsonModule:true}}).outputText;
  mod._compile(js,filename);
};
const data=require(path.resolve('src/native-ime/data.ts')).nativeData;
for(const [name,value] of Object.entries(data)) {
  let folder='native-android/app/src/main/assets/native-ime'; fs.mkdirSync(folder,{recursive:true});
  fs.writeFileSync(path.join(folder,name+'.json'),JSON.stringify(value));
  console.log(name, Buffer.byteLength(JSON.stringify(value)));
}
