// Build-time only: convert the existing TypeScript data sources to JSON and WAV assets.
// There is NO JavaScript engine, React bundle, WebView, or Capacitor inside the native APK.
import fs from 'node:fs/promises';
import path from 'node:path';
import { buildNativeImeData, buildNativeImeSounds } from './build-native-ime.mjs';
const root=process.cwd();
const target=path.join(root,'native-android','app','src','main','assets','native-ime');
await fs.mkdir(target,{recursive:true});
await buildNativeImeData(target);
await buildNativeImeSounds(target);
const javaSource=path.join(root,'android-ime');
const javaTarget=path.join(root,'native-android','app','src','main','java','io','kurdikebord','app');
await fs.mkdir(javaTarget,{recursive:true});
for (const name of (await fs.readdir(javaSource)).filter(n=>n.endsWith('.java') && n!=='ImeLegacyMigration.java')) {
  await fs.copyFile(path.join(javaSource,name),path.join(javaTarget,name));
}
console.log('Native Android Java sources and JSON/WAV assets prepared (no web bundle).');
