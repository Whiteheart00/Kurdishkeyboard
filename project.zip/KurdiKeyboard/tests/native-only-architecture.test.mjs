import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const java=fs.readFileSync('android-ime/MainActivity.java','utf8');
const ime=fs.readFileSync('android-ime/KurdiKeyboardImeService.java','utf8');
const layout=fs.readFileSync('android-ime/NativeImeLayout.java','utf8');
const data=fs.readFileSync('src/native-ime/data.ts','utf8');
test('launcher is Android native (not BridgeActivity)',()=>{
  assert.match(java,/class MainActivity extends Activity/);
  assert.doesNotMatch(java,/new WebView|BridgeActivity|bridge\.getWebView|evaluateJavascript/);
});
test('IME input view launches native rendering',()=>{
  const start=ime.indexOf('public View onCreateInputView()');
  const body=ime.slice(start,ime.indexOf('private void createNativeKeyboard()',start));
  assert.match(body,/createNativeKeyboard\(\)/);
  assert.doesNotMatch(body,/attachWebView\(\)/);
});
test('custom editor persists characters and symbol layouts used by IME',()=>{
  assert.match(java,/currentMode\+":"\+layoutId\(\)/);
  assert.match(layout,/resolver\.mode \+ ":" \+ id/);
  assert.match(data,/editableSymbols:/);
});

test('standalone native APK assets do not contain JavaScript or HTML',()=>{
 const dir='native-android/app/src/main/assets/native-ime';
 assert.ok(fs.existsSync(dir+'/core.json'));
 assert.ok(fs.existsSync(dir+'/layouts.json'));
 const core=JSON.parse(fs.readFileSync(dir+'/core.json','utf8'));
 assert.ok(core.editableRows.kurdi_qvfgh);
 assert.ok(core.editableSymbols.symbols.sym_alt);
 assert.ok(core.editableSymbols.symbols2.sym_alt);
 assert.equal(core.defaults.settings.spaceBarSwipeLeftAction,'move_cursor_left');
 assert.equal(core.defaults.settings.spaceBarSwipeRightAction,'move_cursor_right');
 assert.equal(fs.readdirSync(dir).some(n=>/\.(js|html)$/.test(n)),false);
});
test('native standalone launcher and service staged correctly',()=>{
 const project='native-android/app/src/main/java/io/kurdikebord/app/';
 assert.equal(fs.readFileSync(project+'MainActivity.java','utf8'),java);
 assert.equal(fs.readFileSync(project+'KurdiKeyboardImeService.java','utf8'),ime);
 assert.equal(fs.existsSync(project+'ImeLegacyMigration.java'),false);
});
