# Native Android migration — design fidelity pass

## Implemented
- Standalone Android Java `InputMethodService` and Android-Views keyboard, with no packaged WebView/React/HTML resources.
- Original keyboard layout JSON assets, icon vectors, key hint data and rich media data retained; custom font binaries are not included.
- Native keyboard theme defaults to **rukar_amber_dark** for new installs, matching the black keys, orange small labels, and orange Enter key in the user-provided screenshots. Existing user settings are not overwritten.
- Native settings page navigation reorganized to follow original `HomeScreen.tsx`: two-by-two blue category tiles and grouped settings cards, using its dark surface palette.
- Native Custom Layout Editor includes characters and symbols layers, palette and manual custom symbol input, tap-to-swap, Android drag-and-drop, save/reset and an explanatory help dialog.
- The existing native Smartbar, emoji, clipboard, suggestions, touch, Spacebar cursor gesture, and language switching code is included.

## Limitations / not verified
- No APK has been compiled or installed on a real Android device or emulator in this environment. Android SDK/Gradle are not available.
- Native behavior and visuals have not been proven pixel-for-pixel or 100% feature-equivalent to the original React/WebView implementation. In particular the native settings screens and some special tools still differ.
- Speech, AI and online translation depend on device permissions / external services and have not been live-tested.
- Original WebView LocalStorage settings are not automatically transferable on every device. Native SharedPreferences storage is used.
- A design and behavior reference is in `DESIGN_REFERENCE.md`; no actual Android device screenshots or user screenshots are packaged.

## Build
Open the folder in Android Studio with Android SDK Platform 35 and JDK 17; sync Gradle, then build the debug APK. Test keyboard activation, both language layouts, drag+hold, emoji, and settings against the included references.
