# Visual and behavioral reference (from the original project and user screenshots)

The screenshot target has a dark keyboard: keyboard background near `#0A0B0D`, key faces `#1B1C20`, white key glyphs, orange secondary hints `#F2A34B`, orange Enter key `#FF6D00`, and rounded ~10px key corners. This palette exists in the original project as the `rukar_amber_dark` theme. The original Settings app uses dark `#121316` surfaces and blue category tiles (`#084D88` to `#063A69`).

## Visible features to keep
- Ten positions in the top letter row, large primary keys, small hint text in orange, no permanent separate number row on the Kurdish Sorani subtype; English may enable the number row via per-language setting.
- Top toolbar: selection, copy, left cursor, microphone, right cursor, cut and paste; suggestion strip with tool icons and predicted words.
- Bottom row: symbols switcher, punctuation, globe language switcher, language-labeled Spacebar and arrows, emoji, period and orange Enter.
- Long press hints, popup alternates, cursor dragging on Spacebar, gestures and language toggling.
- Custom layout editor for Characters (symbols can replace letters), Symbols 1, Symbols 2, save, reset, custom input and drag/drop.

## Fidelity status
This reference is a design target, NOT a certificate of pixel-exact rendering. A real APK build and visual comparison are still required.
