# KurdiKeyboard - Native Android (Java + Android Views)

This is an Android Studio project containing a native InputMethodService and native Views-based keyboard and Settings UI. The project does **not** package React, Chromium, a web bundle, or a JavaScript runtime.

## Build
- Install JDK 17 and Android SDK Platform 35.
- Open this folder in Android Studio, sync Gradle and build `:app:assembleDebug`.
- Enable the keyboard in Android settings, then select it using the system input-method picker.

## Preservation and compatibility
- Core keyboard layout assets are copied from the supplied source project, including character layouts, numbers, symbol layers, emoji/media data, and built-in themes.
- Original font selections are supported by the native font loader, but custom font binaries are not bundled in this delivery. The original vector icon collection is retained in `assets/native-ime/icons.json`.
- Native typing screen defaults to the existing original `rukar_amber_dark` theme to resemble the supplied black/orange screenshot. The user can still change themes in Settings. Existing SharedPreferences are not overwritten.
- Native launcher home follows original React Settings home hierarchy (category grid and grouped settings cards), not the illustrative blue mockup.
- Native custom-layout editor supports Characters, Symbols 1/2, drag/drop and tap swap, symbols in Characters, save/reset.
- Cursor dragging, long press, suggestions, media, emoji and clipboard use native Java code.

**IMPORTANT**: This is an implementation / fidelity pass, not a guarantee of perfect visual and functional equivalence. Some React feature panels have not been ported 1:1. There is no verified Android APK build or device screenshot from this environment. See MIGRATION_STATUS.md for detailed limitations.
