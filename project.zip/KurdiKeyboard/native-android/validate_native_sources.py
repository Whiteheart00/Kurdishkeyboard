#!/usr/bin/env python3
"""Static, source-level integrity checks only. Does not build an APK."""
from pathlib import Path
import json, re, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
APP=ROOT/'app/src/main'
SRC=APP/'java/io/kurdikebord/app'
A=APP/'assets/native-ime'
errors=[]
def check(ok,label):
 print(('PASS' if ok else 'FAIL')+'  '+label)
 if not ok: errors.append(label)

check((SRC/'KurdiKeyboardImeService.java').exists(),'Java InputMethodService source exists')
check((SRC/'NativeImeView.java').exists(),'Native keyboard Android View exists')
check((SRC/'NativeImeKeyGrid.java').exists(),'Native touch grid exists')
check((SRC/'MainActivity.java').exists(),'Native Android settings Activity exists')
main=(SRC/'MainActivity.java').read_text()
service=(SRC/'KurdiKeyboardImeService.java').read_text()
keys=(SRC/'NativeImeKeyGrid.java').read_text()
layout=(SRC/'NativeImeLayout.java').read_text()
view=(SRC/'NativeImeView.java').read_text()
check('public View onCreateInputView()' in service and 'createNativeKeyboard();' in service[service.index('public View onCreateInputView()'):service.index('private void createNativeKeyboard()')], 'IME creates native keyboard in input-view startup path')
check('new WebView' not in main and 'extends Activity' in main,'Settings launcher is Java Views, not WebView')
check(all(s in main for s in ['startDragAndDrop(', 'ACTION_DROP', 'currentMode+":"+layoutId()', 'Symbols', 'پیتەکان']), 'Native custom editor has 3 modes, drag/drop and persistence')
check(all(s in keys for s in ['"space".equals(type)','keyboard.moveCursor(', 'keyHold(', 'keyTap(']), 'Native touch/spacebar key code present')
check('customLayouts' in layout and 'editableSymbols' in (SRC/'MainActivity.java').read_text(),'Native layout resolves user overrides')
check('addToolbar();' in view and 'addSuggestions();' in view and 'openPanel(' in view,'Native toolbar and suggestions exist')
check('new WebView' not in main and 'evaluateJavascript' not in main,'No JS rendering in settings launcher')
check(not any(f.suffix.lower() in ('.js','.tsx','.ts','.html') for f in APP.rglob('*') if f.is_file()),'APK app sources/assets have no JS/React/HTML files')
check(not any(f.suffix.lower() in ('.ttf','.otf') for f in ROOT.rglob('*') if f.is_file()),'No font binaries redistributed')
core=json.loads((A/'core.json').read_text())
layouts=json.loads((A/'layouts.json').read_text())
icons=json.loads((A/'icons.json').read_text())
settings=core['defaults']['settings']
check(settings['activeThemeId']=='rukar_amber_dark' and any(t['id']=='rukar_amber_dark' for t in core['themes']),'Screenshot-matching original dark/orange theme is default')
check(settings['spaceBarSwipeLeftAction']=='move_cursor_left' and settings['spaceBarSwipeRightAction']=='move_cursor_right','Spacebar cursor actions preserved')
check(all(k in layouts['layouts'] for k in ('characters','symbols','symbols2')), 'Original 3 layout families retained')
check(all(k in core.get('editableSymbols',{}) for k in ('symbols','symbols2')), 'Editable Symbols 1+2 retained')
check(all(k in icons for k in ('ic_language','ic_themes','ic_keyboards','ic_xanda','ic_keyboard_keys','ic_clipboards')),'Original settings vector icon IDs retained')
manifest=ET.parse(APP/'AndroidManifest.xml').getroot()
ANDROID='{http://schemas.android.com/apk/res/android}'
check(any(e.attrib.get(ANDROID+'name','').endswith('KurdiKeyboardImeService') for e in manifest.iter('service')),'InputMethodService registered in Android manifest')
check((A/'words.json').exists() and (A/'media.json').exists(),'Word and media assets present')
print('\nStatic checks:', 20-len(errors),'/',20) if len(errors)<=20 else None
if errors:
 print('FAILURES:',errors)
 sys.exit(1)
print('All static checks passed. IMPORTANT: APK compilation/device behavior NOT verified.')
