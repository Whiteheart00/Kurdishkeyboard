# KurdiKeyboard — Native Android Migration

## What is in this release

The **active APK project** is `native-android/`, a plain Java / Android Views Android Studio project. It does not build a Vite bundle, run React, create a Capacitor BridgeActivity, or call WebView to show the keyboard or settings.

- **Native IME:** `KurdiKeyboardImeService` now always constructs `NativeImeView` in `onCreateInputView()` / input-session callbacks. The previous WebView path remains as unreachable legacy code in the original Java service source; it is not launched in this native build.
- **Native keyboard:** `NativeImeView`, `NativeImeKeyGrid`, `NativeImeLayout`, `NativeImePanels`, `NativeImeMediaPanel`, `NativeImeClipboardPanel`, `NativeImeWritingPanels` and `NativeImeEngine` perform key display, touch/gesture handling, toolbar, clipboard, emoji, AI/translation panels and text editing through Android APIs.
- **Native settings app:** `MainActivity extends android.app.Activity`, uses Android Views only; no JS bridge. Includes setup, test textbox, native themes/languages, category screens and a searchable editor for all settings contained in native defaults.
- **Custom Layout Editor:** Native Java panel for Characters, Symbols 1 and Symbols 2, with language switching, tap-two-keys swap, symbol/letter palette, custom text, reset and save. Edits go into `settings.customLayouts`. `NativeImeLayout.java` applies symbol overrides to the actual keyboard (as it already did for characters).
- **Spacebar:** Native key enlarged/lifted slightly, and default sideways dragging actions move the text cursor. Existing custom gesture preferences take precedence over new defaults.
- **Native data:** `native-android/app/src/main/assets/native-ime/` contains all JSON layout, word, emoji, icon, theme and settings data, plus short WAV fallback tones. Native runtime reads these JSON files, not TypeScript.
- **Native Android Gradle project:** `native-android/settings.gradle`, `build.gradle`, manifest, Java sources, resources, icon and assets are included; no Node or web dependencies are needed to build it.

## Building the APK

Open `native-android/` in Android Studio and let Android Studio sync Gradle; install Android SDK Platform 35. Use **Build > Build APK(s)**. The debug output will be under `native-android/app/build/outputs/apk/debug/app-debug.apk` after a successful build. You can also run the GitHub Actions workflow `.github/workflows/build-apk.yml`, which builds the Java Android project directly.

The debug signing keystore matches the one supplied with the original project. Do not use debug signing for a public production release.

## Compatibility and limitations

- This is a native-source migration, **not a verified working APK**. Android SDK / emulator are not available in the current execution environment. Build, install, launch, input-method selection, and end-to-end interaction must be tested on a real Android device or Android emulator.
- The previous React, Capacitor, and TypeScript files are retained in the full project as **reference/build-data sources only**, not packaged into the standalone native app. `native-android/` is the deployable project.
- The original IME Java service retains unreachable legacy WebView methods and compatibility bridge code. This source cleanup is not fully complete; no production path in the new launcher or input service creates a WebView.
- Some previous WebView-specific preference screens and integrations have a generic native editor rather than identical bespoke UI. Third-party services (online translation, voice, emoji downloads) can require internet, microphone permission, or other apps. Full feature parity has **not** been proven.
- The old LocalStorage-to-native migration uses WebView and is deliberately **not bundled**. Settings already saved in shared native preferences or recovery mirror are reused; unmirrored browser LocalStorage will not be imported automatically.
- Source-derived preview PNG is an **illustration**, not a device screenshot.

## Main source changes

`android-ime/MainActivity.java`, `KurdiKeyboardImeService.java`, `NativeImeEngine.java`, `NativeImeLayout.java`, `NativeImeKeyGrid.java`, `src/native-ime/data.ts`, `src/data/defaultSettings.ts` and `native-android/` were updated or created. Java classes and native JSON assets are duplicated in `native-android/` intentionally so the Android Studio project is self-contained. 

## Checks performed

- `node --test tests/native-only-architecture.test.mjs` (3 tests passed).
- All native JSON assets were generated, and settings + symbol maps inspected.
- Native AndroidManifest.xml parsed successfully as XML.
- Not compiled with Gradle, and not tested on an emulator or phone.
